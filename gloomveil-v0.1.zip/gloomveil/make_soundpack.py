#!/usr/bin/env python3
"""Builds the Gloomveil sound resource pack (.mcpack) from the .ogg files in sounds_in/."""
import json, os, re, shutil, sys, zipfile, uuid

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "sounds_in")
OUT_DIR = os.path.join(HERE, "build", "sound-pack")
OUT = os.path.join(HERE, "build", "Gloomveil-sounds.mcpack")

def ogg(folder):
    d = os.path.join(SRC, folder)
    if not os.path.isdir(d):
        return []
    return sorted(f for f in os.listdir(d) if f.lower().endswith(".ogg"))

menu, game = ogg("menu"), ogg("game")
if not menu and not game:
    print("No .ogg files in sounds_in/menu or sounds_in/game - sound pack skipped.")
    sys.exit(0)

shutil.rmtree(OUT_DIR, ignore_errors=True)
os.makedirs(os.path.join(OUT_DIR, "sounds", "music", "menu"))
os.makedirs(os.path.join(OUT_DIR, "sounds", "music", "game"))

def clean(n):
    return re.sub(r"[^A-Za-z0-9_]", "_", os.path.splitext(n)[0]).lower()

defs = {}
def add(event, folder, files, vol):
    entries = []
    for f in files:
        name = clean(f)
        shutil.copy(os.path.join(SRC, folder, f), os.path.join(OUT_DIR, "sounds", "music", folder, name + ".ogg"))
        entries.append({"name": f"sounds/music/{folder}/{name}", "stream": True, "volume": vol})
    defs[event] = {"category": "music", "sounds": entries}

if menu:
    add("music.menu", "menu", menu, 0.7)
if game:
    add("music.game", "game", game, 0.6)
    add("music.game.creative", "game", game, 0.6)

with open(os.path.join(OUT_DIR, "sounds", "sound_definitions.json"), "w") as f:
    json.dump({"format_version": "1.14.0", "sound_definitions": defs}, f, indent=2)

music = {}
if menu:
    music["menu"] = {"event_name": "music.menu", "max_delay": 0, "min_delay": 0}
if game:
    music["game"] = {"event_name": "music.game", "max_delay": 240, "min_delay": 90}
    music["creative"] = {"event_name": "music.game.creative", "max_delay": 240, "min_delay": 90}
with open(os.path.join(OUT_DIR, "sounds", "music_definitions.json"), "w") as f:
    json.dump(music, f, indent=2)

manifest = {
    "format_version": 2,
    "header": {
        "name": "Gloomveil Sounds",
        "description": "Dark ambient music for Gloomveil",
        "uuid": "3f0a6d9e-5b1c-4c7a-8d2e-71b94c0a5e11",
        "version": [0, 1, 0],
        "min_engine_version": [1, 21, 0],
    },
    "modules": [{
        "type": "resources",
        "uuid": "a8c2e4b7-90d1-4f36-b5a9-2c7d1e8f4a60",
        "version": [0, 1, 0],
    }],
}
with open(os.path.join(OUT_DIR, "manifest.json"), "w") as f:
    json.dump(manifest, f, indent=2)

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(OUT_DIR):
        for fn in files:
            p = os.path.join(root, fn)
            z.write(p, os.path.relpath(p, OUT_DIR))
print("Built", OUT)
