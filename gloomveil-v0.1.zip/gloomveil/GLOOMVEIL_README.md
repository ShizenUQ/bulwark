# Gloomveil v0.1 (dark fantasy shader for Minecraft Bedrock)

Based on Newb Shader by devendrn (MIT, https://github.com/devendrn/newb-x-mcbe).
Built for personal use. Do not redistribute the compiled pack (see COPYRIGHT.txt inside the pack).

Needs a patched Minecraft that loads shaders (MBL "Minecraft (Patch)" or Draco "DracoPatch").
Target: Minecraft Bedrock 26.60+.

## What changed from Newb
- Dark, desaturated colours with cold shadows and warm torch light
- Very dark nights: sky light and game brightness are almost removed (NL_NIGHT_AMBIENT in src/newb/config.h)
- Morning fog: thick low fog from dawn to mid-morning, strength varies over real time (NL_MORNING_FOG*)
- Torches are stronger, warmer and flicker
- Rainbow, aurora, shooting stars off (cheaper on a low-end phone)
- Quality choices in Minecraft's pack settings: Low / Medium (default) / High

## Easy tweaks (src/newb/config.h)
- Night too dark? raise NL_NIGHT_AMBIENT (0.06 -> 0.15) or NL_NIGHT_MOONLIGHT_COL
- Fog too thick / too rare? change NL_MORNING_FOG and NL_MORNING_FOG_RANDOM
- Fog shows in the evening instead of morning? remove the // in front of NL_MORNING_IS_LOW_TIME
- Brighter overall? raise NL_GAMMA slowly (1.45 -> 1.6) or NL_MIN_LIGHTING_BOOST

## Sound pack
Put .ogg files in sounds_in/menu and sounds_in/game, then build.
Output: Gloomveil-sounds.mcpack (replaces menu and in-game music).
