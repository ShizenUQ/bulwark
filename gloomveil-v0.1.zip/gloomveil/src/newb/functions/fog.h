#ifndef FOG_H
#define FOG_H

float nlRenderFogFade(float relativeDist, vec3 FOG_COLOR, vec2 FOG_CONTROL) {
  #ifdef NL_FOG
    float fade = smoothstep(FOG_CONTROL.x, FOG_CONTROL.y, relativeDist);

    // misty effect
    float density = NL_MIST_DENSITY*(19.0 - 18.0*FOG_COLOR.g);
    fade += (1.0-fade)*(0.3-0.3*exp(-relativeDist*relativeDist*density));

    return NL_FOG * fade;
  #else
    return 0.0;
  #endif
}

// Gloomveil: strength of morning fog [0,1]. Only active between dawn and mid-morning,
// and varies slowly over real time so each morning feels different.
float nlMorningFogAmount(float dayFactor, float timeOfDay, highp float t, float rain) {
  #ifdef NL_MORNING_FOG
    #ifdef NL_MORNING_IS_LOW_TIME
      float isMorning = step(timeOfDay, 0.5);
    #else
      float isMorning = step(0.5, timeOfDay);
    #endif
    float window = smoothstep(-0.3, 0.0, dayFactor)*(1.0 - smoothstep(0.3, 0.85, dayFactor));
    // slow random value, changes about every 20 real minutes
    float r = fract(sin(floor(t*0.00083)*91.7)*43758.5) ;
    float r2 = fract(sin((floor(t*0.00083)+1.0)*91.7)*43758.5);
    float f = fract(t*0.00083);
    f = f*f*(3.0-2.0*f);
    float rnd = mix(r, r2, f);
    float amount = mix(1.0, 0.25 + 1.1*rnd, NL_MORNING_FOG_RANDOM);
    return clamp(NL_MORNING_FOG*isMorning*window*amount*(1.0 - 0.5*rain), 0.0, 1.0);
  #else
    return 0.0;
  #endif
}

// Extra fog thickness added by morning fog (relativeDist is 0 near, 1 at render edge)
float nlMorningFogFade(float relativeDist, float amount, float worldY) {
  // thicker low to the ground, thinner high up
  float height = 1.0 - smoothstep(-8.0, 70.0, worldY);
  float d = relativeDist*(1.5 + 3.5*amount);
  float fade = 1.0 - exp(-d*d*(0.6 + 2.5*amount)*(0.5 + 0.5*height));
  return clamp(fade*amount*1.6, 0.0, 0.92);
}

float nlRenderGodRayIntensity(vec3 cPos, vec3 worldPos, float t, vec2 uv1, float relativeDist, vec3 FOG_COLOR) {
  // offset wPos (only works upto 16 blocks)
  vec3 offset = cPos - 16.0*fract(worldPos*0.0625);
  offset = abs(2.0*fract(offset*0.0625)-1.0);
  offset = offset*offset*(3.0-2.0*offset);
  //offset = 0.5 + 0.5*cos(offset*0.392699082);

  //vec3 ofPos = wPos+offset;
  vec3 nrmof = normalize(worldPos);

  float u = nrmof.z/length(nrmof.zy);
  float diff = dot(offset,vec3(0.1,0.2,1.0)) + 0.07*t;
  float mask = nrmof.x*nrmof.x;

  float vol = sin(7.0*u + 1.5*diff)*sin(3.0*u + diff);
  vol *= vol*mask*uv1.y*(1.0-mask*mask);
  vol *= relativeDist*relativeDist;

  // dawn/dusk mask
  vol *= clamp(3.0*(FOG_COLOR.r-FOG_COLOR.b), 0.0, 1.0);

  vol = smoothstep(0.0, 0.1, vol);
  return vol;
}

#endif
