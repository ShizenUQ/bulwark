Put your .ogg music files here (royalty-free / CC0 / your own):

  sounds_in/menu/   -> plays on the main menu
  sounds_in/game/   -> plays while playing (survival and creative)

File names: letters, numbers and underscores only (example: dark_forest_1.ogg).
Then build again. If both folders are empty, no sound pack is made.
