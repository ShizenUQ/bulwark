package com.custom.engine.terrain

import com.custom.engine.math.Vector3
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sqrt

enum class SculptMode { RAISE, LOWER, SMOOTH }

class SculptEngine {

    var brushRadius = 4f
    var brushStrength = 0.2f
    var sculptMode = SculptMode.RAISE

    /**
     * Deforms the vertices under the brush, then recomputes their normals and marks the changed rows
     * dirty so the next frame uploads only that slice.
     */
    fun applySculpt(hitPoint: Vector3, terrain: TerrainMesh) {
        val r = brushRadius
        val sp = terrain.spacing
        val minX = floor((hitPoint.x - r - terrain.originX) / sp).toInt().coerceAtLeast(0)
        val maxX = ceil((hitPoint.x + r - terrain.originX) / sp).toInt().coerceAtMost(terrain.gridWidth)
        val minZ = floor((hitPoint.z - r - terrain.originZ) / sp).toInt().coerceAtLeast(0)
        val maxZ = ceil((hitPoint.z + r - terrain.originZ) / sp).toInt().coerceAtMost(terrain.gridDepth)
        if (minX > maxX || minZ > maxZ) return

        val width = maxX - minX + 1
        // SMOOTH reads neighbours that may also be changing, so compute targets first, then apply.
        val smoothed = if (sculptMode == SculptMode.SMOOTH) FloatArray(width * (maxZ - minZ + 1)) else null

        for (z in minZ..maxZ) {
            for (x in minX..maxX) {
                val dx = terrain.originX + x * sp - hitPoint.x
                val dz = terrain.originZ + z * sp - hitPoint.z
                val dist = sqrt(dx * dx + dz * dz)
                if (dist >= r) continue

                // Cosine falloff: 1 at the centre, 0 at the rim, with a zero-slope edge.
                val falloff = 0.5f * (1f + cos(PI.toFloat() * dist / r))
                val h = terrain.getHeight(x, z)

                when (sculptMode) {
                    SculptMode.RAISE -> terrain.setHeight(x, z, h + brushStrength * falloff)
                    SculptMode.LOWER -> terrain.setHeight(x, z, h - brushStrength * falloff)
                    SculptMode.SMOOTH -> {
                        val blend = (brushStrength * 2.5f * falloff).coerceAtMost(1f)
                        smoothed!![(z - minZ) * width + (x - minX)] = h + (neighbourAverage(terrain, x, z) - h) * blend
                    }
                }
            }
        }

        if (smoothed != null) {
            for (z in minZ..maxZ) {
                for (x in minX..maxX) {
                    val dx = terrain.originX + x * sp - hitPoint.x
                    val dz = terrain.originZ + z * sp - hitPoint.z
                    if (dx * dx + dz * dz < r * r) {
                        terrain.setHeight(x, z, smoothed[(z - minZ) * width + (x - minX)])
                    }
                }
            }
        }

        terrain.recalcNormals(minX, minZ, maxX, maxZ)
    }

    private fun neighbourAverage(terrain: TerrainMesh, x: Int, z: Int): Float {
        var sum = 0f
        var count = 0
        for (nz in (z - 1).coerceAtLeast(0)..(z + 1).coerceAtMost(terrain.gridDepth)) {
            for (nx in (x - 1).coerceAtLeast(0)..(x + 1).coerceAtMost(terrain.gridWidth)) {
                sum += terrain.getHeight(nx, nz)
                count++
            }
        }
        return sum / count
    }
}
