package com.custom.engine.math

import kotlin.math.sqrt

/** Minimal immutable 3D vector. */
data class Vector3(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f) {

    operator fun plus(o: Vector3) = Vector3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vector3) = Vector3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = Vector3(x * s, y * s, z * s)

    fun dot(o: Vector3): Float = x * o.x + y * o.y + z * o.z

    fun cross(o: Vector3) = Vector3(
        y * o.z - z * o.y,
        z * o.x - x * o.z,
        x * o.y - y * o.x
    )

    fun length(): Float = sqrt(x * x + y * y + z * z)

    /** Returns the zero vector when the length is ~0 instead of producing NaNs. */
    fun normalized(): Vector3 {
        val len = length()
        return if (len < 1e-8f) Vector3() else Vector3(x / len, y / len, z / len)
    }
}
