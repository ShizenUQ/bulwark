package com.custom.engine.terrain

import android.opengl.GLES30
import com.custom.engine.graphics.ShaderProgram
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.floor
import kotlin.math.sqrt

/**
 * Deformable heightfield grid in the XZ plane, centred on the world origin.
 *
 * Interleaved vertex layout (9 floats): position(3) normal(3) colour(3).
 * The CPU-side [vertexBuffer] is the single source of truth for heights, so the
 * terrain survives an EGL context loss: [initGl] simply re-uploads it.
 *
 * Threading: everything here runs on the GL thread (sculpting, height queries,
 * rendering), so no locking is needed.
 */
class TerrainMesh(val gridWidth: Int = 64, val gridDepth: Int = 64) {

    val vertsX = gridWidth + 1
    val vertsZ = gridDepth + 1
    val spacing = 1f
    val originX = -gridWidth * spacing / 2f
    val originZ = -gridDepth * spacing / 2f

    private val vertexCount = vertsX * vertsZ
    private val indexCount = gridWidth * gridDepth * 6

    private val vertexBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(vertexCount * STRIDE_FLOATS * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val indexBuffer: ShortBuffer = ByteBuffer
        .allocateDirect(indexCount * 2)
        .order(ByteOrder.nativeOrder()).asShortBuffer()

    private var vao = 0
    private var vbo = 0
    private var ibo = 0
    private var shader: ShaderProgram? = null

    // Range of vertex rows (Z) changed since the last upload.
    private var dirtyMinRow = Int.MAX_VALUE
    private var dirtyMaxRow = -1

    private val normalScratch = FloatArray(3)

    init {
        for (z in 0 until vertsZ) {
            for (x in 0 until vertsX) {
                val base = (z * vertsX + x) * STRIDE_FLOATS
                vertexBuffer.put(base, originX + x * spacing)
                vertexBuffer.put(base + 1, 0f)
                vertexBuffer.put(base + 2, originZ + z * spacing)
                vertexBuffer.put(base + 3, 0f)
                vertexBuffer.put(base + 4, 1f)
                vertexBuffer.put(base + 5, 0f)
                vertexBuffer.put(base + 6, GRASS_R)
                vertexBuffer.put(base + 7, GRASS_G)
                vertexBuffer.put(base + 8, GRASS_B)
            }
        }
        // Two CCW triangles per quad, seen from above (+Y).
        for (z in 0 until gridDepth) {
            for (x in 0 until gridWidth) {
                val i0 = z * vertsX + x
                val i1 = i0 + 1
                val i2 = i0 + vertsX
                val i3 = i2 + 1
                indexBuffer.put(i0.toShort()); indexBuffer.put(i2.toShort()); indexBuffer.put(i1.toShort())
                indexBuffer.put(i1.toShort()); indexBuffer.put(i2.toShort()); indexBuffer.put(i3.toShort())
            }
        }
        indexBuffer.position(0)
    }

    /** Creates the GL objects. Call from onSurfaceCreated (again after every context loss). */
    fun initGl(program: ShaderProgram) {
        shader = program
        val ids = IntArray(3)
        GLES30.glGenVertexArrays(1, ids, 0)
        GLES30.glGenBuffers(2, ids, 1)
        vao = ids[0]; vbo = ids[1]; ibo = ids[2]

        GLES30.glBindVertexArray(vao)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        vertexBuffer.position(0)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER, vertexCount * STRIDE_FLOATS * 4,
            vertexBuffer, GLES30.GL_DYNAMIC_DRAW
        )

        // The element buffer binding is part of the VAO state.
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        indexBuffer.position(0)
        GLES30.glBufferData(
            GLES30.GL_ELEMENT_ARRAY_BUFFER, indexCount * 2,
            indexBuffer, GLES30.GL_STATIC_DRAW
        )

        val stride = STRIDE_FLOATS * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 3 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, stride, 6 * 4)

        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

        dirtyMinRow = Int.MAX_VALUE
        dirtyMaxRow = -1
        ShaderProgram.checkGlError("TerrainMesh.initGl")
    }

    fun render(mvpMatrix: FloatArray, modelMatrix: FloatArray) {
        val program = shader ?: return
        program.use()
        program.setMat4("u_MVPMatrix", mvpMatrix)
        program.setMat4("u_ModelMatrix", modelMatrix)
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_SHORT, 0)
        GLES30.glBindVertexArray(0)
    }

    // ---------------------------------------------------------------- heights

    fun getHeight(ix: Int, iz: Int): Float =
        vertexBuffer.get((iz * vertsX + ix) * STRIDE_FLOATS + 1)

    fun setHeight(ix: Int, iz: Int, height: Float) {
        vertexBuffer.put((iz * vertsX + ix) * STRIDE_FLOATS + 1, height.coerceIn(MIN_HEIGHT, MAX_HEIGHT))
    }

    fun contains(x: Float, z: Float): Boolean =
        x >= originX && x <= originX + gridWidth * spacing &&
            z >= originZ && z <= originZ + gridDepth * spacing

    /** Bilinearly interpolated surface height; positions outside the grid are clamped to its edge. */
    fun getHeightAt(x: Float, z: Float): Float {
        val gx = ((x - originX) / spacing).coerceIn(0f, gridWidth.toFloat())
        val gz = ((z - originZ) / spacing).coerceIn(0f, gridDepth.toFloat())
        val ix = floor(gx).toInt().coerceAtMost(gridWidth - 1)
        val iz = floor(gz).toInt().coerceAtMost(gridDepth - 1)
        val fx = gx - ix
        val fz = gz - iz
        val h00 = getHeight(ix, iz)
        val h10 = getHeight(ix + 1, iz)
        val h01 = getHeight(ix, iz + 1)
        val h11 = getHeight(ix + 1, iz + 1)
        val top = h00 + (h10 - h00) * fx
        val bottom = h01 + (h11 - h01) * fx
        return top + (bottom - top) * fz
    }

    // ---------------------------------------------------------------- normals

    /**
     * Recomputes normals for the given vertex rectangle plus a one-vertex border
     * (a vertex's normal depends on its neighbours' heights), and marks those rows dirty.
     */
    fun recalcNormals(minX: Int, minZ: Int, maxX: Int, maxZ: Int) {
        val x0 = (minX - 1).coerceAtLeast(0)
        val z0 = (minZ - 1).coerceAtLeast(0)
        val x1 = (maxX + 1).coerceAtMost(gridWidth)
        val z1 = (maxZ + 1).coerceAtMost(gridDepth)
        for (z in z0..z1) {
            for (x in x0..x1) {
                computeNormal(x, z, normalScratch)
                val base = (z * vertsX + x) * STRIDE_FLOATS
                vertexBuffer.put(base + 3, normalScratch[0])
                vertexBuffer.put(base + 4, normalScratch[1])
                vertexBuffer.put(base + 5, normalScratch[2])
            }
        }
        markRowsDirty(z0, z1)
    }

    /** Sum of the cross products of the (up to four) triangle corners around the vertex. */
    private fun computeNormal(ix: Int, iz: Int, out: FloatArray) {
        val h = getHeight(ix, iz)
        val hasE = ix < gridWidth
        val hasW = ix > 0
        val hasS = iz < gridDepth
        val hasN = iz > 0
        val dE = if (hasE) getHeight(ix + 1, iz) - h else 0f
        val dW = if (hasW) getHeight(ix - 1, iz) - h else 0f
        val dS = if (hasS) getHeight(ix, iz + 1) - h else 0f
        val dN = if (hasN) getHeight(ix, iz - 1) - h else 0f
        val s = spacing

        out[0] = 0f; out[1] = 0f; out[2] = 0f
        // Edge vectors: e=(s,dE,0)  s=(0,dS,s)  w=(-s,dW,0)  n=(0,dN,-s)
        if (hasS && hasE) accumulateCross(out, 0f, dS, s, s, dE, 0f)
        if (hasW && hasS) accumulateCross(out, -s, dW, 0f, 0f, dS, s)
        if (hasN && hasW) accumulateCross(out, 0f, dN, -s, -s, dW, 0f)
        if (hasE && hasN) accumulateCross(out, s, dE, 0f, 0f, dN, -s)

        val len = sqrt(out[0] * out[0] + out[1] * out[1] + out[2] * out[2])
        if (len < 1e-8f) {
            out[0] = 0f; out[1] = 1f; out[2] = 0f
        } else {
            out[0] /= len; out[1] /= len; out[2] /= len
        }
    }

    private fun accumulateCross(
        acc: FloatArray,
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float
    ) {
        acc[0] += ay * bz - az * by
        acc[1] += az * bx - ax * bz
        acc[2] += ax * by - ay * bx
    }

    // ---------------------------------------------------------------- uploads

    fun markRowsDirty(minRow: Int, maxRow: Int) {
        if (minRow < dirtyMinRow) dirtyMinRow = minRow
        if (maxRow > dirtyMaxRow) dirtyMaxRow = maxRow
    }

    /** Uploads only the changed rows with glBufferSubData. No-op if nothing changed. */
    fun uploadDirty() {
        if (dirtyMaxRow < 0 || vbo == 0) return
        val rowFloats = vertsX * STRIDE_FLOATS
        val startFloat = dirtyMinRow * rowFloats
        val floatCount = (dirtyMaxRow - dirtyMinRow + 1) * rowFloats

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        vertexBuffer.position(startFloat)
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, startFloat * 4, floatCount * 4, vertexBuffer)
        vertexBuffer.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

        dirtyMinRow = Int.MAX_VALUE
        dirtyMaxRow = -1
    }

    companion object {
        const val STRIDE_FLOATS = 9
        const val MIN_HEIGHT = -20f
        const val MAX_HEIGHT = 40f
        private const val GRASS_R = 0.2f
        private const val GRASS_G = 0.65f
        private const val GRASS_B = 0.2f
    }
}
