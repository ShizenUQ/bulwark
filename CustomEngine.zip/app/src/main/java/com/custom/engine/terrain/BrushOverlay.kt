package com.custom.engine.terrain

import android.opengl.GLES30
import com.custom.engine.graphics.ShaderProgram
import com.custom.engine.math.Vector3
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * A thin ribbon ring draped over the terrain at the brush position. Drawn as a triangle strip rather
 * than GL_LINES because line widths above 1px aren't guaranteed on ES 3.0 devices.
 */
class BrushOverlay(private val segments: Int = 64) {

    private val vertexCount = (segments + 1) * 2
    private val data = FloatArray(vertexCount * 3)
    private val buffer: FloatBuffer = ByteBuffer.allocateDirect(data.size * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer()

    private var vao = 0
    private var vbo = 0

    fun initGl() {
        val ids = IntArray(2)
        GLES30.glGenVertexArrays(1, ids, 0)
        GLES30.glGenBuffers(1, ids, 1)
        vao = ids[0]; vbo = ids[1]

        GLES30.glBindVertexArray(vao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        buffer.position(0)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.size * 4, buffer, GLES30.GL_DYNAMIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    /** Rebuilds the ring so every point sits on the current terrain surface. */
    fun update(center: Vector3, radius: Float, terrain: TerrainMesh) {
        val inner = (radius - HALF_WIDTH).coerceAtLeast(0f)
        val outer = radius + HALF_WIDTH
        var i = 0
        for (s in 0..segments) {
            val angle = (2.0 * PI * s / segments).toFloat()
            val c = cos(angle)
            val sn = sin(angle)
            for (edge in 0..1) {
                val rad = if (edge == 0) inner else outer
                val x = center.x + c * rad
                val z = center.z + sn * rad
                data[i++] = x
                data[i++] = terrain.getHeightAt(x, z) + LIFT
                data[i++] = z
            }
        }
        buffer.position(0)
        buffer.put(data)
        buffer.position(0)

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, data.size * 4, buffer)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    /** The unlit line shader must already be in use with its uniforms set. */
    fun draw() {
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        GLES30.glPolygonOffset(-1f, -1f)

        GLES30.glBindVertexArray(vao)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, vertexCount)
        GLES30.glBindVertexArray(0)

        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        ShaderProgram.checkGlError("BrushOverlay.draw")
    }

    private companion object {
        const val HALF_WIDTH = 0.08f
        const val LIFT = 0.1f
    }
}
