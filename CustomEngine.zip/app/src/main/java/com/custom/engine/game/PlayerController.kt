package com.custom.engine.game

import com.custom.engine.terrain.TerrainMesh
import kotlin.math.sqrt

/** A sphere that walks over the terrain. Runs on the GL thread. */
class PlayerController {

    var x = 0f
        private set
    var y = 0f
        private set
    var z = 0f
        private set

    val radius = 0.5f
    private val playerHeightOffset = radius   // sphere centre sits one radius above the ground
    private val speed = 6f                    // world units per second at full stick

    fun place(px: Float, pz: Float, terrain: TerrainMesh) {
        x = clampX(px, terrain)
        z = clampZ(pz, terrain)
        stickToGround(terrain)
    }

    /**
     * [camForwardX]/[camForwardZ] is the camera's view direction (any length); the stick is
     * interpreted relative to it so "up" always walks away from the camera.
     * [joystickY] is positive when the stick is pushed up.
     */
    fun update(
        joystickX: Float,
        joystickY: Float,
        terrain: TerrainMesh,
        camForwardX: Float,
        camForwardZ: Float,
        dt: Float
    ) {
        val fLen = sqrt(camForwardX * camForwardX + camForwardZ * camForwardZ)
        if (fLen > 1e-5f && (joystickX != 0f || joystickY != 0f)) {
            val fx = camForwardX / fLen
            val fz = camForwardZ / fLen
            // right = forward x up, flattened onto XZ
            val rx = -fz
            val rz = fx

            var mx = rx * joystickX + fx * joystickY
            var mz = rz * joystickX + fz * joystickY
            val mLen = sqrt(mx * mx + mz * mz)
            if (mLen > 1f) { mx /= mLen; mz /= mLen }

            x = clampX(x + mx * speed * dt, terrain)
            z = clampZ(z + mz * speed * dt, terrain)
        }
        stickToGround(terrain)
    }

    /** Bilinear ground query, so the player rides smoothly over sculpted hills. */
    fun stickToGround(terrain: TerrainMesh) {
        y = terrain.getHeightAt(x, z) + playerHeightOffset
    }

    private fun clampX(v: Float, t: TerrainMesh) =
        v.coerceIn(t.originX + radius, t.originX + t.gridWidth * t.spacing - radius)

    private fun clampZ(v: Float, t: TerrainMesh) =
        v.coerceIn(t.originZ + radius, t.originZ + t.gridDepth * t.spacing - radius)
}
