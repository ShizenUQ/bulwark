package com.custom.engine.core

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.custom.engine.game.PlayerController
import com.custom.engine.graphics.Camera3D
import com.custom.engine.graphics.ShaderProgram
import com.custom.engine.graphics.Shaders
import com.custom.engine.graphics.SphereMesh
import com.custom.engine.math.RaycastUtil
import com.custom.engine.math.Vector3
import com.custom.engine.terrain.BrushOverlay
import com.custom.engine.terrain.SculptEngine
import com.custom.engine.terrain.TerrainMesh
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * GL-thread renderer and owner of the world. Terrain, sculpting, raycasting and the player all run
 * on the GL thread; the UI thread talks to it through GLSurfaceView.queueEvent and volatile fields.
 *
 * The terrain and player live outside onSurfaceCreated so they keep their data across an EGL
 * context loss; only GL objects are rebuilt there.
 */
class EngineRenderer(
    private val camera: Camera3D,
    private val state: StateManager
) : GLSurfaceView.Renderer {

    private var litShader: ShaderProgram? = null
    private var lineShader: ShaderProgram? = null
    private var sphere: SphereMesh? = null
    private var brush: BrushOverlay? = null

    private val terrain = TerrainMesh(64, 64)
    private val sculpt = SculptEngine()
    private val player = PlayerController()

    private var playerSpawned = false
    private var brushPoint: Vector3? = null
    private var lastMode = Mode.EDIT
    private var lastNanos = 0L

    private var viewWidth = 1
    private var viewHeight = 1
    private var aspect = 1f

    @Volatile var joystickX = 0f
    @Volatile var joystickY = 0f

    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val viewProj = FloatArray(16)
    private val eye = FloatArray(3)
    private val lightPos = floatArrayOf(40f, 80f, 30f)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.45f, 0.65f, 0.90f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glFrontFace(GLES30.GL_CCW)
        GLES30.glCullFace(GLES30.GL_BACK)

        val lit = ShaderProgram(Shaders.VERTEX, Shaders.FRAGMENT)
        litShader = lit
        lineShader = ShaderProgram(Shaders.LINE_VERTEX, Shaders.LINE_FRAGMENT)
        terrain.initGl(lit)
        sphere = SphereMesh(16, 24, floatArrayOf(0.95f, 0.55f, 0.15f))
        brush = BrushOverlay().also { it.initGl() }
        lastNanos = 0L
        ShaderProgram.checkGlError("onSurfaceCreated")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        viewWidth = width
        viewHeight = height.coerceAtLeast(1)
        aspect = width.toFloat() / viewHeight
        camera.viewportHeight = height.toFloat()
    }

    override fun onDrawFrame(gl: GL10?) {
        val lit = litShader ?: return
        val line = lineShader ?: return

        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0f else ((now - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = now

        updateWorld(dt)

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // Camera methods lock on the camera; hold the same lock for a consistent snapshot.
        synchronized(camera) {
            camera.updateMatrices(aspect)
            System.arraycopy(camera.viewProjMatrix, 0, viewProj, 0, 16)
            System.arraycopy(camera.position, 0, eye, 0, 3)
        }

        lit.use()
        lit.setVec3("u_LightPos", lightPos[0], lightPos[1], lightPos[2])
        lit.setVec3("u_CameraPos", eye[0], eye[1], eye[2])

        Matrix.multiplyMM(mvpMatrix, 0, viewProj, 0, identity, 0)
        terrain.render(mvpMatrix, identity)

        if (playerSpawned) drawPlayer(lit)

        val point = brushPoint
        if (point != null && state.mode == Mode.EDIT && state.tool == EditTool.SCULPT) {
            brush?.let {
                it.update(point, sculpt.brushRadius, terrain)
                line.use()
                line.setMat4("u_MVPMatrix", viewProj)
                line.setVec4("u_Color", 1f, 0.95f, 0.3f, 1f)
                it.draw()
            }
        }
    }

    private fun updateWorld(dt: Float) {
        val mode = state.mode
        if (mode != lastMode) {
            if (mode == Mode.PLAY) enterPlayMode()
            lastMode = mode
        }

        if (mode == Mode.PLAY && playerSpawned) {
            var fx = 0f
            var fz = 0f
            synchronized(camera) {
                fx = camera.target[0] - camera.position[0]
                fz = camera.target[2] - camera.position[2]
            }
            player.update(joystickX, joystickY, terrain, fx, fz, dt)
            camera.follow(player.x, player.y, player.z, dt)
        } else if (playerSpawned) {
            // Terrain may have been sculpted under the parked player.
            player.stickToGround(terrain)
        }

        terrain.uploadDirty()
    }

    /** Drops the character at the spot the camera is looking at and frames it third-person. */
    private fun enterPlayMode() {
        var tx = 0f
        var tz = 0f
        synchronized(camera) {
            tx = camera.target[0]
            tz = camera.target[2]
        }
        player.place(tx, tz, terrain)
        playerSpawned = true
        brushPoint = null
        camera.setFollowDefaults()
        camera.snapTo(player.x, player.y, player.z)
    }

    private fun drawPlayer(lit: ShaderProgram) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, player.x, player.y, player.z)
        Matrix.scaleM(modelMatrix, 0, player.radius, player.radius, player.radius)
        Matrix.multiplyMM(mvpMatrix, 0, viewProj, 0, modelMatrix, 0)
        lit.use()
        lit.setMat4("u_MVPMatrix", mvpMatrix)
        lit.setMat4("u_ModelMatrix", modelMatrix)
        sphere?.draw()
    }

    // ---- Called on the GL thread via GLSurfaceView.queueEvent ----

    /** Raycasts the touch onto the terrain, moves the brush ring there, and sculpts. */
    fun sculptTouch(x: Float, y: Float) {
        val ray = RaycastUtil.getRayFromScreen(
            x, y, viewWidth, viewHeight, camera.viewMatrix, camera.projMatrix
        )
        val hit = RaycastUtil.intersectTerrain(ray, terrain)
        brushPoint = hit
        if (hit != null && state.mode == Mode.EDIT) {
            sculpt.sculptMode = state.sculptMode
            sculpt.applySculpt(hit, terrain)
        }
    }

    fun hideBrush() {
        brushPoint = null
    }
}
