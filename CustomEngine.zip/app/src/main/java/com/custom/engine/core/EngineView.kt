package com.custom.engine.core

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.custom.engine.graphics.Camera3D

/**
 * GL surface plus touch handling.
 *
 * EDIT mode, Sculpt tool:  1 finger = sculpt | 2 fingers = pan + pinch zoom
 * EDIT mode, Orbit tool:   1 finger = orbit  | 2 fingers = pan + pinch zoom
 * PLAY mode:               1 finger = orbit  | pinch = zoom (the camera follows the player)
 *
 * Once a second finger touches during a sculpt stroke, the stroke ends and cannot resume until
 * all fingers lift, so a pinch never leaves a stray dent.
 */
class EngineView(context: Context) : GLSurfaceView(context) {

    val camera = Camera3D()
    val state = StateManager()
    private val engineRenderer = EngineRenderer(camera, state)

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                camera.zoom(detector.scaleFactor)
                return true
            }
        }
    )

    private var lastX = 0f
    private var lastY = 0f
    private var sculpting = false
    private var multiTouch = false

    init {
        // Order matters: version and config chooser must be set before setRenderer.
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        preserveEGLContextOnPause = true
        setRenderer(engineRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    /** Safe to call from the UI thread; the value is read by the GL thread each frame. */
    fun setJoystick(x: Float, y: Float) {
        engineRenderer.joystickX = x
        engineRenderer.joystickY = y
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        val mode = state.mode
        val sculptTool = mode == Mode.EDIT && state.tool == EditTool.SCULPT

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multiTouch = false
                setCentroid(event, -1)
                if (sculptTool) {
                    sculpting = true
                    queueSculpt(event.x, event.y)
                }
            }

            // The centroid jumps whenever a finger is added or removed; re-anchor to avoid a lurch.
            MotionEvent.ACTION_POINTER_DOWN -> {
                multiTouch = true
                setCentroid(event, -1)
                endStroke()
            }

            MotionEvent.ACTION_POINTER_UP -> setCentroid(event, event.actionIndex)

            MotionEvent.ACTION_MOVE -> {
                val cx = centroid(event, -1, true)
                val cy = centroid(event, -1, false)
                val dx = cx - lastX
                val dy = cy - lastY
                lastX = cx
                lastY = cy

                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    if (sculpting) queueSculpt(event.x, event.y)
                    else if (!sculptTool) camera.rotate(dx, dy)
                } else if (event.pointerCount >= 2 && mode == Mode.EDIT) {
                    camera.pan(dx, dy)
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                endStroke()
                multiTouch = false
            }
        }
        return true
    }

    private fun queueSculpt(x: Float, y: Float) {
        queueEvent { engineRenderer.sculptTouch(x, y) }
    }

    private fun endStroke() {
        if (sculpting) {
            sculpting = false
            queueEvent { engineRenderer.hideBrush() }
        }
    }

    private fun setCentroid(event: MotionEvent, skipIndex: Int) {
        lastX = centroid(event, skipIndex, true)
        lastY = centroid(event, skipIndex, false)
    }

    private fun centroid(event: MotionEvent, skipIndex: Int, xAxis: Boolean): Float {
        var sum = 0f
        var n = 0
        for (i in 0 until event.pointerCount) {
            if (i == skipIndex) continue
            sum += if (xAxis) event.getX(i) else event.getY(i)
            n++
        }
        return if (n > 0) sum / n else 0f
    }
}
