package com.custom.engine.graphics

import android.opengl.Matrix
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Orbit camera. Position is derived from (target, yaw, pitch, distance).
 *
 * Thread-safety: gestures arrive on the UI thread while matrices are read on
 * the GL thread, so every public method is synchronized. Readers should take a
 * snapshot via [updateMatrices] and then copy the matrices they need.
 *
 * Conventions: Y is up. yaw = 0 puts the camera on the +Z side of the target.
 * Angles are stored in degrees.
 */
class Camera3D {

    val viewMatrix = FloatArray(16)
    val projMatrix = FloatArray(16)
    val viewProjMatrix = FloatArray(16)

    val position = FloatArray(3)
    val target = FloatArray(3)
    val up = floatArrayOf(0f, 1f, 0f)

    var yaw = 45f
        private set
    var pitch = 30f
        private set
    var distance = 15f
        private set

    /** Set by the renderer; used to convert pixel pans into world units. */
    @Volatile
    var viewportHeight = 1080f

    init {
        computePosition()
        Matrix.setIdentityM(viewMatrix, 0)
        Matrix.setIdentityM(projMatrix, 0)
        Matrix.setIdentityM(viewProjMatrix, 0)
    }

    /** Drag deltas in pixels. Dragging right/down turns the scene with the finger. */
    @Synchronized
    fun rotate(deltaX: Float, deltaY: Float) {
        yaw = (yaw - deltaX * ROTATE_SENSITIVITY) % 360f
        pitch = (pitch + deltaY * ROTATE_SENSITIVITY).coerceIn(MIN_PITCH, MAX_PITCH)
        computePosition()
    }

    /** [scaleFactor] > 1 zooms in (pinch out), < 1 zooms out. */
    @Synchronized
    fun zoom(scaleFactor: Float) {
        if (scaleFactor <= 0f || scaleFactor.isNaN()) return
        distance = (distance / scaleFactor).coerceIn(MIN_DISTANCE, MAX_DISTANCE)
        computePosition()
    }

    /** Drag deltas in pixels; the scene follows the fingers. */
    @Synchronized
    fun pan(dx: Float, dy: Float) {
        // World units covered by one pixel at the target's depth.
        val worldPerPixel =
            2f * distance * tan(FOV_DEGREES * DEG2RAD / 2f) / viewportHeight.coerceAtLeast(1f)

        val fx = target[0] - position[0]
        val fy = target[1] - position[1]
        val fz = target[2] - position[2]
        val fLen = sqrt(fx * fx + fy * fy + fz * fz)
        if (fLen < 1e-6f) return
        val f = floatArrayOf(fx / fLen, fy / fLen, fz / fLen)

        // right = forward x up
        var rx = f[1] * up[2] - f[2] * up[1]
        var ry = f[2] * up[0] - f[0] * up[2]
        var rz = f[0] * up[1] - f[1] * up[0]
        val rLen = sqrt(rx * rx + ry * ry + rz * rz)
        if (rLen < 1e-6f) return
        rx /= rLen; ry /= rLen; rz /= rLen

        // camera up = right x forward
        val ux = ry * f[2] - rz * f[1]
        val uy = rz * f[0] - rx * f[2]
        val uz = rx * f[1] - ry * f[0]

        target[0] += (-rx * dx + ux * dy) * worldPerPixel
        target[1] += (-ry * dx + uy * dy) * worldPerPixel
        target[2] += (-rz * dx + uz * dy) * worldPerPixel
        computePosition()
    }

    /**
     * Third-person follow: eases the orbit target toward the given point, frame-rate independent.
     * Yaw, pitch and distance stay under the player's control, so the offset is simply the orbit.
     */
    @Synchronized
    fun follow(x: Float, y: Float, z: Float, dt: Float) {
        val k = 1f - exp(-FOLLOW_SHARPNESS * dt)
        target[0] += (x - target[0]) * k
        target[1] += (y - target[1]) * k
        target[2] += (z - target[2]) * k
        computePosition()
    }

    /** Jumps the orbit target to a point with no easing. */
    @Synchronized
    fun snapTo(x: Float, y: Float, z: Float) {
        target[0] = x; target[1] = y; target[2] = z
        computePosition()
    }

    /** A comfortable close third-person framing, used when entering Play mode. */
    @Synchronized
    fun setFollowDefaults() {
        distance = FOLLOW_DISTANCE
        pitch = FOLLOW_PITCH
        computePosition()
    }

    /** Recomputes view, projection and their product. Call once per frame. */
    @Synchronized
    fun updateMatrices(aspect: Float) {
        Matrix.setLookAtM(
            viewMatrix, 0,
            position[0], position[1], position[2],
            target[0], target[1], target[2],
            up[0], up[1], up[2]
        )
        Matrix.perspectiveM(projMatrix, 0, FOV_DEGREES, aspect, NEAR, FAR)
        Matrix.multiplyMM(viewProjMatrix, 0, projMatrix, 0, viewMatrix, 0)
    }

    private fun computePosition() {
        val yawRad = yaw * DEG2RAD
        val pitchRad = pitch * DEG2RAD
        val horizontal = distance * cos(pitchRad)
        position[0] = target[0] + horizontal * sin(yawRad)
        position[1] = target[1] + distance * sin(pitchRad)
        position[2] = target[2] + horizontal * cos(yawRad)
    }

    companion object {
        const val FOV_DEGREES = 60f
        const val NEAR = 0.1f
        const val FAR = 1000f
        const val MIN_DISTANCE = 2f
        const val MAX_DISTANCE = 150f
        const val MIN_PITCH = 5f
        const val MAX_PITCH = 89f
        private const val ROTATE_SENSITIVITY = 0.3f
        private const val FOLLOW_SHARPNESS = 8f
        private const val FOLLOW_DISTANCE = 8f
        private const val FOLLOW_PITCH = 28f
        private const val DEG2RAD = (PI / 180.0).toFloat()
    }
}
