package com.custom.engine.math

import android.opengl.Matrix
import com.custom.engine.terrain.TerrainMesh
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Ray(val origin: Vector3, val direction: Vector3)

object RaycastUtil {

    private const val STEP = 0.4f
    private const val MAX_DISTANCE = 600f
    private const val REFINE_ITERATIONS = 12

    /**
     * Unprojects a touch point into a world-space ray. Screen Y grows downward, NDC Y grows upward,
     * hence the flip. If the matrices are singular the returned ray has a zero direction,
     * which [intersectTerrain] treats as "no hit".
     */
    fun getRayFromScreen(
        touchX: Float,
        touchY: Float,
        screenWidth: Int,
        screenHeight: Int,
        viewMatrix: FloatArray,
        projMatrix: FloatArray
    ): Ray {
        val viewProj = FloatArray(16)
        Matrix.multiplyMM(viewProj, 0, projMatrix, 0, viewMatrix, 0)
        val inverse = FloatArray(16)
        if (!Matrix.invertM(inverse, 0, viewProj, 0)) return Ray(Vector3(), Vector3())

        val ndcX = 2f * touchX / screenWidth.coerceAtLeast(1) - 1f
        val ndcY = 1f - 2f * touchY / screenHeight.coerceAtLeast(1)

        val near = unproject(inverse, ndcX, ndcY, -1f)
        val far = unproject(inverse, ndcX, ndcY, 1f)
        return Ray(near, (far - near).normalized())
    }

    private fun unproject(inverse: FloatArray, x: Float, y: Float, z: Float): Vector3 {
        val input = floatArrayOf(x, y, z, 1f)
        val out = FloatArray(4)
        Matrix.multiplyMV(out, 0, inverse, 0, input, 0)
        val w = if (abs(out[3]) < 1e-8f) 1f else out[3]
        return Vector3(out[0] / w, out[1] / w, out[2] / w)
    }

    /**
     * Marches the ray through the terrain's height slab and bisects at the first crossing, so it
     * stays correct after the terrain has been sculpted into hills (a plain Y=0 plane test would not).
     * Returns the point on the surface, or null if the ray misses the terrain.
     */
    fun intersectTerrain(ray: Ray, terrain: TerrainMesh): Vector3? {
        val o = ray.origin
        val d = ray.direction
        if (d.length() < 1e-6f) return null

        var tStart = 0f
        var tEnd = MAX_DISTANCE
        if (abs(d.y) > 1e-6f) {
            val tTop = (TerrainMesh.MAX_HEIGHT - o.y) / d.y
            val tBottom = (TerrainMesh.MIN_HEIGHT - o.y) / d.y
            tStart = max(0f, min(tTop, tBottom))
            tEnd = min(tEnd, max(tTop, tBottom))
        } else if (o.y > TerrainMesh.MAX_HEIGHT || o.y < TerrainMesh.MIN_HEIGHT) {
            return null
        }
        if (tStart >= tEnd) return null

        var t = tStart
        var prevT = tStart
        var prevInside = false
        var prevAbove = false

        while (t <= tEnd) {
            val px = o.x + d.x * t
            val py = o.y + d.y * t
            val pz = o.z + d.z * t
            val inside = terrain.contains(px, pz)

            if (inside) {
                val h = terrain.getHeightAt(px, pz)
                val above = py > h
                if (!above) {
                    if (prevInside && prevAbove) {
                        return refine(o, d, terrain, prevT, t)
                    }
                    // The ray entered the grid already below the surface (e.g. through a cliff edge).
                    return Vector3(px, h, pz)
                }
                prevAbove = true
            }
            prevInside = inside
            prevT = t
            t += STEP
        }
        return null
    }

    /** Bisection between [lo] (above the surface) and [hi] (below it). */
    private fun refine(o: Vector3, d: Vector3, terrain: TerrainMesh, loStart: Float, hiStart: Float): Vector3 {
        var lo = loStart
        var hi = hiStart
        repeat(REFINE_ITERATIONS) {
            val mid = (lo + hi) * 0.5f
            val y = o.y + d.y * mid
            val h = terrain.getHeightAt(o.x + d.x * mid, o.z + d.z * mid)
            if (y > h) lo = mid else hi = mid
        }
        val x = o.x + d.x * hi
        val z = o.z + d.z * hi
        return Vector3(x, terrain.getHeightAt(x, z), z)
    }
}
