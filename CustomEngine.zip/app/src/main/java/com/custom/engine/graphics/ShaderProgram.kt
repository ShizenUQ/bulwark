package com.custom.engine.graphics

import android.opengl.GLES30
import android.util.Log

/**
 * Compiles and links a vertex + fragment shader pair.
 * Must be constructed on the GL thread with a current context.
 * Throws [RuntimeException] with the driver's info log on any failure.
 */
class ShaderProgram(vertexSource: String, fragmentSource: String) {

    val programId: Int
    private val uniformCache = HashMap<String, Int>()

    init {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertexSource)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragmentSource)

        val program = GLES30.glCreateProgram()
        if (program == 0) {
            checkGlError("glCreateProgram")
            throw RuntimeException("glCreateProgram returned 0")
        }
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)

        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(program)
            GLES30.glDeleteProgram(program)
            GLES30.glDeleteShader(vs)
            GLES30.glDeleteShader(fs)
            throw RuntimeException("Program link failed: $log")
        }

        // Shader objects are no longer needed once the program is linked.
        GLES30.glDetachShader(program, vs)
        GLES30.glDetachShader(program, fs)
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)

        programId = program
        checkGlError("ShaderProgram link")
    }

    fun use() = GLES30.glUseProgram(programId)

    fun attribLocation(name: String): Int = GLES30.glGetAttribLocation(programId, name)

    /** Cached. Returns -1 if the uniform doesn't exist or was optimised out. */
    fun uniformLocation(name: String): Int =
        uniformCache.getOrPut(name) { GLES30.glGetUniformLocation(programId, name) }

    fun setMat4(name: String, value: FloatArray) =
        GLES30.glUniformMatrix4fv(uniformLocation(name), 1, false, value, 0)

    fun setVec3(name: String, x: Float, y: Float, z: Float) =
        GLES30.glUniform3f(uniformLocation(name), x, y, z)

    fun setVec4(name: String, x: Float, y: Float, z: Float, w: Float) =
        GLES30.glUniform4f(uniformLocation(name), x, y, z, w)

    fun delete() = GLES30.glDeleteProgram(programId)

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        if (shader == 0) {
            checkGlError("glCreateShader")
            throw RuntimeException("glCreateShader returned 0")
        }
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)

        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            val kind = if (type == GLES30.GL_VERTEX_SHADER) "vertex" else "fragment"
            throw RuntimeException("Could not compile $kind shader: $log")
        }
        return shader
    }

    companion object {
        private const val TAG = "ShaderProgram"

        /** Drains the GL error queue and throws if anything was pending. */
        fun checkGlError(op: String) {
            var error = GLES30.glGetError()
            var first = GLES30.GL_NO_ERROR
            while (error != GLES30.GL_NO_ERROR) {
                if (first == GLES30.GL_NO_ERROR) first = error
                Log.e(TAG, "$op: glError 0x${Integer.toHexString(error)}")
                error = GLES30.glGetError()
            }
            if (first != GLES30.GL_NO_ERROR) {
                throw RuntimeException("$op: glError 0x${Integer.toHexString(first)}")
            }
        }
    }
}
