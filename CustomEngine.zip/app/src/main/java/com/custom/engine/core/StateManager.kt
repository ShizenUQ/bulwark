package com.custom.engine.core

import com.custom.engine.terrain.SculptMode

enum class Mode { EDIT, PLAY }

/** What a one-finger drag does in EDIT mode. */
enum class EditTool { SCULPT, ORBIT }

/**
 * Shared UI/GL state. Fields are @Volatile because the UI thread writes them and the
 * GL thread reads them every frame.
 */
class StateManager {
    @Volatile var mode: Mode = Mode.EDIT
    @Volatile var tool: EditTool = EditTool.SCULPT
    @Volatile var sculptMode: SculptMode = SculptMode.RAISE

    fun toggleMode() {
        mode = if (mode == Mode.EDIT) Mode.PLAY else Mode.EDIT
    }
}
