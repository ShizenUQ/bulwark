package com.custom.engine

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.custom.engine.core.EditTool
import com.custom.engine.core.EngineView
import com.custom.engine.core.Mode
import com.custom.engine.game.VirtualJoystick
import com.custom.engine.terrain.SculptMode

class MainActivity : AppCompatActivity() {

    private lateinit var engineView: EngineView
    private lateinit var joystick: VirtualJoystick
    private lateinit var editPanel: LinearLayout
    private lateinit var modeButton: Button
    private lateinit var toolButton: Button
    private lateinit var raiseButton: Button
    private lateinit var lowerButton: Button
    private lateinit var smoothButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        engineView = EngineView(this)
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(
                engineView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }
        buildHud(root)
        setContentView(root)
        refreshHud()
        enterImmersiveMode()
    }

    private fun buildHud(root: FrameLayout) {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        val state = engineView.state

        toolButton = button("Tool: Sculpt") {
            state.tool = if (state.tool == EditTool.SCULPT) EditTool.ORBIT else EditTool.SCULPT
            refreshHud()
        }
        raiseButton = button("Raise") { state.sculptMode = SculptMode.RAISE; refreshHud() }
        lowerButton = button("Lower") { state.sculptMode = SculptMode.LOWER; refreshHud() }
        smoothButton = button("Smooth") { state.sculptMode = SculptMode.SMOOTH; refreshHud() }

        editPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(toolButton)
            addView(raiseButton)
            addView(lowerButton)
            addView(smoothButton)
        }
        root.addView(
            editPanel,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply { setMargins(dp(12), dp(8), 0, 0) }
        )

        modeButton = button("Play") {
            state.toggleMode()
            engineView.setJoystick(0f, 0f)
            refreshHud()
        }
        root.addView(
            modeButton,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { setMargins(0, dp(8), dp(12), 0) }
        )

        joystick = VirtualJoystick(this).apply {
            onChange = { x, y -> engineView.setJoystick(x, y) }
        }
        root.addView(
            joystick,
            FrameLayout.LayoutParams(dp(180), dp(180), Gravity.BOTTOM or Gravity.START)
                .apply { setMargins(dp(32), 0, 0, dp(32)) }
        )
    }

    private fun refreshHud() {
        val state = engineView.state
        val editing = state.mode == Mode.EDIT
        editPanel.visibility = if (editing) View.VISIBLE else View.GONE
        joystick.visibility = if (editing) View.GONE else View.VISIBLE
        modeButton.text = if (editing) "Play" else "Edit"
        toolButton.text = if (state.tool == EditTool.SCULPT) "Tool: Sculpt" else "Tool: Orbit"

        fun highlight(b: Button, on: Boolean) { b.alpha = if (on) 1f else 0.5f }
        highlight(raiseButton, state.sculptMode == SculptMode.RAISE)
        highlight(lowerButton, state.sculptMode == SculptMode.LOWER)
        highlight(smoothButton, state.sculptMode == SculptMode.SMOOTH)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Sticky immersive is dropped when focus is lost; re-apply it.
        if (hasFocus) enterImmersiveMode()
    }

    override fun onResume() {
        super.onResume()
        engineView.onResume()
    }

    override fun onPause() {
        engineView.onPause()
        super.onPause()
    }

    private fun enterImmersiveMode() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }
}
