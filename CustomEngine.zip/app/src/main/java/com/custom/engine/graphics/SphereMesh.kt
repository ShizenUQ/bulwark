package com.custom.engine.graphics

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Unit-radius UV sphere with a single baked colour, same interleaved layout as the terrain. */
class SphereMesh(stacks: Int = 16, slices: Int = 24, color: FloatArray) {

    private val vao: Int
    private val vbo: Int
    private val ibo: Int
    private val indexCount = stacks * slices * 6

    init {
        val vertexCount = (stacks + 1) * (slices + 1)
        val vb = ByteBuffer.allocateDirect(vertexCount * 9 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0..stacks) {
            val theta = PI.toFloat() * i / stacks
            for (j in 0..slices) {
                val phi = 2f * PI.toFloat() * j / slices
                val x = sin(theta) * cos(phi)
                val y = cos(theta)
                val z = sin(theta) * sin(phi)
                vb.put(x); vb.put(y); vb.put(z)       // position (unit sphere)
                vb.put(x); vb.put(y); vb.put(z)       // normal equals position
                vb.put(color[0]); vb.put(color[1]); vb.put(color[2])
            }
        }
        vb.position(0)

        val ib = ByteBuffer.allocateDirect(indexCount * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        for (i in 0 until stacks) {
            for (j in 0 until slices) {
                val a = i * (slices + 1) + j
                val b = a + slices + 1
                val c = a + 1
                val d = b + 1
                ib.put(a.toShort()); ib.put(c.toShort()); ib.put(b.toShort())
                ib.put(b.toShort()); ib.put(c.toShort()); ib.put(d.toShort())
            }
        }
        ib.position(0)

        val ids = IntArray(3)
        GLES30.glGenVertexArrays(1, ids, 0)
        GLES30.glGenBuffers(2, ids, 1)
        vao = ids[0]; vbo = ids[1]; ibo = ids[2]

        GLES30.glBindVertexArray(vao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertexCount * 9 * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, indexCount * 2, ib, GLES30.GL_STATIC_DRAW)

        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 36, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 36, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, 36, 24)
        GLES30.glBindVertexArray(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    fun draw() {
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_SHORT, 0)
        GLES30.glBindVertexArray(0)
    }
}
