package com.custom.engine.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * On-screen thumb stick. Reports (x, y) in [-1, 1]; y is positive when pushed UP,
 * which is the opposite of Android's screen axis.
 */
class VirtualJoystick @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onChange: ((Float, Float) -> Unit)? = null

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x33FFFFFF }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = 0x88FFFFFF.toInt()
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xAAFFFFFF.toInt() }

    private var knobX = 0f
    private var knobY = 0f
    private var pointerId = -1

    private val baseRadius get() = min(width, height) / 2f - 4f
    private val knobRadius get() = baseRadius * 0.4f
    private val travel get() = baseRadius * 0.6f

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        canvas.drawCircle(cx, cy, baseRadius, basePaint)
        canvas.drawCircle(cx, cy, baseRadius, ringPaint)
        canvas.drawCircle(cx + knobX, cy + knobY, knobRadius, knobPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerId = event.getPointerId(0)
                moveKnob(event.getX(0), event.getY(0))
            }
            MotionEvent.ACTION_MOVE -> {
                val index = event.findPointerIndex(pointerId)
                if (index >= 0) moveKnob(event.getX(index), event.getY(index))
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == pointerId) release()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    private fun moveKnob(touchX: Float, touchY: Float) {
        val dx = touchX - width / 2f
        val dy = touchY - height / 2f
        val dist = hypot(dx, dy)
        val scale = if (dist > travel && dist > 0f) travel / dist else 1f
        knobX = dx * scale
        knobY = dy * scale
        invalidate()
        onChange?.invoke(knobX / travel, -knobY / travel)
    }

    private fun release() {
        pointerId = -1
        knobX = 0f
        knobY = 0f
        invalidate()
        onChange?.invoke(0f, 0f)
    }
}
