package com.custom.engine.graphics

/**
 * Raw GLSL ES 3.00 sources.
 *
 * Attribute locations are pinned with layout(location = N) so every mesh can
 * set up its VAO without querying the program:
 *   0 = a_Position, 1 = a_Normal, 2 = a_Color
 *
 * Note: the spec lists u_MVPMatrix, u_ModelMatrix and u_LightPos only. Blinn-Phong
 * needs the eye position for its half-vector, so u_CameraPos is added.
 */
object Shaders {

    val VERTEX = """
        #version 300 es

        uniform mat4 u_MVPMatrix;
        uniform mat4 u_ModelMatrix;

        layout(location = 0) in vec3 a_Position;
        layout(location = 1) in vec3 a_Normal;
        layout(location = 2) in vec3 a_Color;

        out vec3 v_WorldPos;
        out vec3 v_Normal;
        out vec3 v_Color;

        void main() {
            vec4 worldPos = u_ModelMatrix * vec4(a_Position, 1.0);
            v_WorldPos = worldPos.xyz;
            // Valid for rotation + uniform scale. Non-uniform scale would need
            // the inverse-transpose normal matrix.
            v_Normal = mat3(u_ModelMatrix) * a_Normal;
            v_Color = a_Color;
            gl_Position = u_MVPMatrix * vec4(a_Position, 1.0);
        }
    """.trimIndent()

    /** Unlit flat-colour pair, used for the brush ring. */
    val LINE_VERTEX = """
        #version 300 es

        uniform mat4 u_MVPMatrix;
        layout(location = 0) in vec3 a_Position;

        void main() {
            gl_Position = u_MVPMatrix * vec4(a_Position, 1.0);
        }
    """.trimIndent()

    val LINE_FRAGMENT = """
        #version 300 es
        precision mediump float;

        uniform vec4 u_Color;
        out vec4 fragColor;

        void main() {
            fragColor = u_Color;
        }
    """.trimIndent()

    val FRAGMENT = """
        #version 300 es
        precision highp float;

        uniform vec3 u_LightPos;
        uniform vec3 u_CameraPos;

        in vec3 v_WorldPos;
        in vec3 v_Normal;
        in vec3 v_Color;

        out vec4 fragColor;

        void main() {
            vec3 N = normalize(v_Normal);
            vec3 L = normalize(u_LightPos - v_WorldPos);
            vec3 V = normalize(u_CameraPos - v_WorldPos);
            vec3 H = normalize(L + V);

            float ambient = 0.25;
            float diffuse = max(dot(N, L), 0.0);
            float specular = diffuse > 0.0 ? pow(max(dot(N, H), 0.0), 32.0) * 0.2 : 0.0;

            vec3 color = v_Color * (ambient + diffuse) + vec3(specular);
            fragColor = vec4(color, 1.0);
        }
    """.trimIndent()
}
