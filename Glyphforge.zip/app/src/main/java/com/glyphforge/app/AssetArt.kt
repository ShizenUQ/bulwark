package com.glyphforge.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Typeface
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Turns one picture into "letter art": a solid dark shape, with small letters drawn only where
 * the user painted (the mask). Each letter sits alone in its own cell, so letters never overlap.
 *
 * Two bitmaps are kept: [silhouette] (the dark shape) and [letters] (transparent, letters only).
 * Painting only redraws the cells that changed.
 */
class AssetArt(
    val asset: Asset,
    val src: Bitmap,
    private val sets: (String) -> LetterSet
) {
    val w: Int = src.width
    val h: Int = src.height

    /** The paint mask works on a fixed 3 px grid so changing letter size never loses your painting. */
    val mc = 3
    val mCols: Int = (w + mc - 1) / mc
    val mRows: Int = (h + mc - 1) / mc

    private val px = IntArray(w * h)
    val silhouette: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val letters: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    private val lc = Canvas(letters)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        src.getPixels(px, 0, w, 0, 0, w, h)
        if (asset.mask.size != mCols * mRows) asset.mask = ByteArray(mCols * mRows)
        rebuildSilhouette()
        renderAll()
    }

    /** Size of one letter cell. Always larger than the biggest letter, so nothing touches. */
    private fun cell(): Float = asset.letterSize + 1.5f

    fun rebuildSilhouette() {
        val out = IntArray(w * h)
        val dark = asset.colDark and 0x00FFFFFF
        for (i in 0 until w * h) {
            val a = px[i] ushr 24
            if (a > 0) out[i] = (a shl 24) or dark
        }
        silhouette.setPixels(out, 0, w, 0, 0, w, h)
    }

    // ------------------------------------------------------------ noise and tone

    private fun hash2(i: Int, j: Int): Float {
        var n = i * 374761393 + j * 668265263
        n = (n xor (n ushr 13)) * 1274126177
        n = n xor (n ushr 16)
        return (n and 0xFFFF) / 65535f
    }

    private fun vnoise(x: Float, y: Float): Float {
        val xi = floor(x).toInt()
        val yi = floor(y).toInt()
        val xf = x - xi
        val yf = y - yi
        val u = xf * xf * (3f - 2f * xf)
        val v = yf * yf * (3f - 2f * yf)
        val a = hash2(xi, yi)
        val b = hash2(xi + 1, yi)
        val c = hash2(xi, yi + 1)
        val d = hash2(xi + 1, yi + 1)
        val l1 = a + (b - a) * u
        val l2 = c + (d - c) * u
        return l1 + (l2 - l1) * v
    }

    private fun pixelAt(cx: Float, cy: Float): Int {
        val ix = cx.toInt().coerceIn(0, w - 1)
        val iy = cy.toInt().coerceIn(0, h - 1)
        return px[iy * w + ix]
    }

    /** How lit a spot is, 0 to 1. Light comes from the upper right; bright picture areas count as lit. */
    private fun tone(cx: Float, cy: Float): Float {
        val p = pixelAt(cx, cy)
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        val u = cx / w
        val v = cy / h
        val dir = (0.5f + (u - 0.5f) * 0.95f - (v - 0.42f) * 0.95f).coerceIn(0f, 1f)
        val n = vnoise(cx * 0.06f, cy * 0.06f)
        return 0.42f * (lum / 0.62f).coerceIn(0f, 1f) + 0.58f * dir + (n - 0.5f) * 0.34f
    }

    private fun mix(c1: Int, c2: Int, t: Float): Int {
        val r = Color.red(c1) + ((Color.red(c2) - Color.red(c1)) * t).toInt()
        val g = Color.green(c1) + ((Color.green(c2) - Color.green(c1)) * t).toInt()
        val b = Color.blue(c1) + ((Color.blue(c2) - Color.blue(c1)) * t).toInt()
        return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
    }

    private fun boosted(p: Int): Int {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        val k = max(1f, 0.55f / max(lum, 0.12f))
        return Color.rgb(min(255f, r * k).toInt(), min(255f, g * k).toInt(), min(255f, b * k).toInt())
    }

    // ------------------------------------------------------------ drawing letters

    fun renderAll() {
        drawRegion(0, 0, w, h)
    }

    /** Clears and redraws every letter cell that touches the rectangle (bitmap pixels). */
    fun drawRegion(l: Int, t: Int, r: Int, b: Int) {
        val cell = cell()
        val cols = ceil(w / cell).toInt()
        val rows = ceil(h / cell).toInt()
        val i0 = (max(0, l) / cell).toInt().coerceIn(0, cols - 1)
        val i1 = ((min(w, r) - 1) / cell).toInt().coerceIn(0, cols - 1)
        val j0 = (max(0, t) / cell).toInt().coerceIn(0, rows - 1)
        val j1 = ((min(h, b) - 1) / cell).toInt().coerceIn(0, rows - 1)

        lc.save()
        lc.clipRect(i0 * cell, j0 * cell, (i1 + 1) * cell, (j1 + 1) * cell)
        lc.drawColor(0, PorterDuff.Mode.CLEAR)
        lc.restore()

        val set = sets(asset.setId)
        val chars = if (set.isText) set.chars.filter { !it.isWhitespace() } else ""
        if (set.isText && chars.isEmpty()) return
        if (!set.isText && set.glyphs.isEmpty()) return

        for (j in j0..j1) {
            for (i in i0..i1) {
                val cx = (i + 0.5f) * cell
                val cy = (j + 0.5f) * cell
                if (cx >= w || cy >= h) continue
                val p = pixelAt(cx, cy)
                if ((p ushr 24) < 128) continue
                val mi = (cy.toInt() / mc) * mCols + (cx.toInt() / mc)
                if (asset.mask[mi].toInt() == 0) continue

                val tt = ((tone(cx, cy) - 0.3f) / 0.7f).coerceIn(0f, 1f)
                val color = if (asset.pictureColors) boosted(p) else mix(asset.colShadow, asset.colLight, tt)
                // Sizes run from the chosen size down by at most sizeVar, so the biggest letter is
                // only a little larger than the smallest.
                val size = max(2f, asset.letterSize - asset.sizeVar * hash2(i * 7 + 3, j * 13 + 5))
                val idx = (hash2(i, j) * 1000f).toInt()
                if (set.isText) drawChar(cx, cy, size, color, chars, idx)
                else drawGlyph(cx, cy, size, color, set.glyphs, idx)
            }
        }
    }

    private fun drawChar(cx: Float, cy: Float, size: Float, color: Int, chars: String, idx: Int) {
        val ch = chars[idx % chars.length].toString()
        paint.color = color
        paint.typeface = Typeface.MONOSPACE
        paint.style = Paint.Style.FILL_AND_STROKE
        paint.strokeWidth = asset.thickness * size * 0.14f
        paint.textSize = size * 1.2f
        val fm = paint.fontMetrics
        val tx = cx - paint.measureText(ch) / 2f
        val ty = cy - (fm.ascent + fm.descent) / 2f
        lc.drawText(ch, tx, ty, paint)
    }

    private fun drawGlyph(cx: Float, cy: Float, size: Float, color: Int, glyphs: List<String>, idx: Int) {
        val bits = glyphs[idx % glyphs.size]
        val ps = size / 5f
        val grow = asset.thickness * ps * 0.4f
        val ox = cx - size / 2f
        val oy = cy - size / 2f
        paint.color = color
        paint.style = Paint.Style.FILL
        for (k in 0 until 25) {
            if (k < bits.length && bits[k] == '1') {
                val x = ox + (k % 5) * ps
                val y = oy + (k / 5) * ps
                lc.drawRect(x - grow / 2f, y - grow / 2f, x + ps + grow / 2f, y + ps + grow / 2f, paint)
            }
        }
    }

    // ------------------------------------------------------------ painting

    /** Paints (or erases) letters in a circle. Position and radius are in bitmap pixels. */
    fun paintAt(bx: Float, by: Float, radius: Float, add: Boolean) {
        val r2 = radius * radius
        val x0 = max(0, ((bx - radius) / mc).toInt())
        val x1 = min(mCols - 1, ((bx + radius) / mc).toInt())
        val y0 = max(0, ((by - radius) / mc).toInt())
        val y1 = min(mRows - 1, ((by + radius) / mc).toInt())
        for (my in y0..y1) {
            for (mx in x0..x1) {
                val cx = mx * mc + mc / 2f
                val cy = my * mc + mc / 2f
                val dx = cx - bx
                val dy = cy - by
                if (dx * dx + dy * dy > r2) continue
                val i = my * mCols + mx
                if (add) {
                    if ((pixelAt(cx, cy) ushr 24) >= 128) asset.mask[i] = 1
                } else {
                    asset.mask[i] = 0
                }
            }
        }
        val pad = (cell() + 1f).toInt()
        drawRegion(
            (bx - radius).toInt() - pad, (by - radius).toInt() - pad,
            (bx + radius).toInt() + pad, (by + radius).toInt() + pad
        )
    }

    /** "Fill lit parts for me": letters wherever the light would hit. */
    fun fillLit(threshold: Float) {
        for (my in 0 until mRows) {
            for (mx in 0 until mCols) {
                val cx = mx * mc + mc / 2f
                val cy = my * mc + mc / 2f
                if ((pixelAt(cx, cy) ushr 24) < 128) continue
                if (tone(cx, cy) > threshold) asset.mask[my * mCols + mx] = 1
            }
        }
        renderAll()
    }

    fun clearMask() {
        asset.mask.fill(0)
        renderAll()
    }

    fun hasPainted(): Boolean {
        for (b in asset.mask) if (b.toInt() != 0) return true
        return false
    }

    /** The finished picture used in the world: dark shape plus letters. */
    fun composite(): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(silhouette, 0f, 0f, null)
        c.drawBitmap(letters, 0f, 0f, null)
        return out
    }
}
