package com.glyphforge.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** On-screen thumb stick. Reports (x, y) in [-1, 1]; y is positive when pushed UP. */
class VirtualJoystick(context: Context) : View(context) {

    var onChange: ((Float, Float) -> Unit)? = null

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x1AE4ECE6
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = 0x59E4ECE6
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x73E4ECE6
    }

    private var knobX = 0f
    private var knobY = 0f
    private var pointerId = -1

    private fun baseRadius(): Float = min(width, height) / 2f - 4f
    private fun travel(): Float = baseRadius() * 0.6f

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        canvas.drawCircle(cx, cy, baseRadius(), basePaint)
        canvas.drawCircle(cx, cy, baseRadius(), ringPaint)
        canvas.drawCircle(cx + knobX, cy + knobY, baseRadius() * 0.4f, knobPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerId = event.getPointerId(0)
                moveKnob(event.getX(0), event.getY(0))
            }
            MotionEvent.ACTION_MOVE -> {
                val index = event.findPointerIndex(pointerId)
                if (index >= 0) moveKnob(event.getX(index), event.getY(index))
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == pointerId) release()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    private fun moveKnob(touchX: Float, touchY: Float) {
        val dx = touchX - width / 2f
        val dy = touchY - height / 2f
        val dist = hypot(dx, dy)
        val t = travel()
        val scale = if (dist > t && dist > 0f) t / dist else 1f
        knobX = dx * scale
        knobY = dy * scale
        invalidate()
        onChange?.invoke(knobX / t, -knobY / t)
    }

    private fun release() {
        pointerId = -1
        knobX = 0f
        knobY = 0f
        invalidate()
        onChange?.invoke(0f, 0f)
    }
}
