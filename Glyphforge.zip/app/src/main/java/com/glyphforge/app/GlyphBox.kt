package com.glyphforge.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.abs

private val G_BITS = arrayOf(".#####.", "#......", "#......", "#..####", "#.....#", "#.....#", ".#####.")

/**
 * The built-in starter player: a cube shaded in letters with the Glyphforge "G" on one face.
 * It stands in until the user adds a real character.
 */
object GlyphBox {
    /** Empty pixels under the cube's lowest corner in the bitmap. */
    const val FEET_PAD = 4f

    fun render(): Bitmap {
        val s = 46f
        val dy = s * 0.5f
        val hh = s * 1.05f
        val cw = 4f
        val ch = 6f
        val bw = (2 * s + 8).toInt()
        val bh = (hh + 2 * dy + 8).toInt()
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 6.8f

        val cx = bw / 2f
        val by = bh - FEET_PAD
        val cols = (bw / cw).toInt() + 1
        val rows = (bh / ch).toInt() + 1

        for (y in 0 until rows) {
            for (x in 0 until cols) {
                val px = x * cw + cw / 2f
                val py = y * ch + ch / 2f
                val uL = (px - (cx - s)) / s
                val vL = ((by - dy) + uL * dy - py) / hh
                val uR = (px - cx) / s
                val vR = (by - uR * dy - py) / hh
                val top = abs(px - cx) / s + abs(py - (by - hh - dy)) / dy

                var lum = -1f
                var face = 0
                var logo = false
                if (top <= 1f) {
                    lum = 1f
                    face = 0
                } else if (uL >= 0f && uL <= 1f && vL >= 0f && vL <= 1f) {
                    lum = 0.55f
                    face = 1
                    val a = (uL - 0.14f) / 0.72f
                    val b = (vL - 0.16f) / 0.68f
                    if (a >= 0f && a < 1f && b >= 0f && b < 1f) {
                        val row = 6 - (b * 7f).toInt()
                        val col = (a * 7f).toInt()
                        if (row in 0..6 && col in 0..6 && G_BITS[row][col] == '#') logo = true
                    }
                } else if (uR >= 0f && uR <= 1f && vR >= 0f && vR <= 1f) {
                    lum = 0.22f
                    face = 2
                }
                if (lum < 0f) continue

                val ch2 = if (logo) "@" else if (face == 0) "#" else if (face == 1) "+" else "."
                p.color = if (logo) Color.parseColor("#FF8A4C")
                else Color.rgb((60 + lum * 180f).toInt(), (100 + lum * 140f).toInt(), (92 + lum * 140f).toInt())
                c.drawText(ch2, x * cw, y * ch + ch * 0.85f, p)
            }
        }
        return bmp
    }
}

/** The small "G" logo used in the top bar. */
class LogoView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(canvas: Canvas) {
        val s = width.toFloat()
        r.set(0f, 0f, s, s)
        p.style = Paint.Style.FILL
        p.color = Ui.PANEL2
        canvas.drawRoundRect(r, s * 0.23f, s * 0.23f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = Ui.LINE
        canvas.drawRoundRect(r, s * 0.23f, s * 0.23f, p)
        p.style = Paint.Style.FILL
        p.color = Ui.MINT
        val u = s * 0.1f
        val o = s * 0.15f
        for (row in 0 until 7) {
            for (col in 0 until 7) {
                if (G_BITS[row][col] == '#') {
                    canvas.drawRect(o + col * u, o + row * u, o + col * u + u * 0.85f, o + row * u + u * 0.85f, p)
                }
            }
        }
    }
}
