package com.glyphforge.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The game world, drawn top-down with a little depth. Everything is sorted by its feet (y), so the
 * player is hidden when standing behind a tree and in front of it when standing below it.
 *
 * Coordinates are world units. One unit is one pixel of an asset picture.
 */
class WorldView(context: Context, private val project: Project) : View(context) {

    enum class Mode { EDIT, GAME }
    enum class Tool { SELECT, PAINT, ERASE }

    interface Listener {
        fun onSelectionChanged()
        fun onProjectChanged()
    }

    var listener: Listener? = null
    var mode = Mode.GAME
    var tool = Tool.PAINT
    var brushGrass = true
    var brushAssetId: String? = null
    var brushRadius = 45f
    var brushDensity = 0.5f
    var randomSize = 0.25f
    var eraseRadius = 45f
    var selected: PlacedObject? = null

    private var joyX = 0f
    private var joyY = 0f
    private var camX = 0f
    private var camY = 0f
    private var zoom = 1.8f
    private var lastNanos = 0L
    private var time = 0f
    private var bladesDirty = true

    private val playerBmp: Bitmap = GlyphBox.render()
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bladePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rnd = Random()

    private class Drawable(val y: Float, val obj: PlacedObject?)

    private val drawables = ArrayList<Drawable>()

    // touch state
    private var touching = false
    private var stroking = false
    private var multi = false
    private var touchWX = 0f
    private var touchWY = 0f
    private var lastStampX = 0f
    private var lastStampY = 0f
    private var dragObj: PlacedObject? = null
    private var dragOffX = 0f
    private var dragOffY = 0f
    private var changedInStroke = false
    private var lastCx = 0f
    private var lastCy = 0f

    // undo
    private class Snap(val objs: List<PlacedObject>, val blades: List<Blade>)

    private val undoStack = ArrayList<Snap>()
    private val redoStack = ArrayList<Snap>()

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(0.6f, 4f)
                return true
            }
        }
    )

    init {
        camX = project.playerX
        camY = project.playerY
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 2f
        ringPaint.color = Ui.EMBER
        ringPaint.pathEffect = DashPathEffect(floatArrayOf(9f, 6f), 0f)
    }

    // ------------------------------------------------------------ public controls

    fun setJoystick(x: Float, y: Float) {
        joyX = x
        joyY = y
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(snap())
        restore(undoStack.removeAt(undoStack.size - 1))
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(snap())
        restore(redoStack.removeAt(redoStack.size - 1))
    }

    fun deleteSelected() {
        val o = selected ?: return
        pushUndo()
        project.objects.remove(o)
        selected = null
        listener?.onSelectionChanged()
        listener?.onProjectChanged()
    }

    fun select(o: PlacedObject?) {
        selected = o
        listener?.onSelectionChanged()
    }

    fun focusOn(o: PlacedObject) {
        val bmp = project.asset(o.assetId)?.finalBmp
        camX = o.x
        camY = o.y - (bmp?.height ?: 0) * o.scale / 2f
    }

    fun nudgeSelected(dx: Float, dy: Float) {
        val o = selected ?: return
        pushUndo()
        o.x += dx
        o.y += dy
        listener?.onProjectChanged()
    }

    fun duplicateSelected() {
        val o = selected ?: return
        pushUndo()
        val c = o.copy(x = o.x + 24f, y = o.y + 8f)
        project.objects.add(c)
        selected = c
        listener?.onSelectionChanged()
        listener?.onProjectChanged()
    }

    fun resetAll() {
        undoStack.clear()
        redoStack.clear()
        selected = null
        project.objects.clear()
        project.blades.clear()
        project.playerX = 0f
        project.playerY = 0f
        camX = 0f
        camY = 0f
        listener?.onSelectionChanged()
        listener?.onProjectChanged()
    }

    private fun snap(): Snap = Snap(
        project.objects.map { it.copy() },
        project.blades.map { Blade(it.x, it.y, it.seed) }
    )

    private fun pushUndo() {
        undoStack.add(snap())
        if (undoStack.size > 25) undoStack.removeAt(0)
        redoStack.clear()
    }

    private fun restore(s: Snap) {
        project.objects.clear()
        for (o in s.objs) project.objects.add(o.copy())
        project.blades.clear()
        for (b in s.blades) project.blades.add(Blade(b.x, b.y, b.seed))
        selected = null
        bladesDirty = true
        listener?.onSelectionChanged()
        listener?.onProjectChanged()
    }

    // ------------------------------------------------------------ update

    private fun update(dt: Float) {
        time += dt
        if (mode == Mode.GAME) {
            var dx = joyX
            var dy = -joyY
            val len = sqrt(dx * dx + dy * dy)
            if (len > 1f) {
                dx /= len
                dy /= len
            }
            project.playerX += dx * PLAYER_SPEED * dt
            project.playerY += dy * PLAYER_SPEED * dt
            resolveCollisions()
            val k = min(1f, dt * 6f)
            camX += (project.playerX - camX) * k
            camY += (project.playerY - camY) * k
        }
        updateFades(dt)
    }

    /** Pushes the player out of solid objects. Uses the shape the user drew, or the round trunk area. */
    private fun resolveCollisions() {
        for (iter in 0 until 4) {
            for (o in project.objects) {
                val a = project.asset(o.assetId) ?: continue
                if (!a.solid) continue
                val bmp = a.finalBmp ?: continue
                val w = bmp.width * o.scale
                val h = bmp.height * o.scale
                val px = project.playerX
                val py = project.playerY
                if (abs(px - o.x) > w / 2f + PLAYER_RADIUS || py > o.y + PLAYER_RADIUS || py < o.y - h - PLAYER_RADIUS) continue
                if (a.hasShape()) {
                    pushFromShape(o, a, bmp)
                } else {
                    pushFromCircle(o, a, bmp)
                }
            }
        }
    }

    private fun pushFromCircle(o: PlacedObject, a: Asset, bmp: Bitmap) {
        val r = a.footRadius * bmp.width * o.scale
        val cx = o.x
        val cy = o.y - r * 0.4f
        val dx = project.playerX - cx
        val dy = project.playerY - cy
        val minD = r + PLAYER_RADIUS
        val d2 = dx * dx + dy * dy
        if (d2 < minD * minD) {
            val d = sqrt(d2)
            if (d < 0.001f) {
                project.playerY += minD
            } else {
                val push = (minD - d) / d
                project.playerX += dx * push
                project.playerY += dy * push
            }
        }
    }

    /** Finds the deepest overlap between the player circle and the drawn cells, and pushes straight out of it. */
    private fun pushFromShape(o: PlacedObject, a: Asset, bmp: Bitmap) {
        val s = o.scale
        val cc = Asset.CC
        val cols = (bmp.width + cc - 1) / cc
        val rows = (bmp.height + cc - 1) / cc
        if (a.collide.size != cols * rows) return
        val lx = (project.playerX - (o.x - bmp.width * s / 2f)) / s
        val ly = (project.playerY - (o.y - bmp.height * s)) / s
        val r = PLAYER_RADIUS / s
        val c0 = floor((lx - r) / cc).toInt().coerceAtLeast(0)
        val c1 = floor((lx + r) / cc).toInt().coerceAtMost(cols - 1)
        val r0 = floor((ly - r) / cc).toInt().coerceAtLeast(0)
        val r1 = floor((ly + r) / cc).toInt().coerceAtMost(rows - 1)
        var best = 0f
        var bnx = 0f
        var bny = 0f
        for (j in r0..r1) {
            for (i in c0..c1) {
                if (a.collide[j * cols + i].toInt() == 0) continue
                val minX = (i * cc).toFloat()
                val minY = (j * cc).toFloat()
                val nx = lx.coerceIn(minX, minX + cc)
                val ny = ly.coerceIn(minY, minY + cc)
                val dx = lx - nx
                val dy = ly - ny
                val d2 = dx * dx + dy * dy
                if (d2 >= r * r) continue
                val d = sqrt(d2)
                val pen: Float
                val ux: Float
                val uy: Float
                if (d > 0.0001f) {
                    pen = r - d
                    ux = dx / d
                    uy = dy / d
                } else {
                    var ex = lx - (minX + cc / 2f)
                    var ey = ly - (minY + cc / 2f)
                    var el = sqrt(ex * ex + ey * ey)
                    if (el < 0.001f) {
                        ex = 0f
                        ey = 1f
                        el = 1f
                    }
                    pen = r + cc / 2f
                    ux = ex / el
                    uy = ey / el
                }
                if (pen > best) {
                    best = pen
                    bnx = ux
                    bny = uy
                }
            }
        }
        if (best > 0f) {
            project.playerX += bnx * best * s
            project.playerY += bny * best * s
        }
    }

    private fun updateFades(dt: Float) {
        val px = project.playerX
        val py = project.playerY
        for (o in project.objects) {
            val a = project.asset(o.assetId)
            val bmp = a?.finalBmp
            var target = 1f
            if (a != null && bmp != null && a.fade) {
                val w = bmp.width * o.scale
                val h = bmp.height * o.scale
                val behind = py < o.y && py > o.y - h && abs(px - o.x) < w / 2f
                if (behind) target = 0.45f
            }
            val step = dt * 4f
            o.fadeA = if (o.fadeA < target) min(target, o.fadeA + step) else max(target, o.fadeA - step)
        }
    }

    // ------------------------------------------------------------ drawing

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNanos == 0L) 0.016f else ((now - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNanos = now
        update(dt)

        canvas.drawColor(Ui.BG)
        val halfW = width / 2f / zoom
        val halfH = height / 2f / zoom
        val left = camX - halfW
        val right = camX + halfW
        val top = camY - halfH
        val bottom = camY + halfH

        canvas.save()
        canvas.translate(width / 2f, height / 2f)
        canvas.scale(zoom, zoom)
        canvas.translate(-camX, -camY)

        if (mode == Mode.EDIT) drawGrid(canvas, left, top, right, bottom)

        // 1) ground shadows
        for (o in project.objects) {
            val a = project.asset(o.assetId) ?: continue
            val bmp = a.finalBmp ?: continue
            if (!a.shadow) continue
            val w = bmp.width * o.scale
            if (o.x < left - w || o.x > right + w || o.y < top - 10f || o.y > bottom + bmp.height * o.scale) continue
            drawShadow(canvas, o.x, o.y, w * 0.55f, o.fadeA)
        }
        drawShadow(canvas, project.playerX, project.playerY, 56f, 1f)

        // 2) blades, objects and the player, merged in feet order
        drawables.clear()
        for (o in project.objects) {
            val a = project.asset(o.assetId) ?: continue
            val bmp = a.finalBmp ?: continue
            val w = bmp.width * o.scale
            val h = bmp.height * o.scale
            if (o.x < left - w || o.x > right + w || o.y < top || o.y > bottom + h) continue
            drawables.add(Drawable(o.y, o))
        }
        drawables.add(Drawable(project.playerY, null))
        drawables.sortBy { it.y }

        val bl = project.blades
        if (bladesDirty) {
            bl.sortBy { it.y }
            bladesDirty = false
        }
        var bi = lowerBound(bl, top)
        val limit = bottom + 4f
        for (d in drawables) {
            while (bi < bl.size && bl[bi].y <= d.y && bl[bi].y <= limit) {
                drawBlade(canvas, bl[bi], left, right)
                bi++
            }
            drawDrawable(canvas, d)
        }
        while (bi < bl.size && bl[bi].y <= limit) {
            drawBlade(canvas, bl[bi], left, right)
            bi++
        }

        // 3) editor overlays
        if (mode == Mode.EDIT) drawOverlays(canvas)

        canvas.restore()
        postInvalidateOnAnimation()
    }

    private fun lowerBound(list: List<Blade>, y: Float): Int {
        var lo = 0
        var hi = list.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].y < y) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun drawGrid(canvas: Canvas, left: Float, top: Float, right: Float, bottom: Float) {
        val step = 48f
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = Color.argb(46, 124, 242, 192)
        var gx = floor(left / step) * step
        while (gx < right) {
            var gy = floor(top / step) * step
            while (gy < bottom) {
                canvas.drawCircle(gx, gy, 1.5f, fillPaint)
                gy += step
            }
            gx += step
        }
    }

    private fun drawShadow(canvas: Canvas, cx: Float, cy: Float, w: Float, alpha: Float) {
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = Color.argb((110 * alpha).toInt(), 0, 0, 0)
        rect.set(cx - w / 2f, cy - w * 0.09f, cx + w / 2f, cy + w * 0.09f)
        canvas.drawOval(rect, fillPaint)
    }

    private fun drawBlade(canvas: Canvas, b: Blade, left: Float, right: Float) {
        if (b.x < left - 20f || b.x > right + 20f) return
        BladeDraw.draw(canvas, bladePaint, b.x, b.y, b.seed, project.grass, time, 1f)
    }

    private fun drawDrawable(canvas: Canvas, d: Drawable) {
        val o = d.obj
        if (o == null) {
            canvas.drawBitmap(
                playerBmp,
                project.playerX - playerBmp.width / 2f,
                project.playerY - playerBmp.height + GlyphBox.FEET_PAD,
                bmpPaint
            )
            return
        }
        val asset = project.asset(o.assetId) ?: return
        val bmp = asset.finalBmp ?: return
        val w = bmp.width * o.scale
        val h = bmp.height * o.scale
        bmpPaint.alpha = (o.fadeA * 255f).toInt().coerceIn(0, 255)
        if (asset.swayAmt > 0f) {
            canvas.save()
            canvas.translate(o.x, o.y)
            canvas.skew(sin(time * asset.swaySpeed * 2f + o.x * 0.02f) * asset.swayAmt * 0.12f, 0f)
            rect.set(-w / 2f, -h, w / 2f, 0f)
            canvas.drawBitmap(bmp, null, rect, bmpPaint)
            canvas.restore()
        } else {
            rect.set(o.x - w / 2f, o.y - h, o.x + w / 2f, o.y)
            canvas.drawBitmap(bmp, null, rect, bmpPaint)
        }
        bmpPaint.alpha = 255
    }

    private fun drawOverlays(canvas: Canvas) {
        val sel = selected
        if (sel != null) {
            val a = project.asset(sel.assetId)
            val bmp = a?.finalBmp
            if (a != null && bmp != null) {
                val w = bmp.width * sel.scale
                val h = bmp.height * sel.scale
                ringPaint.strokeWidth = 2f / zoom * 1.6f
                rect.set(sel.x - w / 2f, sel.y - h, sel.x + w / 2f, sel.y)
                canvas.drawRect(rect, ringPaint)
                if (a.solid) {
                    if (a.hasShape()) drawShape(canvas, sel, a, bmp)
                    else {
                        val r = a.footRadius * bmp.width * sel.scale
                        canvas.drawCircle(sel.x, sel.y - r * 0.4f, r, ringPaint)
                    }
                }
            }
        }
        if (touching && (tool == Tool.PAINT || tool == Tool.ERASE)) {
            val r = if (tool == Tool.ERASE) eraseRadius else brushRadius
            ringPaint.strokeWidth = 2f / zoom * 1.6f
            rect.set(touchWX - r, touchWY - r * 0.6f, touchWX + r, touchWY + r * 0.6f)
            canvas.drawOval(rect, ringPaint)
            val c = 8f / zoom * 1.6f
            canvas.drawLine(touchWX - c, touchWY, touchWX + c, touchWY, ringPaint)
            canvas.drawLine(touchWX, touchWY - c, touchWX, touchWY + c, ringPaint)
        }
    }

    private fun drawShape(canvas: Canvas, o: PlacedObject, a: Asset, bmp: Bitmap) {
        val cc = Asset.CC
        val cols = (bmp.width + cc - 1) / cc
        val rows = (bmp.height + cc - 1) / cc
        if (a.collide.size != cols * rows) return
        val ox = o.x - bmp.width * o.scale / 2f
        val oy = o.y - bmp.height * o.scale
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = Color.argb(120, 255, 138, 76)
        for (j in 0 until rows) {
            var i = 0
            while (i < cols) {
                if (a.collide[j * cols + i].toInt() == 0) {
                    i++
                    continue
                }
                var k = i
                while (k < cols && a.collide[j * cols + k].toInt() != 0) k++
                canvas.drawRect(
                    ox + i * cc * o.scale, oy + j * cc * o.scale,
                    ox + k * cc * o.scale, oy + (j + 1) * cc * o.scale, fillPaint
                )
                i = k
            }
        }
    }

    // ------------------------------------------------------------ touch

    private fun wx(sx: Float): Float = (sx - width / 2f) / zoom + camX
    private fun wy(sy: Float): Float = (sy - height / 2f) / zoom + camY

    private fun centroidX(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getX(i)
        return s / e.pointerCount
    }

    private fun centroidY(e: MotionEvent): Float {
        var s = 0f
        for (i in 0 until e.pointerCount) s += e.getY(i)
        return s / e.pointerCount
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                if (mode == Mode.EDIT) beginStroke(e.x, e.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                endStroke()
                multi = true
                lastCx = centroidX(e)
                lastCy = centroidY(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2) {
                    val cx = centroidX(e)
                    val cy = centroidY(e)
                    if (mode == Mode.EDIT) {
                        camX -= (cx - lastCx) / zoom
                        camY -= (cy - lastCy) / zoom
                    }
                    lastCx = cx
                    lastCy = cy
                } else if (!multi && stroking) {
                    moveStroke(e.x, e.y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                endStroke()
                multi = false
            }
        }
        return true
    }

    private fun beginStroke(sx: Float, sy: Float) {
        val x = wx(sx)
        val y = wy(sy)
        touchWX = x
        touchWY = y
        changedInStroke = false
        when (tool) {
            Tool.SELECT -> {
                val hit = hitTest(x, y)
                selected = hit
                dragObj = hit
                if (hit != null) {
                    // Snapshot now, so undo restores the position from before the drag.
                    pushUndo()
                    dragOffX = hit.x - x
                    dragOffY = hit.y - y
                }
                stroking = hit != null
                touching = false
                listener?.onSelectionChanged()
            }
            Tool.PAINT -> {
                pushUndo()
                touching = true
                stroking = true
                stamp(x, y, true)
                lastStampX = x
                lastStampY = y
            }
            Tool.ERASE -> {
                pushUndo()
                touching = true
                stroking = true
                eraseAt(x, y)
            }
        }
    }

    private fun moveStroke(sx: Float, sy: Float) {
        val x = wx(sx)
        val y = wy(sy)
        touchWX = x
        touchWY = y
        when (tool) {
            Tool.SELECT -> {
                val o = dragObj ?: return
                o.x = x + dragOffX
                o.y = y + dragOffY
                changedInStroke = true
            }
            Tool.PAINT -> {
                val spacing = if (brushGrass) brushRadius * 0.3f else brushRadius * 0.9f
                val dx = x - lastStampX
                val dy = y - lastStampY
                if (dx * dx + dy * dy >= spacing * spacing) {
                    stamp(x, y, false)
                    lastStampX = x
                    lastStampY = y
                }
            }
            Tool.ERASE -> eraseAt(x, y)
        }
    }

    private fun endStroke() {
        val wasStroking = stroking || touching
        stroking = false
        touching = false
        dragObj = null
        if (wasStroking && changedInStroke) {
            changedInStroke = false
            listener?.onProjectChanged()
        }
    }

    private fun hitTest(x: Float, y: Float): PlacedObject? {
        for (o in project.objects.sortedByDescending { it.y }) {
            val bmp = project.asset(o.assetId)?.finalBmp ?: continue
            val w = bmp.width * o.scale
            val h = bmp.height * o.scale
            val left = o.x - w / 2f
            val top = o.y - h
            if (x < left || x > left + w || y < top || y > o.y) continue
            val bx = ((x - left) / o.scale).toInt().coerceIn(0, bmp.width - 1)
            val by = ((y - top) / o.scale).toInt().coerceIn(0, bmp.height - 1)
            if ((bmp.getPixel(bx, by) ushr 24) >= 40) return o
        }
        return null
    }

    // ------------------------------------------------------------ brushes

    private fun stamp(x: Float, y: Float, first: Boolean) {
        if (brushGrass) {
            val count = (4 + brushDensity * 26f).toInt()
            for (k in 0 until count) {
                if (project.blades.size >= MAX_BLADES) break
                val ang = rnd.nextFloat() * 2f * PI.toFloat()
                val rr = sqrt(rnd.nextFloat()) * brushRadius
                project.blades.add(Blade(x + cos(ang) * rr, y + sin(ang) * rr * 0.6f, rnd.nextInt()))
            }
            bladesDirty = true
            changedInStroke = true
            return
        }
        val a = project.asset(brushAssetId) ?: return
        val bmp = a.finalBmp ?: return
        if (first) {
            project.objects.add(PlacedObject(a.id, x, y, randomScale()))
            changedInStroke = true
            return
        }
        val count = 1 + (brushDensity * 3f).toInt()
        for (k in 0 until count) {
            val ang = rnd.nextFloat() * 2f * PI.toFloat()
            val rr = sqrt(rnd.nextFloat()) * brushRadius
            val nx = x + cos(ang) * rr
            val ny = y + sin(ang) * rr * 0.6f
            val sc = randomScale()
            val minGap = bmp.width * sc * 0.28f
            var tooClose = false
            for (o in project.objects) {
                if (o.assetId != a.id) continue
                val dx = o.x - nx
                val dy = o.y - ny
                if (dx * dx + dy * dy < minGap * minGap) {
                    tooClose = true
                    break
                }
            }
            if (!tooClose) {
                project.objects.add(PlacedObject(a.id, nx, ny, sc))
                changedInStroke = true
            }
        }
    }

    private fun randomScale(): Float = max(0.2f, 1f + (rnd.nextFloat() * 2f - 1f) * randomSize)

    private fun eraseAt(x: Float, y: Float) {
        val rx = eraseRadius
        val ry = eraseRadius * 0.6f
        val before = project.blades.size + project.objects.size
        project.blades.removeAll { val dx = (it.x - x) / rx; val dy = (it.y - y) / ry; dx * dx + dy * dy <= 1f }
        project.objects.removeAll { val dx = (it.x - x) / rx; val dy = (it.y - y) / ry; dx * dx + dy * dy <= 1f }
        val sel = selected
        if (sel != null && !project.objects.contains(sel)) selected = null
        if (project.blades.size + project.objects.size != before) changedInStroke = true
    }

    companion object {
        private const val PLAYER_SPEED = 150f
        private const val PLAYER_RADIUS = 12f
        private const val MAX_BLADES = 15000
    }
}
