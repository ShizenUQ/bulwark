package com.glyphforge.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen editor for one picture. Two tabs:
 *  - Letters: paint letters onto the black shape.
 *  - Collision: draw the area the player can't walk through, and set how the object behaves.
 * Pinch to zoom, two fingers to pan. [onDone] reports whether the asset should be kept.
 */
class GlyphStudio(
    context: Context,
    private val project: Project,
    private val asset: Asset,
    private val isNew: Boolean,
    startOnCollision: Boolean,
    private val onDone: (Boolean) -> Unit
) : FrameLayout(context) {

    private enum class Tab { LETTERS, COLLISION }
    private enum class CTool { BOX, BRUSH, ERASE }

    private val art = AssetArt(asset, asset.src!!, { id -> project.findSet(id) })
    private val canvasView = StudioCanvas(context)
    private var tab = if (startOnCollision) Tab.COLLISION else Tab.LETTERS
    private var painting = true
    private var ctool = CTool.BOX
    private var brushRadius = 18f
    private var cBrush = 10f

    private lateinit var topBar: LinearLayout
    private lateinit var toolStrip: LinearLayout
    private lateinit var lettersPanel: LinearLayout
    private lateinit var collisionPanel: LinearLayout
    private lateinit var setRow: LinearLayout
    private lateinit var setPreview: GlyphPreview
    private val drawView = GlyphDrawView(context)

    init {
        setBackgroundColor(Ui.BG)
        isClickable = true
        if (isNew && !art.hasPainted()) art.fillLit(0.45f)

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        addView(col, LayoutParams(Ui.MATCH, Ui.MATCH))

        topBar = LinearLayout(context)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(Ui.PANEL)
        topBar.setPadding(dp(10), 0, dp(10), 0)
        col.addView(topBar, LinearLayout.LayoutParams(Ui.MATCH, dp(44)))

        val body = LinearLayout(context)
        body.orientation = LinearLayout.HORIZONTAL
        col.addView(body, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val canvasHolder = FrameLayout(context)
        canvasHolder.addView(canvasView, LayoutParams(Ui.MATCH, Ui.MATCH))
        toolStrip = LinearLayout(context)
        toolStrip.orientation = LinearLayout.VERTICAL
        toolStrip.setPadding(dp(6), dp(6), dp(6), dp(6))
        toolStrip.background = Ui.box(context, Color.argb(235, 13, 24, 21), Ui.LINE, 10)
        val tp = LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.START or Gravity.CENTER_VERTICAL)
        tp.setMargins(dp(10), 0, 0, 0)
        canvasHolder.addView(toolStrip, tp)
        val hint = Ui.text(context, "Pinch to zoom, two fingers to move", 10.5f, Ui.MUTE)
        val hp = LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        hp.bottomMargin = dp(8)
        canvasHolder.addView(hint, hp)
        body.addView(canvasHolder, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))

        val scroll = ScrollView(context)
        scroll.setBackgroundColor(Ui.PANEL)
        val panels = LinearLayout(context)
        panels.orientation = LinearLayout.VERTICAL
        lettersPanel = buildLettersPanel()
        collisionPanel = buildCollisionPanel()
        panels.addView(lettersPanel)
        panels.addView(collisionPanel)
        scroll.addView(panels)
        body.addView(scroll, LinearLayout.LayoutParams(dp(300), Ui.MATCH))

        refreshTab()
    }

    private fun dp(v: Int): Int = Ui.dp(context, v)

    fun requestClose() {
        finish(!isNew)
    }

    private fun finish(save: Boolean) {
        if (save) asset.finalBmp = art.composite()
        onDone(save)
    }

    // ------------------------------------------------------------ top bar, tools

    private fun refreshTab() {
        lettersPanel.visibility = if (tab == Tab.LETTERS) VISIBLE else GONE
        collisionPanel.visibility = if (tab == Tab.COLLISION) VISIBLE else GONE
        topBar.removeAllViews()
        topBar.addView(Ui.button(context, "Back") { requestClose() })
        val gap = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        gap.leftMargin = dp(14)
        topBar.addView(Ui.button(context, "Letters", active = tab == Tab.LETTERS) { tab = Tab.LETTERS; refreshTab() }, gap)
        val gap2 = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        gap2.leftMargin = dp(6)
        topBar.addView(Ui.button(context, "Collision", active = tab == Tab.COLLISION) { tab = Tab.COLLISION; refreshTab() }, gap2)
        topBar.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
        topBar.addView(Ui.button(context, if (isNew) "Add to project" else "Save changes", primary = true) { finish(true) })

        toolStrip.removeAllViews()
        val lp = LinearLayout.LayoutParams(dp(74), Ui.WRAP)
        lp.setMargins(0, dp(3), 0, dp(3))
        if (tab == Tab.LETTERS) {
            toolStrip.addView(Ui.button(context, "Paint", active = painting) { painting = true; refreshTab() }, lp)
            toolStrip.addView(Ui.button(context, "Erase", active = !painting) { painting = false; refreshTab() }, lp)
            toolStrip.addView(Ui.button(context, "Fill lit") { art.fillLit(0.45f); canvasView.invalidate() }, lp)
            toolStrip.addView(Ui.button(context, "Clear") { art.clearMask(); canvasView.invalidate() }, lp)
        } else {
            toolStrip.addView(Ui.button(context, "Box", active = ctool == CTool.BOX) { ctool = CTool.BOX; refreshTab() }, lp)
            toolStrip.addView(Ui.button(context, "Brush", active = ctool == CTool.BRUSH) { ctool = CTool.BRUSH; refreshTab() }, lp)
            toolStrip.addView(Ui.button(context, "Erase", active = ctool == CTool.ERASE) { ctool = CTool.ERASE; refreshTab() }, lp)
            toolStrip.addView(Ui.button(context, "Clear") { art.collideClear(); canvasView.invalidate() }, lp)
        }
        canvasView.invalidate()
    }

    // ------------------------------------------------------------ letters panel

    private fun buildLettersPanel(): LinearLayout {
        val p = LinearLayout(context)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(14), dp(8), dp(14), dp(24))

        p.addView(Ui.section(context, "Name"))
        val name = EditText(context)
        name.setText(asset.name)
        name.setTextColor(Ui.BONE)
        name.textSize = 12.5f
        name.typeface = Typeface.MONOSPACE
        name.setSingleLine(true)
        name.background = Ui.box(context, Ui.BG, Ui.LINE, 6)
        name.setPadding(dp(10), dp(6), dp(10), dp(6))
        name.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                asset.name = s?.toString()?.ifBlank { "Image" } ?: "Image"
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        p.addView(name, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        p.addView(Ui.section(context, "Letters"))
        val hs = HorizontalScrollView(context)
        setRow = LinearLayout(context)
        setRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(setRow)
        p.addView(hs, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setPreview = GlyphPreview(context)
        p.addView(setPreview, LinearLayout.LayoutParams(Ui.MATCH, dp(56)))
        rebuildSets()

        p.addView(Ui.section(context, "Type your own letters"))
        val typed = EditText(context)
        typed.hint = "@#+\$)#*"
        typed.setHintTextColor(Ui.MUTE)
        typed.setTextColor(Ui.MINT)
        typed.textSize = 14f
        typed.typeface = Typeface.MONOSPACE
        typed.setSingleLine(true)
        typed.background = Ui.box(context, Ui.BG, Ui.LINE, 6)
        typed.setPadding(dp(10), dp(6), dp(10), dp(6))
        val existing = project.customSets.firstOrNull { it.id == typedId() }
        if (existing != null) typed.setText(existing.chars)
        typed.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val text = (s?.toString() ?: "").filter { !it.isWhitespace() }
                if (text.isEmpty()) return
                var set = project.customSets.firstOrNull { it.id == typedId() }
                if (set == null) {
                    set = LetterSet(typedId(), "My letters", true, text, mutableListOf(), false)
                    project.customSets.add(set)
                } else {
                    set.chars = text
                }
                asset.setId = set.id
                rebuildSets()
                art.renderAll()
                canvasView.invalidate()
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        p.addView(typed, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        p.addView(Ui.text(context, "Applies right away. Paint letters on the shape with the Paint tool, or tap Fill lit.", 10.5f, Ui.MUTE))

        p.addView(Ui.section(context, "Draw your own letter"))
        val drawRow = LinearLayout(context)
        drawRow.orientation = LinearLayout.HORIZONTAL
        drawRow.gravity = Gravity.CENTER_VERTICAL
        drawRow.addView(drawView, LinearLayout.LayoutParams(dp(100), dp(100)))
        val drawCol = LinearLayout(context)
        drawCol.orientation = LinearLayout.VERTICAL
        drawCol.setPadding(dp(12), 0, 0, 0)
        drawCol.addView(Ui.button(context, "Save to Mine") {
            val bits = drawView.bits()
            if (bits.contains('1')) {
                var mine = project.customSets.firstOrNull { it.id == "mine" }
                if (mine == null) {
                    mine = LetterSet("mine", "Mine", false, "", mutableListOf(), false)
                    project.customSets.add(mine)
                }
                mine.glyphs.add(bits)
                asset.setId = "mine"
                drawView.clear()
                rebuildSets()
                art.renderAll()
                canvasView.invalidate()
            }
        })
        val lpClr = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        lpClr.topMargin = dp(6)
        drawCol.addView(Ui.button(context, "Clear grid") { drawView.clear() }, lpClr)
        drawCol.addView(Ui.text(context, "Tap squares to draw.", 11f, Ui.MUTE))
        drawRow.addView(drawCol)
        p.addView(drawRow)

        p.addView(Ui.section(context, "Size"))
        p.addView(Ui.slider(context, "Brush size", 6f, 60f, brushRadius, { "${it.toInt()} px" }) { brushRadius = it })
        p.addView(Ui.slider(context, "Letter size", 3f, 14f, asset.letterSize, { String.format("%.1f px", it) }) {
            asset.letterSize = it
            relayer()
        })
        p.addView(Ui.slider(context, "Size variation", 0f, 1.5f, asset.sizeVar, { String.format("%.1f px", it) }) {
            asset.sizeVar = it
            relayer()
        })
        p.addView(Ui.slider(context, "Thickness", 0f, 1f, asset.thickness, { "${(it * 100).toInt()}%" }) {
            asset.thickness = it
            relayer()
        })

        p.addView(Ui.section(context, "Colours"))
        val sw = LinearLayout(context)
        sw.orientation = LinearLayout.HORIZONTAL
        sw.gravity = Gravity.CENTER_VERTICAL
        fun labelled(label: String, color: Int, onPick: (Int) -> Unit) {
            val c = LinearLayout(context)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER_HORIZONTAL
            c.addView(Ui.swatch(context, color, 34, onPick))
            c.addView(Ui.text(context, label, 10.5f, Ui.MUTE))
            sw.addView(c, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
        labelled("Shadow", asset.colShadow) { asset.colShadow = it; relayer() }
        labelled("Light", asset.colLight) { asset.colLight = it; relayer() }
        labelled("Dark shape", asset.colDark) {
            asset.colDark = it
            art.rebuildSilhouette()
            canvasView.invalidate()
        }
        p.addView(sw)
        p.addView(Ui.toggle(context, "Use the picture's own colours", asset.pictureColors) {
            asset.pictureColors = it
            relayer()
        })
        return p
    }

    private fun typedId(): String = "typed_" + asset.id

    // ------------------------------------------------------------ collision panel

    private fun buildCollisionPanel(): LinearLayout {
        val p = LinearLayout(context)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(14), dp(8), dp(14), dp(24))
        p.addView(Ui.section(context, "Blocked area"))
        p.addView(Ui.text(context, "Draw where the player can't walk. Box drags a rectangle, Brush paints any shape, Erase removes. Orange = blocked.", 11f, Ui.MUTE))
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val l1 = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        l1.topMargin = dp(8)
        l1.rightMargin = dp(6)
        row.addView(Ui.button(context, "Auto trunk box") { art.collideAutoTrunk(); canvasView.invalidate() }, l1)
        p.addView(row)
        p.addView(Ui.slider(context, "Brush size", 3f, 40f, cBrush, { "${it.toInt()} px" }) { cBrush = it })
        p.addView(Ui.text(context, "With nothing drawn, the game uses a round trunk area (the slider below).", 10.5f, Ui.MUTE))
        p.addView(Ui.section(context, "In the game"))
        addBehaviour(p, asset)
        return p
    }

    private fun relayer() {
        art.renderAll()
        canvasView.invalidate()
    }

    private fun rebuildSets() {
        setRow.removeAllViews()
        for (s in project.allSets()) {
            val b = Ui.button(context, s.name, active = s.id == asset.setId) {
                asset.setId = s.id
                rebuildSets()
                art.renderAll()
                canvasView.invalidate()
            }
            val lp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            lp.rightMargin = dp(6)
            setRow.addView(b, lp)
        }
        setPreview.letterSet = project.findSet(asset.setId)
        setPreview.invalidate()
    }

    // ------------------------------------------------------------ canvas

    private inner class StudioCanvas(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shape = Paint(Paint.ANTI_ALIAS_FLAG)
        private var touching = false
        private var multi = false
        private var tx = 0f
        private var ty = 0f
        private var zoomK = 1f
        private var panX = 0f
        private var panY = 0f
        private var lastCx = 0f
        private var lastCy = 0f
        private var boxing = false
        private var bx0 = 0f
        private var by0 = 0f
        private var bx1 = 0f
        private var by1 = 0f

        private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoomK = (zoomK * detector.scaleFactor).coerceIn(0.6f, 8f)
                invalidate()
                return true
            }
        })

        init {
            p.isFilterBitmap = true
            ring.style = Paint.Style.STROKE
            ring.strokeWidth = 2f
            ring.color = Ui.EMBER
            ring.pathEffect = DashPathEffect(floatArrayOf(8f, 5f), 0f)
            shape.style = Paint.Style.FILL
            shape.color = Color.argb(130, 255, 138, 76)
        }

        private fun scale(): Float = min(width / art.w.toFloat(), height / art.h.toFloat()) * 0.94f * zoomK
        private fun offX(): Float = (width - art.w * scale()) / 2f + panX
        private fun offY(): Float = (height - art.h * scale()) / 2f + panY
        private fun bmpX(sx: Float): Float = (sx - offX()) / scale()
        private fun bmpY(sy: Float): Float = (sy - offY()) / scale()

        override fun onDraw(canvas: Canvas) {
            canvas.drawColor(Color.parseColor("#0B1A15"))
            val s = scale()
            canvas.save()
            canvas.translate(offX(), offY())
            canvas.scale(s, s)
            canvas.drawBitmap(art.silhouette, 0f, 0f, p)
            canvas.drawBitmap(art.letters, 0f, 0f, p)
            if (tab == Tab.COLLISION) {
                val cc = art.cc
                for (j in 0 until art.crows) {
                    var i = 0
                    while (i < art.ccols) {
                        if (asset.collide[j * art.ccols + i].toInt() == 0) {
                            i++
                            continue
                        }
                        var k = i
                        while (k < art.ccols && asset.collide[j * art.ccols + k].toInt() != 0) k++
                        canvas.drawRect((i * cc).toFloat(), (j * cc).toFloat(), (k * cc).toFloat(), ((j + 1) * cc).toFloat(), shape)
                        i = k
                    }
                }
                if (boxing) {
                    canvas.drawRect(min(bx0, bx1), min(by0, by1), max(bx0, bx1), max(by0, by1), shape)
                }
            }
            canvas.restore()
            if (touching && !boxing && (tab == Tab.LETTERS || ctool != CTool.BOX)) {
                val r = if (tab == Tab.LETTERS) brushRadius else cBrush
                canvas.drawCircle(tx, ty, r * s, ring)
            }
        }

        private fun cx(e: MotionEvent): Float {
            var s = 0f
            for (i in 0 until e.pointerCount) s += e.getX(i)
            return s / e.pointerCount
        }

        private fun cy(e: MotionEvent): Float {
            var s = 0f
            for (i in 0 until e.pointerCount) s += e.getY(i)
            return s / e.pointerCount
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            scaler.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    multi = false
                    stroke(e.x, e.y, true)
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    multi = true
                    touching = false
                    boxing = false
                    lastCx = cx(e)
                    lastCy = cy(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {
                        val nx = cx(e)
                        val ny = cy(e)
                        panX += nx - lastCx
                        panY += ny - lastCy
                        lastCx = nx
                        lastCy = ny
                        invalidate()
                    } else if (!multi) {
                        stroke(e.x, e.y, false)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (boxing) {
                        art.collideRect(bx0, by0, bx1, by1, true)
                        boxing = false
                    }
                    touching = false
                    multi = false
                    invalidate()
                }
            }
            return true
        }

        private fun stroke(sx: Float, sy: Float, down: Boolean) {
            touching = true
            tx = sx
            ty = sy
            val x = bmpX(sx)
            val y = bmpY(sy)
            if (tab == Tab.LETTERS) {
                art.paintAt(x, y, brushRadius, painting)
            } else when (ctool) {
                CTool.BOX -> {
                    if (down) {
                        boxing = true
                        bx0 = x
                        by0 = y
                    }
                    bx1 = x
                    by1 = y
                }
                CTool.BRUSH -> art.collideBrush(x, y, cBrush, true)
                CTool.ERASE -> art.collideBrush(x, y, cBrush, false)
            }
            invalidate()
        }
    }

    companion object {
        /** Behaviour settings, shared by the studio and the editor inspector. */
        fun addBehaviour(parent: LinearLayout, a: Asset) {
            val ctx = parent.context
            parent.addView(Ui.toggle(ctx, "Solid (blocks the player)", a.solid) { a.solid = it })
            parent.addView(
                Ui.slider(ctx, "Round blocked area", 0.03f, 0.45f, a.footRadius, { "${(it * 100).toInt()}%" }) {
                    a.footRadius = it
                }
            )
            parent.addView(Ui.toggle(ctx, "Fade when hiding the player", a.fade) { a.fade = it })
            parent.addView(Ui.toggle(ctx, "Casts a shadow", a.shadow) { a.shadow = it })
            parent.addView(Ui.section(ctx, "Motion"))
            parent.addView(Ui.slider(ctx, "Sway in wind", 0f, 1f, a.swayAmt, { "${(it * 100).toInt()}%" }) { a.swayAmt = it })
            parent.addView(Ui.slider(ctx, "Sway speed", 0.2f, 3f, a.swaySpeed, { String.format("%.1fx", it) }) { a.swaySpeed = it })
        }
    }
}

/** A row showing every letter in a set, so you can see what the brush will use. */
class GlyphPreview(ctx: Context) : View(ctx) {
    var letterSet: LetterSet? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val s = letterSet ?: return
        p.color = Ui.MINT
        if (s.isText) {
            p.typeface = Typeface.MONOSPACE
            p.textSize = height * 0.62f
            p.style = Paint.Style.FILL
            canvas.drawText(s.chars, 4f, height * 0.72f, p)
        } else {
            val ps = height / 7f
            p.style = Paint.Style.FILL
            var x = 4f
            for (g in s.glyphs) {
                if (x + ps * 5 > width) break
                for (k in 0 until 25) {
                    if (k < g.length && g[k] == '1') {
                        canvas.drawRect(
                            x + (k % 5) * ps, ps + (k / 5) * ps,
                            x + (k % 5) * ps + ps * 0.9f, ps + (k / 5) * ps + ps * 0.9f, p
                        )
                    }
                }
                x += ps * 6.5f
            }
        }
    }
}

/** A 5x5 grid you tap to draw your own letter. */
class GlyphDrawView(ctx: Context) : View(ctx) {
    private val on = BooleanArray(25)
    private var paintValue = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun bits(): String {
        val sb = StringBuilder()
        for (b in on) sb.append(if (b) '1' else '0')
        return sb.toString()
    }

    fun clear() {
        on.fill(false)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Ui.BG)
        val c = width / 5f
        for (i in 0 until 25) {
            val x = (i % 5) * c
            val y = (i / 5) * c
            p.style = Paint.Style.FILL
            p.color = if (on[i]) Ui.EMBER else Ui.PANEL2
            canvas.drawRect(x + 2f, y + 2f, x + c - 2f, y + c - 2f, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val c = width / 5f
        val cx = (e.x / c).toInt()
        val cy = (e.y / c).toInt()
        if (cx !in 0..4 || cy !in 0..4) return true
        val i = cy * 5 + cx
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            paintValue = !on[i]
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            on[i] = paintValue
            invalidate()
        }
        return true
    }
}
