package com.glyphforge.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/**
 * Full-screen editor that turns one picture into letter art: a black shape you paint letters onto.
 * Settings change the asset live; [onDone] reports whether the asset should be kept.
 */
class GlyphStudio(
    context: Context,
    private val project: Project,
    private val asset: Asset,
    private val isNew: Boolean,
    private val onDone: (Boolean) -> Unit
) : FrameLayout(context) {

    private val art = AssetArt(asset, asset.src!!, { id -> project.findSet(id) })
    private val canvasView = StudioCanvas(context)
    private var painting = true
    private var brushRadius = 18f

    private lateinit var setRow: LinearLayout
    private lateinit var setPreview: GlyphPreview
    private lateinit var paintBtn: TextView
    private lateinit var eraseBtn: TextView
    private val drawView = GlyphDrawView(context)

    init {
        setBackgroundColor(Ui.BG)
        isClickable = true

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        addView(col, LayoutParams(Ui.MATCH, Ui.MATCH))

        col.addView(buildTopBar(), LinearLayout.LayoutParams(Ui.MATCH, dp(44)))

        val body = LinearLayout(context)
        body.orientation = LinearLayout.HORIZONTAL
        col.addView(body, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        val canvasHolder = FrameLayout(context)
        canvasHolder.addView(canvasView, LayoutParams(Ui.MATCH, Ui.MATCH))
        canvasHolder.addView(buildToolStrip(), LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.START or Gravity.CENTER_VERTICAL))
        body.addView(canvasHolder, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))

        val scroll = ScrollView(context)
        scroll.setBackgroundColor(Ui.PANEL)
        scroll.addView(buildPanel())
        body.addView(scroll, LinearLayout.LayoutParams(dp(300), Ui.MATCH))
    }

    private fun dp(v: Int): Int = Ui.dp(context, v)

    fun requestClose() {
        finish(!isNew)
    }

    private fun finish(save: Boolean) {
        if (save) asset.finalBmp = art.composite()
        onDone(save)
    }

    // ------------------------------------------------------------ layout pieces

    private fun buildTopBar(): View {
        val bar = LinearLayout(context)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.PANEL)
        bar.setPadding(dp(10), 0, dp(10), 0)
        bar.addView(Ui.button(context, "Back") { requestClose() })
        val title = Ui.text(context, "Glyph studio", 13f, Ui.MINT, true)
        title.setPadding(dp(12), 0, dp(10), 0)
        bar.addView(title)
        bar.addView(Ui.text(context, "Paint letters onto the black shape", 11.5f, Ui.MUTE))
        bar.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(Ui.button(context, if (isNew) "Add to project" else "Save changes", primary = true) { finish(true) })
        return bar
    }

    private fun buildToolStrip(): View {
        val strip = LinearLayout(context)
        strip.orientation = LinearLayout.VERTICAL
        strip.setPadding(dp(6), dp(6), dp(6), dp(6))
        strip.background = Ui.box(context, Color.argb(235, 13, 24, 21), Ui.LINE, 10)
        val lp = LinearLayout.LayoutParams(dp(78), Ui.WRAP)
        lp.setMargins(0, dp(3), 0, dp(3))

        paintBtn = Ui.button(context, "Paint", active = true) { painting = true; refreshTools() }
        eraseBtn = Ui.button(context, "Erase") { painting = false; refreshTools() }
        strip.addView(paintBtn, lp)
        strip.addView(eraseBtn, lp)
        strip.addView(Ui.button(context, "Fill lit") { art.fillLit(0.5f); canvasView.invalidate() }, lp)
        strip.addView(Ui.button(context, "Clear") { art.clearMask(); canvasView.invalidate() }, lp)
        val m = LayoutParams(Ui.WRAP, Ui.WRAP)
        m.setMargins(dp(10), 0, 0, 0)
        strip.layoutParams = m
        return strip
    }

    private fun refreshTools() {
        val bar = paintBtn.parent as LinearLayout
        val idx = bar.indexOfChild(paintBtn)
        bar.removeViewAt(idx)
        bar.removeView(eraseBtn)
        val lp = LinearLayout.LayoutParams(dp(78), Ui.WRAP)
        lp.setMargins(0, dp(3), 0, dp(3))
        paintBtn = Ui.button(context, "Paint", active = painting) { painting = true; refreshTools() }
        eraseBtn = Ui.button(context, "Erase", active = !painting) { painting = false; refreshTools() }
        bar.addView(paintBtn, idx, lp)
        bar.addView(eraseBtn, idx + 1, lp)
    }

    private fun buildPanel(): View {
        val p = LinearLayout(context)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(14), dp(8), dp(14), dp(24))

        // name
        p.addView(Ui.section(context, "Name"))
        val name = EditText(context)
        name.setText(asset.name)
        name.setTextColor(Ui.BONE)
        name.textSize = 12.5f
        name.typeface = Typeface.MONOSPACE
        name.setSingleLine(true)
        name.background = Ui.box(context, Ui.BG, Ui.LINE, 6)
        name.setPadding(dp(10), dp(6), dp(10), dp(6))
        name.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                asset.name = s?.toString()?.ifBlank { "Image" } ?: "Image"
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        p.addView(name, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        // letter sets
        p.addView(Ui.section(context, "Letters"))
        val hs = HorizontalScrollView(context)
        setRow = LinearLayout(context)
        setRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(setRow)
        p.addView(hs, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setPreview = GlyphPreview(context)
        p.addView(setPreview, LinearLayout.LayoutParams(Ui.MATCH, dp(40)))
        rebuildSets()

        // typed letters
        p.addView(Ui.section(context, "Type your own letters"))
        val typed = EditText(context)
        typed.hint = "@#+\$)#*"
        typed.setHintTextColor(Ui.MUTE)
        typed.setTextColor(Ui.MINT)
        typed.textSize = 14f
        typed.typeface = Typeface.MONOSPACE
        typed.setSingleLine(true)
        typed.background = Ui.box(context, Ui.BG, Ui.LINE, 6)
        typed.setPadding(dp(10), dp(6), dp(10), dp(6))
        p.addView(typed, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        val addTyped = Ui.button(context, "Add as a new set") {
            val text = typed.text.toString().filter { !it.isWhitespace() }
            if (text.isNotEmpty()) {
                val n = project.customSets.count { it.isText } + 1
                val set = LetterSet("t" + System.currentTimeMillis(), "Typed $n", true, text, mutableListOf(), false)
                project.customSets.add(set)
                asset.setId = set.id
                typed.setText("")
                rebuildSets()
                art.renderAll()
                canvasView.invalidate()
            }
        }
        val lpAdd = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        lpAdd.topMargin = dp(6)
        p.addView(addTyped, lpAdd)

        // drawn letters
        p.addView(Ui.section(context, "Draw your own letter"))
        val drawRow = LinearLayout(context)
        drawRow.orientation = LinearLayout.HORIZONTAL
        drawRow.gravity = Gravity.CENTER_VERTICAL
        drawRow.addView(drawView, LinearLayout.LayoutParams(dp(100), dp(100)))
        val drawCol = LinearLayout(context)
        drawCol.orientation = LinearLayout.VERTICAL
        drawCol.setPadding(dp(12), 0, 0, 0)
        drawCol.addView(Ui.button(context, "Save to Mine") {
            val bits = drawView.bits()
            if (bits.contains('1')) {
                var mine = project.customSets.firstOrNull { it.id == "mine" }
                if (mine == null) {
                    mine = LetterSet("mine", "Mine", false, "", mutableListOf(), false)
                    project.customSets.add(mine)
                }
                mine.glyphs.add(bits)
                asset.setId = "mine"
                drawView.clear()
                rebuildSets()
                art.renderAll()
                canvasView.invalidate()
            }
        })
        val clr = Ui.button(context, "Clear grid") { drawView.clear() }
        val lpClr = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        lpClr.topMargin = dp(6)
        drawCol.addView(clr, lpClr)
        drawCol.addView(Ui.text(context, "Tap squares to draw.", 11f, Ui.MUTE))
        drawRow.addView(drawCol)
        p.addView(drawRow)

        // sizes
        p.addView(Ui.section(context, "Size"))
        p.addView(Ui.slider(context, "Brush size", 6f, 60f, brushRadius, { "${it.toInt()} px" }) {
            brushRadius = it
        })
        p.addView(Ui.slider(context, "Letter size", 3f, 12f, asset.letterSize, { String.format("%.1f px", it) }) {
            asset.letterSize = it
            relayer()
        })
        p.addView(Ui.slider(context, "Size variation", 0f, 1.5f, asset.sizeVar, { String.format("%.1f px", it) }) {
            asset.sizeVar = it
            relayer()
        })
        p.addView(Ui.slider(context, "Thickness", 0f, 1f, asset.thickness, { "${(it * 100).toInt()}%" }) {
            asset.thickness = it
            relayer()
        })

        // colours
        p.addView(Ui.section(context, "Colours"))
        val sw = LinearLayout(context)
        sw.orientation = LinearLayout.HORIZONTAL
        sw.gravity = Gravity.CENTER_VERTICAL
        fun labelled(label: String, color: Int, onPick: (Int) -> Unit) {
            val c = LinearLayout(context)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER_HORIZONTAL
            c.addView(Ui.swatch(context, color, 34, onPick))
            c.addView(Ui.text(context, label, 10.5f, Ui.MUTE))
            val lp = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            sw.addView(c, lp)
        }
        labelled("Shadow", asset.colShadow) { asset.colShadow = it; relayer() }
        labelled("Light", asset.colLight) { asset.colLight = it; relayer() }
        labelled("Dark shape", asset.colDark) {
            asset.colDark = it
            art.rebuildSilhouette()
            canvasView.invalidate()
        }
        p.addView(sw)
        p.addView(Ui.toggle(context, "Use the picture's own colours", asset.pictureColors) {
            asset.pictureColors = it
            relayer()
        })

        // behaviour
        p.addView(Ui.section(context, "In the game"))
        addBehaviour(p, asset)
        return p
    }

    private fun relayer() {
        art.renderAll()
        canvasView.invalidate()
    }

    private fun rebuildSets() {
        setRow.removeAllViews()
        for (s in project.allSets()) {
            val b = Ui.button(context, s.name, active = s.id == asset.setId) {
                asset.setId = s.id
                rebuildSets()
                art.renderAll()
                canvasView.invalidate()
            }
            val lp = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
            lp.rightMargin = dp(6)
            setRow.addView(b, lp)
        }
        setPreview.letterSet = project.findSet(asset.setId)
        setPreview.invalidate()
    }

    // ------------------------------------------------------------ canvas

    private inner class StudioCanvas(ctx: Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        private var touching = false
        private var tx = 0f
        private var ty = 0f

        init {
            p.isFilterBitmap = true
            ring.style = Paint.Style.STROKE
            ring.strokeWidth = 2f
            ring.color = Ui.EMBER
            ring.pathEffect = DashPathEffect(floatArrayOf(8f, 5f), 0f)
        }

        private fun scale(): Float = min(width / art.w.toFloat(), height / art.h.toFloat()) * 0.94f
        private fun offX(): Float = (width - art.w * scale()) / 2f
        private fun offY(): Float = (height - art.h * scale()) / 2f

        override fun onDraw(canvas: Canvas) {
            canvas.drawColor(Color.parseColor("#0B1A15"))
            val s = scale()
            canvas.save()
            canvas.translate(offX(), offY())
            canvas.scale(s, s)
            canvas.drawBitmap(art.silhouette, 0f, 0f, p)
            canvas.drawBitmap(art.letters, 0f, 0f, p)
            canvas.restore()
            if (touching) {
                canvas.drawCircle(tx, ty, brushRadius * s, ring)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    touching = true
                    tx = e.x
                    ty = e.y
                    val s = scale()
                    art.paintAt((e.x - offX()) / s, (e.y - offY()) / s, brushRadius, painting)
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    touching = false
                    invalidate()
                }
            }
            return true
        }
    }

    companion object {
        /** Solid / pass-through rules, shared by the studio and the editor inspector. */
        fun addBehaviour(parent: LinearLayout, a: Asset) {
            val ctx = parent.context
            parent.addView(Ui.toggle(ctx, "Solid (blocks the player)", a.solid) { a.solid = it })
            parent.addView(
                Ui.slider(ctx, "Blocked area size", 0.03f, 0.45f, a.footRadius, { "${(it * 100).toInt()}%" }) {
                    a.footRadius = it
                }
            )
            parent.addView(Ui.toggle(ctx, "Fade when hiding the player", a.fade) { a.fade = it })
            parent.addView(Ui.toggle(ctx, "Casts a shadow", a.shadow) { a.shadow = it })
        }
    }
}

/** A row showing every letter in a set, so you can see what the brush will use. */
class GlyphPreview(ctx: Context) : View(ctx) {
    var letterSet: LetterSet? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val s = letterSet ?: return
        p.color = Ui.MINT
        if (s.isText) {
            p.typeface = Typeface.MONOSPACE
            p.textSize = height * 0.5f
            p.style = Paint.Style.FILL
            canvas.drawText(s.chars, 4f, height * 0.7f, p)
        } else {
            val ps = height / 7f
            p.style = Paint.Style.FILL
            var x = 4f
            for (g in s.glyphs) {
                if (x + ps * 5 > width) break
                for (k in 0 until 25) {
                    if (k < g.length && g[k] == '1') {
                        canvas.drawRect(
                            x + (k % 5) * ps, ps + (k / 5) * ps,
                            x + (k % 5) * ps + ps * 0.9f, ps + (k / 5) * ps + ps * 0.9f, p
                        )
                    }
                }
                x += ps * 6.5f
            }
        }
    }
}

/** A 5x5 grid you tap to draw your own letter. */
class GlyphDrawView(ctx: Context) : View(ctx) {
    private val on = BooleanArray(25)
    private var paintValue = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun bits(): String {
        val sb = StringBuilder()
        for (b in on) sb.append(if (b) '1' else '0')
        return sb.toString()
    }

    fun clear() {
        on.fill(false)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Ui.BG)
        val c = width / 5f
        for (i in 0 until 25) {
            val x = (i % 5) * c
            val y = (i / 5) * c
            p.style = Paint.Style.FILL
            p.color = if (on[i]) Ui.EMBER else Ui.PANEL2
            canvas.drawRect(x + 2f, y + 2f, x + c - 2f, y + c - 2f, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val c = width / 5f
        val cx = (e.x / c).toInt()
        val cy = (e.y / c).toInt()
        if (cx !in 0..4 || cy !in 0..4) return true
        val i = cy * 5 + cx
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            paintValue = !on[i]
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            on[i] = paintValue
            invalidate()
        }
        return true
    }
}
