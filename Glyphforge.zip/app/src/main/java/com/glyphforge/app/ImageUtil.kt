package com.glyphforge.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlin.math.abs
import kotlin.math.max

object ImageUtil {

    /** Loads an image from a file the user picked, shrunk so its longest side is [maxSide]. */
    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null

            val scale = maxSide.toFloat() / max(raw.width, raw.height)
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    raw,
                    max(1, (raw.width * scale).toInt()),
                    max(1, (raw.height * scale).toInt()),
                    true
                )
            } else raw
            out.copy(Bitmap.Config.ARGB_8888, true)
        } catch (e: Exception) {
            null
        }
    }

    /** True if the picture already has see-through parts (a cutout). */
    fun hasAlpha(bmp: Bitmap): Boolean {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        var clear = 0
        for (p in px) if ((p ushr 24) < 200) clear++
        return clear > (w * h) / 50
    }

    /**
     * For pictures without a cutout: makes everything that looks like the background
     * transparent, starting from the edges and spreading inward.
     */
    fun removeBackground(bmp: Bitmap, tolerance: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        val corners = intArrayOf(px[0], px[w - 1], px[(h - 1) * w], px[h * w - 1])
        var r = 0
        var g = 0
        var b = 0
        for (c in corners) {
            r += (c shr 16) and 255
            g += (c shr 8) and 255
            b += c and 255
        }
        r /= 4; g /= 4; b /= 4

        fun close(p: Int): Boolean {
            val dr = abs(((p shr 16) and 255) - r)
            val dg = abs(((p shr 8) and 255) - g)
            val db = abs((p and 255) - b)
            return dr + dg + db <= tolerance * 3
        }

        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        var sp = 0
        fun push(i: Int) {
            if (!seen[i] && close(px[i])) {
                seen[i] = true
                stack[sp++] = i
            }
        }
        for (x in 0 until w) {
            push(x)
            push((h - 1) * w + x)
        }
        for (y in 0 until h) {
            push(y * w)
            push(y * w + w - 1)
        }
        while (sp > 0) {
            val i = stack[--sp]
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        for (i in 0 until w * h) if (seen[i]) px[i] = 0
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
