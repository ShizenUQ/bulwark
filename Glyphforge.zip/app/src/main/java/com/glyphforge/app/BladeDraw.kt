package com.glyphforge.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * One grass blade: a stroke leaning like "/", some thin and some thick, with a thicker dot on the tip.
 * Everything about a blade comes from its seed plus the layer's [GrassStyle], so changing the style
 * changes every blade already painted.
 */
object BladeDraw {

    fun rf(seed: Int, k: Int): Float {
        var n = seed * 1103515245 + k * 12345 + 777
        n = n xor (n ushr 13)
        n *= 1274126177
        n = n xor (n ushr 16)
        return (n and 0xFFFF) / 65535f
    }

    fun draw(c: Canvas, p: Paint, x: Float, y: Float, seed: Int, st: GrassStyle, time: Float, size: Float) {
        val thick = rf(seed, 1) < st.thickRatio
        val w = max(0.8f, if (thick) st.thickness else st.thickness * 0.35f) * size
        val len = st.length * (0.6f + 0.8f * rf(seed, 2)) * size
        var lean = st.lean * (0.6f + 0.8f * rf(seed, 3))
        lean += sin(time * 2f + x * 0.05f) * st.sway * 7f
        val rad = Math.toRadians(lean.toDouble()).toFloat()
        val dx = sin(rad) * len
        val dy = -cos(rad) * len

        val ci = (rf(seed, 4) * st.colors.size).toInt().coerceIn(0, st.colors.size - 1)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = w
        p.color = st.colors[ci]
        c.drawLine(x, y, x + dx, y + dy, p)

        p.style = Paint.Style.FILL
        p.color = if (rf(seed, 5) < 0.12f) st.accentColor else st.tipColor
        c.drawCircle(x + dx, y + dy, max(1f, w * 0.62f) * st.tipDot * size, p)
    }
}

/** A strip of sample blades shown in the inspector so changes are visible right away. */
class BladePreview(ctx: Context, private val style: GrassStyle) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var time = 0f

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Ui.BG)
        val n = 12
        val step = width / (n + 1).toFloat()
        for (i in 0 until n) {
            // Fixed seeds so the preview is stable; every third blade is thick.
            val seed = 11 + i * 37
            BladeDraw.draw(canvas, p, step * (i + 1), height - 8f, seed, style, time, 1f)
        }
        time += 0.016f
        postInvalidateOnAnimation()
    }
}
