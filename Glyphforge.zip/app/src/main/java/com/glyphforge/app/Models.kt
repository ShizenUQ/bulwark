package com.glyphforge.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * A set of letters a brush can paint with. Either typed characters (isText) or little
 * 5x5 pixel shapes stored as 25-character strings of 0 and 1, row by row.
 */
class LetterSet(
    val id: String,
    var name: String,
    val isText: Boolean,
    var chars: String,
    val glyphs: MutableList<String>,
    val builtIn: Boolean
)

object LetterSets {
    private fun g(vararg rows: String): String {
        val sb = StringBuilder()
        for (r in rows) for (c in r) sb.append(if (c == '#') '1' else '0')
        return sb.toString()
    }

    val builtIn: List<LetterSet> = listOf(
        LetterSet(
            "leaves", "Leaves", false, "",
            mutableListOf(
                g(".#...", "###..", ".###.", "..###", "...#."),
                g("..#..", ".###.", "#####", ".###.", "..#.."),
                g("#..#.", ".##..", "####.", ".##..", "#..#."),
                g(".##..", "####.", "#.###", ".###.", "..#.."),
                g("#.#..", ".###.", "#####", ".###.", ".#.#."),
                g("..##.", ".###.", "###..", ".##..", "#....")
            ),
            true
        ),
        LetterSet(
            "bark", "Bark", false, "",
            mutableListOf(
                g("#.#.#", ".#.#.", "#.#.#", ".#.#.", "#.#.#"),
                g("##...", "#.##.", "..#..", ".##.#", "...##"),
                g("#...#", "#.#.#", "#.#.#", "#.#.#", "#...#"),
                g(".#.#.", "#.#.#", ".#.#.", "#.#.#", ".#.#.")
            ),
            true
        ),
        LetterSet(
            "stars", "Stars", false, "",
            mutableListOf(
                g("..#..", "..#..", "#####", "..#..", "..#.."),
                g("#...#", ".#.#.", "..#..", ".#.#.", "#...#")
            ),
            true
        ),
        LetterSet(
            "dust", "Dust", false, "",
            mutableListOf(
                g(".....", "..#..", ".###.", "..#..", "....."),
                g(".....", ".....", "..#..", ".....", "....."),
                g(".....", ".#...", ".....", "...#.", "....."),
                g("#....", ".....", "..#..", ".....", "....#")
            ),
            true
        ),
        LetterSet("symbols", "Symbols", true, "@#+$)*%&", mutableListOf(), true)
    )
}

/** One thing standing in the world. Its picture comes from the asset with [assetId]. */
data class PlacedObject(var assetId: String, var x: Float, var y: Float, var scale: Float) {
    /** Runtime only: 1 = fully visible, lower while the player hides behind it. */
    var fadeA: Float = 1f
}

class Blade(var x: Float, var y: Float, val seed: Int)

class GrassStyle {
    var thickness = 3f
    var thickRatio = 0.38f
    var length = 18f
    var lean = 22f
    var tipDot = 1f
    var sway = 0.35f
    var colors = intArrayOf(
        Color.parseColor("#2F7A55"),
        Color.parseColor("#3F9A6C"),
        Color.parseColor("#58B585")
    )
    var tipColor = Color.parseColor("#CFE9D8")
    var accentColor = Color.parseColor("#FFB27A")

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("thickness", thickness.toDouble())
        o.put("thickRatio", thickRatio.toDouble())
        o.put("length", length.toDouble())
        o.put("lean", lean.toDouble())
        o.put("tipDot", tipDot.toDouble())
        o.put("sway", sway.toDouble())
        val arr = JSONArray()
        for (c in colors) arr.put(c)
        o.put("colors", arr)
        o.put("tipColor", tipColor)
        o.put("accentColor", accentColor)
        return o
    }

    fun load(o: JSONObject) {
        thickness = o.optDouble("thickness", thickness.toDouble()).toFloat()
        thickRatio = o.optDouble("thickRatio", thickRatio.toDouble()).toFloat()
        length = o.optDouble("length", length.toDouble()).toFloat()
        lean = o.optDouble("lean", lean.toDouble()).toFloat()
        tipDot = o.optDouble("tipDot", tipDot.toDouble()).toFloat()
        sway = o.optDouble("sway", sway.toDouble()).toFloat()
        val arr = o.optJSONArray("colors")
        if (arr != null && arr.length() >= 3) {
            colors = intArrayOf(arr.getInt(0), arr.getInt(1), arr.getInt(2))
        }
        tipColor = o.optInt("tipColor", tipColor)
        accentColor = o.optInt("accentColor", accentColor)
    }
}

/** A picture turned into letter art, plus how it behaves in the world. */
class Asset(val id: String) {
    var name = "Image"

    // look
    var setId = "leaves"
    var letterSize = 3.5f
    var sizeVar = 0.8f
    var thickness = 0.2f
    var colShadow: Int = Color.parseColor("#1F5A3A")
    var colLight: Int = Color.parseColor("#9DF5C5")
    var colDark: Int = Color.parseColor("#020605")
    var pictureColors = false

    /** Where letters are painted, on a fixed 3 px grid (see AssetArt.MC). */
    var mask = ByteArray(0)

    // behaviour
    var solid = true
    var footRadius = 0.12f
    var fade = true
    var shadow = true

    // runtime
    var src: Bitmap? = null
    var finalBmp: Bitmap? = null

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("setId", setId)
        o.put("letterSize", letterSize.toDouble())
        o.put("sizeVar", sizeVar.toDouble())
        o.put("thickness", thickness.toDouble())
        o.put("colShadow", colShadow)
        o.put("colLight", colLight)
        o.put("colDark", colDark)
        o.put("pictureColors", pictureColors)
        o.put("mask", Base64.encodeToString(mask, Base64.NO_WRAP))
        o.put("solid", solid)
        o.put("footRadius", footRadius.toDouble())
        o.put("fade", fade)
        o.put("shadow", shadow)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Asset {
            val a = Asset(o.getString("id"))
            a.name = o.optString("name", "Image")
            a.setId = o.optString("setId", "leaves")
            a.letterSize = o.optDouble("letterSize", 3.5).toFloat()
            a.sizeVar = o.optDouble("sizeVar", 0.8).toFloat()
            a.thickness = o.optDouble("thickness", 0.2).toFloat()
            a.colShadow = o.optInt("colShadow", a.colShadow)
            a.colLight = o.optInt("colLight", a.colLight)
            a.colDark = o.optInt("colDark", a.colDark)
            a.pictureColors = o.optBoolean("pictureColors", false)
            val m = o.optString("mask", "")
            a.mask = if (m.isEmpty()) ByteArray(0) else Base64.decode(m, Base64.NO_WRAP)
            a.solid = o.optBoolean("solid", true)
            a.footRadius = o.optDouble("footRadius", 0.12).toFloat()
            a.fade = o.optBoolean("fade", true)
            a.shadow = o.optBoolean("shadow", true)
            return a
        }
    }
}

class Project {
    var name = "Untitled game"
    val assets = ArrayList<Asset>()
    val objects = ArrayList<PlacedObject>()
    val blades = ArrayList<Blade>()
    val grass = GrassStyle()
    val customSets = ArrayList<LetterSet>()
    var playerX = 0f
    var playerY = 0f

    fun allSets(): List<LetterSet> = LetterSets.builtIn + customSets

    fun findSet(id: String): LetterSet =
        allSets().firstOrNull { it.id == id } ?: LetterSets.builtIn[0]

    fun asset(id: String?): Asset? = if (id == null) null else assets.firstOrNull { it.id == id }

    fun isEmpty(): Boolean = objects.isEmpty() && blades.isEmpty()

    /** Rebuilds the finished letter picture of an asset after its settings or mask change. */
    fun rebuild(a: Asset) {
        val s = a.src ?: return
        a.finalBmp = AssetArt(a, s) { id -> findSet(id) }.composite()
    }

    fun save(dir: File) {
        val o = JSONObject()
        o.put("name", name)
        o.put("playerX", playerX.toDouble())
        o.put("playerY", playerY.toDouble())
        o.put("grass", grass.toJson())

        val aa = JSONArray()
        for (a in assets) aa.put(a.toJson())
        o.put("assets", aa)

        val oa = JSONArray()
        for (p in objects) {
            val po = JSONObject()
            po.put("a", p.assetId)
            po.put("x", p.x.toDouble())
            po.put("y", p.y.toDouble())
            po.put("s", p.scale.toDouble())
            oa.put(po)
        }
        o.put("objects", oa)

        val ba = JSONArray()
        for (b in blades) {
            ba.put(b.x.toDouble())
            ba.put(b.y.toDouble())
            ba.put(b.seed)
        }
        o.put("blades", ba)

        val sa = JSONArray()
        for (s in customSets) {
            val so = JSONObject()
            so.put("id", s.id)
            so.put("name", s.name)
            so.put("isText", s.isText)
            so.put("chars", s.chars)
            val ga = JSONArray()
            for (g in s.glyphs) ga.put(g)
            so.put("glyphs", ga)
            sa.put(so)
        }
        o.put("sets", sa)

        File(dir, "project.json").writeText(o.toString())
    }

    companion object {
        fun load(dir: File): Project? {
            val f = File(dir, "project.json")
            if (!f.exists()) return null
            return try {
                val o = JSONObject(f.readText())
                val p = Project()
                p.name = o.optString("name", "Untitled game")
                p.playerX = o.optDouble("playerX", 0.0).toFloat()
                p.playerY = o.optDouble("playerY", 0.0).toFloat()
                o.optJSONObject("grass")?.let { p.grass.load(it) }

                val sa = o.optJSONArray("sets")
                if (sa != null) {
                    for (i in 0 until sa.length()) {
                        val so = sa.getJSONObject(i)
                        val glyphs = ArrayList<String>()
                        val ga = so.optJSONArray("glyphs")
                        if (ga != null) for (k in 0 until ga.length()) glyphs.add(ga.getString(k))
                        p.customSets.add(
                            LetterSet(
                                so.getString("id"), so.optString("name", "Set"),
                                so.optBoolean("isText", false), so.optString("chars", ""),
                                glyphs, false
                            )
                        )
                    }
                }

                val aa = o.optJSONArray("assets")
                if (aa != null) {
                    for (i in 0 until aa.length()) {
                        val a = Asset.fromJson(aa.getJSONObject(i))
                        val bmp = BitmapFactory.decodeFile(File(dir, "a_${a.id}.png").path)
                        if (bmp != null) {
                            a.src = bmp
                            p.assets.add(a)
                            p.rebuild(a)
                        }
                    }
                }

                val oa = o.optJSONArray("objects")
                if (oa != null) {
                    for (i in 0 until oa.length()) {
                        val po = oa.getJSONObject(i)
                        val id = po.getString("a")
                        if (p.asset(id) == null) continue
                        p.objects.add(
                            PlacedObject(
                                id, po.getDouble("x").toFloat(), po.getDouble("y").toFloat(),
                                po.optDouble("s", 1.0).toFloat()
                            )
                        )
                    }
                }

                val ba = o.optJSONArray("blades")
                if (ba != null) {
                    var i = 0
                    while (i + 2 < ba.length()) {
                        p.blades.add(Blade(ba.getDouble(i).toFloat(), ba.getDouble(i + 1).toFloat(), ba.getInt(i + 2)))
                        i += 3
                    }
                }
                p
            } catch (e: Exception) {
                null
            }
        }
    }
}
