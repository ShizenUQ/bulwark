package com.glyphforge.app

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Small helpers so every screen shares one look. All views are built in code. */
object Ui {
    val BG: Int = Color.parseColor("#050D0B")
    val PANEL: Int = Color.parseColor("#0D1815")
    val PANEL2: Int = Color.parseColor("#122019")
    val LINE: Int = Color.parseColor("#1E322B")
    val BONE: Int = Color.parseColor("#E4ECE6")
    val MUTE: Int = Color.parseColor("#7F9C90")
    val MINT: Int = Color.parseColor("#7CF2C0")
    val EMBER: Int = Color.parseColor("#FF8A4C")
    val EMBERD: Int = Color.parseColor("#33201A")
    val INK: Int = Color.parseColor("#1A0D06")

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun box(ctx: Context, fill: Int, stroke: Int, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = radiusDp * ctx.resources.displayMetrics.density
        if (stroke != 0) d.setStroke(dp(ctx, 1), stroke)
        return d
    }

    fun text(ctx: Context, s: String, sp: Float = 12f, color: Int = BONE, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
        return t
    }

    fun button(
        ctx: Context,
        label: String,
        active: Boolean = false,
        primary: Boolean = false,
        onClick: () -> Unit
    ): TextView {
        val color = if (primary) INK else if (active) EMBER else BONE
        val t = text(ctx, label, 12f, color, primary)
        t.gravity = Gravity.CENTER
        t.minHeight = dp(ctx, 32)
        t.setPadding(dp(ctx, 12), dp(ctx, 5), dp(ctx, 12), dp(ctx, 5))
        val fill = if (primary) EMBER else if (active) EMBERD else PANEL2
        val stroke = if (primary || active) EMBER else LINE
        t.background = box(ctx, fill, stroke, 6)
        t.setOnClickListener { onClick() }
        return t
    }

    fun section(ctx: Context, title: String): TextView {
        val t = text(ctx, title, 11.5f, MUTE)
        t.setPadding(0, dp(ctx, 12), 0, dp(ctx, 3))
        return t
    }

    fun slider(
        ctx: Context,
        label: String,
        min: Float,
        max: Float,
        value: Float,
        fmt: (Float) -> String,
        onChange: (Float) -> Unit
    ): LinearLayout {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(ctx, 3), 0, dp(ctx, 1))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val name = text(ctx, label, 11.5f, MUTE)
        val shown = text(ctx, fmt(value), 11.5f, BONE)
        row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(shown)
        col.addView(row)
        val sb = SeekBar(ctx)
        sb.max = 1000
        sb.progress = (((value - min) / (max - min)) * 1000f).toInt().coerceIn(0, 1000)
        sb.progressTintList = ColorStateList.valueOf(EMBER)
        sb.thumbTintList = ColorStateList.valueOf(BONE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val x = min + (max - min) * p / 1000f
                shown.text = fmt(x)
                onChange(x)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        return col
    }

    fun toggle(ctx: Context, label: String, on: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(ctx, 4), 0, dp(ctx, 4))
        row.addView(text(ctx, label, 12f, BONE), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(ctx)
        sw.isChecked = on
        sw.thumbTintList = ColorStateList.valueOf(EMBER)
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        row.addView(sw)
        return row
    }

    /** A tappable colour square that opens the colour picker. */
    fun swatch(ctx: Context, color: Int, sizeDp: Int, onPick: (Int) -> Unit): View {
        val v = View(ctx)
        v.background = box(ctx, color, Color.argb(70, 255, 255, 255), 6)
        v.layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        v.setOnClickListener {
            pickColor(ctx, color) { c ->
                v.background = box(ctx, c, Color.argb(70, 255, 255, 255), 6)
                onPick(c)
            }
        }
        return v
    }

    fun pickColor(ctx: Context, initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 8))
        col.setBackgroundColor(PANEL)
        val preview = View(ctx)
        preview.setBackgroundColor(Color.HSVToColor(hsv))
        col.addView(preview, LinearLayout.LayoutParams(MATCH, dp(ctx, 44)))

        fun addSeek(label: String, max: Int, start: Int, apply: (Int) -> Unit) {
            col.addView(text(ctx, label, 11f, MUTE))
            val sb = SeekBar(ctx)
            sb.max = max
            sb.progress = start
            sb.progressTintList = ColorStateList.valueOf(EMBER)
            sb.thumbTintList = ColorStateList.valueOf(BONE)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    apply(p)
                    preview.setBackgroundColor(Color.HSVToColor(hsv))
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        addSeek("Hue", 360, hsv[0].toInt().coerceIn(0, 360)) { hsv[0] = it.toFloat() }
        addSeek("Saturation", 100, (hsv[1] * 100f).toInt()) { hsv[1] = it / 100f }
        addSeek("Brightness", 100, (hsv[2] * 100f).toInt()) { hsv[2] = it / 100f }

        AlertDialog.Builder(ctx)
            .setView(col)
            .setPositiveButton("Use colour") { _, _ -> onPick(Color.HSVToColor(hsv)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
