package com.glyphforge.app

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MainActivity : AppCompatActivity(), WorldView.Listener {

    private lateinit var project: Project
    private lateinit var world: WorldView
    private lateinit var root: FrameLayout

    private lateinit var projLabel: TextView
    private lateinit var editBar: LinearLayout
    private lateinit var segEdit: TextView
    private lateinit var segGame: TextView
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var rail: LinearLayout
    private lateinit var trayScroll: HorizontalScrollView
    private lateinit var tray: LinearLayout
    private lateinit var inspectorScroll: ScrollView
    private lateinit var inspector: LinearLayout
    private lateinit var sceneScroll: ScrollView
    private lateinit var scene: LinearLayout
    private lateinit var hint: LinearLayout
    private lateinit var joystick: VirtualJoystick
    private lateinit var fab: TextView
    private var studio: GlyphStudio? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) onImagePicked(uri)
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        project = Project.load(filesDir) ?: Project()
        world = WorldView(this, project)
        world.listener = this

        root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)
        root.addView(world, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        buildTopBar()
        buildRail()
        buildTray()
        buildPanels()
        buildGameUi()
        setContentView(root)

        // The app always opens on the game preview. A brand new project is completely empty.
        applyMode(WorldView.Mode.GAME)
        enterImmersive()
    }

    override fun onPause() {
        saveQuietly()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val s = studio
        if (s != null) s.requestClose() else super.onBackPressed()
    }

    private fun enterImmersive() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun saveQuietly() {
        try {
            project.save(filesDir)
        } catch (e: Exception) {
            // Saving is best effort here; the Save button reports problems.
        }
    }

    private fun saveNow() {
        try {
            project.save(filesDir)
            toast("Saved")
        } catch (e: Exception) {
            toast("Couldn't save: " + (e.message ?: "unknown error"))
        }
    }

    // ------------------------------------------------------------ world callbacks

    override fun onSelectionChanged() {
        refreshInspector()
    }

    override fun onProjectChanged() {
        refreshScene()
        refreshHint()
        updateUndo()
    }

    // ------------------------------------------------------------ building the screen

    private fun lp(left: Int = 0, right: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        p.leftMargin = dp(left)
        p.rightMargin = dp(right)
        return p
    }

    private fun segLabel(label: String, onClick: () -> Unit): TextView {
        val t = Ui.text(this, label, 12f, Ui.MUTE)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(6), dp(12), dp(6))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildTopBar() {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Ui.PANEL)
        bar.setPadding(dp(10), 0, dp(10), 0)

        bar.addView(LogoView(this), LinearLayout.LayoutParams(dp(26), dp(26)))
        val brand = Ui.text(this, "Glyphforge", 13f, Ui.MINT, true)
        brand.setPadding(dp(8), 0, dp(10), 0)
        bar.addView(brand)
        projLabel = Ui.text(this, project.name, 12f, Ui.BONE)
        projLabel.setOnClickListener { renameProject() }
        bar.addView(projLabel)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        editBar = LinearLayout(this)
        editBar.orientation = LinearLayout.HORIZONTAL
        editBar.gravity = Gravity.CENTER_VERTICAL
        undoBtn = Ui.button(this, "Undo") { world.undo(); updateUndo() }
        redoBtn = Ui.button(this, "Redo") { world.redo(); updateUndo() }
        editBar.addView(undoBtn, lp(0, 6))
        editBar.addView(redoBtn, lp(0, 6))
        editBar.addView(Ui.button(this, "Scene") { toggle(sceneScroll, inspectorScroll) }, lp(0, 6))
        editBar.addView(Ui.button(this, "Settings") { toggle(inspectorScroll, sceneScroll) }, lp(0, 6))
        bar.addView(editBar)

        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = Ui.box(this, Ui.PANEL2, Ui.LINE, 6)
        segEdit = segLabel("Edit") { applyMode(WorldView.Mode.EDIT) }
        segGame = segLabel("Game view") { applyMode(WorldView.Mode.GAME) }
        seg.addView(segEdit)
        seg.addView(segGame)
        bar.addView(seg, lp(4, 8))
        bar.addView(Ui.button(this, "Save") { saveNow() })

        root.addView(bar, FrameLayout.LayoutParams(Ui.MATCH, dp(44), Gravity.TOP))
    }

    private fun toggle(show: View, hide: View) {
        hide.visibility = View.GONE
        show.visibility = if (show.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun buildRail() {
        rail = LinearLayout(this)
        rail.orientation = LinearLayout.VERTICAL
        rail.setPadding(dp(4), dp(4), dp(4), dp(4))
        rail.background = Ui.box(this, Color.argb(235, 13, 24, 21), Ui.LINE, 10)
        val p = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP or Gravity.START)
        p.topMargin = dp(52)
        p.leftMargin = dp(6)
        root.addView(rail, p)
    }

    private fun buildTray() {
        tray = LinearLayout(this)
        tray.orientation = LinearLayout.HORIZONTAL
        tray.gravity = Gravity.CENTER_VERTICAL
        tray.setPadding(dp(8), dp(6), dp(8), dp(6))
        trayScroll = HorizontalScrollView(this)
        trayScroll.background = Ui.box(this, Color.argb(240, 13, 24, 21), Ui.LINE, 10)
        trayScroll.addView(tray)
        val p = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        p.bottomMargin = dp(8)
        p.leftMargin = dp(70)
        p.rightMargin = dp(70)
        root.addView(trayScroll, p)
    }

    private fun buildPanels() {
        inspector = LinearLayout(this)
        inspector.orientation = LinearLayout.VERTICAL
        inspector.setPadding(dp(14), dp(10), dp(14), dp(16))
        inspectorScroll = ScrollView(this)
        inspectorScroll.background = Ui.box(this, Color.argb(246, 13, 24, 21), Ui.LINE, 10)
        inspectorScroll.addView(inspector)
        val ip = FrameLayout.LayoutParams(dp(270), Ui.MATCH, Gravity.END or Gravity.TOP)
        ip.topMargin = dp(50)
        ip.bottomMargin = dp(92)
        ip.rightMargin = dp(6)
        root.addView(inspectorScroll, ip)
        inspectorScroll.visibility = View.GONE

        scene = LinearLayout(this)
        scene.orientation = LinearLayout.VERTICAL
        scene.setPadding(dp(12), dp(10), dp(12), dp(14))
        sceneScroll = ScrollView(this)
        sceneScroll.background = Ui.box(this, Color.argb(246, 13, 24, 21), Ui.LINE, 10)
        sceneScroll.addView(scene)
        val sp = FrameLayout.LayoutParams(dp(250), Ui.MATCH, Gravity.START or Gravity.TOP)
        sp.topMargin = dp(50)
        sp.bottomMargin = dp(92)
        sp.leftMargin = dp(70)
        root.addView(sceneScroll, sp)
        sceneScroll.visibility = View.GONE
    }

    private fun buildGameUi() {
        hint = LinearLayout(this)
        hint.orientation = LinearLayout.VERTICAL
        hint.gravity = Gravity.CENTER_HORIZONTAL
        hint.addView(Ui.text(this, "Your world is empty", 16f, Ui.BONE, true))
        val sub = Ui.text(this, "Tap + to add land, a tree, or an image from your files.", 12f, Ui.MUTE)
        sub.setPadding(0, dp(6), 0, 0)
        hint.addView(sub)
        val hp = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER)
        hp.topMargin = dp(120)
        root.addView(hint, hp)

        joystick = VirtualJoystick(this)
        joystick.onChange = { x, y -> world.setJoystick(x, y) }
        val jp = FrameLayout.LayoutParams(dp(140), dp(140), Gravity.BOTTOM or Gravity.START)
        jp.leftMargin = dp(28)
        jp.bottomMargin = dp(24)
        root.addView(joystick, jp)

        fab = TextView(this)
        fab.text = "+"
        fab.textSize = 30f
        fab.gravity = Gravity.CENTER
        fab.setTextColor(Ui.INK)
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(Ui.EMBER)
        fab.background = oval
        fab.setOnClickListener { showAddMenu() }
        val fp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END)
        fp.rightMargin = dp(28)
        fp.bottomMargin = dp(28)
        root.addView(fab, fp)
    }

    // ------------------------------------------------------------ mode and refresh

    private fun applyMode(m: WorldView.Mode) {
        world.mode = m
        val edit = m == WorldView.Mode.EDIT
        editBar.visibility = if (edit) View.VISIBLE else View.GONE
        rail.visibility = if (edit) View.VISIBLE else View.GONE
        trayScroll.visibility = if (edit) View.VISIBLE else View.GONE
        joystick.visibility = if (edit) View.GONE else View.VISIBLE
        fab.visibility = if (edit) View.GONE else View.VISIBLE
        if (!edit) {
            inspectorScroll.visibility = View.GONE
            sceneScroll.visibility = View.GONE
        }
        world.setJoystick(0f, 0f)
        styleSeg()
        refreshAll()
    }

    private fun styleSeg() {
        val edit = world.mode == WorldView.Mode.EDIT
        segEdit.setTextColor(if (edit) Ui.EMBER else Ui.MUTE)
        segEdit.background = if (edit) Ui.box(this, Ui.EMBERD, 0, 6) else null
        segGame.setTextColor(if (edit) Ui.MUTE else Ui.EMBER)
        segGame.background = if (edit) null else Ui.box(this, Ui.EMBERD, 0, 6)
    }

    private fun refreshAll() {
        refreshRail()
        refreshTray()
        refreshInspector()
        refreshScene()
        refreshHint()
        updateUndo()
    }

    private fun refreshHint() {
        hint.visibility = if (world.mode == WorldView.Mode.GAME && project.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun updateUndo() {
        undoBtn.alpha = if (world.canUndo()) 1f else 0.4f
        redoBtn.alpha = if (world.canRedo()) 1f else 0.4f
    }

    private fun refreshRail() {
        rail.removeAllViews()
        fun tool(label: String, t: WorldView.Tool) {
            val b = Ui.button(this, label, active = world.tool == t) {
                world.tool = t
                refreshAll()
            }
            b.textSize = 10.5f
            b.setPadding(dp(2), dp(4), dp(2), dp(4))
            val p = LinearLayout.LayoutParams(dp(46), dp(42))
            p.bottomMargin = dp(4)
            rail.addView(b, p)
        }
        tool("Move", WorldView.Tool.SELECT)
        tool("Paint", WorldView.Tool.PAINT)
        tool("Erase", WorldView.Tool.ERASE)
    }

    private fun chip(label: String, bmp: Bitmap?, active: Boolean, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.background = Ui.box(this, Ui.BG, if (active) Ui.EMBER else Ui.LINE, 7)
        box.setPadding(dp(6), dp(4), dp(6), dp(4))
        if (bmp != null) {
            val iv = ImageView(this)
            iv.setImageBitmap(bmp)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            box.addView(iv, LinearLayout.LayoutParams(dp(64), dp(38)))
        } else {
            box.addView(BladePreview(this, project.grass), LinearLayout.LayoutParams(dp(64), dp(38)))
        }
        val t = Ui.text(this, label, 10f, if (active) Ui.EMBER else Ui.BONE)
        t.maxWidth = dp(64)
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        box.addView(t)
        box.setOnClickListener { onClick() }
        return box
    }

    private fun refreshTray() {
        tray.removeAllViews()
        tray.addView(Ui.text(this, "Brush", 11f, Ui.MUTE), lp(0, 8))
        tray.addView(chip("Grass blades", null, world.brushGrass) { chooseGrass() }, lp(0, 8))
        for (a in project.assets) {
            val active = !world.brushGrass && world.brushAssetId == a.id
            tray.addView(chip(a.name, a.finalBmp, active) { chooseAsset(a) }, lp(0, 8))
        }
        tray.addView(Ui.button(this, "+ Image\nfrom files") { picker.launch("image/*") }, lp(0, 0))
    }

    private fun chooseGrass() {
        world.brushGrass = true
        world.tool = WorldView.Tool.PAINT
        refreshAll()
    }

    private fun chooseAsset(a: Asset) {
        world.brushGrass = false
        world.brushAssetId = a.id
        world.tool = WorldView.Tool.PAINT
        refreshAll()
    }

    // ------------------------------------------------------------ inspector

    private fun pct(v: Float): String = "${(v * 100f).toInt()}%"

    private fun header(title: String) {
        val t = Ui.text(this, title, 14f, Ui.BONE, true)
        t.setPadding(0, 0, 0, dp(6))
        inspector.addView(t)
    }

    private fun note(text: String) {
        val t = Ui.text(this, text, 11.5f, Ui.MUTE)
        t.setPadding(0, dp(4), 0, dp(4))
        inspector.addView(t)
    }

    private fun refreshInspector() {
        inspector.removeAllViews()
        when (world.tool) {
            WorldView.Tool.ERASE -> {
                header("Eraser")
                inspector.addView(Ui.slider(this, "Size", 15f, 150f, world.eraseRadius, { "${it.toInt()}" }) {
                    world.eraseRadius = it
                })
                note("Removes grass blades and objects inside the circle.")
            }
            WorldView.Tool.SELECT -> selectInspector()
            WorldView.Tool.PAINT -> if (world.brushGrass) grassInspector() else assetInspector()
        }
    }

    private fun selectInspector() {
        val sel = world.selected
        if (sel == null) {
            header("Move")
            note("Tap an object to select it, then drag to move it. Two fingers pan the view, pinch to zoom.")
            return
        }
        val a = project.asset(sel.assetId)
        header(a?.name ?: "Object")
        inspector.addView(Ui.slider(this, "Size", 0.2f, 3f, sel.scale, { String.format("%.2fx", it) }) {
            sel.scale = it
        })
        if (a != null) {
            inspector.addView(Ui.section(this, "In the game"))
            GlyphStudio.addBehaviour(inspector, a)
            val edit = Ui.button(this, "Edit letters") { openStudio(a, false) }
            val ep = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
            ep.topMargin = dp(10)
            inspector.addView(edit, ep)
        }
        val del = Ui.button(this, "Delete this object") { world.deleteSelected() }
        val dpm = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        dpm.topMargin = dp(8)
        inspector.addView(del, dpm)
    }

    private fun grassInspector() {
        val g = project.grass
        header("Grass blades")
        inspector.addView(BladePreview(this, g), LinearLayout.LayoutParams(Ui.MATCH, dp(64)))
        inspector.addView(Ui.slider(this, "Thickness", 1f, 7f, g.thickness, { String.format("%.1f px", it) }) { g.thickness = it })
        inspector.addView(Ui.slider(this, "How many are thick", 0f, 1f, g.thickRatio, { pct(it) }) { g.thickRatio = it })
        inspector.addView(Ui.slider(this, "Length", 8f, 45f, g.length, { "${it.toInt()} px" }) { g.length = it })
        inspector.addView(Ui.slider(this, "Lean", 0f, 50f, g.lean, { "${it.toInt()}°" }) { g.lean = it })
        inspector.addView(Ui.slider(this, "Tip dot size", 0.5f, 2.5f, g.tipDot, { String.format("%.1fx", it) }) { g.tipDot = it })
        inspector.addView(Ui.slider(this, "Sway in wind", 0f, 1f, g.sway, { pct(it) }) { g.sway = it })

        inspector.addView(Ui.section(this, "Colours (3 greens, tip, accent)"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val sp = { LinearLayout.LayoutParams(dp(30), dp(30)).also { it.rightMargin = dp(8) } }
        row.addView(Ui.swatch(this, g.colors[0], 30) { g.colors[0] = it }, sp())
        row.addView(Ui.swatch(this, g.colors[1], 30) { g.colors[1] = it }, sp())
        row.addView(Ui.swatch(this, g.colors[2], 30) { g.colors[2] = it }, sp())
        row.addView(Ui.swatch(this, g.tipColor, 30) { g.tipColor = it }, sp())
        row.addView(Ui.swatch(this, g.accentColor, 30) { g.accentColor = it }, sp())
        inspector.addView(row)

        inspector.addView(Ui.section(this, "Brush"))
        inspector.addView(Ui.slider(this, "Size", 10f, 120f, world.brushRadius, { "${it.toInt()}" }) { world.brushRadius = it })
        inspector.addView(Ui.slider(this, "Density", 0f, 1f, world.brushDensity, { pct(it) }) { world.brushDensity = it })
    }

    private fun assetInspector() {
        val a = project.asset(world.brushAssetId)
        if (a == null) {
            header("Brush")
            note("Add a picture with + Image from files. It becomes letter art you can paint into the world.")
            return
        }
        header(a.name)
        inspector.addView(Ui.slider(this, "Brush size", 15f, 150f, world.brushRadius, { "${it.toInt()}" }) { world.brushRadius = it })
        inspector.addView(Ui.slider(this, "Density", 0f, 1f, world.brushDensity, { pct(it) }) { world.brushDensity = it })
        inspector.addView(Ui.slider(this, "Random size", 0f, 0.8f, world.randomSize, { pct(it) }) { world.randomSize = it })
        inspector.addView(Ui.section(this, "In the game"))
        GlyphStudio.addBehaviour(inspector, a)
        val edit = Ui.button(this, "Edit letters") { openStudio(a, false) }
        val ep = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        ep.topMargin = dp(10)
        inspector.addView(edit, ep)
        val del = Ui.button(this, "Remove from project") { confirmDeleteAsset(a) }
        val dpm = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        dpm.topMargin = dp(8)
        inspector.addView(del, dpm)
        note("Tap or drag in the world to place it.")
    }

    // ------------------------------------------------------------ scene list

    private fun sceneRow(label: String, right: String, active: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(8), dp(8), dp(8))
        if (active) row.background = Ui.box(this, Ui.EMBERD, 0, 6)
        val c = if (active) Ui.EMBER else Ui.BONE
        row.addView(Ui.text(this, label, 12f, c), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        row.addView(Ui.text(this, right, 11.5f, if (active) Ui.EMBER else Ui.MUTE))
        row.setOnClickListener { onClick() }
        return row
    }

    private fun refreshScene() {
        scene.removeAllViews()

        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(8), dp(8), dp(8), dp(10))
        card.addView(LogoView(this), LinearLayout.LayoutParams(dp(34), dp(34)))
        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(10), 0, 0, 0)
        info.addView(Ui.text(this, project.name, 13f, Ui.BONE, true))
        info.addView(Ui.text(this, "Glyphforge game", 11f, Ui.MUTE))
        card.addView(info)
        scene.addView(card)

        scene.addView(Ui.section(this, "In this game"))
        scene.addView(sceneRow("Player", "Glyph box", false) { toast("The Glyph box is the starter player. You can swap it for your own character later.") })
        scene.addView(sceneRow("Grass blades", "${project.blades.size}", world.brushGrass) { chooseGrass() })
        for (a in project.assets) {
            val n = project.objects.count { it.assetId == a.id }
            scene.addView(sceneRow(a.name, "x$n", !world.brushGrass && world.brushAssetId == a.id) { chooseAsset(a) })
        }

        val rn = Ui.button(this, "Rename game") { renameProject() }
        val rp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        rp.topMargin = dp(14)
        scene.addView(rn, rp)
        val nw = Ui.button(this, "New empty game") { confirmNewGame() }
        val np = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        np.topMargin = dp(8)
        scene.addView(nw, np)
    }

    // ------------------------------------------------------------ dialogs and actions

    private fun showAddMenu() {
        val items = arrayOf("Image from files (tree, rock, anything)", "Grass blades")
        AlertDialog.Builder(this)
            .setTitle("Add to your world")
            .setItems(items) { _, which ->
                if (which == 0) {
                    picker.launch("image/*")
                } else {
                    applyMode(WorldView.Mode.EDIT)
                    chooseGrass()
                }
            }
            .show()
    }

    private fun renameProject() {
        val et = EditText(this)
        et.setText(project.name)
        et.setSingleLine(true)
        AlertDialog.Builder(this)
            .setTitle("Game name")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                project.name = et.text.toString().ifBlank { "Untitled game" }
                projLabel.text = project.name
                refreshScene()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(this)
            .setTitle("Start a new empty game?")
            .setMessage("This clears everything in the current game.")
            .setPositiveButton("Clear everything") { _, _ -> clearProject() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearProject() {
        for (a in project.assets) File(filesDir, "a_${a.id}.png").delete()
        project.assets.clear()
        project.customSets.clear()
        project.name = "Untitled game"
        projLabel.text = project.name
        world.brushGrass = true
        world.brushAssetId = null
        world.resetAll()
        saveQuietly()
        applyMode(WorldView.Mode.GAME)
    }

    private fun confirmDeleteAsset(a: Asset) {
        AlertDialog.Builder(this)
            .setTitle("Remove \"${a.name}\"?")
            .setMessage("Every copy of it in the world is removed too.")
            .setPositiveButton("Remove") { _, _ ->
                project.objects.removeAll { it.assetId == a.id }
                project.assets.remove(a)
                File(filesDir, "a_${a.id}.png").delete()
                world.selected = null
                world.brushGrass = true
                world.brushAssetId = null
                refreshAll()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ images and the studio

    private fun onImagePicked(uri: Uri) {
        val decoded = ImageUtil.decode(this, uri, 360)
        if (decoded == null) {
            toast("Couldn't open that picture.")
            return
        }
        val bmp = if (ImageUtil.hasAlpha(decoded)) {
            decoded
        } else {
            toast("No cutout found, so the background was erased automatically.")
            ImageUtil.removeBackground(decoded, 40)
        }
        val a = Asset(UUID.randomUUID().toString().take(8))
        a.name = "Image ${project.assets.size + 1}"
        a.src = bmp
        try {
            FileOutputStream(File(filesDir, "a_${a.id}.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (e: Exception) {
            toast("Couldn't store that picture.")
            return
        }
        openStudio(a, true)
    }

    private fun openStudio(a: Asset, isNew: Boolean) {
        if (studio != null) return
        val s = GlyphStudio(this, project, a, isNew) { saved -> closeStudio(a, isNew, saved) }
        studio = s
        root.addView(s, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun closeStudio(a: Asset, isNew: Boolean, saved: Boolean) {
        val s = studio
        if (s != null) root.removeView(s)
        studio = null
        if (isNew) {
            if (saved) {
                project.assets.add(a)
                world.brushGrass = false
                world.brushAssetId = a.id
                world.tool = WorldView.Tool.PAINT
                applyMode(WorldView.Mode.EDIT)
                saveQuietly()
            } else {
                File(filesDir, "a_${a.id}.png").delete()
            }
        } else {
            saveQuietly()
        }
        refreshAll()
    }
}
