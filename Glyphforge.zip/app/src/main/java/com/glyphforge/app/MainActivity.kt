package com.glyphforge.app

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MainActivity : AppCompatActivity(), WorldView.Listener {

    private lateinit var project: Project
    private lateinit var world: WorldView
    private lateinit var root: FrameLayout

    private lateinit var topBar: LinearLayout
    private lateinit var projLabel: TextView
    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var sceneBtnHolder: LinearLayout
    private lateinit var rail: LinearLayout
    private lateinit var leftScroll: ScrollView
    private lateinit var scene: LinearLayout
    private lateinit var rightScroll: ScrollView
    private lateinit var inspector: LinearLayout
    private lateinit var trayScroll: HorizontalScrollView
    private lateinit var tray: LinearLayout
    private lateinit var hint: LinearLayout
    private lateinit var joystick: VirtualJoystick
    private lateinit var fab: TextView
    private lateinit var editPill: TextView
    private var studio: GlyphStudio? = null

    private var leftOn = true
    private var rightOn = true
    private val expanded = HashSet<String>()

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) onImagePicked(uri)
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        project = Project.load(filesDir) ?: Project()
        world = WorldView(this, project)
        world.listener = this

        root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        root.addView(column, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        buildTopBar()
        column.addView(topBar, LinearLayout.LayoutParams(Ui.MATCH, dp(44)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        column.addView(body, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        buildRail()
        body.addView(rail, LinearLayout.LayoutParams(dp(50), Ui.MATCH))

        scene = LinearLayout(this)
        scene.orientation = LinearLayout.VERTICAL
        scene.setPadding(dp(10), dp(8), dp(10), dp(14))
        leftScroll = ScrollView(this)
        leftScroll.setBackgroundColor(Ui.PANEL)
        leftScroll.addView(scene)
        body.addView(leftScroll, LinearLayout.LayoutParams(dp(158), Ui.MATCH))

        val center = FrameLayout(this)
        center.addView(world, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        body.addView(center, LinearLayout.LayoutParams(0, Ui.MATCH, 1f))

        inspector = LinearLayout(this)
        inspector.orientation = LinearLayout.VERTICAL
        inspector.setPadding(dp(12), dp(8), dp(12), dp(16))
        rightScroll = ScrollView(this)
        rightScroll.setBackgroundColor(Ui.PANEL)
        rightScroll.addView(inspector)
        body.addView(rightScroll, LinearLayout.LayoutParams(dp(196), Ui.MATCH))

        buildTray(center)
        buildGameUi(center)
        setContentView(root)

        // The app always opens on the game preview. A brand new project is completely empty.
        applyMode(WorldView.Mode.GAME)
        enterImmersive()
    }

    override fun onPause() {
        saveQuietly()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val s = studio
        if (s != null) s.requestClose() else super.onBackPressed()
    }

    private fun enterImmersive() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun saveQuietly() {
        try {
            project.save(filesDir)
        } catch (e: Exception) {
            // Best effort; the Save button reports problems.
        }
    }

    private fun saveNow() {
        try {
            project.save(filesDir)
            toast("Saved")
        } catch (e: Exception) {
            toast("Couldn't save: " + (e.message ?: "unknown error"))
        }
    }

    // ------------------------------------------------------------ world callbacks

    override fun onSelectionChanged() {
        refreshInspector()
        refreshScene()
    }

    override fun onProjectChanged() {
        refreshScene()
        refreshInspector()
        refreshHint()
        updateUndo()
    }

    // ------------------------------------------------------------ building the screen

    private fun lp(left: Int = 0, right: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP)
        p.leftMargin = dp(left)
        p.rightMargin = dp(right)
        return p
    }

    private fun small(b: TextView): TextView {
        b.setPadding(dp(9), dp(4), dp(9), dp(4))
        b.textSize = 11.5f
        b.minHeight = dp(30)
        return b
    }

    private fun buildTopBar() {
        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(Ui.PANEL)
        topBar.setPadding(dp(10), 0, dp(10), 0)

        topBar.addView(LogoView(this), LinearLayout.LayoutParams(dp(26), dp(26)))
        val brand = Ui.text(this, "Glyphforge", 13f, Ui.MINT, true)
        brand.setPadding(dp(8), 0, dp(10), 0)
        topBar.addView(brand)
        projLabel = Ui.text(this, project.name, 12f, Ui.BONE)
        projLabel.setOnClickListener { renameProject() }
        topBar.addView(projLabel)
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        undoBtn = small(Ui.button(this, "Undo") { world.undo(); updateUndo() })
        redoBtn = small(Ui.button(this, "Redo") { world.redo(); updateUndo() })
        topBar.addView(undoBtn, lp(0, 5))
        topBar.addView(redoBtn, lp(0, 10))
        topBar.addView(small(Ui.button(this, "Scene") { leftOn = !leftOn; applyPanels() }), lp(0, 5))
        topBar.addView(small(Ui.button(this, "Inspector") { rightOn = !rightOn; applyPanels() }), lp(0, 10))
        topBar.addView(small(Ui.button(this, "Save") { saveNow() }), lp(0, 5))
        topBar.addView(small(Ui.button(this, "Play", primary = true) { applyMode(WorldView.Mode.GAME) }))
    }

    private fun buildRail() {
        rail = LinearLayout(this)
        rail.orientation = LinearLayout.VERTICAL
        rail.setPadding(dp(4), dp(6), dp(4), dp(6))
        rail.setBackgroundColor(Ui.PANEL)
    }

    private fun buildTray(center: FrameLayout) {
        tray = LinearLayout(this)
        tray.orientation = LinearLayout.HORIZONTAL
        tray.gravity = Gravity.CENTER_VERTICAL
        tray.setPadding(dp(8), dp(6), dp(8), dp(6))
        trayScroll = HorizontalScrollView(this)
        trayScroll.background = Ui.box(this, Color.argb(240, 13, 24, 21), Ui.LINE, 10)
        trayScroll.addView(tray)
        val p = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        p.bottomMargin = dp(8)
        p.leftMargin = dp(8)
        p.rightMargin = dp(8)
        center.addView(trayScroll, p)
    }

    private fun buildGameUi(center: FrameLayout) {
        hint = LinearLayout(this)
        hint.orientation = LinearLayout.VERTICAL
        hint.gravity = Gravity.CENTER_HORIZONTAL
        hint.addView(Ui.text(this, "Your world is empty", 16f, Ui.BONE, true))
        val sub = Ui.text(this, "Tap + to add land, a tree, or an image from your files.", 12f, Ui.MUTE)
        sub.setPadding(0, dp(6), 0, 0)
        hint.addView(sub)
        val hp = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER)
        hp.topMargin = dp(40)
        center.addView(hint, hp)

        joystick = VirtualJoystick(this)
        joystick.onChange = { x, y -> world.setJoystick(x, y) }
        val jp = FrameLayout.LayoutParams(dp(140), dp(140), Gravity.BOTTOM or Gravity.START)
        jp.leftMargin = dp(28)
        jp.bottomMargin = dp(24)
        center.addView(joystick, jp)

        fab = TextView(this)
        fab.text = "+"
        fab.textSize = 30f
        fab.gravity = Gravity.CENTER
        fab.setTextColor(Ui.INK)
        val oval = GradientDrawable()
        oval.shape = GradientDrawable.OVAL
        oval.setColor(Ui.EMBER)
        fab.background = oval
        fab.setOnClickListener { showAddMenu() }
        val fp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END)
        fp.rightMargin = dp(28)
        fp.bottomMargin = dp(28)
        center.addView(fab, fp)

        editPill = small(Ui.button(this, "Edit") { applyMode(WorldView.Mode.EDIT) })
        val ep = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP or Gravity.END)
        ep.topMargin = dp(10)
        ep.rightMargin = dp(12)
        center.addView(editPill, ep)
    }

    // ------------------------------------------------------------ mode and refresh

    private fun applyMode(m: WorldView.Mode) {
        world.mode = m
        val edit = m == WorldView.Mode.EDIT
        topBar.visibility = if (edit) View.VISIBLE else View.GONE
        rail.visibility = if (edit) View.VISIBLE else View.GONE
        trayScroll.visibility = if (edit) View.VISIBLE else View.GONE
        joystick.visibility = if (edit) View.GONE else View.VISIBLE
        fab.visibility = if (edit) View.GONE else View.VISIBLE
        editPill.visibility = if (edit) View.GONE else View.VISIBLE
        world.setJoystick(0f, 0f)
        applyPanels()
        refreshAll()
    }

    private fun applyPanels() {
        val edit = world.mode == WorldView.Mode.EDIT
        leftScroll.visibility = if (edit && leftOn) View.VISIBLE else View.GONE
        rightScroll.visibility = if (edit && rightOn) View.VISIBLE else View.GONE
    }

    private fun refreshAll() {
        refreshRail()
        refreshTray()
        refreshInspector()
        refreshScene()
        refreshHint()
        updateUndo()
    }

    private fun refreshHint() {
        hint.visibility = if (world.mode == WorldView.Mode.GAME && project.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun updateUndo() {
        undoBtn.alpha = if (world.canUndo()) 1f else 0.4f
        redoBtn.alpha = if (world.canRedo()) 1f else 0.4f
    }

    private fun refreshRail() {
        rail.removeAllViews()
        fun tool(label: String, t: WorldView.Tool) {
            val b = Ui.button(this, label, active = world.tool == t) {
                world.tool = t
                refreshAll()
            }
            b.textSize = 10f
            b.setPadding(dp(1), dp(4), dp(1), dp(4))
            val p = LinearLayout.LayoutParams(Ui.MATCH, dp(44))
            p.bottomMargin = dp(5)
            rail.addView(b, p)
        }
        tool("Move", WorldView.Tool.SELECT)
        tool("Paint", WorldView.Tool.PAINT)
        tool("Erase", WorldView.Tool.ERASE)
    }

    private fun thumb(label: String, bmp: Bitmap?, active: Boolean, size: Int, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.background = Ui.box(this, Ui.BG, if (active) Ui.EMBER else Ui.LINE, 7)
        box.setPadding(dp(5), dp(4), dp(5), dp(4))
        if (bmp != null) {
            val iv = ImageView(this)
            iv.setImageBitmap(bmp)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            box.addView(iv, LinearLayout.LayoutParams(dp(size), dp(size * 3 / 5)))
        } else {
            box.addView(BladePreview(this, project.grass), LinearLayout.LayoutParams(dp(size), dp(size * 3 / 5)))
        }
        val t = Ui.text(this, label, 10f, if (active) Ui.EMBER else Ui.BONE)
        t.maxWidth = dp(size)
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        box.addView(t)
        box.setOnClickListener { onClick() }
        return box
    }

    private fun refreshTray() {
        tray.removeAllViews()
        tray.addView(Ui.text(this, "Brush", 11f, Ui.MUTE), lp(0, 8))
        tray.addView(thumb("Blades", null, world.brushGrass && world.tool == WorldView.Tool.PAINT, 64) { chooseGrass() }, lp(0, 8))
        for (a in project.assets) {
            val active = !world.brushGrass && world.brushAssetId == a.id && world.tool == WorldView.Tool.PAINT
            tray.addView(thumb(a.name, a.finalBmp, active, 64) { chooseAsset(a) }, lp(0, 8))
        }
        val plus = Ui.button(this, "+") { picker.launch("image/*") }
        plus.textSize = 20f
        tray.addView(plus, LinearLayout.LayoutParams(dp(48), dp(52)))
    }

    private fun chooseGrass() {
        world.brushGrass = true
        world.tool = WorldView.Tool.PAINT
        world.select(null)
        refreshAll()
    }

    private fun chooseAsset(a: Asset) {
        world.brushGrass = false
        world.brushAssetId = a.id
        world.tool = WorldView.Tool.PAINT
        world.select(null)
        refreshAll()
    }

    // ------------------------------------------------------------ inspector

    private fun pct(v: Float): String = "${(v * 100f).toInt()}%"

    private fun header(title: String, tag: String = "") {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(Ui.text(this, title, 13.5f, Ui.BONE, true), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        if (tag.isNotEmpty()) row.addView(Ui.text(this, tag, 10f, Ui.EMBER))
        row.setPadding(0, 0, 0, dp(6))
        inspector.addView(row)
    }

    private fun note(text: String) {
        val t = Ui.text(this, text, 11f, Ui.MUTE)
        t.setPadding(0, dp(4), 0, dp(4))
        inspector.addView(t)
    }

    private fun wide(b: TextView, top: Int = 8): TextView {
        val p = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        p.topMargin = dp(top)
        inspector.addView(b, p)
        return b
    }

    private fun refreshInspector() {
        inspector.removeAllViews()
        when (world.tool) {
            WorldView.Tool.ERASE -> {
                header("Eraser", "tool")
                inspector.addView(Ui.slider(this, "Size", 15f, 150f, world.eraseRadius, { "${it.toInt()}" }) {
                    world.eraseRadius = it
                })
                note("Removes grass blades and objects inside the circle.")
            }
            WorldView.Tool.SELECT -> selectInspector()
            WorldView.Tool.PAINT -> if (world.brushGrass) grassInspector() else assetInspector()
        }
    }

    private fun selectInspector() {
        val sel = world.selected
        if (sel == null) {
            header("Move", "tool")
            note("Tap an object to select it, then drag to move it. Two fingers pan the view, pinch to zoom.")
            return
        }
        val a = project.asset(sel.assetId)
        header(a?.name ?: "Object", "selected")
        inspector.addView(Ui.text(this, "x ${sel.x.toInt()}   y ${sel.y.toInt()}", 11f, Ui.MUTE))
        val nudge = LinearLayout(this)
        nudge.orientation = LinearLayout.HORIZONTAL
        fun n(label: String, dx: Float, dy: Float) {
            val b = small(Ui.button(this, label) {
                world.nudgeSelected(dx, dy)
            })
            val p = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            p.rightMargin = dp(4)
            nudge.addView(b, p)
        }
        n("<", -4f, 0f)
        n(">", 4f, 0f)
        n("^", 0f, -4f)
        n("v", 0f, 4f)
        inspector.addView(nudge, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        inspector.addView(Ui.slider(this, "Size", 0.2f, 3f, sel.scale, { String.format("%.2fx", it) }) {
            sel.scale = it
        })
        if (a != null) {
            inspector.addView(Ui.section(this, "In the game"))
            GlyphStudio.addBehaviour(inspector, a)
            wide(Ui.button(this, "Edit letters") { openStudio(a, false, false) }, 10)
            wide(Ui.button(this, "Edit collision") { openStudio(a, false, true) })
        }
        wide(Ui.button(this, "Duplicate") { world.duplicateSelected() })
        wide(Ui.button(this, "Delete this object") { world.deleteSelected() })
    }

    private fun grassInspector() {
        val g = project.grass
        header("Grass blades", "paint layer")
        inspector.addView(BladePreview(this, g), LinearLayout.LayoutParams(Ui.MATCH, dp(56)))
        inspector.addView(Ui.slider(this, "Thickness", 1f, 7f, g.thickness, { String.format("%.1f px", it) }) { g.thickness = it })
        inspector.addView(Ui.slider(this, "How many are thick", 0f, 1f, g.thickRatio, { pct(it) }) { g.thickRatio = it })
        inspector.addView(Ui.slider(this, "Length", 8f, 45f, g.length, { "${it.toInt()} px" }) { g.length = it })
        inspector.addView(Ui.slider(this, "Lean", 0f, 50f, g.lean, { "${it.toInt()}°" }) { g.lean = it })
        inspector.addView(Ui.slider(this, "Tip dot size", 0.5f, 2.5f, g.tipDot, { String.format("%.1fx", it) }) { g.tipDot = it })
        inspector.addView(Ui.slider(this, "Sway in wind", 0f, 1f, g.sway, { pct(it) }) { g.sway = it })

        inspector.addView(Ui.section(this, "Colours"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val sp = { LinearLayout.LayoutParams(dp(26), dp(26)).also { it.rightMargin = dp(6) } }
        row.addView(Ui.swatch(this, g.colors[0], 26) { g.colors[0] = it }, sp())
        row.addView(Ui.swatch(this, g.colors[1], 26) { g.colors[1] = it }, sp())
        row.addView(Ui.swatch(this, g.colors[2], 26) { g.colors[2] = it }, sp())
        row.addView(Ui.swatch(this, g.tipColor, 26) { g.tipColor = it }, sp())
        row.addView(Ui.swatch(this, g.accentColor, 26) { g.accentColor = it }, sp())
        inspector.addView(row)

        inspector.addView(Ui.section(this, "Brush"))
        inspector.addView(Ui.slider(this, "Size", 10f, 120f, world.brushRadius, { "${it.toInt()}" }) { world.brushRadius = it })
        inspector.addView(Ui.slider(this, "Density", 0f, 1f, world.brushDensity, { pct(it) }) { world.brushDensity = it })
    }

    private fun assetInspector() {
        val a = project.asset(world.brushAssetId)
        if (a == null) {
            header("Brush")
            note("Tap + in the tray to add a picture. It becomes letter art you can paint into the world.")
            return
        }
        header(a.name, "paint layer")
        inspector.addView(Ui.slider(this, "Brush size", 15f, 150f, world.brushRadius, { "${it.toInt()}" }) { world.brushRadius = it })
        inspector.addView(Ui.slider(this, "Density", 0f, 1f, world.brushDensity, { pct(it) }) { world.brushDensity = it })
        inspector.addView(Ui.slider(this, "Random size", 0f, 0.8f, world.randomSize, { pct(it) }) { world.randomSize = it })
        inspector.addView(Ui.section(this, "In the game"))
        GlyphStudio.addBehaviour(inspector, a)
        wide(Ui.button(this, "Edit letters") { openStudio(a, false, false) }, 10)
        wide(Ui.button(this, "Edit collision") { openStudio(a, false, true) })
        wide(Ui.button(this, "Remove from project") { confirmDeleteAsset(a) })
        note("Tap or drag in the world to place it.")
    }

    // ------------------------------------------------------------ scene panel

    private fun sceneRow(label: String, right: String, active: Boolean, indent: Int = 0, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(6 + indent), dp(7), dp(6), dp(7))
        if (active) row.background = Ui.box(this, Ui.EMBERD, 0, 6)
        val c = if (active) Ui.EMBER else Ui.BONE
        val t = Ui.text(this, label, 11.5f, c)
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        row.addView(t, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        row.addView(Ui.text(this, right, 11f, if (active) Ui.EMBER else Ui.MUTE))
        row.setOnClickListener { onClick() }
        return row
    }

    private fun refreshScene() {
        scene.removeAllViews()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.text(this, "Scene", 13f, Ui.BONE, true), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        head.addView(small(Ui.button(this, "+ Add") { showAddMenu() }))
        scene.addView(head)

        scene.addView(Ui.section(this, project.name))
        scene.addView(sceneRow("Player", "Glyph box", false) {
            toast("The Glyph box is the starter player. A real character can replace it later.")
        })
        scene.addView(sceneRow("Grass blades", "${project.blades.size}", world.brushGrass && world.tool == WorldView.Tool.PAINT) { chooseGrass() })
        for (a in project.assets) {
            val objs = project.objects.filter { it.assetId == a.id }
            val open = expanded.contains(a.id)
            val active = !world.brushGrass && world.brushAssetId == a.id && world.tool == WorldView.Tool.PAINT
            scene.addView(sceneRow((if (open) "v " else "> ") + a.name, "${objs.size}", active) {
                if (open) expanded.remove(a.id) else expanded.add(a.id)
                chooseAsset(a)
            })
            if (open) {
                var i = 0
                for (o in objs) {
                    i++
                    if (i > 30) {
                        scene.addView(sceneRow("+${objs.size - 30} more", "", false, 14) {})
                        break
                    }
                    scene.addView(sceneRow("${a.name} $i", "", world.selected === o, 14) {
                        world.tool = WorldView.Tool.SELECT
                        world.select(o)
                        world.focusOn(o)
                        refreshAll()
                    })
                }
            }
        }

        scene.addView(Ui.section(this, "Images"))
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        var rowLayout: LinearLayout? = null
        var count = 0
        for (a in project.assets) {
            if (count % 2 == 0) {
                rowLayout = LinearLayout(this)
                rowLayout.orientation = LinearLayout.HORIZONTAL
                grid.addView(rowLayout, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            }
            rowLayout?.addView(thumb(a.name, a.finalBmp, false, 56) { chooseAsset(a) }, lp(0, 6))
            count++
        }
        if (count % 2 == 0) {
            rowLayout = LinearLayout(this)
            rowLayout.orientation = LinearLayout.HORIZONTAL
            grid.addView(rowLayout, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        }
        val plus = Ui.button(this, "+") { picker.launch("image/*") }
        plus.textSize = 18f
        rowLayout?.addView(plus, LinearLayout.LayoutParams(dp(56), dp(52)))
        scene.addView(grid)

        val sp = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        sp.topMargin = dp(14)
        scene.addView(small(Ui.button(this, "Rename game") { renameProject() }), sp)
        val np = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        np.topMargin = dp(6)
        scene.addView(small(Ui.button(this, "New empty game") { confirmNewGame() }), np)
    }

    // ------------------------------------------------------------ dialogs and actions

    private fun showAddMenu() {
        val items = arrayOf("Image from files (tree, rock, anything)", "Grass blades")
        AlertDialog.Builder(this)
            .setTitle("Add to your world")
            .setItems(items) { _, which ->
                if (which == 0) {
                    picker.launch("image/*")
                } else {
                    applyMode(WorldView.Mode.EDIT)
                    chooseGrass()
                }
            }
            .show()
    }

    private fun renameProject() {
        val et = EditText(this)
        et.setText(project.name)
        et.setSingleLine(true)
        AlertDialog.Builder(this)
            .setTitle("Game name")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                project.name = et.text.toString().ifBlank { "Untitled game" }
                projLabel.text = project.name
                refreshScene()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmNewGame() {
        AlertDialog.Builder(this)
            .setTitle("Start a new empty game?")
            .setMessage("This clears everything in the current game.")
            .setPositiveButton("Clear everything") { _, _ -> clearProject() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearProject() {
        for (a in project.assets) File(filesDir, "a_${a.id}.png").delete()
        project.assets.clear()
        project.customSets.clear()
        project.name = "Untitled game"
        projLabel.text = project.name
        world.brushGrass = true
        world.brushAssetId = null
        world.resetAll()
        saveQuietly()
        applyMode(WorldView.Mode.GAME)
    }

    private fun confirmDeleteAsset(a: Asset) {
        AlertDialog.Builder(this)
            .setTitle("Remove \"${a.name}\"?")
            .setMessage("Every copy of it in the world is removed too.")
            .setPositiveButton("Remove") { _, _ ->
                project.objects.removeAll { it.assetId == a.id }
                project.assets.remove(a)
                File(filesDir, "a_${a.id}.png").delete()
                world.selected = null
                world.brushGrass = true
                world.brushAssetId = null
                refreshAll()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ images and the studio

    private fun onImagePicked(uri: Uri) {
        val decoded = ImageUtil.decode(this, uri, 360)
        if (decoded == null) {
            toast("Couldn't open that picture.")
            return
        }
        val bmp = if (ImageUtil.hasAlpha(decoded)) {
            decoded
        } else {
            toast("No cutout found, so the background was erased automatically.")
            ImageUtil.removeBackground(decoded, 40)
        }
        val a = Asset(UUID.randomUUID().toString().take(8))
        a.name = "Image ${project.assets.size + 1}"
        a.src = bmp
        try {
            FileOutputStream(File(filesDir, "a_${a.id}.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (e: Exception) {
            toast("Couldn't store that picture.")
            return
        }
        openStudio(a, true, false)
    }

    private fun openStudio(a: Asset, isNew: Boolean, collision: Boolean) {
        if (studio != null) return
        val s = GlyphStudio(this, project, a, isNew, collision) { saved -> closeStudio(a, isNew, saved) }
        studio = s
        root.addView(s, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
    }

    private fun closeStudio(a: Asset, isNew: Boolean, saved: Boolean) {
        val s = studio
        if (s != null) root.removeView(s)
        studio = null
        if (isNew) {
            if (saved) {
                project.assets.add(a)
                world.brushGrass = false
                world.brushAssetId = a.id
                world.tool = WorldView.Tool.PAINT
                applyMode(WorldView.Mode.EDIT)
                saveQuietly()
            } else {
                File(filesDir, "a_${a.id}.png").delete()
            }
        } else {
            saveQuietly()
        }
        refreshAll()
    }
}
