NullGrid: unofficial modified version of Fold Craft Launcher 1.3.4.9 (commit bc0f903de2721b722742a4a1d72e5d77b8afc1a8), GPL-3.0.
https://github.com/FCL-Team/FoldCraftLauncher
Not affiliated with its developers, Mojang or Microsoft. Changes are in patch.py and TermFx.java (2026-11-28).
