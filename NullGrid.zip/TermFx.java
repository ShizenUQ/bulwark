package com.nullgrid;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;

/** Terminal effects for the launcher screens only. Nothing here runs inside the game screen. */
public final class TermFx extends View {
    private static final int SCAN = 0, BOOT = 1, TAB = 2;
    private static final int GREEN = 0x7CE0A3;
    private static final String[] BOOT_LINES = {
        "> NULLGRID boot sequence", "[ OK ] game folders", "[ OK ] java runtime",
        "[ OK ] renderer table", "[ OK ] version list", "> access granted_"
    };
    private static final String[] COMMANDS = {
        "neofetch --launcher", "cd ./manage", "wget --mods --packs --shaders", "cat controls.cfg",
        "netstat --multiplayer", "vim launcher.conf", "whoami", "ls -l ./versions"
    };
    private static boolean booted = false;

    private final int mode;
    private final int page;
    private final long start = SystemClock.uptimeMillis();
    private final Paint paint = new Paint();
    private final float dp;

    private TermFx(Context context, int mode, int page) {
        super(context);
        this.mode = mode;
        this.page = page;
        this.dp = context.getResources().getDisplayMetrics().density;
        paint.setTypeface(Typeface.MONOSPACE);
    }

    private static boolean enabled(Context c) {
        return Settings.Global.getFloat(c.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f;
    }

    private static void add(Activity a, View v) {
        ((ViewGroup) a.getWindow().getDecorView()).addView(v, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    public static void start(Activity a) {
        if (!enabled(a)) return;
        add(a, new TermFx(a, SCAN, 0));
        if (!booted) {
            booted = true;
            add(a, new TermFx(a, BOOT, 0));
        }
    }

    public static void tab(Context c, int page) {
        if (c instanceof Activity && enabled(c) && page >= 0 && page < COMMANDS.length) {
            add((Activity) c, new TermFx(c, TAB, page));
        }
    }

    public static void rain(Dialog d) {
        if (d.getWindow() != null && enabled(d.getContext())) {
            d.getWindow().getDecorView().setForeground(new Rain(d.getContext().getResources().getDisplayMetrics().density));
        }
    }

    private void remove() {
        post(() -> {
            if (getParent() instanceof ViewGroup) ((ViewGroup) getParent()).removeView(this);
        });
    }

    private void color(int rgb, int alpha) {
        paint.setColor((Math.max(0, Math.min(255, alpha)) << 24) | rgb);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long t = SystemClock.uptimeMillis() - start;
        int w = getWidth(), h = getHeight();
        if (mode == SCAN) {
            color(0x000000, 28);
            for (float y = 0; y < h; y += 4 * dp) canvas.drawRect(0, y, w, y + dp, paint);
            float sweep = (t % 6000) / 6000f * (h + 60 * dp) - 60 * dp;
            color(GREEN, 12);
            canvas.drawRect(0, sweep, w, sweep + 46 * dp, paint);
            if (isShown() && hasWindowFocus()) postInvalidateDelayed(90);
        } else if (mode == BOOT) {
            if (t > 1900) { remove(); return; }
            int alpha = t > 1500 ? (int) (255 * (1900 - t) / 400) : 255;
            color(0x050806, alpha);
            canvas.drawRect(0, 0, w, h, paint);
            color(GREEN, alpha);
            paint.setTextSize(15 * dp);
            int lines = (int) Math.min(BOOT_LINES.length, t / 200 + 1);
            for (int i = 0; i < lines; i++) canvas.drawText(BOOT_LINES[i], 28 * dp, (44 + i * 24) * dp, paint);
            postInvalidateDelayed(40);
        } else {
            if (t > 1100) { remove(); return; }
            int alpha = t > 800 ? (int) (255 * (1100 - t) / 300) : 255;
            float line = Math.min(1f, t / 350f) * h;
            color(GREEN, alpha / 3);
            canvas.drawRect(0, line, w, line + 2 * dp, paint);
            String full = "$ " + COMMANDS[page];
            String typed = full.substring(0, (int) Math.min(full.length(), t / 18 + 1));
            paint.setTextSize(13 * dp);
            float width = paint.measureText(full) + 28 * dp;
            color(0x07100B, alpha);
            canvas.drawRect(w - width - 12 * dp, h - 42 * dp, w - 12 * dp, h - 12 * dp, paint);
            color(GREEN, alpha);
            canvas.drawText(typed + "_", w - width, h - 22 * dp, paint);
            postInvalidateDelayed(30);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) invalidate();
    }

    /** Falling characters drawn over the download progress dialog. */
    private static final class Rain extends Drawable {
        private static final String CHARS = "01ABCDEF<>/#$";
        private final Paint paint = new Paint();
        private final float dp;
        private final Runnable tick = this::invalidateSelf;

        Rain(float dp) {
            this.dp = dp;
            paint.setTypeface(Typeface.MONOSPACE);
            paint.setTextSize(11 * dp);
        }

        @Override
        public void draw(Canvas canvas) {
            Rect b = getBounds();
            long step = SystemClock.uptimeMillis() / 100;
            int rows = (int) (b.height() / (13 * dp)) + 8;
            int col = 0;
            for (float x = b.left + 8 * dp; x < b.right; x += 22 * dp, col++) {
                int head = (int) ((step + col * 7L) % rows);
                for (int k = 0; k < 6; k++) {
                    int index = (int) ((step / 2 + col * 5L + k * 3L) % CHARS.length());
                    paint.setColor(((46 - k * 7) << 24) | GREEN);
                    canvas.drawText(CHARS, index, index + 1, x, b.top + (head - k) * 13 * dp, paint);
                }
            }
            unscheduleSelf(tick);
            scheduleSelf(tick, SystemClock.uptimeMillis() + 100);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter filter) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
