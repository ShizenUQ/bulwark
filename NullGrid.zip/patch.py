import pathlib, sys

def swap(path, old, new):
    p = pathlib.Path(path)
    text = p.read_text(encoding="utf-8")
    if text.count(old) != 1:
        sys.exit(f"Patch failed in {path}: expected one match for {old!r}, found {text.count(old)}")
    p.write_text(text.replace(old, new), encoding="utf-8")

app = "ZalithLauncher/"
src = app + "src/main/java/com/movtery/zalithlauncher/"

# Own name (required by the base project's extra license terms)
props = app + "gradle.properties"
swap(props, "launcher_name=ZalithLauncher", "launcher_name=NullGrid")
swap(props, "launcher_app_name=Zalith Launcher", "launcher_app_name=NullGrid")
swap(props, "launcher_short_name=ZL2", "launcher_short_name=NG")

# Own app ID, and sign the optimized build with the repo's debug key
gradle = app + "build.gradle.kts"
swap(gradle, "applicationId = zalithPackageName", 'applicationId = "io.github.nullgrid.launcher"')
swap(gradle, 'applicationIdSuffix = ".v2"', "")
swap(gradle, 'signingConfig = signingConfigs.getByName("releaseBuild")',
             'signingConfig = signingConfigs.getByName("debugBuild")')

# Required "unofficial" label on the main screen
main = src + "ui/screens/main/MainScreen.kt"
swap(main, "if (festivals.isEmpty()) {", "if (true) {")
swap(main, "text = BuildKeys.LAUNCHER_IDENTIFIER,",
           'text = "NullGrid · Unofficial Modified Version",')

# Lighter defaults for a low-end 32-bit phone (all changeable in Settings)
swap(src + "setting/RendererSettings.kt",
     'intSetting("resolutionRatio", 100, 25..300)', 'intSetting("resolutionRatio", 70, 25..300)')
swap(src + "setting/RendererSettings.kt",
     'boolSetting("requestMaxRefreshRate", true)', 'boolSetting("requestMaxRefreshRate", false)')
swap(src + "setting/LauncherSettings.kt",
     'boolSetting("launcherSwapAnimEnabled", true)', 'boolSetting("launcherSwapAnimEnabled", false)')
print("All changes applied")
