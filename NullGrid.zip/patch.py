import pathlib, re, shutil, sys

here = pathlib.Path(__file__).resolve().parent
main = pathlib.Path("FCL/src/main")
java = main / "java/com/tungsten"

def swap(path, old, new, count=1):
    text = path.read_text(encoding="utf-8")
    if text.count(old) != count:
        sys.exit(f"Patch failed in {path}: expected {count} match(es) for {old!r}, found {text.count(old)}")
    path.write_text(text.replace(old, new), encoding="utf-8")

# name
swap(main / "res/values/strings.xml", '<string name="app_name" translatable="false">Fold Craft Launcher</string>',
     '<string name="app_name" translatable="false">NullGrid</string>')

# skin: background, colours, monospace font, dark mode by default
for name in ("background_light.jpg", "background_dark.jpg"):
    shutil.copy(here / "background.jpg", main / "res/drawable" / name)
colors = main / "res/values/colors.xml"
swap(colors, '"default_theme_color">#7797CF<', '"default_theme_color">#1F5A3A<')
swap(colors, '"default_theme_color_dark">#4E77C1<', '"default_theme_color_dark">#1F5A3A<')
pref = java / "fcllibrary/component/theme/ThemePreference.kt"
swap(pref, "val color: Int = 0xFF7797CF.toInt()", "val color: Int = 0xFF1F5A3A.toInt()")
swap(pref, "val colorDark: Int = 0xFF4E77C1.toInt()", "val colorDark: Int = 0xFF1F5A3A.toInt()")
swap(pref, "val color2Dark: Int = 0xFFFFFFFF.toInt()", "val color2Dark: Int = 0xFFB8F2CC.toInt()")
for themes in (main / "res/values/themes.xml", main / "res/values-v31/themes.xml"):
    text = themes.read_text(encoding="utf-8")
    new, n = re.subn(r'(<style name="Theme\.FoldCraftLauncher"[^>]*>)',
                     r'\1\n        <item name="android:fontFamily">monospace</item>', text)
    if n != 1:
        sys.exit(f"Patch failed in {themes}: theme not found")
    themes.write_text(new, encoding="utf-8")
swap(java / "fcllibrary/component/FCLActivity.java", 'getInt("themeMode", 0)', 'getInt("themeMode", 2)')
swap(java / "fcllibrary/component/theme/ThemeEngine.kt", 'getInt("themeMode", 0)', 'getInt("themeMode", 2)')

# animations
fx = main / "java/com/nullgrid"
fx.mkdir(parents=True, exist_ok=True)
shutil.copy(here / "TermFx.java", fx / "TermFx.java")
swap(java / "fcl/activity/MainActivity.kt", "uiManager.init()",
     "uiManager.init()\n                com.nullgrid.TermFx.start(this@MainActivity)")
swap(java / "fcl/ui/UIManager.kt", "if (position != lastSelectedPosition) {",
     "if (position != lastSelectedPosition) {\n                if (lastSelectedPosition >= 0) com.nullgrid.TermFx.tab(context, position)")
swap(java / "fcl/ui/TaskDialog.java", "setContentView(R.layout.dialog_task);",
     "setContentView(R.layout.dialog_task);\n        com.nullgrid.TermFx.rain(this);")

# no CurseForge key: use Modrinth only, so searches do not end in a 403
page = java / "fcl/ui/download/common/DownloadPage.java"
swap(page, "        if (localized) {\n            downloadSources.get().setAll(",
     "        if (localized && !CurseForgeRemoteModRepository.isAvailable()) {\n"
     "            downloadSources.get().setAll(getContext().getString(R.string.mods_modrinth));\n"
     "            downloadSource.set(getContext().getString(R.string.mods_modrinth));\n"
     "        } else if (localized) {\n            downloadSources.get().setAll(")
print("All changes applied")
