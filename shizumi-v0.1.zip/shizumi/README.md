# Shizumi 0.1

Player with plugin sources.

## Plugin format (.szp)
A zip file with:
- `manifest.json`: `{ "id": "com.me.foo", "name": "Foo", "version": 1, "apiVersion": 1, "mainClass": "com.me.foo.FooPlugin" }`
- `classes.dex`: compiled code. `mainClass` extends `com.xio.shizumi.api.Plugin` and returns its `Source` objects.

The contract is in `app/src/main/java/com/xio/shizumi/api/Api.kt`.

## Repo format (repo.json, https only)
```
{ "name": "My repo",
  "plugins": [ { "id": "com.me.foo", "name": "Foo", "version": 1, "lang": "en",
                 "description": "...", "url": "foo.szp", "sha256": "<hex sha-256 of the .szp>", "nsfw": false } ] }
```
`url` may be relative to the repo file. A plugin without `sha256` is refused.

## Built-in sources
- Internet Archive (animation and cartoons)
- Direct link (paste a video URL in search)
