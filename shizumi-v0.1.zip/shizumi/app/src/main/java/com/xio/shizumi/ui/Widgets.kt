package com.xio.shizumi.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object K {
    const val CYAN = 0xFF19E6F2.toInt()
    const val PINK = 0xFFFF2E93.toInt()
    const val GREEN = 0xFF3DDC97.toInt()
    const val AMBER = 0xFFFFC24B.toInt()
    const val BG = 0xFF070B10.toInt()
    const val PANEL = 0xFF0E151C.toInt()
    const val PANEL2 = 0xFF131D26.toInt()
    const val TEXT = 0xFFE6EDF3.toInt()
    const val DIM = 0xFF8B96A3.toInt()
    const val LINE = 0xFF22303C.toInt()

    fun a(c: Int, f: Float): Int = (c and 0x00FFFFFF) or ((f * 255f).toInt().coerceIn(0, 255) shl 24)
}

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Rectangle with two cut corners (top-left, bottom-right), optional outline and a pink tick on the top edge. */
class CutDrawable(
    private val ctx: Context,
    private val fill: Int,
    private val stroke: Int = 0,
    private val cutDp: Float = 8f,
    private val strokeDp: Float = 1f,
    private val tick: Int = 0
) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun draw(c: Canvas) {
        val b = bounds
        val cu = ctx.dpf(cutDp)
        val s = ctx.dpf(strokeDp)
        val l = b.left + s / 2f
        val t = b.top + s / 2f
        val r = b.right - s / 2f
        val bt = b.bottom - s / 2f
        path.reset()
        path.moveTo(l + cu, t); path.lineTo(r, t); path.lineTo(r, bt - cu)
        path.lineTo(r - cu, bt); path.lineTo(l, bt); path.lineTo(l, t + cu); path.close()
        p.style = Paint.Style.FILL
        p.color = fill
        c.drawPath(path, p)
        if (stroke != 0) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = s
            p.color = stroke
            c.drawPath(path, p)
        }
        if (tick != 0) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 2.4f
            p.color = tick
            c.drawLine(l + cu + ctx.dpf(2f), t, l + cu + ctx.dpf(22f), t, p)
        }
    }

    override fun setAlpha(alpha: Int) { p.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun txt(ctx: Context, s: String, size: Float = 14f, color: Int = K.TEXT, bold: Boolean = false): TextView {
    val t = TextView(ctx)
    t.text = s
    t.textSize = size
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

fun lp(w: Int = -1, h: Int = -2, top: Int = 0, bottom: Int = 0, start: Int = 0, end: Int = 0): LinearLayout.LayoutParams {
    val l = LinearLayout.LayoutParams(w, h)
    l.setMargins(start, top, end, bottom)
    return l
}

/** Angular button. */
fun btn(ctx: Context, text: String, accent: Int = K.CYAN, onClick: () -> Unit): TextView {
    val t = TextView(ctx)
    t.text = text.uppercase()
    t.textSize = 12f
    t.typeface = Typeface.DEFAULT_BOLD
    t.letterSpacing = 0.08f
    t.setTextColor(accent)
    t.gravity = Gravity.CENTER
    t.setPadding(ctx.dp(14f), ctx.dp(9f), ctx.dp(14f), ctx.dp(9f))
    t.background = CutDrawable(ctx, K.a(accent, 0.12f), K.a(accent, 0.8f), 6f, 1f)
    t.setOnTouchListener { v, e ->
        if (e.action == MotionEvent.ACTION_DOWN) v.alpha = 0.6f
        if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.alpha = 1f
        false
    }
    t.setOnClickListener { onClick() }
    return t
}

fun panel(ctx: Context, accent: Int = 0): LinearLayout {
    val l = LinearLayout(ctx)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(ctx.dp(14f), ctx.dp(12f), ctx.dp(14f), ctx.dp(12f))
    l.background = CutDrawable(ctx, K.PANEL, K.LINE, 9f, 1f, accent)
    return l
}

/** Segmented control. */
class Seg(ctx: Context, private val labels: List<String>) : LinearLayout(ctx) {
    var onSelect: (Int) -> Unit = {}
    var sel = 0
    private val cells = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        for ((i, s) in labels.withIndex()) {
            val t = TextView(ctx)
            t.text = s.uppercase()
            t.textSize = 11f
            t.typeface = Typeface.DEFAULT_BOLD
            t.letterSpacing = 0.08f
            t.gravity = Gravity.CENTER
            t.setPadding(0, ctx.dp(10f), 0, ctx.dp(10f))
            t.setOnClickListener { select(i, true) }
            cells.add(t)
            addView(t, lp(0, -2, 0, 0, if (i == 0) 0 else ctx.dp(6f), 0).also { it.weight = 1f })
        }
        paint()
    }

    fun select(i: Int, fire: Boolean) {
        sel = i
        paint()
        if (fire) onSelect(i)
    }

    private fun paint() {
        for ((i, t) in cells.withIndex()) {
            val on = i == sel
            t.setTextColor(if (on) K.CYAN else K.DIM)
            t.background = CutDrawable(context, if (on) K.a(K.CYAN, 0.16f) else K.PANEL, if (on) K.CYAN else K.LINE, 6f, 1f)
        }
    }
}

/** Cover card: picture cut at two corners, title over a fade at the bottom. */
class Poster(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) { field = v; invalidate() }
    var title: String = ""
        set(v) { field = v; layout = null; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val src = RectF()
    private val dst = RectF()
    private var layout: StaticLayout? = null
    private var fade: Shader? = null

    init {
        tp.color = K.TEXT
        tp.textSize = ctx.dpf(11.5f)
        tp.typeface = Typeface.DEFAULT_BOLD
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        setMeasuredDimension(w, (w * 1.5f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        layout = null
        fade = LinearGradient(0f, h * 0.45f, 0f, h.toFloat(), 0x00000000, 0xEE05080C.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cu = context.dpf(12f)
        val s = context.dpf(1f)
        path.reset()
        path.moveTo(cu, 0f); path.lineTo(w, 0f); path.lineTo(w, h - cu); path.lineTo(w - cu, h); path.lineTo(0f, h); path.lineTo(0f, cu); path.close()
        c.save()
        c.clipPath(path)
        p.style = Paint.Style.FILL
        p.color = K.PANEL2
        c.drawRect(0f, 0f, w, h, p)
        val b = bmp
        if (b != null && b.width > 0 && b.height > 0) {
            val sc = maxOf(w / b.width, h / b.height)
            val sw = w / sc
            val sh = h / sc
            src.set((b.width - sw) / 2f, (b.height - sh) / 2f, (b.width + sw) / 2f, (b.height + sh) / 2f)
            dst.set(0f, 0f, w, h)
            c.drawBitmap(b, src.toRect(), dst, p)
        } else {
            p.color = K.a(K.CYAN, 0.25f)
            p.textSize = context.dpf(34f)
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            c.drawText(title.take(1).uppercase(), w / 2f, h * 0.48f, p)
            p.textAlign = Paint.Align.LEFT
        }
        p.shader = fade
        c.drawRect(0f, h * 0.45f, w, h, p)
        p.shader = null
        if (layout == null && title.isNotEmpty() && w > 0f) {
            layout = StaticLayout.Builder.obtain(title, 0, title.length, tp, (w - context.dpf(16f)).toInt().coerceAtLeast(10))
                .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
        }
        val lay = layout
        if (lay != null) {
            c.save()
            c.translate(context.dpf(8f), h - lay.height - context.dpf(8f))
            lay.draw(c)
            c.restore()
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = s
        p.color = K.a(K.CYAN, 0.4f)
        c.drawPath(path, p)
        p.strokeWidth = s * 2.4f
        p.color = K.PINK
        c.drawLine(cu + context.dpf(2f), s, cu + context.dpf(20f), s, p)
    }

    private fun RectF.toRect(): android.graphics.Rect = android.graphics.Rect(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())
}

/** Bottom navigation with angular plates and drawn icons. */
class NavBar(ctx: Context, private val labels: List<String>) : View(ctx) {
    var sel = 0
        set(v) { field = v; invalidate() }
    var onSel: (Int) -> Unit = {}

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), context.dp(62f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val i = (e.x / (width / labels.size.toFloat())).toInt().coerceIn(0, labels.size - 1)
            if (i != sel) { sel = i; onSel(i) }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = context.dpf(1f)
        p.style = Paint.Style.FILL
        p.color = 0xFF0A1016.toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d
        p.color = K.a(K.CYAN, 0.3f)
        c.drawLine(0f, d / 2f, w, d / 2f, p)
        val cw = w / labels.size
        for (i in labels.indices) {
            val x0 = i * cw
            val cx = x0 + cw / 2f
            val on = i == sel
            if (on) {
                val l = x0 + 10f * d; val r = x0 + cw - 10f * d; val t = 8f * d; val b = h - 6f * d; val cu = 9f * d
                path.reset()
                path.moveTo(l + cu, t); path.lineTo(r, t); path.lineTo(r, b - cu); path.lineTo(r - cu, b); path.lineTo(l, b); path.lineTo(l, t + cu); path.close()
                p.style = Paint.Style.FILL
                p.color = K.a(K.CYAN, 0.13f)
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = d
                p.color = K.a(K.CYAN, 0.75f)
                c.drawPath(path, p)
                p.strokeWidth = 2.6f * d
                p.color = K.PINK
                c.drawLine(l + cu + 2f * d, t, l + cu + 16f * d, t, p)
            }
            icon(c, i, cx, 26f * d, 8.5f * d, if (on) K.CYAN else K.DIM)
            p.style = Paint.Style.FILL
            p.color = if (on) K.CYAN else K.DIM
            p.textSize = 10f * d
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.letterSpacing = 0.1f
            c.drawText(labels[i].uppercase(), cx, h - 15f * d, p)
            p.letterSpacing = 0f
        }
    }

    private fun icon(c: Canvas, i: Int, cx: Float, cy: Float, s: Float, col: Int) {
        val d = context.dpf(1f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.strokeJoin = Paint.Join.MITER
        p.color = col
        path.reset()
        when (i) {
            0 -> {
                path.moveTo(cx - s, cy + s * 0.9f); path.lineTo(cx - s, cy - s * 0.1f); path.lineTo(cx, cy - s)
                path.lineTo(cx + s, cy - s * 0.1f); path.lineTo(cx + s, cy + s * 0.9f); path.close()
                c.drawPath(path, p)
                c.drawLine(cx - s * 0.3f, cy + s * 0.9f, cx - s * 0.3f, cy + s * 0.2f, p)
            }
            1 -> {
                val g = s * 0.15f
                c.drawRect(cx - s, cy - s, cx - g, cy - g, p)
                c.drawRect(cx + g, cy - s, cx + s, cy - g, p)
                c.drawRect(cx - s, cy + g, cx - g, cy + s, p)
                c.drawRect(cx + g, cy + g, cx + s, cy + s, p)
            }
            2 -> {
                path.moveTo(cx - s * 0.7f, cy - s); path.lineTo(cx + s * 0.7f, cy - s); path.lineTo(cx + s * 0.7f, cy + s)
                path.lineTo(cx, cy + s * 0.45f); path.lineTo(cx - s * 0.7f, cy + s); path.close()
                c.drawPath(path, p)
            }
            else -> {
                for (k in 0..2) {
                    val y = cy - s * 0.7f + k * s * 0.7f
                    c.drawLine(cx - s, y, cx + s, y, p)
                    val kx = cx + (if (k == 1) -s * 0.4f else s * 0.35f)
                    p.style = Paint.Style.FILL
                    c.drawRect(kx - s * 0.2f, y - s * 0.22f, kx + s * 0.2f, y + s * 0.22f, p)
                    p.style = Paint.Style.STROKE
                }
            }
        }
    }
}
