package com.xio.shizumi.sources

import com.xio.shizumi.api.AnimePage
import com.xio.shizumi.api.Net
import com.xio.shizumi.api.SAnime
import com.xio.shizumi.api.SEpisode
import com.xio.shizumi.api.SVideo
import com.xio.shizumi.api.Source
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Public-domain and freely shared video from the Internet Archive (animation and cartoons). */
class ArchiveSource : Source {
    override val id = "builtin.archive"
    override val name = "Internet Archive"
    override val lang = "en"
    override val hint = "Free animation and cartoons from archive.org. Search by title."
    override val hasLatest = true

    private val base = "collection:(animationandcartoons) AND mediatype:(movies)"
    private val rows = 24

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun encPath(s: String) = s.split("/").joinToString("/") { enc(it).replace("+", "%20") }

    private fun text(o: JSONObject, key: String): String {
        val v = o.opt(key) ?: return ""
        return when (v) {
            is JSONArray -> if (v.length() > 0) v.optString(0) else ""
            else -> v.toString()
        }
    }

    private fun strip(s: String): String =
        s.replace(Regex("<[^>]*>"), " ").replace("&nbsp;", " ").replace("&amp;", "&").replace(Regex("\\s+"), " ").trim()

    private fun list(q: String, page: Int, sort: String): AnimePage {
        val url = "https://archive.org/advancedsearch.php?q=" + enc(q) +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=description" +
            "&sort%5B%5D=" + enc(sort) + "&rows=$rows&page=$page&output=json"
        val resp = JSONObject(Net.get(url)).getJSONObject("response")
        val docs = resp.getJSONArray("docs")
        val total = resp.optInt("numFound", 0)
        val items = ArrayList<SAnime>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier")
            if (id.isEmpty()) continue
            val title = text(d, "title").ifEmpty { id }
            items.add(SAnime(id, title, "https://archive.org/services/img/" + enc(id), strip(text(d, "description")).take(600)))
        }
        return AnimePage(items, page * rows < total)
    }

    override fun popular(page: Int) = list(base, page, "downloads desc")
    override fun latest(page: Int) = list(base, page, "addeddate desc")

    override fun search(query: String, page: Int): AnimePage {
        val clean = query.replace(Regex("[\"():\\[\\]{}\\\\/^~*?]"), " ").trim()
        if (clean.isEmpty()) return popular(page)
        return list("$base AND title:($clean)", page, "downloads desc")
    }

    override fun details(anime: SAnime): SAnime {
        val root = JSONObject(Net.get("https://archive.org/metadata/" + enc(anime.url)))
        val md = root.optJSONObject("metadata") ?: return anime
        val subj = md.opt("subject")
        val genres = ArrayList<String>()
        when (subj) {
            is JSONArray -> for (i in 0 until subj.length()) genres.add(subj.optString(i).trim())
            is String -> subj.split(";", ",").forEach { genres.add(it.trim()) }
        }
        val desc = strip(text(md, "description")).ifEmpty { anime.description ?: "" }
        return SAnime(
            anime.url, text(md, "title").ifEmpty { anime.title }, anime.cover, desc,
            genres.filter { it.isNotEmpty() }.take(8), text(md, "year").ifEmpty { text(md, "date").take(4) }.ifEmpty { null },
            text(md, "creator").ifEmpty { null }
        )
    }

    override fun episodes(anime: SAnime): List<SEpisode> {
        val root = JSONObject(Net.get("https://archive.org/metadata/" + enc(anime.url)))
        val files = root.optJSONArray("files") ?: return emptyList()
        val names = ArrayList<String>()
        for (i in 0 until files.length()) names.add(files.getJSONObject(i).optString("name"))
        fun pick(exts: List<String>): List<String> =
            names.filter { n -> exts.any { n.lowercase().endsWith(it) } && !n.lowercase().contains("_thumb") }
        var vids = pick(listOf(".mp4", ".m4v"))
        if (vids.isEmpty()) vids = pick(listOf(".mkv", ".webm", ".ogv", ".avi"))
        val trimmed = vids.filter { !it.lowercase().endsWith("_512kb.mp4") }
        val use = (if (trimmed.isNotEmpty()) trimmed else vids).sorted().take(200)
        val out = ArrayList<SEpisode>()
        for ((i, n) in use.withIndex()) {
            val label = n.substringAfterLast('/').substringBeforeLast('.').replace('_', ' ')
            out.add(SEpisode(anime.url + "/" + n, if (use.size == 1) "Full video" else label, (i + 1).toFloat()))
        }
        return out
    }

    override fun videos(episode: SEpisode): List<SVideo> =
        listOf(SVideo("https://archive.org/download/" + encPath(episode.url), "Original"))
}

/** Paste any direct video link (mp4, m3u8, ...) in the search box. */
class DirectSource : Source {
    override val id = "builtin.direct"
    override val name = "Direct link"
    override val lang = "all"
    override val hint = "Paste a direct video link (https://...) into the search box and press search."

    override fun popular(page: Int) = AnimePage(emptyList(), false)

    override fun search(query: String, page: Int): AnimePage {
        val q = query.trim()
        if (!q.startsWith("http://") && !q.startsWith("https://")) return AnimePage(emptyList(), false)
        val title = q.substringBefore('?').substringAfterLast('/').ifEmpty { q }
        return AnimePage(listOf(SAnime(q, title, null, q)), false)
    }

    override fun episodes(anime: SAnime) = listOf(SEpisode(anime.url, "Play", 1f))

    override fun videos(episode: SEpisode) =
        listOf(SVideo(episode.url, "Direct", emptyMap(), episode.url.contains(".m3u8")))
}
