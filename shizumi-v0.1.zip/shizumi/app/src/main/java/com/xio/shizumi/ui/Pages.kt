package com.xio.shizumi.ui

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.xio.shizumi.api.SAnime
import com.xio.shizumi.api.SEpisode
import com.xio.shizumi.api.SVideo
import com.xio.shizumi.api.Source
import com.xio.shizumi.core.Bg
import com.xio.shizumi.core.Img
import com.xio.shizumi.core.PluginEntry
import com.xio.shizumi.core.Plugins
import com.xio.shizumi.core.Registry
import com.xio.shizumi.core.RepoInfo
import com.xio.shizumi.core.Repos
import com.xio.shizumi.core.Store

interface Host {
    fun openDetails(source: Source, anime: SAnime)
    fun closeDetails()
    fun showTab(i: Int)
    fun sourcesChanged()
    fun toast(s: String)
}

private fun input(ctx: Context, hint: String): EditText {
    val et = EditText(ctx)
    et.hint = hint
    et.setHintTextColor(K.DIM)
    et.setTextColor(K.TEXT)
    et.textSize = 14f
    et.isSingleLine = true
    et.imeOptions = EditorInfo.IME_ACTION_SEARCH
    et.setPadding(ctx.dp(14f), ctx.dp(10f), ctx.dp(14f), ctx.dp(10f))
    et.background = CutDrawable(ctx, K.PANEL, K.LINE, 7f, 1f)
    return et
}

private fun hideKeyboard(v: View) {
    val m = v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    m.hideSoftInputFromWindow(v.windowToken, 0)
}

private fun scroller(ctx: Context, content: View): ScrollView {
    val s = ScrollView(ctx)
    s.isVerticalScrollBarEnabled = false
    s.addView(content, FrameLayout.LayoutParams(-1, -2))
    return s
}

// ======================================================= HOME

class HomePage(private val ctx: Context, private val host: Host) : LinearLayout(ctx) {
    private val srcBtn: TextView
    private val field: EditText
    private val seg: Seg
    private val grid = LinearLayout(ctx)
    private val status: TextView
    private val more: TextView
    private val items = ArrayList<SAnime>()
    private var mode = 0
    private var page = 1
    private var query = ""
    private var hasNext = false
    private var token = 0
    private var cur: Source? = null

    init {
        orientation = VERTICAL
        setPadding(ctx.dp(14f), ctx.dp(8f), ctx.dp(14f), 0)

        srcBtn = btn(ctx, "Source") { pickSource() }
        addView(srcBtn, lp(-1, -2, 0, ctx.dp(8f)))

        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        field = input(ctx, "Search")
        field.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEARCH) { doSearch(); true } else false
        }
        row.addView(field, lp(0, -2).also { it.weight = 1f })
        row.addView(btn(ctx, "Go") { doSearch() }, lp(-2, -1, 0, 0, ctx.dp(8f), 0))
        addView(row, lp(-1, -2, 0, ctx.dp(8f)))

        seg = Seg(ctx, listOf("Popular", "Latest"))
        seg.onSelect = { i -> mode = i; query = ""; field.setText(""); load(true) }
        addView(seg, lp(-1, -2, 0, ctx.dp(10f)))

        status = txt(ctx, "", 13f, K.DIM)
        status.gravity = Gravity.CENTER
        more = btn(ctx, "Load more") { page++; load(false) }
        more.visibility = GONE

        val body = LinearLayout(ctx)
        body.orientation = VERTICAL
        body.addView(grid)
        body.addView(status, lp(-1, -2, ctx.dp(10f), ctx.dp(6f)))
        body.addView(more, lp(-1, -2, 0, ctx.dp(16f)))
        addView(scroller(ctx, body), lp(-1, 0).also { it.weight = 1f })
        grid.orientation = VERTICAL
    }

    private fun pickSource() {
        val all = Registry.all()
        val names = all.map { it.name + "  (" + it.lang + ")" }.toTypedArray()
        AlertDialog.Builder(ctx).setTitle("Source").setItems(names) { _, i ->
            Store.activeSource = all[i].id
            refreshSource()
        }.show()
    }

    private fun doSearch() {
        val q = field.text.toString().trim()
        hideKeyboard(field)
        if (q.isEmpty()) { mode = 0; seg.select(0, false); load(true); return }
        query = q
        mode = 2
        load(true)
    }

    /** Call when the active source or the list of sources may have changed. */
    fun refreshSource() {
        val s = Registry.active()
        cur = s
        srcBtn.text = if (s == null) "NO SOURCE" else ("SOURCE  ›  " + s.name.uppercase())
        seg.visibility = if (s != null && s.hasLatest) VISIBLE else GONE
        mode = 0
        query = ""
        seg.select(0, false)
        load(true)
    }

    private fun load(reset: Boolean) {
        val s = cur ?: Registry.active()
        if (s == null) {
            status.text = "No source yet. Open Browse to pick one."
            return
        }
        cur = s
        if (reset) { page = 1; items.clear(); render() }
        val my = ++token
        status.text = "Loading..."
        more.visibility = GONE
        val m = mode
        val q = query
        val p = page
        Bg.run({
            when (m) {
                0 -> s.popular(p)
                1 -> s.latest(p)
                else -> s.search(q, p)
            }
        }, { r ->
            if (my == token) {
                val pg = r.getOrNull()
                if (pg != null) {
                    items.addAll(pg.items)
                    hasNext = pg.hasNext
                    render()
                    status.text = if (items.isEmpty()) (if (m == 2) "Nothing found." else s.hint.ifEmpty { "Nothing here." }) else ""
                    more.visibility = if (hasNext) VISIBLE else GONE
                } else {
                    status.text = "Could not load: " + (r.exceptionOrNull()?.message ?: "unknown error")
                }
            }
        })
    }

    private fun render() {
        grid.removeAllViews()
        val s = cur ?: return
        val cols = 3
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(ctx)
            row.orientation = HORIZONTAL
            for (c in 0 until cols) {
                val idx = i + c
                if (idx < items.size) {
                    val a = items[idx]
                    val po = Poster(ctx)
                    po.title = a.title
                    val u = a.cover
                    if (u != null) {
                        po.tag = u
                        Img.load(u, 360) { b -> if (po.tag == u) po.bmp = b }
                    }
                    po.setOnClickListener { host.openDetails(s, a) }
                    row.addView(po, lp(0, -2, 0, 0, if (c == 0) 0 else ctx.dp(8f), 0).also { it.weight = 1f })
                } else {
                    row.addView(View(ctx), lp(0, 1, 0, 0, ctx.dp(8f), 0).also { it.weight = 1f })
                }
            }
            grid.addView(row, lp(-1, -2, 0, ctx.dp(8f)))
            i += cols
        }
    }
}

// ======================================================= DETAILS

class DetailsView(private val ctx: Context, private val host: Host, private val source: Source, private val anime: SAnime) : FrameLayout(ctx) {
    private val list = LinearLayout(ctx)
    private val titleV: TextView
    private val metaV: TextView
    private val genresV: TextView
    private val descV: TextView
    private val epHead: TextView
    private val epBox = LinearLayout(ctx)
    private val poster = Poster(ctx)

    init {
        setBackgroundColor(K.BG)
        isClickable = true
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(ctx.dp(14f), ctx.dp(10f), ctx.dp(14f), ctx.dp(6f))
        top.addView(btn(ctx, "‹ Back") { host.closeDetails() })
        val src = txt(ctx, source.name.uppercase(), 11f, K.DIM, true)
        src.letterSpacing = 0.1f
        top.addView(src, lp(-2, -2, 0, 0, ctx.dp(12f), 0))
        col.addView(top)

        list.orientation = LinearLayout.VERTICAL
        list.setPadding(ctx.dp(14f), ctx.dp(6f), ctx.dp(14f), ctx.dp(24f))

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        poster.title = ""
        head.addView(poster, LinearLayout.LayoutParams(ctx.dp(112f), -2))
        val info = LinearLayout(ctx)
        info.orientation = LinearLayout.VERTICAL
        titleV = txt(ctx, anime.title, 18f, K.TEXT, true)
        metaV = txt(ctx, "", 12f, K.DIM)
        genresV = txt(ctx, "", 12f, K.CYAN)
        info.addView(titleV)
        info.addView(metaV, lp(-1, -2, ctx.dp(6f)))
        info.addView(genresV, lp(-1, -2, ctx.dp(8f)))
        head.addView(info, lp(0, -2, 0, 0, ctx.dp(14f), 0).also { it.weight = 1f })
        list.addView(head)

        descV = txt(ctx, anime.description ?: "", 13f, K.TEXT)
        descV.setLineSpacing(0f, 1.15f)
        list.addView(descV, lp(-1, -2, ctx.dp(14f)))

        epHead = txt(ctx, "EPISODES", 12f, K.CYAN, true)
        epHead.letterSpacing = 0.15f
        list.addView(epHead, lp(-1, -2, ctx.dp(18f), ctx.dp(8f)))
        epBox.orientation = LinearLayout.VERTICAL
        list.addView(epBox)

        col.addView(scroller(ctx, list), LinearLayout.LayoutParams(-1, 0, 1f))
        addView(col, FrameLayout.LayoutParams(-1, -1))

        val u = anime.cover
        if (u != null) { poster.tag = u; Img.load(u, 360) { b -> if (poster.tag == u) poster.bmp = b } }
        fill(anime)
        epBox.addView(txt(ctx, "Loading...", 13f, K.DIM))
        Bg.run({
            val d = try { source.details(anime) } catch (t: Throwable) { anime }
            val eps = source.episodes(d)
            Pair(d, eps)
        }, { r ->
            epBox.removeAllViews()
            val pr = r.getOrNull()
            if (pr == null) {
                epBox.addView(txt(ctx, "Could not load episodes: " + (r.exceptionOrNull()?.message ?: "error"), 13f, K.PINK))
            } else {
                fill(pr.first)
                showEpisodes(pr.second)
            }
        })
    }

    private fun fill(a: SAnime) {
        titleV.text = a.title
        val meta = ArrayList<String>()
        a.status?.let { if (it.isNotBlank()) meta.add(it) }
        a.author?.let { if (it.isNotBlank()) meta.add(it) }
        metaV.text = meta.joinToString("  ·  ")
        genresV.text = a.genres.joinToString("  ·  ")
        descV.text = a.description ?: ""
    }

    private fun showEpisodes(eps: List<SEpisode>) {
        epHead.text = "EPISODES  (" + eps.size + ")"
        if (eps.isEmpty()) { epBox.addView(txt(ctx, "No episodes found.", 13f, K.DIM)); return }
        for (e in eps) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(ctx.dp(14f), ctx.dp(12f), ctx.dp(14f), ctx.dp(12f))
            row.background = CutDrawable(ctx, K.PANEL, K.LINE, 7f, 1f)
            val n = txt(ctx, e.name, 13f, K.TEXT)
            n.maxLines = 2
            row.addView(n, lp(0, -2).also { it.weight = 1f })
            row.addView(txt(ctx, "▶", 14f, K.CYAN), lp(-2, -2, 0, 0, ctx.dp(10f), 0))
            row.setOnClickListener { play(e) }
            epBox.addView(row, lp(-1, -2, 0, ctx.dp(6f)))
        }
    }

    private fun play(e: SEpisode) {
        host.toast("Finding video...")
        Bg.run({ source.videos(e) }, { r ->
            val v = r.getOrNull()
            if (v == null) host.toast("No video: " + (r.exceptionOrNull()?.message ?: "error"))
            else if (v.isEmpty()) host.toast("No video found for this episode")
            else if (v.size == 1) openVideo(v[0])
            else {
                val labels = v.map { it.quality }.toTypedArray()
                AlertDialog.Builder(ctx).setTitle("Quality").setItems(labels) { _, i -> openVideo(v[i]) }.show()
            }
        })
    }

    private fun openVideo(v: SVideo) {
        AlertDialog.Builder(ctx).setTitle(v.quality)
            .setMessage("The built-in player arrives in the next version. For now the video opens in another player app.")
            .setPositiveButton("Open") { _, _ ->
                try {
                    val i = Intent(Intent.ACTION_VIEW)
                    i.setDataAndType(Uri.parse(v.url), if (v.hls) "application/x-mpegURL" else "video/*")
                    ctx.startActivity(i)
                } catch (t: Throwable) {
                    host.toast("No video player app found")
                }
            }
            .setNeutralButton("Copy link") { _, _ ->
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("video", v.url))
                host.toast("Link copied")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

// ======================================================= BROWSE

class BrowsePage(private val ctx: Context, private val host: Host) : LinearLayout(ctx) {
    private val seg = Seg(ctx, listOf("Sources", "Plugins", "Repos"))
    private val list = LinearLayout(ctx)
    private val cache = HashMap<String, Result<RepoInfo>>()
    private var tab = 0

    init {
        orientation = VERTICAL
        setPadding(ctx.dp(14f), ctx.dp(8f), ctx.dp(14f), 0)
        addView(seg, lp(-1, -2, 0, ctx.dp(10f)))
        list.orientation = VERTICAL
        addView(scroller(ctx, list), lp(-1, 0).also { it.weight = 1f })
        seg.onSelect = { i -> tab = i; render() }
        render()
    }

    fun render() {
        list.removeAllViews()
        when (tab) {
            0 -> sources()
            1 -> plugins()
            else -> repos()
        }
    }

    private fun note(s: String, col: Int = K.DIM): TextView {
        val t = txt(ctx, s, 13f, col)
        t.setLineSpacing(0f, 1.15f)
        return t
    }

    private fun tag(s: String, col: Int): TextView {
        val t = txt(ctx, s.uppercase(), 9.5f, col, true)
        t.letterSpacing = 0.12f
        return t
    }

    private fun sources() {
        val active = Registry.active()
        for (s in Registry.all()) {
            val card = panel(ctx, if (active != null && active.id == s.id) K.PINK else 0)
            val row = LinearLayout(ctx)
            row.orientation = HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(txt(ctx, s.name, 15f, K.TEXT, true), lp(0, -2).also { it.weight = 1f })
            if (active != null && active.id == s.id) row.addView(tag("active", K.GREEN))
            card.addView(row)
            val owner = Registry.owner(s)
            val kind = if (owner == null) "BUILT-IN" else "PLUGIN · " + owner.name
            card.addView(txt(ctx, s.lang + "  ·  " + kind, 11f, K.DIM), lp(-1, -2, ctx.dp(2f)))
            if (s.hint.isNotEmpty()) card.addView(note(s.hint), lp(-1, -2, ctx.dp(6f)))
            card.setOnClickListener {
                Store.activeSource = s.id
                host.sourcesChanged()
                host.showTab(0)
            }
            list.addView(card, lp(-1, -2, 0, ctx.dp(8f)))
        }
        for ((f, msg) in Plugins.errors) {
            list.addView(note("Plugin failed to load ($f): $msg", K.PINK), lp(-1, -2, ctx.dp(4f), ctx.dp(4f)))
        }
        list.addView(note("Tap a source to use it on Home. Add more sources as plugins from a repo (Repos tab, then Plugins)."), lp(-1, -2, ctx.dp(8f), ctx.dp(16f)))
    }

    private fun plugins() {
        val repos = Store.repos
        if (repos.isEmpty()) {
            list.addView(note("No repos yet. Add one in the Repos tab, then its plugins show up here."))
            return
        }
        list.addView(btn(ctx, "Refresh") { cache.clear(); render() }, lp(-1, -2, 0, ctx.dp(8f)))
        for (url in repos) {
            val c = cache[url]
            if (c == null) {
                list.addView(note("Loading $url ..."), lp(-1, -2, 0, ctx.dp(6f)))
                Bg.run({ Repos.fetch(url) }, { r -> cache[url] = r; if (tab == 1) render() })
                continue
            }
            val info = c.getOrNull()
            if (info == null) {
                list.addView(note("Could not read $url: " + (c.exceptionOrNull()?.message ?: "error"), K.PINK), lp(-1, -2, 0, ctx.dp(6f)))
                continue
            }
            val h = txt(ctx, info.name.uppercase(), 12f, K.CYAN, true)
            h.letterSpacing = 0.12f
            list.addView(h, lp(-1, -2, ctx.dp(8f), ctx.dp(6f)))
            if (info.plugins.isEmpty()) list.addView(note("This repo has no plugins."))
            for (e in info.plugins) list.addView(pluginRow(e), lp(-1, -2, 0, ctx.dp(8f)))
        }
    }

    private fun pluginRow(e: PluginEntry): View {
        val card = panel(ctx)
        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val left = LinearLayout(ctx)
        left.orientation = VERTICAL
        left.addView(txt(ctx, e.name, 15f, K.TEXT, true))
        left.addView(txt(ctx, "v" + e.version + "  ·  " + e.lang + (if (e.nsfw) "  ·  18+" else ""), 11f, if (e.nsfw) K.PINK else K.DIM), lp(-1, -2, ctx.dp(2f)))
        row.addView(left, lp(0, -2).also { it.weight = 1f })
        val have = Plugins.installedVersion(e.id)
        val label = if (have == 0) "Install" else if (have < e.version) "Update" else "Remove"
        val accent = if (have != 0 && have >= e.version) K.PINK else K.CYAN
        val b = btn(ctx, label, accent) { }
        b.setOnClickListener {
            if (have != 0 && have >= e.version) {
                Plugins.remove(e.id)
                host.sourcesChanged()
                render()
            } else {
                b.text = "..."
                b.isEnabled = false
                Bg.run({ Plugins.install(ctx, e) }, { r ->
                    val err = r.exceptionOrNull()
                    if (err != null) host.toast(err.message ?: "Install failed")
                    host.sourcesChanged()
                    render()
                })
            }
        }
        row.addView(b)
        card.addView(row)
        if (e.description.isNotEmpty()) card.addView(note(e.description), lp(-1, -2, ctx.dp(6f)))
        return card
    }

    private fun repos() {
        val warn = panel(ctx, K.AMBER)
        warn.addView(txt(ctx, "BE CAREFUL", 11f, K.AMBER, true))
        warn.addView(note("A plugin is code that runs inside this app. Only add repos from people you trust. Every plugin is checked against the checksum its repo publishes before it is loaded."), lp(-1, -2, ctx.dp(4f)))
        list.addView(warn, lp(-1, -2, 0, ctx.dp(10f)))

        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        val et = input(ctx, "https://.../repo.json")
        et.setOnEditorActionListener { _, _, _ -> false }
        row.addView(et, lp(0, -2).also { it.weight = 1f })
        row.addView(btn(ctx, "Add") {
            val u = et.text.toString().trim()
            hideKeyboard(et)
            if (!u.startsWith("https://")) host.toast("The link must start with https://")
            else if (Store.repos.contains(u)) host.toast("Already added")
            else {
                host.toast("Checking repo...")
                Bg.run({ Repos.fetch(u) }, { r ->
                    val info = r.getOrNull()
                    if (info == null) host.toast("Not a valid repo: " + (r.exceptionOrNull()?.message ?: "error"))
                    else {
                        Store.repos = Store.repos + u
                        cache[u] = r
                        host.toast("Added " + info.name)
                        render()
                    }
                })
            }
        }, lp(-2, -1, 0, 0, ctx.dp(8f), 0))
        list.addView(row, lp(-1, -2, 0, ctx.dp(10f)))

        val rs = Store.repos
        if (rs.isEmpty()) list.addView(note("No repos added yet."))
        for (u in rs) {
            val card = panel(ctx)
            val r = LinearLayout(ctx)
            r.orientation = HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val name = cache[u]?.getOrNull()?.name
            val t = LinearLayout(ctx)
            t.orientation = VERTICAL
            if (name != null) t.addView(txt(ctx, name, 14f, K.TEXT, true))
            val ut = txt(ctx, u, 11f, K.DIM)
            ut.maxLines = 2
            t.addView(ut)
            r.addView(t, lp(0, -2).also { it.weight = 1f })
            r.addView(btn(ctx, "Remove", K.PINK) {
                Store.repos = Store.repos.filter { it != u }
                cache.remove(u)
                render()
            })
            card.addView(r)
            list.addView(card, lp(-1, -2, 0, ctx.dp(8f)))
        }
        list.addView(View(ctx), lp(-1, ctx.dp(16f)))
    }
}

// ======================================================= LIBRARY / SETTINGS

class LibraryPage(ctx: Context) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        setPadding(ctx.dp(14f), ctx.dp(14f), ctx.dp(14f), 0)
        val p = panel(ctx, K.PINK)
        p.addView(txt(ctx, "LIBRARY", 12f, K.CYAN, true))
        val t = txt(ctx, "Favourites, watch history and resume points arrive in a later version.", 13f, K.DIM)
        t.setLineSpacing(0f, 1.15f)
        p.addView(t, lp(-1, -2, ctx.dp(6f)))
        addView(p)
    }
}

class SettingsPage(private val ctx: Context, private val host: Host) : LinearLayout(ctx) {
    init {
        orientation = VERTICAL
        setPadding(ctx.dp(14f), ctx.dp(8f), ctx.dp(14f), 0)
        val col = LinearLayout(ctx)
        col.orientation = VERTICAL

        val a = panel(ctx, K.PINK)
        a.addView(txt(ctx, "SHIZUMI  0.1", 14f, K.CYAN, true))
        val at = txt(ctx, "A player with plugin sources. The app has no websites built in: sources come from plugins you add from a repo, plus a few built-in free ones.", 13f, K.DIM)
        at.setLineSpacing(0f, 1.15f)
        a.addView(at, lp(-1, -2, ctx.dp(6f)))
        col.addView(a, lp(-1, -2, 0, ctx.dp(10f)))

        val f = panel(ctx)
        f.addView(txt(ctx, "REPO FORMAT", 12f, K.CYAN, true))
        val ft = txt(
            ctx,
            "repo.json\n{\n \"name\": \"My repo\",\n \"plugins\": [{\n  \"id\": \"com.me.foo\",\n  \"name\": \"Foo\",\n  \"version\": 1,\n  \"lang\": \"en\",\n  \"url\": \"foo.szp\",\n  \"sha256\": \"<hex>\"\n }]\n}\n\nfoo.szp = zip with manifest.json\n(id, name, version, apiVersion 1,\nmainClass) and classes.dex",
            11f, K.TEXT
        )
        ft.typeface = Typeface.MONOSPACE
        f.addView(ft, lp(-1, -2, ctx.dp(6f)))
        col.addView(f, lp(-1, -2, 0, ctx.dp(10f)))

        col.addView(btn(ctx, "Clear image cache") { Img.clear(); host.toast("Cleared") }, lp(-1, -2, 0, ctx.dp(16f)))
        addView(scroller(ctx, col), lp(-1, 0).also { it.weight = 1f })
    }
}
