package com.xio.shizumi.core

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import com.xio.shizumi.api.API_VERSION
import com.xio.shizumi.api.Net
import com.xio.shizumi.api.Plugin
import com.xio.shizumi.api.Source
import dalvik.system.DexClassLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.zip.ZipFile

/** Background work with a callback on the main thread. */
object Bg {
    private val pool = Executors.newFixedThreadPool(4)
    private val ui = Handler(Looper.getMainLooper())

    fun <T> run(work: () -> T, done: (Result<T>) -> Unit) {
        pool.execute {
            val r: Result<T> = try { Result.success(work()) } catch (t: Throwable) { Result.failure(t) }
            ui.post { done(r) }
        }
    }

    fun post(r: () -> Unit) { ui.post(r) }
}

object Store {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) { sp = c.getSharedPreferences("shizumi", Context.MODE_PRIVATE) }

    var repos: List<String>
        get() {
            val raw = sp.getString("repos", "[]") ?: "[]"
            val a = try { JSONArray(raw) } catch (t: Throwable) { JSONArray() }
            val l = ArrayList<String>()
            for (i in 0 until a.length()) l.add(a.getString(i))
            return l
        }
        set(v) { sp.edit().putString("repos", JSONArray(v).toString()).apply() }

    var activeSource: String
        get() = sp.getString("active", "") ?: ""
        set(v) { sp.edit().putString("active", v).apply() }

    fun pluginVersion(id: String): Int = sp.getInt("pv_$id", 0)
    fun setPluginVersion(id: String, v: Int) { sp.edit().putInt("pv_$id", v).apply() }
    fun clearPlugin(id: String) { sp.edit().remove("pv_$id").apply() }
}

class PluginEntry(
    val repoUrl: String,
    val id: String,
    val name: String,
    val version: Int,
    val lang: String,
    val description: String,
    val url: String,
    val sha256: String,
    val nsfw: Boolean
)

class RepoInfo(val url: String, val name: String, val plugins: List<PluginEntry>)

/**
 * Repo format (repo.json):
 * { "name": "My repo", "plugins": [ { "id": "com.me.foo", "name": "Foo", "version": 1, "lang": "en",
 *   "description": "...", "url": "foo.szp", "sha256": "<hex>", "nsfw": false } ] }
 * `url` may be relative to the repo file.
 */
object Repos {
    fun fetch(url: String): RepoInfo {
        val root = JSONObject(Net.get(url))
        val arr = root.optJSONArray("plugins") ?: JSONArray()
        val list = ArrayList<PluginEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val rel = o.getString("url")
            val abs = try { URI(url).resolve(rel).toString() } catch (t: Throwable) { rel }
            list.add(
                PluginEntry(
                    url, o.getString("id"), o.optString("name", o.getString("id")), o.optInt("version", 1),
                    o.optString("lang", "en"), o.optString("description", ""), abs,
                    o.optString("sha256", ""), o.optBoolean("nsfw", false)
                )
            )
        }
        return RepoInfo(url, root.optString("name", URL(url).host), list)
    }
}

class LoadedPlugin(val id: String, val name: String, val version: Int, val sources: List<Source>)

/** Plug-in file (.szp) = a zip with manifest.json {id,name,version,apiVersion,mainClass} and classes.dex. */
object Plugins {
    private lateinit var dir: File
    val loaded = LinkedHashMap<String, LoadedPlugin>()
    val errors = HashMap<String, String>()

    fun init(c: Context) {
        dir = File(c.filesDir, "plugins")
        dir.mkdirs()
    }

    @Synchronized
    fun loadAll(c: Context) {
        loaded.clear()
        errors.clear()
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (!f.name.endsWith(".szp")) continue
            try {
                val lp = load(c, f)
                loaded[lp.id] = lp
            } catch (t: Throwable) {
                errors[f.name] = t.message ?: t.toString()
            }
        }
    }

    private fun load(c: Context, f: File): LoadedPlugin {
        val m: JSONObject = ZipFile(f).use { z ->
            val e = z.getEntry("manifest.json") ?: throw IllegalStateException("manifest.json missing")
            if (z.getEntry("classes.dex") == null) throw IllegalStateException("classes.dex missing")
            JSONObject(z.getInputStream(e).bufferedReader().readText())
        }
        if (m.optInt("apiVersion", 0) != API_VERSION) throw IllegalStateException("Built for another app API version")
        f.setReadOnly()
        val cl = DexClassLoader(f.absolutePath, c.codeCacheDir.absolutePath, null, Source::class.java.classLoader)
        val cls = cl.loadClass(m.getString("mainClass"))
        val plugin = cls.getDeclaredConstructor().newInstance() as Plugin
        return LoadedPlugin(m.getString("id"), m.optString("name", m.getString("id")), m.optInt("version", 1), plugin.sources())
    }

    fun installedVersion(id: String): Int = if (loaded.containsKey(id)) Store.pluginVersion(id) else 0

    /** Blocking: download, check the checksum, then load. */
    fun install(c: Context, e: PluginEntry) {
        if (e.sha256.isBlank()) throw IllegalStateException("This repo gave no checksum for the plug-in, so it was not installed")
        val data = Net.bytes(e.url, timeoutMs = 30000)
        val sum = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
        if (!sum.equals(e.sha256.trim(), ignoreCase = true)) throw IllegalStateException("Checksum does not match, the file was not installed")
        val tmp = File(c.cacheDir, "dl_" + System.nanoTime() + ".szp")
        tmp.writeBytes(data)
        try {
            val target = File(dir, safeName(e.id) + ".szp")
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) { target.writeBytes(data) }
            tmp.delete()
            val lp: LoadedPlugin = try {
                load(c, target)
            } catch (t: Throwable) {
                target.delete()
                throw t
            }
            synchronized(this) { loaded[lp.id] = lp }
            Store.setPluginVersion(lp.id, e.version)
        } finally {
            tmp.delete()
        }
    }

    fun remove(id: String) {
        synchronized(this) { loaded.remove(id) }
        File(dir, safeName(id) + ".szp").delete()
        Store.clearPlugin(id)
    }

    private fun safeName(id: String) = id.replace(Regex("[^A-Za-z0-9._-]"), "_")
}

object Registry {
    val builtin: List<Source> = listOf(
        com.xio.shizumi.sources.ArchiveSource(),
        com.xio.shizumi.sources.DirectSource()
    )

    fun all(): List<Source> {
        val l = ArrayList<Source>(builtin)
        synchronized(Plugins) { for (p in Plugins.loaded.values) l.addAll(p.sources) }
        return l
    }

    fun isBuiltin(s: Source) = builtin.any { it.id == s.id }
    fun owner(s: Source): LoadedPlugin? = synchronized(Plugins) { Plugins.loaded.values.firstOrNull { p -> p.sources.any { it.id == s.id } } }

    fun active(): Source? {
        val all = all()
        return all.firstOrNull { it.id == Store.activeSource } ?: all.firstOrNull()
    }
}

object Img {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(url: String, target: Int, cb: (Bitmap?) -> Unit) {
        val hit = cache.get(url)
        if (hit != null) { cb(hit); return }
        Bg.run({
            val b = Net.bytes(url)
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= target && o.outWidth > 0) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            BitmapFactory.decodeByteArray(b, 0, b.size, o2)
        }, { r ->
            val bmp = r.getOrNull()
            if (bmp != null) cache.put(url, bmp)
            cb(bmp)
        })
    }

    fun clear() { cache.evictAll() }
}
