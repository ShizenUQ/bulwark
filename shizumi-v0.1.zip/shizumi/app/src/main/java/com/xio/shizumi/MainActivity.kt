package com.xio.shizumi

import android.app.Activity
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.xio.shizumi.api.SAnime
import com.xio.shizumi.api.Source
import com.xio.shizumi.core.Bg
import com.xio.shizumi.core.Plugins
import com.xio.shizumi.core.Store
import com.xio.shizumi.ui.BrowsePage
import com.xio.shizumi.ui.DetailsView
import com.xio.shizumi.ui.Host
import com.xio.shizumi.ui.HomePage
import com.xio.shizumi.ui.K
import com.xio.shizumi.ui.LibraryPage
import com.xio.shizumi.ui.NavBar
import com.xio.shizumi.ui.SettingsPage
import com.xio.shizumi.ui.dp
import com.xio.shizumi.ui.lp

class MainActivity : Activity(), Host {
    private lateinit var root: FrameLayout
    private lateinit var home: HomePage
    private lateinit var browse: BrowsePage
    private lateinit var library: LibraryPage
    private lateinit var settings: SettingsPage
    private lateinit var content: FrameLayout
    private lateinit var nav: NavBar
    private var details: DetailsView? = null
    private lateinit var pages: List<View>

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        Plugins.init(this)

        root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF05080C.toInt(), 0xFF0B1118.toInt())
        )

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16f), dp(12f), dp(16f), dp(10f))
        val mark = View(this)
        mark.background = com.xio.shizumi.ui.CutDrawable(this, K.a(K.CYAN, 0.15f), K.CYAN, 4f, 1.2f, K.PINK)
        head.addView(mark, LinearLayout.LayoutParams(dp(18f), dp(18f)))
        val title = TextView(this)
        title.text = "SHIZUMI"
        title.textSize = 19f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.28f
        title.setTextColor(K.TEXT)
        head.addView(title, lp(-2, -2, 0, 0, dp(10f), 0))
        col.addView(head)
        val line = View(this)
        line.setBackgroundColor(K.a(K.CYAN, 0.25f))
        col.addView(line, LinearLayout.LayoutParams(-1, 1))

        content = FrameLayout(this)
        home = HomePage(this, this)
        browse = BrowsePage(this, this)
        library = LibraryPage(this)
        settings = SettingsPage(this, this)
        pages = listOf(home, browse, library, settings)
        for (p in pages) content.addView(p, FrameLayout.LayoutParams(-1, -1))
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        nav = NavBar(this, listOf("Home", "Browse", "Library", "Settings"))
        nav.onSel = { i -> showTab(i) }
        col.addView(nav, LinearLayout.LayoutParams(-1, -2))

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        showTab(0)
        home.refreshSource()
        Bg.run({ Plugins.loadAll(this) }, { sourcesChanged() })
    }

    override fun showTab(i: Int) {
        for ((k, p) in pages.withIndex()) p.visibility = if (k == i) View.VISIBLE else View.GONE
        nav.sel = i
        if (i == 1) browse.render()
    }

    override fun sourcesChanged() {
        home.refreshSource()
        if (nav.sel == 1) browse.render()
    }

    override fun openDetails(source: Source, anime: SAnime) {
        closeDetails()
        val d = DetailsView(this, this, source, anime)
        details = d
        root.addView(d, FrameLayout.LayoutParams(-1, -1))
    }

    override fun closeDetails() {
        val d = details ?: return
        (d.parent as? ViewGroup)?.removeView(d)
        details = null
    }

    override fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (details != null) closeDetails() else super.onBackPressed()
    }
}
