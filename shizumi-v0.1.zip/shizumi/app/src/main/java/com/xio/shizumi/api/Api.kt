package com.xio.shizumi.api

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Bump this when the contract below changes. Plug-ins built for another version are refused. */
const val API_VERSION = 1

class SAnime(
    val url: String,
    val title: String,
    val cover: String? = null,
    val description: String? = null,
    val genres: List<String> = emptyList(),
    val status: String? = null,
    val author: String? = null
)

class SEpisode(val url: String, val name: String, val number: Float = -1f)

class SVideo(
    val url: String,
    val quality: String,
    val headers: Map<String, String> = emptyMap(),
    val hls: Boolean = false
)

class AnimePage(val items: List<SAnime>, val hasNext: Boolean)

/**
 * One place to get videos from. All functions are called on a background thread and may block.
 * Throw an exception to report an error; the app shows the message.
 */
interface Source {
    val id: String
    val name: String
    val lang: String
    val hint: String get() = ""
    val hasLatest: Boolean get() = false

    fun popular(page: Int): AnimePage
    fun latest(page: Int): AnimePage = AnimePage(emptyList(), false)
    fun search(query: String, page: Int): AnimePage
    fun details(anime: SAnime): SAnime = anime
    fun episodes(anime: SAnime): List<SEpisode>
    fun videos(episode: SEpisode): List<SVideo>
}

/** The class named by `mainClass` in a plug-in's manifest.json extends this. */
abstract class Plugin {
    abstract fun sources(): List<Source>
}

/** Small HTTP helper that plug-ins can use too. */
object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14) Shizumi/0.1"

    private fun open(url: String, headers: Map<String, String>, timeoutMs: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        for ((k, v) in headers) c.setRequestProperty(k, v)
        val code = c.responseCode
        if (code >= 400) throw IOException("HTTP $code")
        return c
    }

    fun get(url: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 15000): String {
        val c = open(url, headers, timeoutMs)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun bytes(url: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 20000): ByteArray {
        val c = open(url, headers, timeoutMs)
        try {
            val out = ByteArrayOutputStream()
            c.inputStream.use { it.copyTo(out) }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }
}
