package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.sin

object Neon {
    const val CYAN = 0xFF19E6F2.toInt()
    const val GREEN = 0xFF3DDC97.toInt()
    const val VIOLET = 0xFF8F6BFF.toInt()
    fun a(c: Int, alpha: Int): Int = (c and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
    fun now(): Float = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
}

/** Animated backdrop: dark gradient, drifting perspective grid, slow scan line and floating sparks. */
class CyberBg(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var running = false
    private val sx = FloatArray(14) { (it * 0.6180339f) % 1f }
    private val sy = FloatArray(14) { (it * 0.3819660f + 0.2f) % 1f }
    private val sv = FloatArray(14) { 0.02f + (it % 5) * 0.012f }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val d = Ui.dp(context, 1f)
        val t = Neon.now()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF05080C.toInt(), 0xFF0B1118.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // glow blobs
        p.shader = android.graphics.RadialGradient(
            w * (0.2f + 0.1f * sin(t * 0.3f)), h * 0.12f, w * 0.7f,
            Neon.a(Neon.CYAN, 38), 0, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = android.graphics.RadialGradient(
            w * (0.85f - 0.1f * sin(t * 0.25f)), h * 0.9f, w * 0.8f,
            Neon.a(Neon.VIOLET, 30), 0, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // grid
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Neon.a(Neon.CYAN, 16)
        val step = 34 * d
        val off = (t * 10 * d) % step
        var y = -step + off
        while (y < h) { c.drawLine(0f, y, w, y, p); y += step }
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, p); x += step }
        // scan line
        val sy0 = ((t * 0.12f) % 1f) * (h + 160 * d) - 80 * d
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, sy0 - 60 * d, 0f, sy0 + 60 * d,
            intArrayOf(0, Neon.a(Neon.CYAN, 26), 0), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, sy0 - 60 * d, w, sy0 + 60 * d, p)
        p.shader = null
        // sparks
        for (i in sx.indices) {
            val yy = ((sy[i] - t * sv[i]) % 1f + 1f) % 1f
            val xx = sx[i] * w + sin(t * 0.7f + i) * 12 * d
            val tw = 0.5f + 0.5f * sin(t * 2f + i * 1.7f)
            p.color = Neon.a(if (i % 3 == 0) Neon.GREEN else Neon.CYAN, (30 + 80 * tw).toInt())
            c.drawCircle(xx, yy * h, (1f + (i % 3) * 0.5f) * d, p)
        }
    }
}

/** Card with a dark glass fill, a neon edge, corner brackets and a light that runs around the border. */
class NeonCard(ctx: Context) : LinearLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private var running = false
    private var phase = (System.identityHashCode(this) % 1000) / 1000f

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            phase = (phase + 0.0045f) % 1f
            invalidate()
            postDelayed(this, 40)
        }
    }

    init {
        setWillNotDraw(false)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val d = Ui.dp(context, 1f)
        r.set(d, d, w - d, h - d)
        path.reset()
        path.addRoundRect(r, 16 * d, 16 * d, Path.Direction.CW)
        pm.setPath(path, false)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xE6111A22.toInt(), 0xE60A1016.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = Neon.a(Neon.CYAN, 46)
        c.drawPath(path, p)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val d = Ui.dp(context, 1f)
        val len = pm.length
        if (len <= 0f) return
        // running light
        val seglen = len * 0.16f
        val start = phase * len
        seg.reset()
        pm.getSegment(start, minOf(start + seglen, len), seg, true)
        if (start + seglen > len) pm.getSegment(0f, start + seglen - len, seg, true)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3.2f * d
        p.color = Neon.a(Neon.CYAN, 40)
        c.drawPath(seg, p)
        p.strokeWidth = 1.4f * d
        p.color = Neon.a(Neon.CYAN, 230)
        c.drawPath(seg, p)
        p.strokeCap = Paint.Cap.BUTT
        // corner brackets
        val w = width.toFloat()
        val h = height.toFloat()
        val k = 12 * d
        val pulse = 150 + (80 * (0.5f + 0.5f * sin(Neon.now() * 2.2f))).toInt()
        p.strokeWidth = 1.6f * d
        p.color = Neon.a(Neon.GREEN, pulse)
        val m = 1.5f * d
        c.drawLine(m, m + k, m, m, p); c.drawLine(m, m, m + k, m, p)
        c.drawLine(w - m - k, h - m, w - m, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - k, p)
    }
}

/** Header logo: a ring with an energy bolt, pulsing glow and crackling arcs. */
class BoltLogo(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bolt = Path()
    private val arc = Path()
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val t = Neon.now()
        val pulse = 0.5f + 0.5f * sin(t * 2.6f)
        val flick = if (((t * 7f).toInt() % 11) == 0) 1f else 0f      // quick flash now and then
        p.style = Paint.Style.FILL
        p.shader = android.graphics.RadialGradient(cx, cy, s * 0.55f,
            Neon.a(Neon.CYAN, (50 + 60 * pulse + 80 * flick).toInt()), 0, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, s * 0.55f, p)
        p.shader = null
        // ring, with a gap that rotates
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.055f
        val rr = s * 0.40f
        val ro = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
        p.color = Neon.a(Neon.CYAN, 60)
        c.drawArc(ro, 0f, 360f, false, p)
        p.color = Neon.GREEN
        c.drawArc(ro, (t * 140f) % 360f, 110f, false, p)
        p.color = Neon.CYAN
        c.drawArc(ro, (t * -90f + 180f) % 360f, 50f, false, p)
        // bolt
        val u = s / 100f
        bolt.reset()
        bolt.moveTo(cx + 6 * u, cy - 30 * u)
        bolt.lineTo(cx - 14 * u, cy + 4 * u)
        bolt.lineTo(cx - 1 * u, cy + 4 * u)
        bolt.lineTo(cx - 7 * u, cy + 30 * u)
        bolt.lineTo(cx + 15 * u, cy - 7 * u)
        bolt.lineTo(cx + 2 * u, cy - 7 * u)
        bolt.close()
        p.style = Paint.Style.FILL
        p.color = Neon.a(Neon.CYAN, (60 + 70 * pulse).toInt())
        c.save(); c.scale(1.18f, 1.18f, cx, cy); c.drawPath(bolt, p); c.restore()
        p.color = Ui.mix(0xFFFFFFFF.toInt(), Neon.CYAN, 0.25f * (1f - pulse))
        c.drawPath(bolt, p)
        // crackling arcs
        val seed = (t * 9f).toInt()
        for (k in 0..1) {
            val ang = ((seed * 67 + k * 180) % 360) * 0.01745f
            val show = ((seed + k * 3) % 4) != 0
            if (!show) continue
            arc.reset()
            var x = cx + kotlin.math.cos(ang) * s * 0.40f
            var y = cy + kotlin.math.sin(ang) * s * 0.40f
            arc.moveTo(x, y)
            for (j in 1..3) {
                val a2 = ang + (((seed + j * 5 + k) % 7) - 3) * 0.06f
                x = cx + kotlin.math.cos(a2) * s * (0.40f - j * 0.075f)
                y = cy + kotlin.math.sin(a2) * s * (0.40f - j * 0.075f)
                arc.lineTo(x, y)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = s * 0.022f
            p.color = Neon.a(Neon.GREEN, 220)
            c.drawPath(arc, p)
        }
        p.strokeCap = Paint.Cap.BUTT
    }
}

/** App title with a moving light and a short glitch every few seconds. */
class GlitchTitle(ctx: Context, private val text: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 40)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        val d = Ui.dp(context, 1f)
        p.textSize = 21 * d
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.letterSpacing = 0.16f
        setMeasuredDimension((p.measureText(text) + 6 * d).toInt(), (30 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.dp(context, 1f)
        val t = Neon.now()
        p.textSize = 21 * d
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.letterSpacing = 0.16f
        val base = 23 * d
        val glitch = (t % 5f) in 4.7f..4.85f
        p.style = Paint.Style.FILL
        if (glitch) {
            val o = 2.4f * d * (if (((t * 40f).toInt() % 2) == 0) 1 else -1)
            p.shader = null
            p.color = Neon.a(Neon.CYAN, 200)
            c.drawText(text, 2 * d + o, base, p)
            p.color = Neon.a(0xFFFF3D7F.toInt(), 170)
            c.drawText(text, 2 * d - o, base, p)
        }
        val tw = p.measureText(text)
        val sweep = ((t * 0.35f) % 1.6f - 0.3f) * tw
        p.shader = LinearGradient(sweep - 40 * d, 0f, sweep + 40 * d, 0f,
            intArrayOf(0xFFE6EDF3.toInt(), Neon.CYAN, 0xFFE6EDF3.toInt()), null, Shader.TileMode.CLAMP)
        c.drawText(text, 2 * d, base, p)
        p.shader = null
        p.letterSpacing = 0f
    }
}
