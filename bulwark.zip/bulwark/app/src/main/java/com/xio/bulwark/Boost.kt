package com.xio.bulwark

import android.app.ActivityManager
import android.content.Context
import android.view.WindowManager

/** One-tap "get the phone ready" actions. Runs shell commands through Shizuku. */
object Boost {
    class Line(val ok: Boolean, val text: String)
    class Result(val freedMb: Long, val lines: List<Line>)

    @Volatile var running = false
    @Volatile var last: Result? = null
    @Volatile var lastAt = 0L

    fun availMb(c: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.availMem / 1048576L
    }

    fun totalMb(c: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.totalMem / 1048576L
    }

    fun active(c: Context) = Prefs.bool(c, "bo_on", false)

    @Suppress("DEPRECATION")
    private fun maxHz(c: Context): Int {
        return try {
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            var best = 60f
            for (m in wm.defaultDisplay.supportedModes) if (m.refreshRate > best) best = m.refreshRate
            Math.round(best)
        } catch (t: Throwable) { 60 }
    }

    private fun bad(o: String): Boolean {
        val l = o.lowercase()
        return l.startsWith("err:") || l.contains("exception") || l.contains("error") ||
            l.contains("unknown command") || l.contains("not found") || l.contains("denied")
    }

    private fun get(c: Context, ns: String, key: String): String {
        val o = FpsClient.shell(c, "settings get $ns $key", 4000).trim()
        return if (o.isEmpty() || bad(o)) "null" else o
    }

    private fun put(c: Context, ns: String, key: String, v: String): Boolean {
        val o = if (v == "null") FpsClient.shell(c, "settings delete $ns $key", 4000)
        else FpsClient.shell(c, "settings put $ns $key $v", 4000)
        return !bad(o)
    }

    /** Runs the boost. Blocking: call from a background thread. step(text, progress 0..1). */
    fun run(c: Context, game: String?, step: (String, Float) -> Unit): Result {
        running = true
        val lines = ArrayList<Line>()
        var freed = 0L
        try {
            val first = !active(c)
            val before = availMb(c)
            var n = 0
            val total = listOf(Prefs.BO_RAM, Prefs.BO_CACHE, Prefs.BO_HZ, Prefs.BO_BATT, Prefs.BO_DND).count {
                Prefs.bool(c, it, true)
            } + (if (game != null && Prefs.bool(c, Prefs.BO_GAME, true)) 1 else 0)
            fun adv(t: String) { n++; step(t, n / (total + 1f)) }

            if (Prefs.bool(c, Prefs.BO_RAM, true)) {
                adv("Closing background apps")
                val o = FpsClient.shell(c, "am kill-all", 8000)
                lines.add(Line(!bad(o), if (bad(o)) "Background apps: command refused" else "Background apps closed"))
            }
            if (Prefs.bool(c, Prefs.BO_CACHE, true)) {
                adv("Trimming caches")
                val o = FpsClient.shell(c, "pm trim-caches 999G", 20000)
                lines.add(Line(!bad(o), if (bad(o)) "Cache trim: not supported here" else "App caches trimmed"))
            }
            if (Prefs.bool(c, Prefs.BO_HZ, true)) {
                adv("Locking refresh rate")
                val hz = maxHz(c)
                if (first) {
                    Prefs.putStr(c, "bo_o_min", get(c, "system", "min_refresh_rate"))
                    Prefs.putStr(c, "bo_o_peak", get(c, "system", "peak_refresh_rate"))
                }
                val a = put(c, "system", "min_refresh_rate", hz.toString())
                val b = put(c, "system", "peak_refresh_rate", hz.toString())
                lines.add(Line(a && b, if (a && b) "Refresh rate pinned at $hz Hz" else "Refresh rate: not allowed by this phone"))
            }
            if (Prefs.bool(c, Prefs.BO_BATT, true)) {
                adv("Battery saver off")
                if (first) Prefs.putStr(c, "bo_o_batt", get(c, "global", "low_power"))
                val ok = put(c, "global", "low_power", "0")
                lines.add(Line(ok, if (ok) "Battery saver off" else "Battery saver: could not change"))
            }
            if (Prefs.bool(c, Prefs.BO_DND, false)) {
                adv("Silencing notifications")
                if (first) Prefs.putStr(c, "bo_o_dnd", get(c, "global", "zen_mode"))
                val o = FpsClient.shell(c, "cmd notification set_dnd priority", 4000)
                lines.add(Line(!bad(o), if (bad(o)) "Do not disturb: not supported" else "Do not disturb on"))
            }
            if (game != null && Prefs.bool(c, Prefs.BO_GAME, true)) {
                adv("Game performance mode")
                val o = FpsClient.shell(c, "cmd game set --mode performance $game", 5000)
                val ok = !bad(o)
                if (ok) Prefs.putStr(c, "bo_game_pkg", game)
                lines.add(Line(ok, if (ok) "Game mode: performance" else "Game mode: not supported here"))
            }
            Prefs.putBool(c, "bo_on", true)
            step("Measuring", 0.96f)
            Thread.sleep(1500)
            freed = maxOf(0L, availMb(c) - before)
            val r = Result(freed, lines)
            last = r
            lastAt = System.currentTimeMillis()
            step("Done", 1f)
            return r
        } catch (t: Throwable) {
            lines.add(Line(false, "Stopped: ${t.message ?: t}"))
            val r = Result(freed, lines)
            last = r
            return r
        } finally {
            running = false
        }
    }

    /** Puts every setting back to what it was before the boost. Blocking. */
    fun restore(c: Context): List<Line> {
        val out = ArrayList<Line>()
        if (!active(c)) { out.add(Line(true, "Nothing to restore")); return out }
        if (Prefs.bool(c, Prefs.BO_HZ, true) && Prefs.str(c, "bo_o_min", "") != "") {
            val a = put(c, "system", "min_refresh_rate", Prefs.str(c, "bo_o_min", "null"))
            val b = put(c, "system", "peak_refresh_rate", Prefs.str(c, "bo_o_peak", "null"))
            out.add(Line(a && b, "Refresh rate restored"))
        }
        if (Prefs.str(c, "bo_o_batt", "") != "") {
            val v = Prefs.str(c, "bo_o_batt", "0")
            if (v == "1") out.add(Line(put(c, "global", "low_power", "1"), "Battery saver restored"))
        }
        if (Prefs.str(c, "bo_o_dnd", "") != "") {
            val v = Prefs.str(c, "bo_o_dnd", "0")
            if (v == "0" || v == "null") {
                val o = FpsClient.shell(c, "cmd notification set_dnd off", 4000)
                out.add(Line(!bad(o), "Do not disturb off"))
            }
        }
        val g = Prefs.str(c, "bo_game_pkg", "")
        if (g.isNotEmpty()) {
            FpsClient.shell(c, "cmd game set --mode standard $g", 4000)
            Prefs.putStr(c, "bo_game_pkg", "")
            out.add(Line(true, "Game mode restored"))
        }
        for (k in listOf("bo_o_min", "bo_o_peak", "bo_o_batt", "bo_o_dnd")) Prefs.putStr(c, k, "")
        Prefs.putBool(c, "bo_on", false)
        if (out.isEmpty()) out.add(Line(true, "Settings restored"))
        return out
    }

    /** Called when a game session starts (auto boost). */
    fun autoStart(c: Context, pkg: String) {
        if (!Prefs.bool(c, Prefs.BO_AUTO, false) || running) return
        if (FpsClient.state(c) != FpsClient.St.READY) return
        val app = c.applicationContext
        Thread { run(app, pkg) { _, _ -> } }.start()
    }

    /** Called when the game session ends (auto boost). */
    fun autoEnd(c: Context) {
        if (!Prefs.bool(c, Prefs.BO_AUTO, false) || !active(c)) return
        val app = c.applicationContext
        Thread { restore(app) }.start()
    }
}
