package com.xio.bulwark

import kotlin.system.exitProcess

/** Backup path: runs inside the Shizuku "shell" process (uid 2000) when it can be bound. */
class ShellService : IShellService.Stub() {

    private val engine = FpsEngine { sh(it) }

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(cmd: String?): String? = sh(cmd ?: "")

    override fun debug(): String? = engine.dbg

    override fun sample(ownPkg: String?): String? = engine.sample(ownPkg ?: "")

    private fun sh(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "$cmd 2>&1"))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            p.destroy()
            out
        } catch (t: Throwable) {
            "ERR:$t"
        }
    }
}
