package com.xio.bulwark

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

class Song(val file: String, val title: String)

/** The playlist (songs copied into the app) and one MediaPlayer. Everything is called on the main thread. */
object Music {
    private var songs: List<Song> = emptyList()
    private var stamp = -1L
    private var mp: MediaPlayer? = null

    var index = -1
        private set
    @Volatile var playing = false
        private set
    @Volatile var panelOpen = false
    var onChange: (() -> Unit)? = null

    private fun dir(c: Context) = File(c.filesDir, "music").also { it.mkdirs() }
    private fun listFile(c: Context) = File(dir(c), "list.txt")

    @Synchronized
    fun list(c: Context): List<Song> {
        val f = listFile(c)
        val st = if (f.exists()) f.lastModified() + f.length() else 0L
        if (st != stamp) {
            stamp = st
            songs = if (!f.exists()) emptyList() else f.readLines().mapNotNull {
                val p = it.split("\t")
                if (p.size >= 2 && File(dir(c), p[0]).exists()) Song(p[0], p[1]) else null
            }
        }
        return songs
    }

    fun count(c: Context): Int = list(c).size

    private fun save(c: Context, l: List<Song>) {
        listFile(c).writeText(l.joinToString("\n") { it.file + "\t" + it.title.replace("\t", " ").replace("\n", " ") })
        stamp = -1L
    }

    /** Copies one audio file into the app. Returns false if it is not audio or could not be read. */
    fun add(c: Context, uri: Uri): Boolean {
        return try {
            val mime = c.contentResolver.getType(uri) ?: ""
            if (mime.isNotEmpty() && !mime.startsWith("audio") && mime != "application/ogg") return false
            var name = "song"
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0) ?: name
            }
            val title = name.substringBeforeLast('.', name)
            val fn = "s" + System.currentTimeMillis() + "_" + (Math.random() * 1000).toInt() + ".dat"
            val out = File(dir(c), fn)
            var total = 0L
            c.contentResolver.openInputStream(uri)!!.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > 60L * 1024 * 1024) { out.delete(); return false }
                        os.write(buf, 0, n)
                    }
                }
            }
            synchronized(this) { save(c, list(c) + Song(fn, title)) }
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun remove(c: Context, i: Int) {
        val l = list(c).toMutableList()
        if (i !in l.indices) return
        if (i == index) stop()
        else if (i < index) index--
        File(dir(c), l[i].file).delete()
        l.removeAt(i)
        synchronized(this) { save(c, l) }
        onChange?.invoke()
    }

    fun clear(c: Context) {
        stop()
        for (s in list(c)) File(dir(c), s.file).delete()
        synchronized(this) { save(c, emptyList()) }
        onChange?.invoke()
    }

    fun move(c: Context, from: Int, to: Int) {
        val l = list(c).toMutableList()
        if (from !in l.indices) return
        val t = to.coerceIn(0, l.size - 1)
        if (t == from) return
        val sg = l.removeAt(from)
        l.add(t, sg)
        if (index == from) index = t
        else if (from < index && t >= index) index--
        else if (from > index && t <= index) index++
        synchronized(this) { save(c, l) }
    }

    fun position(): Int = try { mp?.currentPosition ?: 0 } catch (t: Throwable) { 0 }
    fun duration(): Int = try { mp?.duration ?: 0 } catch (t: Throwable) { 0 }
    fun seek(ms: Int) { try { mp?.seekTo(ms) } catch (t: Throwable) { } }

    fun pause() {
        try {
            val m = mp
            if (m != null && m.isPlaying) { m.pause(); playing = false; onChange?.invoke() }
        } catch (t: Throwable) { }
    }

    fun title(c: Context): String = list(c).getOrNull(index)?.title ?: ""

    fun play(c: Context, i: Int) {
        val l = list(c)
        if (l.isEmpty()) return
        val n = ((i % l.size) + l.size) % l.size
        release()
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            m.setDataSource(File(dir(c), l[n].file).absolutePath)
            m.setOnCompletionListener { next(c) }          // after the last song it loops to the first
            m.setOnErrorListener { _, _, _ -> playing = false; onChange?.invoke(); true }
            m.prepare()
            m.start()
            mp = m
            index = n
            playing = true
        } catch (t: Throwable) {
            release()
            playing = false
        }
        onChange?.invoke()
    }

    fun toggle(c: Context) {
        val m = mp
        if (m == null) { play(c, if (index < 0) 0 else index); return }
        try {
            if (m.isPlaying) { m.pause(); playing = false } else { m.start(); playing = true }
        } catch (t: Throwable) { }
        onChange?.invoke()
    }

    fun next(c: Context) = play(c, (if (index < 0) 0 else index) + 1)
    fun prev(c: Context) = play(c, (if (index < 0) 0 else index) - 1)

    private fun release() {
        try { mp?.release() } catch (t: Throwable) { }
        mp = null
    }

    fun stop() {
        release()
        playing = false
        index = -1
        onChange?.invoke()
    }
}
