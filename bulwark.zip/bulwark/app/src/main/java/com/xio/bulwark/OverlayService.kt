package com.xio.bulwark

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.xio.bulwark.STOP"
        const val ACTION_TOGGLE_LOCK = "com.xio.bulwark.TOGGLE_LOCK"
        const val ACTION_TOGGLE_SOUND = "com.xio.bulwark.TOGGLE_SOUND"
        private const val CHANNEL = "bulwark_watch"
        private const val NOTIF_ID = 7
        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        const val ACTION_MUSIC_PREV = "com.xio.bulwark.MUSIC_PREV"
        const val ACTION_MUSIC_TOGGLE = "com.xio.bulwark.MUSIC_TOGGLE"
        const val ACTION_MUSIC_NEXT = "com.xio.bulwark.MUSIC_NEXT"

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var root: HudRoot? = null
    private lateinit var lp: WindowManager.LayoutParams
    private class Spot(val v: TapSpot, val lp: WindowManager.LayoutParams)
    private val spots = HashMap<String, Spot>()
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var t0 = 0L
    private var screenOn = true

    private val loop = object : Runnable {
        override fun run() {
            try {
                val c = applicationContext
                val raw = try { FpsClient.sample(c) } catch (t: Throwable) { null }
                val data = FpsData.parse(raw)
                val sys = StatsReader.read(c, t0)
                main.post {
                    try {
                        root?.applyPrefs()
                        applyWindowState()
                        root?.update(data, sys)
                    } catch (t: Throwable) { }
                }
            } catch (t: Throwable) {
            }
            if (screenOn) wh?.postDelayed(this, 500)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; wh?.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; wh?.removeCallbacks(loop); wh?.post(loop) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        t0 = SystemClock.elapsedRealtime()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true
        registerReceiver(screenRx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        showOverlay()
        Music.onChange = {
            main.post {
                root?.hud?.poke()
                panel?.refreshCurrent()
                try {
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
                } catch (t: Throwable) { }
            }
        }
        worker = HandlerThread("bulwark-sampler").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE_LOCK -> toggleLock()
            ACTION_TOGGLE_SOUND -> toggleSound()
            ACTION_MUSIC_PREV -> Music.prev(applicationContext)
            ACTION_MUSIC_TOGGLE -> Music.toggle(applicationContext)
            ACTION_MUSIC_NEXT -> Music.next(applicationContext)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenRx) } catch (t: Throwable) { }
        Music.onChange = null
        hidePanel()
        Music.stop()
        clearSpots()
        root?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        root = null
        FpsClient.unbind(applicationContext)
        super.onDestroy()
    }

    // ---------- overlay window ----------

    private fun showOverlay() {
        val dm = Resources.getSystem().displayMetrics
        val v = HudRoot(this)
        v.applyPrefs()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Prefs.int(this, Prefs.X, (24 * dm.density).toInt())
        lp.y = Prefs.int(this, Prefs.Y, (24 * dm.density).toInt())
        lp.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        v.onMusic = { i -> onMusicTap(i) }
        v.onDrag = { dx, dy ->
            if (panel != null) hidePanel()
            lp.x += dx
            lp.y += dy
            clamp(v)
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        v.onDragEnd = { snap(v) }
        v.onToggleLock = { toggleLock() }
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> syncSpots() }
        try {
            wm.addView(v, lp)
            root = v
        } catch (t: Throwable) {
            stopSelf()
        }
    }

    private fun clamp(v: View) {
        val dm = Resources.getSystem().displayMetrics
        val w = if (v.width > 0) v.width else 1
        val h = if (v.height > 0) v.height else 1
        lp.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, dm.heightPixels - h))
    }

    private fun snap(v: View) {
        val dm = Resources.getSystem().displayMetrics
        val margin = (10 * dm.density).toInt()
        val mid = lp.x + v.width / 2
        val target = if (mid < dm.widthPixels / 2) margin else maxOf(margin, dm.widthPixels - v.width - margin)
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
            }
            start()
        }
        Prefs.putInt(this, Prefs.X, target)
        Prefs.putInt(this, Prefs.Y, lp.y)
    }

    // ---------- lock ----------

    private fun toggleLock() {
        val now = !Prefs.bool(this, Prefs.LOCKED, false)
        Prefs.putBool(this, Prefs.LOCKED, now)
        root?.applyPrefs()
        applyWindowState()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /** Locked = every touch passes through to the game (window opacity must stay at 80% or less on Android 12+). */
    private fun applyWindowState() {
        val v = root ?: return
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val op = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        val flags = if (locked) BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else BASE_FLAGS
        val a = if (locked) min(op, 0.8f) else op
        if (lp.flags != flags || lp.alpha != a) {
            lp.flags = flags
            lp.alpha = a
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        if (locked) syncSpots() else clearSpots()
    }

    private fun toggleSound() {
        Prefs.putBool(this, Prefs.SOUND, !Prefs.bool(this, Prefs.SOUND, false))
        root?.applyPrefs()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /**
     * While locked the overlay lets every touch through. The only exceptions are two tiny invisible
     * windows placed exactly over the lock icon (to unlock) and the sound icon (to mute / unmute).
     */
    private fun syncSpots() {
        val r = root ?: return
        if (!Prefs.bool(this, Prefs.LOCKED, false)) return
        spot("lock", r.lockRectPx()) { toggleLock() }
        spot("sound", r.soundRectPx()) { toggleSound() }
        val mr = r.musicRectsPx()
        for (i in 0..3) spot("m$i", mr.getOrNull(i)) { onMusicTap(i) }
    }

    // ---------- music ----------

    private var panel: MusicPanel? = null
    private var panelLp: WindowManager.LayoutParams? = null

    private fun onMusicTap(i: Int) {
        val c = applicationContext
        when (i) {
            0 -> if (panel != null) hidePanel() else showPanel()
            1 -> Music.prev(c)
            2 -> Music.toggle(c)
            3 -> Music.next(c)
        }
        root?.hud?.poke()
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        panelLp = null
        Music.panelOpen = false
        root?.hud?.poke()
        p.animate().alpha(0f).scaleY(0.85f).setDuration(140).withEndAction {
            try { wm.removeView(p) } catch (t: Throwable) { }
        }.start()
    }

    private fun showPanel() {
        val r = root ?: return
        val c = applicationContext
        val songs = Music.list(c)
        if (songs.isEmpty()) {
            android.widget.Toast.makeText(c, "Add songs first: Frameline app > Live > Music", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val dm = Resources.getSystem().displayMetrics
        val hits = r.hud.musicHits()
        val s = r.hud.scalePx()
        val iconCx = if (hits != null) (hits[0].left + hits[0].right) / 2f * s else 40f * s
        val p = MusicPanel(this)
        val ph = p.desiredHeight(songs.size)
        val gap = (2 * dm.density).toInt()
        val below = lp.y + r.height + ph <= dm.heightPixels - (24 * dm.density).toInt()
        p.wireOnTop = below
        p.wireX = iconCx
        p.fill(songs)
        p.onPick = { i -> Music.play(c, i); hidePanel() }
        p.onOutside = { hidePanel() }
        val pw = maxOf(r.width, (200 * dm.density).toInt())
        val l = WindowManager.LayoutParams(
            pw, ph, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - pw))
        l.y = if (below) lp.y + r.height - gap else lp.y - ph + gap
        p.wireX = iconCx + (lp.x - l.x)
        p.alpha = 0f
        p.scaleY = 0.85f
        p.pivotX = p.wireX
        p.pivotY = if (below) 0f else ph.toFloat()
        try {
            wm.addView(p, l)
            panel = p
            panelLp = l
            Music.panelOpen = true
            p.animate().alpha(1f).scaleY(1f).setDuration(220).start()
            r.hud.poke()
        } catch (t: Throwable) { }
    }

    private fun spot(name: String, rect: Rect?, onTap: () -> Unit) {
        val old = spots[name]
        if (rect == null || rect.width() <= 0 || rect.height() <= 0) {
            if (old != null) { try { wm.removeView(old.v) } catch (t: Throwable) { }; spots.remove(name) }
            return
        }
        val dm = Resources.getSystem().displayMetrics
        val x = (lp.x + rect.left).coerceIn(0, maxOf(0, dm.widthPixels - rect.width()))
        val y = (lp.y + rect.top).coerceIn(0, maxOf(0, dm.heightPixels - rect.height()))
        if (old != null) {
            if (old.lp.x == x && old.lp.y == y && old.lp.width == rect.width() && old.lp.height == rect.height()) return
            old.lp.x = x; old.lp.y = y; old.lp.width = rect.width(); old.lp.height = rect.height()
            try { wm.updateViewLayout(old.v, old.lp) } catch (t: Throwable) { }
            return
        }
        val v = TapSpot(this)
        v.onTap = onTap
        val l = WindowManager.LayoutParams(rect.width(), rect.height(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        l.x = x; l.y = y
        try {
            wm.addView(v, l)
            spots[name] = Spot(v, l)
        } catch (t: Throwable) { }
    }

    private fun clearSpots() {
        for (sp in spots.values) { try { wm.removeView(sp.v) } catch (t: Throwable) { } }
        spots.clear()
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Overlay watch", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val lock = PendingIntent.getService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_LOCK), PendingIntent.FLAG_IMMUTABLE
        )
        val snd = PendingIntent.getService(
            this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_SOUND), PendingIntent.FLAG_IMMUTABLE
        )
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val soundOn = Prefs.bool(this, Prefs.SOUND, false)
        val hasVideo = Prefs.str(this, Prefs.MEDIA_TYPE, "") == "video"
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Frameline is running")
            .setContentText(if (locked) "Locked - touches pass through to the game." else "Unlocked - drag the overlay anywhere.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, if (locked) "Unlock" else "Lock", lock).build())
        if (hasVideo) b.addAction(Notification.Action.Builder(icon, if (soundOn) "Sound off" else "Sound on", snd).build())
        if (Music.count(this) > 0) {
            val pv = PendingIntent.getService(this, 4, Intent(this, OverlayService::class.java).setAction(ACTION_MUSIC_PREV), PendingIntent.FLAG_IMMUTABLE)
            val pt = PendingIntent.getService(this, 5, Intent(this, OverlayService::class.java).setAction(ACTION_MUSIC_TOGGLE), PendingIntent.FLAG_IMMUTABLE)
            val pn = PendingIntent.getService(this, 6, Intent(this, OverlayService::class.java).setAction(ACTION_MUSIC_NEXT), PendingIntent.FLAG_IMMUTABLE)
            b.addAction(Notification.Action.Builder(icon, "Prev", pv).build())
            b.addAction(Notification.Action.Builder(icon, if (Music.playing) "Pause" else "Play", pt).build())
            b.addAction(Notification.Action.Builder(icon, "Next", pn).build())
        }
        b.addAction(Notification.Action.Builder(icon, "Stop", stop).build())
        return b.build()
    }
}

/** Invisible touch area. Sits over an icon of a locked overlay so only that spot catches taps. */
class TapSpot(ctx: Context) : View(ctx) {
    var onTap: (() -> Unit)? = null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}
