package com.xio.bulwark

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.xio.bulwark.STOP"
        private const val CHANNEL = "bulwark_watch"
        private const val NOTIF_ID = 7

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var hud: HudView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var t0 = 0L
    private var screenOn = true

    private val loop = object : Runnable {
        override fun run() {
            val c = applicationContext
            val raw = try { FpsClient.sample(c) } catch (t: Throwable) { null }
            val data = FpsData.parse(raw)
            val sys = StatsReader.read(c, t0)
            main.post {
                hud?.applyPrefs()
                hud?.update(data, sys)
            }
            if (screenOn) wh?.postDelayed(this, 500)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; wh?.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; wh?.removeCallbacks(loop); wh?.post(loop) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        t0 = SystemClock.elapsedRealtime()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true
        registerReceiver(screenRx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        showOverlay()
        worker = HandlerThread("bulwark-sampler").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenRx) } catch (t: Throwable) { }
        hud?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        hud = null
        FpsClient.unbind(applicationContext)
        super.onDestroy()
    }

    // ---------- overlay window ----------

    private fun showOverlay() {
        val dm = Resources.getSystem().displayMetrics
        val v = HudView(this)
        v.applyPrefs()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Prefs.int(this, Prefs.X, (24 * dm.density).toInt())
        lp.y = Prefs.int(this, Prefs.Y, (24 * dm.density).toInt())
        v.onDrag = { dx, dy ->
            lp.x += dx
            lp.y += dy
            clamp(v)
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        v.onDragEnd = { snap(v) }
        v.onLong = {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (t: Throwable) { }
        }
        try {
            wm.addView(v, lp)
            hud = v
        } catch (t: Throwable) {
            stopSelf()
        }
    }

    private fun clamp(v: HudView) {
        val dm = Resources.getSystem().displayMetrics
        val w = if (v.width > 0) v.width else 1
        val h = if (v.height > 0) v.height else 1
        lp.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, dm.heightPixels - h))
    }

    private fun snap(v: HudView) {
        val dm = Resources.getSystem().displayMetrics
        val margin = (10 * dm.density).toInt()
        val mid = lp.x + v.width / 2
        val target = if (mid < dm.widthPixels / 2) margin else maxOf(margin, dm.widthPixels - v.width - margin)
        val from = lp.x
        ValueAnimator.ofInt(from, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
            }
            start()
        }
        Prefs.putInt(this, Prefs.X, target)
        Prefs.putInt(this, Prefs.Y, lp.y)
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Overlay watch", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stand down", stop).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Bulwark is on watch")
            .setContentText("Overlay running. Tap to open settings.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action)
            .build()
    }
}
