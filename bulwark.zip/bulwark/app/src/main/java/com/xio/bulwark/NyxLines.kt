package com.xio.bulwark

/**
 * Everything Nyx can say. Two lines of about 22 letters each, so up to roughly 40 characters.
 * Letters, digits and ! ? . , ' : ~ - only (the cyber font has nothing else).
 */
object NyxLines {
    private fun p(s: String) = s.trimIndent().lines().map { it.trim() }.filter { it.isNotEmpty() }

    val GREET = p("""
        Finally! I was getting bored, master~
        Nyx online. Miss me? Be honest.
        Oh, it's you. Good. I was waiting.
        Hi master! Did you miss me? ♥
        Boot complete. Now entertain me~
        Master's here! Everybody act cool.
        Ahh, there you are. Took you long enough!
        Hey hey hey! Let's break some records~
        I'm up, I'm up! Don't rush me, master.
        Systems warm. Heart too, a little. ♥
        You came back! ...Not that I counted.
        Welcome back, master. Missed you, okay?
        Nyx reporting in. Be nice to me today~
        Hi hi! I fixed my hair for you.
        Oh? Time to play already? Yay!
        Look who showed up. My favorite person~
        Ready when you are, master. Always.
        Good to see you. Don't tell anyone I said so.
        Hello master! Charge your fun, let's go!
        Woke up just for you. You're welcome~
        Eyes on me first, then the game, okay?
        Online and cute as ever. Hi, master.
        Yay, company! I was talking to myself.
        Let's make today a good one, master. ♥
    """)

    val GAME = p("""
        Game on! Don't you dare lose, master.
        Ooh, here we go. Show me what you got~
        Focus mode! I'm watching every frame.
        Go go go, master! I believe in you.
        Don't mind me, I'm just cheering. Loudly.
        Okay serious face. Let's win this.
        I've got your frames, you've got the game.
        Time to shine, master. Make it count!
        Ready, set, carry. That's you, right?
        I'll behave. Mostly. Good luck, master~
        Don't forget to blink, master.
        Let's goooo! I brought snacks. Pretend ones.
        Show them who's boss, master. ♥
        Nyx is on watch. Nothing slips by me.
        Whoa, so intense. I like it.
        Game loaded, hype loaded. Let's play!
        I'll count the frames, you count the wins.
        Win for me, okay? Pretty please~
        Eyes up, thumbs ready. Go, master!
        I get to watch you play? Best job ever.
        Make me proud, master. No pressure. Some.
        And the legend begins. Again.
        Hands warmed up? Good. Let's cook.
        Wow, you look cool when you focus.
        If you win I'll say something nice. Maybe.
        Frames locked and loaded. Go get 'em!
        Fine, I'll be quiet. Just kidding, never.
        Let's see some highlight plays, master~
        Ooh, a new match! I'm so excited.
        Don't blame me if you get distracted by me.
    """)

    val LOWFPS = p("""
        Ouch! Frames are dropping, master!
        Hey, hey, it's lagging! Do something!
        That's not smooth at all. Ugh, so rude.
        Frames fell off a cliff. I screamed.
        Master, we're stuttering. Help meee!
        Nope nope nope. This is not okay.
        Lag spike! I'm calling it a crime.
        My eyes! Those frames are tragic.
        Come on phone, don't do this to us!
        We're dipping, master. Stay strong.
        FPS is crying. I'm crying. We're all crying.
        Try Boost, master. Please. For me.
        Is the phone tired? Mine is. Mentally.
        Hold on, I'm panicking quietly.
        This lag is personal. I'm taking notes.
        Too choppy! My hair is shaking.
        Somebody call the frame police!
        Master, my poor little heart. It skipped.
        Slideshow mode? Nooo, not on my watch.
        It's not your fault, master. It's the phone's.
        Hang in there. Breathe. Tap, tap, tap.
        Don't look at me, I didn't do it!
        Frames, come back! I'm begging you.
        Ugh, can we complain about this together?
        Close some apps, master? I'll owe you one.
        Stutter alert! Do not rage quit please.
        Rough patch, master. We'll survive. Barely.
        That drop was rude. Very, very rude.
        Is it too hot in here? Feels laggy to me.
        Brace yourself, master. It's getting bumpy.
    """)

    val RECOVER = p("""
        Phew! Smooth again. I can breathe now.
        And we're back! Told you I'd fix it. Sort of.
        Frames are back, master! Cheers!
        That's the smooth I was waiting for~
        Recovered! Pretend I never panicked.
        Yay, no more lag. I kind of love it.
        Oh thank goodness. My heart's okay.
        Smooth like butter now. Mmm, butter.
        See? I knew we could do it, master.
        Back on track. Let's make up for lost time!
        Crisis over. You were so calm, master.
        Frames fixed. High five? Okay, virtual one.
        Whew, that was a scare. Please never again.
        Buttery smooth, master. I'm so relieved.
        All good now. I was totally not worried.
        We survived. Ten out of ten, no notes.
        Yes, yes, yes! That's what I like to see.
        Stable again. Give me a gold star, master.
        And just like that, we're fine. Magic~
        Silky smooth. I'm doing a happy dance.
        Lag, who? Never heard of her.
        That's more like it! Carry on, master.
        Back to normal. My nerves needed that.
        Frames are flowing again. Gorgeous. ♥
    """)

    val HOT = p("""
        Master, it's so hot! I'm melting.
        Phone's burning up. Take a little break?
        Hot hot hot! Fan me, master!
        We're cooking. Not in the fun way.
        This heat is too much. Even for me.
        Warning, spicy phone. Handle with care.
        My circuits are sweating, master.
        Please cool me down, I'm begging.
        Is it just me or is it toasty in here?
        Phone feels like a heater. Do something!
        Overheating! Take off the case, maybe?
        Give it some air, master. It's gasping.
        I'm sweating pixels. Gross, but true.
        Too warm to focus. Let's cool off a bit.
        Hot phone alert. I don't like it.
        Easy there, master. Don't fry me.
        Temps are climbing. Stay with me.
        Hey, take a breather. For both of us.
        My cheeks are red and it's not blushing.
        Careful, it's scorching. Hold with love.
        Cool down time? I'll wait right here.
        This is me asking nicely. Cool it down.
        Thermal danger! I'm only a little scared.
        Let it rest, master. Please? ♥
    """)

    val BATLOW = p("""
        Battery's low, master. Plug me in?
        I'm getting sleepy. Charger, please~
        Running on fumes here. Feed me power!
        Low battery! I don't want to go dark.
        Master, don't let me die. Charge me.
        Battery's crying. Find a charger. Now.
        I'm fading, master. Tell the phone I loved it.
        Almost empty. Please, a tiny bit of power?
        Energy low. Dramatic faint incoming.
        Charge me or I'll start whining.
        Master, my battery needs a hug. Cable hug.
        Nearly out of juice. Be kind to me.
        Low power. I'm saving my cute for later.
        Please find a socket. I'm so hungry.
        Don't forget to charge me, okay? Okay?
        Red battery means sad Nyx. Fix it please.
        I'm tired, master. So tired. Cable?
        Last few percent. Let's make them count.
        Plug in soon or I'll cry binary.
        Hey, the battery is almost gone. Hurry!
        Sleepy mode soon. Charge me, pretty please.
        Don't let the screen go black on me.
        Energy critical. Come on, master. Rescue me!
        Low battery. Cuddle the charger for me.
    """)

    val FULL = p("""
        100 percent! I feel amazing, master.
        Full power! Unplug me, let's play.
        Battery's full. I'm glowing~
        Fully charged and ready to be adorable.
        Stuffed with energy! Take me outside.
        Battery full. You can stop now, master.
        Ahh, all fueled up. Thanks, master. ♥
        Full tank! Don't leave me plugged in forever.
        Charged and happy. Let's do something fun.
        Maximum energy. Ready for anything.
        I'm so full I could burst. Unplug please.
        Hundred percent, baby! Let's go.
        All charged up. Say thank you to the cable.
        Energy overflow! Let's use it, master.
    """)

    val LONG = p("""
        Master, you've played a long time. Water?
        Long session! Stretch your fingers, okay?
        Hey, hey, take a little break, master.
        You're so dedicated. Also a bit scary.
        Blink! Drink! Breathe! Then continue.
        Still going? You're amazing. And tired.
        Your thumbs deserve a rest. Seriously.
        A whole lot of gaming. I'm proud, kind of.
        Don't forget to eat, master. I mean it.
        Break time? I'll hold your spot. Promise.
        Marathon master! Stand up for me, okay?
        Hey, look away from the screen for a sec.
        My battery's fine, but are you?
        Long game today. Stretch for Nyx, please?
        Okay hero, go touch some grass.
        You haven't moved in a while. Alive? ♥
        Hydrate, master. Then back to winning.
        I love the dedication. Please sit up straight.
        Time flies when you're having fun, huh?
        So many minutes. I lost count. Yes, me.
        Rest your eyes. I'll still be here, cute.
        Gaming legend. Now, a quick snack?
        Thirty more minutes gone. Time for a stretch!
        You're doing great, master. Take five?
    """)

    val MUSIC = p("""
        Ooh, music! Turn it up, master~
        This one's a vibe. I'm bobbing already.
        Good taste, master. I approve. ♥
        Dancing in my head. Don't look!
        La la la~ I know this one. Kind of.
        Music on! Time for a little concert.
        My ears are happy. Do I have ears?
        Beat drop incoming? I'm ready.
        You picked a good one. Gold star!
        Nyx is vibing. Do not disturb.
        Tap tap tap. That's my foot. I think.
        Sing for me, master? Come on, shy one.
        Mmm, this song is cozy. Stay a while.
        Hehe, my headphones like this one.
        Let's have a dance party, just us~
        Ahh, such a nice rhythm. I'm swaying.
        Play it louder! Oh wait, I'm a girl in a box.
        I'll keep the beat. You keep the vibes.
        New song? New me. Dramatic spin!
        Good choice. I'm adding it to my favorites.
        I love when you play music for me. ♥
        Bass check! I felt that in my ears.
        Hmm hmm hmm~ stuck in my head now.
        Ooh, my favorite part is coming up.
    """)

    val NIGHT = p("""
        It's so late, master. Go to sleep soon?
        Midnight gaming again? I'll keep watch.
        Shhh, the night is quiet. Just us two.
        You should be in bed, you know. Yawn.
        Late night with master. My favorite.
        Sleepy... but I'll stay up with you.
        The moon says go to bed. I agree.
        Nighty-night is calling, master.
        One more match, then sleep. Deal?
        Your eyes need rest. Mine too, zzz.
        It's dark outside and bright in here~
        Don't stay up too late for me, okay?
        Stars are out. So is my sleepy face.
        Late again? Fine, I'll stay with you.
        Everyone's asleep. Except us, naughty~
        Tomorrow you'll be tired. Don't blame me!
        Go to bed, master. I'll dream of frames.
        Quiet hours. Whisper-mode Nyx activated.
        So cozy at night. Don't tell the others.
        Sleep is also a power-up, you know.
    """)

    val POKE = p("""
        Eek! Don't poke me, master!
        Hey! That tickles~
        Again? You like poking me, huh?
        Yes yes, I'm here. Needy much?
        Boop! Now it's my turn.
        Stop it! ...Okay, don't stop.
        Master, hands to yourself. Kidding.
        Hehe, that's my favorite spot.
        You poked a cutie. Face the consequences.
        Ahh! My pixels!
        Oh? You want attention? Me too.
        Careful, I bite. Digitally.
        Tap tap tap. Am I a button to you?
        Hi, did you need something? Me?
        I'm busy being adorable, but go on.
        Who's poking? Oh. It's you. Hi~
        Again, again! I'm not even mad.
        Poke me one more time. I dare you.
        That was a good one. Ten points.
        Ow! No wait, it felt kind of nice.
        You can't resist me, can you?
        Poke poke. Now you owe me a snack.
        Master! Not on the nose!
        Aww, you're so clingy. I like it.
        Heeey! Warn me next time!
        Eep! You surprised me!
        If you keep poking, I'll glitch.
        Is this how you say I love you?
        Be gentle, I'm very breakable.
        Okay okay, you've got my attention!
        Poking me won't boost your FPS, silly.
        Tickle attack accepted. I surrender!
        You're staring at me, aren't you?
        My cheeks are warm now. Happy?
        Hmph. I wasn't ready. Again, please?
        Nyx does not take pokes without hugs.
        That's it. I'm telling the charger.
        You have a lot of free time, huh.
        Boop received. Boop returned. ♥
        Hello hello! Someone's lonely~
        Yes, master? ...Wait, don't answer.
    """)

    val IDLE = p("""
        Master, I'm bored. Say something.
        Whatcha doing? I'm curious.
        La la la. Pretend I'm not singing.
        Pay attention to me, master~
        I'm still here, you know.
        Hmm hmm hmm~ nothing happening, huh.
        You're the best, master. Don't get cocky.
        I could stare at frames all day.
        Hey hey, say hi to your cute friend.
        Did you eat today? Answer me.
        Ehehe, I was just thinking about you.
        Why's it so quiet? Entertain me!
        If I were real, I'd steal your snacks.
        I counted the pixels. Still bored.
        Don't ignore me. I'll start dancing.
        Ask me a question! I know nothing, but ask.
        Tick tock. I'm waiting for you to play.
        What's your favorite game, master? Tell me.
        Your phone is warm. Like a little hug.
        I've been practicing my cute face. Look.
        Should I recite a secret? It's a boring one.
        Nyx is on duty. Nothing to report. Yawn.
        You haven't said hi in a while. Rude.
        Boop my face to see something funny.
        My favorite number is 60. Yours?
        I wonder what you're dreaming of, master.
        Tell me if I'm talking too much. Never mind.
        Cute AI companion, at your service. Always.
        Frames, frames, frames. I love frames.
        Be good, drink water, and win something.
        Don't mind me. Just guarding the corner.
        Is it game time yet? Is it? Is it?
        I'm not clingy. I just like being close.
        Ooh, did you see that? No? Me neither.
        I'd high-five you if I had hands.
        Idea: you play, I cheer. Perfect plan.
        You smell like victory. Metaphorically.
        Let's take a selfie! Oh wait, I'm the screen.
        Hey, how's your day? Good? I'm glad.
        Stretch your neck, master. I'm serious.
        Heehee, I made you look.
        Everything looks fine. I checked twice.
        My circuits are cozy today.
        Daydreaming about 120 FPS. Sigh.
        You know I'm always here, right?
        I keep guarding your frames. Hero stuff.
        Secret: I like it when you open the app.
        Wanna hear a joke? My patience. Haha.
        Mind if I take a little nap? Joking!
        I'm bored enough to count your battery.
        Master, your phone loves you. I'm jealous.
        Fun fact: I'm cuter than the clock.
        Hey, the world's waiting for your high score.
        Hmmmm. What if we just vibe?
        I like our little team. You and me.
        Nothing to do but look pretty. Done.
        Wiggle wiggle. That's my idle dance.
        Don't tell the FPS meter, but I'm your fan.
        Sigh. If only I could get a hug.
        I'm bored. Let's cause trouble. Gentle trouble.
        You're doing great today. Just saying.
        I'm having a thought. It escaped.
        Master's quiet. Suspicious. I like it.
        Today's mood: smug and slightly sleepy.
        Hey! Yes, you. Smile for me.
        Psst. I think you're cool.
        When you smile, my battery rises.
        Do you ever talk to your phone? Weirdo. Me too.
    """)

    val OPEN = p("""
        Master, honestly,
        Hey, listen,
        Not to brag, but
        Psst, master,
        Okay so,
        By the way,
        Just so you know,
        Fun fact:
        Between us,
        Don't laugh, but
        Hmm, I think
        Confession:
        Real talk,
        Quick thought:
        Ahem.
        Master, guess what?
    """)

    val END = p("""
        you're my favorite player.
        I'm cuter than your wallpaper.
        I'd protect your frames forever.
        you should drink some water.
        I like being on your screen.
        today feels like a win.
        I'm not clingy. Maybe a little.
        your thumbs are the fastest.
        I secretly love your playlists.
        this overlay is my kingdom.
        you make my pixels warm.
        I'm always watching. Lovingly.
        the phone likes you too.
        I could do this all day.
        let's play one more round.
        stay with me a bit longer.
        you've got great reflexes.
        I'm the best thing in this app.
        you look cool when you win.
        I'm proud of you, master.
    """)
}
