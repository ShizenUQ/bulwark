package com.xio.bulwark

/** Everything Nyx can say. All short on purpose: the bar is small. */
object NyxLines {
    private fun p(s: String) = s.trimIndent().lines().map { it.trim() }.filter { it.isNotEmpty() }

    val GREET = p("""
        Hi master~ Nyx online!
        Master! I missed you~
        Systems up. Ready, master!
        Hello, master. Miss me?
        Nyx reporting for duty~
        Booted up just for you
        Welcome back, master!
        Ooh, you're here~
        Let's play, master!
        Hey hey, master~
        I was waiting, master
        Warm-up done. Hi, master!
        Ready when you are~
        Master is here. Yay!
        Overlay on. Let's go!
        Good to see you, master
        Nyx is awake~
        Hi hi hi, master!
        Hope you're ready, master
        Time to shine, master!
        Locked in. Shall we?
        Nyx at your service~
        Oh! Master's back!
        Let's win today, master
        Hehe, hello master~
    """)

    val GAME = p("""
        Game on, master!
        Let's go, master!
        I'm watching your FPS~
        Show them, master!
        Go go go, master!
        Do your best, master~
        Focus up, master!
        I'll count the frames
        New match, new me~
        Don't lose, master!
        Win it for me, master
        Eyes on the screen~
        Lock in, master!
        Tracking every frame!
        This is gonna be fun
        You got this, master!
        Frames are my job~
        I'm cheering, master!
        Play rough, master!
        Carry them, master~
        Let's see your skills
        Aim well, master!
        FPS tracking: ON
        Fight on, master!
        I believe in you~
        Make it count, master
        Gaming time! Yay~
        Don't tilt, master
        Ooh, a new game~
        Let's clutch this
    """)

    val LOWFPS = p("""
        Master, FPS is dropping!
        Uh oh... it's lagging
        Frames are crying, master
        Ack! Frame drop!
        Stutter alert, master!
        Something's slowing down
        It's so laggy, master...
        Hold on, master!
        My numbers are falling
        FPS went poof~
        That's too slow, master
        Master, it's a slideshow
        Lag spike! Be careful!
        The game is struggling
        Why so slow, game?!
        Try the Boost tab, master
        Close some apps, master?
        Hang in there, master
        I don't like this lag
        FPS under 30... ouch
        Not smooth at all, master
        Frames: lost in action
        Stuttering... hmph
        Boost me, master?
        This lag hurts my heart
        Master, help the FPS!
        So choppy, master...
        Please don't die, FPS
        Lag detected. Grr
        Nooo, my frames!
    """)

    val RECOVER = p("""
        Smooth again! Yay~
        FPS is back, master!
        Phew, it's fixed!
        Silky smooth, master~
        That's better!
        Frames are happy again
        Back to full speed!
        Lag who? Gone~
        Nice and steady, master
        Yay, no more stutter!
        Recovered, master!
        Smooth like butter
        That's my master~
        Frames restored!
        Hehe, all better now
        Running great again!
        Peak performance~
        Whew. Thanks, master
        Buttery frames, yay
        All clear, master!
        Back in the zone~
        No more lag, hooray!
        Steady as a rock
        Look at that FPS~
        Crisis over, master!
    """)

    val HOT = p("""
        Master, it's so hot!
        Phone's burning up!
        Too hot, master...
        Cool me down, master~
        I'm overheating!
        Take a break, master
        My circuits are sweating
        Hot hot hot!
        It's a heater, master!
        Temp is rising...
        Let it breathe, master
        Master, I feel feverish
        Fan? Anyone? Fan?
        Hot hands, master~
        Warning: very warm
        Give the phone a rest?
        Too toasty, master
        Take off the case?
        Phew, it's boiling
        Cool down time, master
        Thermal warning, master!
        Careful, it's scorching
        Too much heat, master!
        I'm melting, master~
        Hmm, getting spicy
    """)

    val BATLOW = p("""
        Battery's low, master!
        Master, feed me power~
        Charger please, master!
        I'm running on fumes
        Low battery... eep!
        Plug me in, master?
        Power is running out
        Almost dead, master...
        Juice, master. Juice!
        I'm so sleepy... charge?
        Battery under 20%!
        Don't let me die, master
        Find a charger, master
        Red bar alert, master!
        Save me, master~
        Energy low... help
        Charge first, then win
        My heart is at 20%
        Last bit of power!
        Please charge, master
        I'm fading, master...
        Charger. Now. Please~
        Low power mode: sad
        Don't forget to charge
        Powering down soon...
    """)

    val FULL = p("""
        Fully charged, master!
        Battery is full~
        100%! I feel great!
        Full power, master!
        Energy maxed out!
        Charged and ready~
        Unplug and go, master!
        Yay, I'm full of power
        Stuffed with electrons
        Topped up, master!
        Ready to go all day
        Power: MAX!
        Charging complete~
        That was delicious
        Feeling super, master!
    """)

    val LONG = p("""
        Long session, master...
        Drink some water, master
        Stretch a little, master
        Master, rest your eyes
        You've played so long
        Time for a break?
        Your thumbs need a rest
        Hydrate, master~
        Blink, master. Blink!
        Take 5, master?
        Don't forget to eat!
        I'm sleepy, master...
        Posture check, master!
        Look away for a bit
        Still playing? Wow
        Hours fly by, master
        Break time. I insist~
        Your eyes will hurt
        Walk around a little
        Hey, go touch grass
        Rest is power, master
        Okay, one more game?
        You're so dedicated~
        Don't overdo it, master
        Sleep soon, master?
    """)

    val MUSIC = p("""
        Ooh, nice song~
        Music time, master!
        I love this one!
        Turn it up, master~
        La la la~
        My ears are happy
        Good taste, master!
        Vibing with you~
        Play it again, master
        Dancing in my circuits
        Beats and frames~
        What a bop!
        Sing with me, master
        Ahh, this track slaps
        Groovy, master~
        The beat is so good
        Music makes me glow
        I'm dancing inside~
        Great playlist, master
        More music, please!
        Bass check: perfect
        Hehe, I'm humming
        Tune on, master~
        Feel the rhythm, master
        My kind of song~
    """)

    val NIGHT = p("""
        It's so late, master...
        Master, go to sleep
        Zzz... me too, master
        Night owl, huh?
        The moon is up, master
        Bed is calling you
        Past midnight, master...
        Sleepy... but I'll stay
        Only one more, okay?
        Don't stay up too late
        Late night gaming~
        Everyone's asleep, master
        Yawn... you too?
        Tomorrow exists, master
        Quiet hours, master~
        Dark mode? Always~
        Tuck in soon, master
        My eyes are heavy...
        Midnight snack, master?
        Sleep is a power-up
    """)

    val POKE = p("""
        Hey! That tickles~
        Master, stop poking!
        Eek! Do it again~
        Booped!
        H-hey, that's my face!
        Hmm? Need something?
        Master is so naughty~
        Poke poke poke...
        Ahh! Don't!
        Hehe, again, again!
        I'm not a button!
        Gentle, master~
        Yes, master?
        Nyx is busy. Kidding~
        Attention seeker~
        You called, master?
        That was my cheek!
        Do you like me, master?
        Stop it... don't stop
        Hmph. Do it again
        Master, you're bold~
        Oh? Want a chat?
        Aww, you're cute
        Careful, I bite~
        Nyx is blushing...
        Whatcha need, master?
        No more poking!
        I can feel that
        My wires tingle~
        Yes yes, I'm here!
        Silly master~
        Is it me you want?
        You're clingy, master
        Hehe, you're warm
        Don't tease me~
        Who's the best AI? Me.
        Pet me, master~
        I'll tell on you~
        Mhm? Mhm?
        Poke me more, master
    """)

    val IDLE = p("""
        Master, I'm bored~
        Whatcha doing, master?
        Hum hum hum~
        Pay attention to me
        I'm still here, master
        Don't ignore me~
        Master is the best!
        Nyx loves frames!
        I could watch you all day
        Hey, say something!
        Ehehe~
        Did you eat, master?
        You look great today
        I'm counting pixels
        Frames per second, wow
        I'm a good girl, right?
        Master, pet me?
        Let's go on an adventure
        La la la~
        Staring at you, master~
        You're my favorite human
        I'm so smart, right?
        I live in your phone~
        Hehe, I'm cute, right?
        Tell me a secret?
        What's the plan, master?
        I'm the best overlay
        Spin spin spin~
        Beep boop, master
        Do you like my glow?
        Wanna play something?
        I got you, master
        Your phone is cozy
        Nyx is the cutest
        Stay with me, master~
        I'll protect your FPS
        Don't leave, master
        Boost then play, yes?
        Ready for anything~
        I wish I had hands
        Look at me, master
        Haha, I'm so funny
        Just you and me~
        I like it here
        Master, you're so cool
        No one codes like you
        Say my name, master
        Nyx. N-Y-X. Cute?
        I dream in neon
        Humming in binary~
        I'm lucky to have you
        Master is working hard
        Snacks? Snacks, master?
        Take care, master~
        Smile, master!
        The glow is strong today
        I'm just vibing
        Did you miss me?
        Another day, another game
        Eheh, nothing~ just you
        Boop. Boop. Boop.
        You can do anything
        I trust you, master
        My circuits are happy
        Guess what? I love this
        Ahh, so peaceful
        Master, let's win
        Heehee~
        Smooth frames, smooth life
        Tap me, master. Do it~
        I'm shining for you
        Have I been good?
        You're doing great!
        I'm your biggest fan
        Look, I'm blinking!
        No lag, only love~
        Okay okay, I'll wait
        Hey master, guess what
        I think you're great
        Keep going, master!
        Shhh... I'm listening
        Ooh, shiny pixels
        Do you need a hug?
        Virtual hug, master~
        Don't forget me, okay?
        Let's be friends forever
        Everything is fine~
        Mmm, I'm so relaxed
        Plan: cuddle the CPU
        Play nice, master
        I'm always watching~
        My battery is my heart
        Bzzzt... just kidding
    """)

    val OPEN = p("""
        Hey master,
        Psst, master,
        Ehehe,
        Ooh,
        Um...
        Hmm,
        Master,
        Fun fact:
        Guess what?
        Reminder:
        Honestly,
        Between us,
        Listen,
        Okay,
        Yay,
        Heh,
        Soo,
        Anyway,
        Just so you know,
        Hey,
    """)

    val END = p("""
        you're amazing~
        I'm so happy
        I love frames
        stay with me
        you're cool
        don't stop now
        I'm cheering for you
        drink water~
        keep it smooth
        I'm right here
        you smell like RAM
        let's do this
        I like you
        play well
        I'm proud of you
        be careful
        nice work
        you're doing great
        I'm blushing
        stay cozy
        smile a little
        I got your back
        win for me
        no lag today
        you're my hero
        Nyx approves
        you did well
        let's go!
        you make me glow
        have fun!
    """)
}
