package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * The status screen that loops through the gallery: images and clips one after another, muted (unless
 * "clip sound" is on). Runs only while it is visible. A short scan flash plays between items.
 */
class MediaBox(private val ctx: Context) : FrameLayout(ctx) {

    var hasSource = false
        private set
    var onPos: ((Int, Int) -> Unit)? = null

    private var list: List<GItem> = emptyList()
    private var idx = 0
    private var loadedKey = ""
    private var active = false
    private var soundOn = false
    private var tv: TextureView? = null
    private var mp: MediaPlayer? = null
    private val iv = ImageView(ctx)
    private var anim: Drawable? = null
    private var wantVideo: GItem? = null
    private val h = Handler(Looper.getMainLooper())
    private val nextRun = Runnable { advance() }
    private var flashAt = 0L
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 4f * resources.displayMetrics.density)
            }
        }
        setBackgroundColor(0xFF000000.toInt())
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(iv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    fun configure(sound: Boolean) {
        if (sound == soundOn) return
        soundOn = sound
        if (wantVideo != null && mp != null) { releasePlayer(); if (active) startVideo() }
    }

    /** Reloads when the gallery (or shuffle) changed. Cheap when nothing changed. */
    fun load() {
        val key = Gallery.ver(ctx).toString() + "/" + Prefs.bool(ctx, Gallery.SHUF, false)
        if (key == loadedKey) return
        loadedKey = key
        stopAll()
        var l = Gallery.enabled(ctx)
        if (Prefs.bool(ctx, Gallery.SHUF, false)) l = l.shuffled()
        list = l
        hasSource = l.isNotEmpty()
        idx = 0
        shown = -1
        if (active && hasSource) show(0, false)
    }

    private var shown = -1

    fun setActive(a: Boolean) {
        active = a
        if (!a) { stopAll(); shown = -1; return }
        if (hasSource && shown != idx) show(idx, false)
    }

    /** Next item right now (tap on the screen). */
    fun advance() {
        if (list.isEmpty()) return
        idx = (idx + 1) % list.size
        show(idx, true)
    }

    private fun slideMs(): Long = Prefs.int(ctx, Gallery.SLIDE, 4000).toLong().coerceIn(2000L, 20000L)

    private fun show(i: Int, flash: Boolean) {
        if (list.isEmpty() || !active) return
        h.removeCallbacks(nextRun)
        releasePlayer()
        val it = list[i.coerceIn(0, list.size - 1)]
        shown = idx
        if (flash) { flashAt = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
        onPos?.invoke(idx, list.size)
        val a = anim
        if (a is AnimatedImageDrawable) a.stop()
        anim = null
        if (it.type == "video") {
            wantVideo = it
            iv.visibility = View.GONE
            val t = ensureTv()
            t.alpha = 1f
            if (t.isAvailable) startVideo()
        } else {
            wantVideo = null
            tv?.alpha = 0f
            iv.visibility = View.VISIBLE
            var set = false
            if (it.type == "anim" && Build.VERSION.SDK_INT >= 28) {
                try {
                    val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(Gallery.file(ctx, it)))
                    if (d is AnimatedImageDrawable) { d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; d.start() }
                    anim = d
                    iv.setImageDrawable(d)
                    set = true
                } catch (t: Throwable) { }
            }
            if (!set) iv.setImageBitmap(Gallery.thumb(ctx, it))
            if (list.size > 1) h.postDelayed(nextRun, slideMs())
        }
    }

    private fun ensureTv(): TextureView {
        tv?.let { return it }
        val t = TextureView(ctx)
        t.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { if (active && wantVideo != null) startVideo() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { releasePlayer(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = t
        addView(t, 0, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        return t
    }

    private fun startVideo() {
        if (mp != null) return
        val it = wantVideo ?: return
        val st = tv?.surfaceTexture ?: return
        try {
            val m = MediaPlayer()
            val s = Gallery.silent(ctx, it)
            m.setDataSource((if (!soundOn && s.exists()) s else Gallery.file(ctx, it)).absolutePath)
            m.setSurface(Surface(st))
            val solo = list.size <= 1
            m.isLooping = solo
            if (soundOn) m.setVolume(1f, 1f) else m.setVolume(0f, 0f)
            m.setOnVideoSizeChangedListener { _, vw, vh -> fit(vw, vh) }
            m.setOnErrorListener { _, _, _ -> releasePlayer(); h.postDelayed(nextRun, 600); true }
            if (!solo) m.setOnCompletionListener { advance() }
            m.setOnPreparedListener { p -> if (active) p.start() }
            m.prepareAsync()
            mp = m
        } catch (t: Throwable) {
            releasePlayer()
            h.postDelayed(nextRun, 600)
        }
    }

    private fun fit(vw: Int, vh: Int) {
        val t = tv ?: return
        t.post {
            val w = t.width.toFloat()
            val hh = t.height.toFloat()
            if (w <= 0f || hh <= 0f || vw <= 0 || vh <= 0) return@post
            val va = vw.toFloat() / vh
            val ba = w / hh
            val m = Matrix()
            if (va > ba) m.setScale(va / ba, 1f, w / 2f, hh / 2f) else m.setScale(1f, ba / va, w / 2f, hh / 2f)
            t.setTransform(m)
        }
    }

    private fun releasePlayer() {
        val m = mp ?: return
        mp = null
        try { m.setOnPreparedListener(null); m.setOnCompletionListener(null); m.stop() } catch (t: Throwable) { }
        try { m.release() } catch (t: Throwable) { }
    }

    private fun stopAll() {
        h.removeCallbacks(nextRun)
        releasePlayer()
        val a = anim
        if (a is AnimatedImageDrawable) a.stop()
    }

    /** A quick cyan scan + glitch bars between items. */
    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val age = SystemClock.uptimeMillis() - flashAt
        if (flashAt != 0L && age in 0..360) {
            val k = age / 360f
            val w = width.toFloat()
            val hh = height.toFloat()
            fp.style = Paint.Style.FILL
            fp.color = 0x2219E6F2 and 0x00FFFFFF or (((1f - k) * 70).toInt() shl 24)
            c.drawRect(0f, 0f, w, hh, fp)
            val y = k * hh
            fp.color = 0xFF19E6F2.toInt()
            c.drawRect(0f, y - 1f, w, y + 1f, fp)
            for (i in 0 until 4) {
                val ry = Cy.rnd((age / 60).toInt() * 7 + i) * hh
                fp.color = Cy.a(0xFFFFFFFF.toInt(), 0.18f * (1f - k))
                c.drawRect(0f, ry, w, ry + hh * 0.03f, fp)
            }
            postInvalidateOnAnimation()
        }
    }

    override fun onDetachedFromWindow() {
        stopAll()
        super.onDetachedFromWindow()
    }
}
