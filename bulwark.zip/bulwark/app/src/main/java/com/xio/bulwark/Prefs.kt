package com.xio.bulwark

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bulwark", Context.MODE_PRIVATE)

    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    const val SOUND = "sound"
    const val STYLE = "style"
    const val MODE = "mode"
    const val LOCKED = "locked"
    const val MEDIA_TYPE = "media_type"
    const val MEDIA_VER = "media_ver"
    const val X = "x"
    const val Y = "y"
    const val TARGET = "target"
    const val OPACITY = "opacity"
    const val SCALE = "scale"
    const val GRAPH = "graph"
    const val BARS = "bars"
    const val FOOTER = "footer"
    const val COLLAPSED = "collapsed"
    const val EFFECTS = "effects"
    const val REMIND = "remind_h"
    const val BOOT = "boot"
    const val NYX = "nyx_on"
    const val NYX_FREQ = "nyx_freq"
    const val BO_RAM = "bo_ram"
    const val BO_CACHE = "bo_cache"
    const val BO_HZ = "bo_hz"
    const val BO_BATT = "bo_batt"
    const val BO_DND = "bo_dnd"
    const val BO_GAME = "bo_game"
    const val BO_AUTO = "bo_auto"
}
