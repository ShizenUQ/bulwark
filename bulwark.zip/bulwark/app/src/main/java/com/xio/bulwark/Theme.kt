package com.xio.bulwark

object C {
    val BG = 0xFF14171A.toInt()
    val PANEL = 0xFF1E2227.toInt()
    val STEEL_HI = 0xFF2E343B.toInt()
    val STEEL_LO = 0xFF1B1F24.toInt()
    val BRASS = 0xFFB8935A.toInt()
    val BRASS_HI = 0xFFE0C27A.toInt()
    val BRASS_DIM = 0xFF7A6238.toInt()
    val BRASS_DARK = 0xFF4A4130.toInt()
    val TEXT = 0xFFD8D3C4.toInt()
    val TEXT_DIM = 0xFF8D8A80.toInt()
    val GOOD = 0xFF5FA37A.toInt()
    val MID = 0xFFD9A441.toInt()
    val BAD = 0xFFD9532B.toInt()
    val EMPTY = 0xFF23282E.toInt()
    val SLIT = 0xFF0D1012.toInt()
    val SH_GOOD = 0xFF2F5B45.toInt()
    val SH_MID = 0xFF6B5224.toInt()
    val SH_BAD = 0xFF6E2A1B.toInt()
    val SH_NA = 0xFF343A41.toInt()
}
