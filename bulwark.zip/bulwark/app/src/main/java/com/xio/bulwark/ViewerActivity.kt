package com.xio.bulwark

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Full-screen viewer: just the picture or the clip. Swipe sideways for the next one, down to close, pinch / double-tap to zoom. */
class ViewerActivity : Activity() {

    private lateinit var items: List<GItem>
    private var idx = 0
    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var iv: ImageView
    private var tv: TextureView? = null
    private var mp: MediaPlayer? = null
    private lateinit var hud: Overlay
    private lateinit var soundBtn: RoundBtn
    private lateinit var closeBtn: RoundBtn
    private var soundOn = false
    private var curVideo: GItem? = null
    private var bmp: Bitmap? = null
    private var token = 0
    private val vm = Matrix()
    private var base = 1f
    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var mode = 0 // 0 none, 1 pan, 2 swipe, 3 drag down
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var scaling = false
    private var vt: VelocityTracker? = null
    private var busy = false
    private lateinit var sd: ScaleGestureDetector
    private lateinit var gd: GestureDetector

    private fun dp(v: Float) = (v * resources.displayMetrics.density)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        items = if (intent.getIntExtra("kind", 1) == 0) Gallery.videos(this) else Gallery.images(this)
        if (items.isEmpty()) { finish(); return }
        idx = intent.getIntExtra("idx", 0).coerceIn(0, items.size - 1)
        root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(-1, -1))
        iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.MATRIX
        stage.addView(iv, FrameLayout.LayoutParams(-1, -1))
        hud = Overlay(this)
        root.addView(hud, FrameLayout.LayoutParams(-1, -1))
        val bs = dp(46f).toInt()
        closeBtn = RoundBtn(this, 0)
        val cl = FrameLayout.LayoutParams(bs, bs)
        cl.gravity = android.view.Gravity.TOP or android.view.Gravity.END
        cl.topMargin = dp(30f).toInt(); cl.rightMargin = dp(16f).toInt()
        root.addView(closeBtn, cl)
        closeBtn.setOnClickListener { finish() }
        soundBtn = RoundBtn(this, 1)
        val sl = FrameLayout.LayoutParams(bs, bs)
        sl.gravity = android.view.Gravity.BOTTOM or android.view.Gravity.END
        sl.bottomMargin = dp(34f).toInt(); sl.rightMargin = dp(16f).toInt()
        root.addView(soundBtn, sl)
        soundBtn.setOnClickListener { toggleSound() }
        setContentView(root)
        sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean = curVideo == null && bmp != null
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val ns = (scale * d.scaleFactor).coerceIn(1f, 6f)
                val f = ns / scale
                scale = ns
                tx = d.focusX - (d.focusX - tx) * f
                ty = d.focusY - (d.focusY - ty) * f
                apply()
                return true
            }
        })
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (curVideo != null || bmp == null) return false
                val target = if (scale > 1.05f) 1f else 2.6f
                val f = target / scale
                scale = target
                tx = e.x - (e.x - tx) * f
                ty = e.y - (e.y - ty) * f
                apply(true)
                return true
            }
        })
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) window.attributes.layoutInDisplayCutoutMode =
            android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        stage.addOnLayoutChangeListener { _, l, t, r, bt, ol, ot, orr, ob ->
            if (r - l != orr - ol || bt - t != ob - ot) { if (curVideo != null) fitVideo() else fitImage() }
        }
        stage.alpha = 0f
        stage.scaleX = 0.96f; stage.scaleY = 0.96f
        stage.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        open(idx)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onPause() {
        super.onPause()
        releasePlayer()
    }

    override fun onResume() {
        super.onResume()
        val v = curVideo
        if (v != null && mp == null && tv?.isAvailable == true) startVideo(v)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, android.R.anim.fade_out)
    }

    // ---- content ----

    private fun open(i: Int) {
        idx = i
        token++
        val my = token
        releasePlayer()
        val a = iv.drawable
        if (a is AnimatedImageDrawable) a.stop()
        iv.setImageDrawable(null)
        bmp = null
        val it = items[i]
        hud.setPos(i, items.size)
        scale = 1f; tx = 0f; ty = 0f
        if (it.type == "video") {
            curVideo = it
            iv.visibility = View.GONE
            soundBtn.visibility = View.VISIBLE
            val t = ensureTv()
            t.visibility = View.VISIBLE
            if (t.isAvailable) startVideo(it)
        } else {
            curVideo = null
            tv?.visibility = View.GONE
            soundBtn.visibility = View.GONE
            iv.visibility = View.VISIBLE
            val th = Gallery.thumb(this, it)
            if (th != null) { bmp = th; fitImage() }
            Thread {
                var d: android.graphics.drawable.Drawable? = null
                var full: Bitmap? = null
                if (it.type == "anim" && Build.VERSION.SDK_INT >= 28) {
                    try { d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(Gallery.file(this, it))) } catch (t: Throwable) { }
                }
                if (d == null) full = Gallery.decode(Gallery.file(this, it), 2600)
                runOnUiThread {
                    if (my != token) return@runOnUiThread
                    if (d != null) {
                        if (d is AnimatedImageDrawable) { d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; d.start() }
                        bmp = null
                        iv.imageMatrix = Matrix()
                        iv.scaleType = ImageView.ScaleType.FIT_CENTER
                        iv.setImageDrawable(d)
                    } else if (full != null) {
                        iv.scaleType = ImageView.ScaleType.MATRIX
                        bmp = full
                        fitImage()
                    }
                }
            }.start()
        }
    }

    private fun fitImage() {
        val b = bmp ?: return
        val w = stage.width.toFloat(); val h = stage.height.toFloat()
        if (w <= 0f || h <= 0f) return
        iv.scaleType = ImageView.ScaleType.MATRIX
        if (iv.drawable == null || (iv.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap !== b) iv.setImageBitmap(b)
        base = min(w / b.width, h / b.height)
        scale = 1f; tx = (w - b.width * base) / 2f; ty = (h - b.height * base) / 2f
        apply()
    }

    private fun apply(animate: Boolean = false) {
        val b = bmp ?: return
        val w = stage.width.toFloat(); val h = stage.height.toFloat()
        val s = base * scale
        val iw = b.width * s; val ih = b.height * s
        tx = if (iw <= w) (w - iw) / 2f else tx.coerceIn(w - iw, 0f)
        ty = if (ih <= h) (h - ih) / 2f else ty.coerceIn(h - ih, 0f)
        vm.reset()
        vm.postScale(s, s)
        vm.postTranslate(tx, ty)
        iv.imageMatrix = vm
    }

    private fun ensureTv(): TextureView {
        tv?.let { return it }
        val t = TextureView(this)
        t.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { curVideo?.let { startVideo(it) } }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fitVideo() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { releasePlayer(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv = t
        stage.addView(t, 0, FrameLayout.LayoutParams(-1, -1))
        return t
    }

    private var vw = 0
    private var vh = 0

    private fun startVideo(it: GItem) {
        if (mp != null) return
        val st = tv?.surfaceTexture ?: return
        try {
            val m = MediaPlayer()
            m.setDataSource(Gallery.file(this, it).absolutePath)
            m.setSurface(Surface(st))
            m.isLooping = true
            val v = if (soundOn) 1f else 0f
            m.setVolume(v, v)
            m.setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; fitVideo() }
            m.setOnPreparedListener { p -> p.start() }
            m.setOnErrorListener { _, _, _ -> true }
            m.prepareAsync()
            mp = m
        } catch (t: Throwable) { releasePlayer() }
    }

    private fun fitVideo() {
        val t = tv ?: return
        val w = t.width.toFloat(); val h = t.height.toFloat()
        if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return
        val va = vw.toFloat() / vh
        val ba = w / h
        val m = Matrix()
        if (va > ba) m.setScale(1f, ba / va, w / 2f, h / 2f) else m.setScale(va / ba, 1f, w / 2f, h / 2f)
        t.setTransform(m)
    }

    private fun releasePlayer() {
        val m = mp ?: return
        mp = null
        try { m.setOnPreparedListener(null); m.stop() } catch (t: Throwable) { }
        try { m.release() } catch (t: Throwable) { }
    }

    private fun toggleSound() {
        soundOn = !soundOn
        soundBtn.on = soundOn
        if (soundOn) Music.pause()
        try { mp?.setVolume(if (soundOn) 1f else 0f, if (soundOn) 1f else 0f) } catch (t: Throwable) { }
    }

    // ---- touch ----

    private fun go(dir: Int) {
        val n = idx + dir
        if (n < 0 || n >= items.size || busy) { back(); return }
        busy = true
        val w = stage.width.toFloat()
        stage.animate().translationX(-dir * w).alpha(0.2f).setDuration(150).withEndAction {
            open(n)
            stage.translationX = dir * w
            stage.animate().translationX(0f).alpha(1f).setDuration(230).setInterpolator(DecelerateInterpolator()).withEndAction { busy = false }.start()
        }.start()
    }

    private fun back() {
        stage.animate().translationX(0f).translationY(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        hud.fade(1f)
    }

    private var btnDown = false

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        // let the two small buttons take their own taps
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            btnDown = inView(closeBtn, e) || (soundBtn.visibility == View.VISIBLE && inView(soundBtn, e))
        }
        if (btnDown) {
            val r = super.dispatchTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) btnDown = false
            return r
        }
        return onTouch(e)
    }

    private fun inView(v: View, e: MotionEvent): Boolean {
        val r = IntArray(2)
        v.getLocationOnScreen(r)
        return e.rawX >= r[0] && e.rawX <= r[0] + v.width && e.rawY >= r[1] && e.rawY <= r[1] + v.height
    }

    private fun onTouch(e: MotionEvent): Boolean {
        if (busy) return true
        gd.onTouchEvent(e)
        sd.onTouchEvent(e)
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; mode = 0; scaling = false
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
            }
            MotionEvent.ACTION_POINTER_DOWN -> { scaling = true; mode = 1 }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (e.pointerCount > 1 || sd.isInProgress) { scaling = true; lastX = e.x; lastY = e.y; return true }
                if (scaling) { lastX = e.x; lastY = e.y; return true }
                val dx = e.x - downX; val dy = e.y - downY
                if (mode == 0 && (abs(dx) > slop || abs(dy) > slop)) {
                    mode = if (scale > 1.05f && bmp != null) 1 else if (abs(dx) > abs(dy)) 2 else 3
                }
                when (mode) {
                    1 -> { tx += e.x - lastX; ty += e.y - lastY; apply() }
                    2 -> {
                        val edge = (idx == 0 && dx > 0) || (idx == items.size - 1 && dx < 0)
                        stage.translationX = if (edge) dx * 0.3f else dx
                    }
                    3 -> {
                        stage.translationY = if (dy > 0) dy else dy * 0.25f
                        val f = (1f - abs(dy) / (stage.height * 0.9f)).coerceIn(0.35f, 1f)
                        stage.alpha = f; stage.scaleX = 0.8f + 0.2f * f; stage.scaleY = stage.scaleX
                        hud.fade(f)
                    }
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                val dx = e.x - downX; val dy = e.y - downY
                when (mode) {
                    2 -> {
                        val far = abs(dx) > stage.width * 0.2f || abs(vx) > 1300f
                        if (far && dx != 0f) go(if (dx < 0) 1 else -1) else back()
                    }
                    3 -> if (dy > stage.height * 0.14f) finish() else back()
                    1 -> { if (scale < 1.05f) apply() }
                }
                scaling = false
                mode = 0
                vt?.recycle(); vt = null
            }
        }
        return true
    }

    // ---- small drawn views ----

    private class RoundBtn(ctx: Context, private val kind: Int) : View(ctx) {
        var on = false
            set(v) { field = v; invalidate() }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val cx = w / 2f; val cy = h / 2f; val rad = min(w, h) / 2f - 2f
            val d = resources.displayMetrics.density
            p.style = Paint.Style.FILL
            p.color = 0x99070B10.toInt()
            c.drawCircle(cx, cy, rad, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f * d
            p.color = Cy.a(if (kind == 1 && on) 0xFF3DDC97.toInt() else Cy.CYAN, 0.14f)
            c.drawCircle(cx, cy, rad - 1f, p)
            p.strokeWidth = 1.3f * d
            p.color = Cy.a(if (kind == 1 && on) 0xFF3DDC97.toInt() else Cy.CYAN, 0.85f)
            c.drawCircle(cx, cy, rad - 1f, p)
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.strokeWidth = 1.8f * d
            p.color = 0xFFEAFBFF.toInt()
            if (kind == 0) {
                val k = 6f * d
                c.drawLine(cx - k, cy - k, cx + k, cy + k, p)
                c.drawLine(cx + k, cy - k, cx - k, cy + k, p)
            } else {
                val path = android.graphics.Path()
                path.moveTo(cx - 8f * d, cy - 3f * d); path.lineTo(cx - 4f * d, cy - 3f * d); path.lineTo(cx + 1f * d, cy - 7f * d)
                path.lineTo(cx + 1f * d, cy + 7f * d); path.lineTo(cx - 4f * d, cy + 3f * d); path.lineTo(cx - 8f * d, cy + 3f * d); path.close()
                c.drawPath(path, p)
                if (on) {
                    r.set(cx - 2f * d, cy - 5f * d, cx + 7f * d, cy + 5f * d)
                    c.drawArc(r, -45f, 90f, false, p)
                    r.set(cx - 5f * d, cy - 9f * d, cx + 10f * d, cy + 9f * d)
                    c.drawArc(r, -45f, 90f, false, p)
                } else {
                    c.drawLine(cx + 4f * d, cy - 4f * d, cx + 10f * d, cy + 4f * d, p)
                    c.drawLine(cx + 10f * d, cy - 4f * d, cx + 4f * d, cy + 4f * d, p)
                }
            }
        }
    }

    /** Corner brackets and the position counter. */
    private class Overlay(ctx: Context) : View(ctx) {
        private var i = 0
        private var n = 1
        private var a = 1f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun setPos(i: Int, n: Int) { this.i = i; this.n = n; invalidate() }
        fun fade(f: Float) { a = f; invalidate() }
        override fun onDraw(c: Canvas) {
            val d = resources.displayMetrics.density
            val w = width.toFloat(); val h = height.toFloat()
            val m = 14f * d; val k = 18f * d
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * d
            p.color = Cy.a(0xFF3DDC97.toInt(), 0.55f * a)
            c.drawLine(m, m + k + 14 * d, m, m + 14 * d, p); c.drawLine(m, m + 14 * d, m + k, m + 14 * d, p)
            c.drawLine(w - m - k, h - m, w - m, h - m, p); c.drawLine(w - m, h - m, w - m, h - m - k, p)
            c.drawLine(m, h - m - k, m, h - m, p); c.drawLine(m, h - m, m + k, h - m, p)
            // counter
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textAlign = Paint.Align.CENTER
            p.textSize = 12f * d
            p.letterSpacing = 0.25f
            val s = String.format("%02d / %02d", i + 1, n)
            p.color = Cy.a(Cy.CYAN, 0.9f * a)
            c.drawText(s, w / 2f, h - 30f * d, p)
            if (n > 1) {
                val bw = 120f * d
                val x0 = w / 2f - bw / 2f
                val seg = bw / n
                p.strokeWidth = 2f * d
                p.style = Paint.Style.STROKE
                for (q in 0 until n) {
                    p.color = if (q == i) Cy.a(0xFFFFFFFF.toInt(), 0.95f * a) else Cy.a(0xFFFFFFFF.toInt(), 0.22f * a)
                    c.drawLine(x0 + q * seg + 1f, h - 20f * d, x0 + (q + 1) * seg - 1f, h - 20f * d, p)
                }
            }
        }
    }
}
