package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.sin

class MainActivity : Activity() {

    private class PermRow(val status: TextView, val btn: PButton, val box: LinearLayout)

    private val main = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.elapsedRealtime()
    private var tick = 0

    private lateinit var preview: HudRoot
    private lateinit var nav: NavBar
    private lateinit var startBar: LinearLayout
    private lateinit var startBtn: PButton
    private lateinit var statePill: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var pageLive: ScrollView
    private lateinit var pageSettings: ScrollView
    private val liveCards = ArrayList<View>()
    private val settingsCards = ArrayList<View>()
    private var curPage = 0
    private lateinit var diagText: TextView

    private val designCards = ArrayList<DesignCard>()
    private lateinit var segSize: Segmented
    private lateinit var segTarget: Segmented
    private lateinit var slOpacity: PSlider
    private lateinit var slScale: PSlider
    private lateinit var tvOpacity: TextView
    private lateinit var tvScale: TextView
    private lateinit var swGraph: PSwitch
    private lateinit var swBars: PSwitch
    private lateinit var swFooter: PSwitch
    private lateinit var swLock: PSwitch
    private lateinit var swSound: PSwitch
    private lateinit var swBoot: PSwitch
    private lateinit var tvMedia: TextView
    private lateinit var rowOverlay: PermRow
    private lateinit var rowShizuku: PermRow
    private lateinit var rowBattery: PermRow
    private lateinit var rowNotif: PermRow

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    // ---------------- small builders ----------------

    private fun dp(v: Float) = Ui.dpi(this, v)

    private fun tv(s: String, size: Float, color: Int, face: Int = Typeface.NORMAL): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.typeface = Typeface.create("sans-serif-medium", face)
        return t
    }

    private fun card(title: String, into: ViewGroup, list: ArrayList<View>): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.cardBg(this)
        c.setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12f)
        c.layoutParams = lp
        val t = tv(title.uppercase(), 11f, P.LABEL)
        t.letterSpacing = 0.2f
        c.addView(t)
        into.addView(c)
        list.add(c)
        return c
    }

    private fun row(title: String, sub: String?, ctl: View, ctlW: Int = ViewGroup.LayoutParams.WRAP_CONTENT): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(9f), 0, dp(9f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 15f, P.TEXT))
        if (sub != null) col.addView(tv(sub, 11.5f, P.DIM))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ctl, LinearLayout.LayoutParams(ctlW, -2))
        return r
    }

    private fun label(s: String): TextView {
        val t = tv(s, 12f, P.DIM)
        t.setPadding(0, dp(12f), 0, dp(4f))
        return t
    }

    private fun sw(key: String, def: Boolean): PSwitch {
        val s = PSwitch(this)
        s.setChecked(Prefs.bool(this, key, def))
        s.onChange = { v -> Prefs.putBool(this, key, v); pushPreview() }
        return s
    }

    private fun permRow(title: String, into: LinearLayout): PermRow {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(0, dp(9f), 0, dp(9f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 15f, P.TEXT))
        val st = tv("", 12f, P.DIM)
        col.addView(st)
        box.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        val b = PButton(this, "Open", 1, 38f)
        box.addView(b, LinearLayout.LayoutParams(dp(118f), -2))
        into.addView(box)
        return PermRow(st, b, box)
    }

    // ---------------- screen ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Ui.BG0, Ui.BG1))
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = bg

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(20f), dp(14f), dp(20f), dp(6f))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        head.addView(logo, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8f), 0, 0, 0)
        val title = tv("FRAMELINE", 19f, 0xFFFFFFFF.toInt(), Typeface.BOLD)
        title.letterSpacing = 0.16f
        titles.addView(title)
        titles.addView(tv("performance overlay", 11f, P.DIM))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        statePill = tv("", 10.5f, P.DIM)
        statePill.letterSpacing = 0.12f
        statePill.setPadding(dp(12f), dp(6f), dp(12f), dp(6f))
        head.addView(statePill)
        root.addView(head)

        // live preview (the real overlay drawing)
        val pbox = PreviewBox(this)
        preview = HudRoot(this)
        preview.interactive = false
        pbox.addView(preview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val plp = LinearLayout.LayoutParams(-1, dp(172f))
        plp.setMargins(dp(16f), dp(6f), dp(16f), dp(4f))
        root.addView(pbox, plp)

        // pages
        val pages = FrameLayout(this)
        pageLive = ScrollView(this)
        pageSettings = ScrollView(this)
        pageLive.isVerticalScrollBarEnabled = false
        pageSettings.isVerticalScrollBarEnabled = false
        pages.addView(pageLive, FrameLayout.LayoutParams(-1, -1))
        pages.addView(pageSettings, FrameLayout.LayoutParams(-1, -1))
        pageSettings.visibility = View.GONE
        root.addView(pages, LinearLayout.LayoutParams(-1, 0, 1f))

        buildLive()
        buildSettings()

        // start bar + tabs
        startBar = LinearLayout(this)
        startBar.orientation = LinearLayout.VERTICAL
        startBar.setPadding(dp(16f), dp(8f), dp(16f), dp(10f))
        startBar.setBackgroundColor(0xFF0D1217.toInt())
        startBtn = PButton(this, "START OVERLAY", 0, 52f)
        startBtn.onClick = { startStop() }
        startBar.addView(startBtn, LinearLayout.LayoutParams(-1, -2))
        root.addView(startBar)

        nav = NavBar(this, listOf("Live", "Games", "Boost", "Settings"), listOf(true, false, false, true))
        nav.onSelect = { i -> showPage(if (i == 3) 1 else 0) }
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        Ui.enter(liveCards, 150L)
    }

    private fun buildLive() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageLive.addView(col, FrameLayout.LayoutParams(-1, -2))

        // setup banner
        banner = LinearLayout(this)
        banner.orientation = LinearLayout.HORIZONTAL
        banner.gravity = Gravity.CENTER_VERTICAL
        val bb = GradientDrawable()
        bb.setColor(0x26FFC24B)
        bb.cornerRadius = dp(16f).toFloat()
        bb.setStroke(dp(1f), 0x66FFC24B)
        banner.background = bb
        banner.setPadding(dp(14f), dp(10f), dp(10f), dp(10f))
        bannerText = tv("", 12.5f, P.MID)
        banner.addView(bannerText, LinearLayout.LayoutParams(0, -2, 1f))
        val bbtn = PButton(this, "Fix", 1, 34f)
        bbtn.onClick = { showPage(1); nav.select(3) }
        banner.addView(bbtn, LinearLayout.LayoutParams(dp(70f), -2))
        val blp = LinearLayout.LayoutParams(-1, -2)
        blp.topMargin = dp(8f)
        col.addView(banner, blp)
        liveCards.add(banner)

        // design
        val c1 = card("Design", col, liveCards)
        val dr = LinearLayout(this)
        dr.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Glass", "Gauge", "Pill")
        for (i in 0..2) {
            val d = DesignCard(this, i, names[i])
            d.onPick = {
                Prefs.putInt(this, Prefs.STYLE, i)
                refreshControls()
                pushPreview()
            }
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            lp.setMargins(dp(3f), dp(10f), dp(3f), 0)
            dr.addView(d, lp)
            designCards.add(d)
        }
        c1.addView(dr)
        c1.addView(label("Size"))
        segSize = Segmented(this, listOf("Full", "Compact", "Dot"))
        segSize.onSelect = { i -> Prefs.putInt(this, Prefs.MODE, i); pushPreview() }
        c1.addView(segSize, LinearLayout.LayoutParams(-1, -2))
        c1.addView(label("Target FPS"))
        segTarget = Segmented(this, listOf("30", "60", "90", "120"))
        segTarget.onSelect = { i -> Prefs.putInt(this, Prefs.TARGET, intArrayOf(30, 60, 90, 120)[i]); pushPreview() }
        c1.addView(segTarget, LinearLayout.LayoutParams(-1, -2))

        // look
        val c2 = card("Look", col, liveCards)
        tvOpacity = label("Opacity")
        c2.addView(tvOpacity)
        slOpacity = PSlider(this, 40, 100)
        slOpacity.onValue = { v -> Prefs.putInt(this, Prefs.OPACITY, v); tvOpacity.text = "Opacity  $v%"; pushPreview() }
        c2.addView(slOpacity, LinearLayout.LayoutParams(-1, -2))
        tvScale = label("Size")
        c2.addView(tvScale)
        slScale = PSlider(this, 70, 140)
        slScale.onValue = { v -> Prefs.putInt(this, Prefs.SCALE, v); tvScale.text = "Scale  $v%"; pushPreview() }
        c2.addView(slScale, LinearLayout.LayoutParams(-1, -2))

        // show
        val c3 = card("Show", col, liveCards)
        swGraph = sw(Prefs.GRAPH, true)
        c3.addView(row("Frame-time graph", null, swGraph))
        swBars = sw(Prefs.BARS, true)
        c3.addView(row("CPU and RAM", null, swBars))
        swFooter = sw(Prefs.FOOTER, true)
        c3.addView(row("Clock and battery", null, swFooter))

        // video box
        val c4 = card("Video box", col, liveCards)
        tvMedia = tv("", 12.5f, P.DIM)
        tvMedia.setPadding(0, dp(8f), 0, dp(4f))
        c4.addView(tvMedia)
        c4.addView(tv("A short clip (5-10 s), GIF or image loops silently in a small box when the overlay is full size.", 11.5f, P.DIM))
        val br = LinearLayout(this)
        br.orientation = LinearLayout.HORIZONTAL
        val pick = PButton(this, "Choose clip", 0, 42f)
        pick.onClick = {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*"))
            startActivityForResult(i, 31)
        }
        val rm = PButton(this, "Remove", 1, 42f)
        rm.onClick = { setMedia("") }
        val l1 = LinearLayout.LayoutParams(0, -2, 1f)
        l1.setMargins(0, dp(10f), dp(4f), 0)
        val l2 = LinearLayout.LayoutParams(0, -2, 1f)
        l2.setMargins(dp(4f), dp(10f), 0, 0)
        br.addView(pick, l1)
        br.addView(rm, l2)
        c4.addView(br)
        swSound = sw(Prefs.SOUND, false)
        c4.addView(row("Clip sound", "Off plays a silent copy, so recordings stay quiet", swSound))

        // position
        val c5 = card("Position", col, liveCards)
        swLock = sw(Prefs.LOCKED, false)
        c5.addView(row("Lock in place", "Touches pass through to the game. Unlock with the lock icon.", swLock))
    }

    private fun buildSettings() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16f), dp(2f), dp(16f), dp(24f))
        pageSettings.addView(col, FrameLayout.LayoutParams(-1, -2))

        val c1 = card("Permissions", col, settingsCards)
        rowOverlay = permRow("Display over other apps", c1)
        rowOverlay.btn.onClick = {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        rowShizuku = permRow("Shizuku (reads FPS)", c1)
        rowShizuku.btn.onClick = { shizukuAction() }
        rowBattery = permRow("Run in background", c1)
        rowBattery.btn.onClick = {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (t: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        rowNotif = permRow("Notifications", c1)
        rowNotif.btn.onClick = {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }

        val c2 = card("Keep it alive", col, settingsCards)
        c2.addView(tv("Some phones have their own Autostart or Background activity switch. Open app settings and allow both, then lock the app in the recents list.", 12f, P.DIM))
        val ab = PButton(this, "Open app settings", 1, 42f)
        ab.onClick = {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        val ablp = LinearLayout.LayoutParams(-1, -2)
        ablp.topMargin = dp(10f)
        c2.addView(ab, ablp)
        swBoot = sw(Prefs.BOOT, false)
        c2.addView(row("Start after reboot", "Shizuku must be started again after a reboot", swBoot))

        val cd = card("Diagnostics", col, settingsCards)
        cd.addView(tv("If FPS shows --, open this while a game is running, then send me a screenshot.", 12f, P.DIM))
        diagText = tv("", 10f, P.TEXT)
        diagText.typeface = Typeface.MONOSPACE
        diagText.setPadding(0, dp(8f), 0, dp(8f))
        cd.addView(diagText)
        val cb = PButton(this, "Copy report", 1, 42f)
        cb.onClick = {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Frameline report", FpsClient.debugText(this)))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        cd.addView(cb, LinearLayout.LayoutParams(-1, -2))

        val c3 = card("About", col, settingsCards)
        c3.addView(tv("Frameline 1.3.1", 15f, P.TEXT))
        c3.addView(tv("Privacy and licences will appear here later.", 12f, P.DIM))
    }

    private fun showPage(i: Int) {
        if (i == curPage) return
        val out = if (curPage == 0) pageLive else pageSettings
        val inn = if (i == 0) pageLive else pageSettings
        out.animate().alpha(0f).translationX(-30f).setDuration(150).withEndAction {
            out.visibility = View.GONE
            out.translationX = 0f
        }.start()
        inn.alpha = 0f
        inn.translationX = 30f
        inn.visibility = View.VISIBLE
        inn.animate().alpha(1f).translationX(0f).setDuration(240).start()
        curPage = i
        startBar.visibility = if (i == 0) View.VISIBLE else View.GONE
        Ui.enter(if (i == 0) liveCards else settingsCards, 80L)
    }

    // ---------------- lifecycle ----------------

    override fun onStart() {
        super.onStart()
        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
    }

    override fun onStop() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
        super.onStop()
    }

    private val demo = object : Runnable {
        override fun run() {
            tick++
            pushPreview()
            if (curPage == 1) diagText.text = FpsClient.debugText(this@MainActivity)
            main.postDelayed(this, 500)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        preview.setPlaying(true)
        main.removeCallbacks(demo)
        main.post(demo)
    }

    override fun onPause() {
        main.removeCallbacks(demo)
        preview.setPlaying(false)
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ---------------- preview ----------------

    /** Demo numbers for the preview (your real FPS can't be read while this screen is open). */
    private fun pushPreview() {
        val target = Prefs.int(this, Prefs.TARGET, 60).toFloat()
        val dip = (tick % 24) in 20..21
        val fps = target * (if (dip) 0.7f else 0.985f) + sin(tick * 0.9f) * target * 0.012f
        val ft = 1000f / fps
        val frames = FloatArray(48) { i ->
            ft * (1f + 0.09f * sin((i + tick) * 1.7f)) * (if (dip && i > 38) 1.5f else 1f)
        }
        val d = FpsData(fps, fps * 0.88f, ft, 34f + 9f * sin(tick * 0.5f), "demo", "OK", frames)
        preview.applyPrefs()
        preview.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        preview.update(d, StatsReader.read(this, t0))
    }

    // ---------------- actions ----------------

    private fun shizukuAction() {
        when (FpsClient.state(this)) {
            FpsClient.St.NOT_INSTALLED -> Toast.makeText(this, "Install Shizuku first, then come back.", Toast.LENGTH_LONG).show()
            FpsClient.St.NOT_RUNNING -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
            }
            FpsClient.St.NO_PERMISSION -> try { Shizuku.requestPermission(21) } catch (t: Throwable) { }
            FpsClient.St.READY -> Toast.makeText(this, "Shizuku is linked.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startStop() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow display over other apps first.", Toast.LENGTH_LONG).show()
                showPage(1)
                nav.select(3)
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        startBtn.postDelayed({ refresh() }, 600)
    }

    private fun setMedia(type: String) {
        Prefs.putStr(this, Prefs.MEDIA_TYPE, type)
        Prefs.putInt(this, Prefs.MEDIA_VER, Prefs.int(this, Prefs.MEDIA_VER, 0) + 1)
        if (type.isEmpty()) {
            File(filesDir, "media.dat").delete()
            File(filesDir, "media_s.dat").delete()
        }
        refresh()
        pushPreview()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 31 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: ""
                val type = when {
                    mime.startsWith("video") -> "video"
                    mime == "image/gif" || mime == "image/webp" -> "anim"
                    mime.startsWith("image") -> "image"
                    else -> ""
                }
                if (type.isEmpty()) throw RuntimeException("not a video or image")
                val out = File(filesDir, "media.dat")
                val silent = File(filesDir, "media_s.dat")
                silent.delete()
                var total = 0L
                contentResolver.openInputStream(uri)!!.use { ins ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > 80L * 1024 * 1024) throw RuntimeException("file too big (max 80 MB)")
                            os.write(buf, 0, n)
                        }
                    }
                }
                if (type == "video") {
                    // a copy with no audio track, so "sound off" is really silent even in recordings
                    if (!stripAudio(out, silent)) silent.delete()
                }
                runOnUiThread { setMedia(type) }
            } catch (t: Throwable) {
                runOnUiThread { Toast.makeText(this, "Could not load: " + t.message, Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun stripAudio(src: File, dst: File): Boolean {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        return try {
            ex.setDataSource(src.absolutePath)
            var vi = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("video/")) { vi = i; break }
            }
            if (vi < 0) return false
            ex.selectTrack(vi)
            mux = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val ti = mux.addTrack(ex.getTrackFormat(vi))
            var rot = 0
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(src.absolutePath)
                rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                r.release()
            } catch (t: Throwable) { }
            mux.setOrientationHint(rot)
            mux.start()
            val buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                info.offset = 0
                info.size = n
                info.presentationTimeUs = ex.sampleTime
                info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                mux.writeSampleData(ti, buf, info)
                ex.advance()
            }
            mux.stop()
            true
        } catch (t: Throwable) {
            false
        } finally {
            try { mux?.release() } catch (t: Throwable) { }
            try { ex.release() } catch (t: Throwable) { }
        }
    }

    // ---------------- state -> screen ----------------

    private fun refreshControls() {
        val style = Prefs.int(this, Prefs.STYLE, 0)
        for (i in designCards.indices) designCards[i].setSelected2(i == style)
        segSize.select(Prefs.int(this, Prefs.MODE, 0), false)
        val tg = Prefs.int(this, Prefs.TARGET, 60)
        segTarget.select(listOf(30, 60, 90, 120).indexOf(tg).coerceAtLeast(0), false)
        val op = Prefs.int(this, Prefs.OPACITY, 92)
        slOpacity.setValue(op)
        tvOpacity.text = "Opacity  $op%"
        val sc = Prefs.int(this, Prefs.SCALE, 100)
        slScale.setValue(sc)
        tvScale.text = "Scale  $sc%"
        swGraph.setChecked(Prefs.bool(this, Prefs.GRAPH, true))
        swBars.setChecked(Prefs.bool(this, Prefs.BARS, true))
        swFooter.setChecked(Prefs.bool(this, Prefs.FOOTER, true))
        swLock.setChecked(Prefs.bool(this, Prefs.LOCKED, false))
        swSound.setChecked(Prefs.bool(this, Prefs.SOUND, false))
        swBoot.setChecked(Prefs.bool(this, Prefs.BOOT, false))
    }

    private fun refresh() {
        refreshControls()

        val mt = Prefs.str(this, Prefs.MEDIA_TYPE, "")
        val mf = File(filesDir, "media.dat")
        tvMedia.text = if (mt.isEmpty() || !mf.exists()) "No clip chosen" else "Loaded: " + mt + " (" + (mf.length() / 1024) + " KB)"
        tvMedia.setTextColor(if (mt.isEmpty()) P.DIM else P.GOOD)

        val ov = Settings.canDrawOverlays(this)
        val st = FpsClient.state(this)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val free = pm.isIgnoringBatteryOptimizations(packageName)
        val nOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

        setPerm(rowOverlay, ov, "Allowed", "Needed to show the overlay", "Allow")
        val shMsg = when (st) {
            FpsClient.St.NOT_INSTALLED -> "Not installed" to "Install"
            FpsClient.St.NOT_RUNNING -> "Installed, not running. Start it first" to "Open Shizuku"
            FpsClient.St.NO_PERMISSION -> "Running. Needs your permission" to "Grant"
            FpsClient.St.READY -> "Linked" to "Linked"
        }
        setPerm(rowShizuku, st == FpsClient.St.READY, shMsg.first, shMsg.first, shMsg.second)
        setPerm(rowBattery, free, "Unrestricted", "Restricted: the system may close the overlay", "Allow")
        setPerm(rowNotif, nOk, "Allowed", "Hidden: the overlay still runs", "Allow")

        val miss = ArrayList<String>()
        if (!ov) miss.add("overlay permission")
        if (st != FpsClient.St.READY) miss.add("Shizuku (needed for FPS)")
        banner.visibility = if (miss.isEmpty()) View.GONE else View.VISIBLE
        bannerText.text = "Setup needed: " + miss.joinToString(" and ")

        val on = OverlayService.running
        startBtn.set(if (on) "STOP OVERLAY" else "START OVERLAY", if (on) 2 else 0)
        statePill.text = if (on) "OVERLAY ON" else "OVERLAY OFF"
        statePill.setTextColor(if (on) P.GOOD else P.DIM)
        val pb = GradientDrawable()
        pb.cornerRadius = dp(20f).toFloat()
        pb.setColor(if (on) 0x203DDC97 else 0x14FFFFFF)
        pb.setStroke(dp(1f), if (on) 0x663DDC97 else Ui.EDGE)
        statePill.background = pb
    }

    private fun setPerm(r: PermRow, ok: Boolean, okText: String, badText: String, btn: String) {
        r.status.text = if (ok) okText else badText
        r.status.setTextColor(if (ok) P.GOOD else P.MID)
        r.btn.visibility = if (ok) View.INVISIBLE else View.VISIBLE
        r.btn.set(btn, 1)
    }
}
