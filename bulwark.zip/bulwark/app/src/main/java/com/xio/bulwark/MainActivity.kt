package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var tvOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var tvShizuku: TextView
    private lateinit var btnShizuku: Button
    private lateinit var tvBattery: TextView
    private lateinit var btnBattery: Button
    private lateinit var tvNotif: TextView
    private lateinit var btnNotif: Button
    private lateinit var btnStart: Button
    private val chips = ArrayList<Button>()

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- small view helpers ----------

    private fun plateBg(fillColor: Int, stroke: Int, radius: Int = 6): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fillColor)
        g.cornerRadius = dp(radius).toFloat()
        g.setStroke(dp(1), stroke)
        return g
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        return t
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = plateBg(C.PANEL, C.BRASS_DARK)
        c.setPadding(dp(14), dp(12), dp(14), dp(14))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        val t = label(title.uppercase(), 11f, C.BRASS, true)
        t.letterSpacing = 0.18f
        c.addView(t)
        return c
    }

    private fun body(text: String): TextView {
        val t = label(text, 13f, C.TEXT_DIM)
        t.setPadding(0, dp(6), 0, dp(6))
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(C.TEXT)
        b.background = plateBg(C.STEEL_HI, C.BRASS)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(-1, dp(44))
        lp.topMargin = dp(6)
        b.layoutParams = lp
        return b
    }

    private fun toggle(text: String, key: String, def: Boolean): Switch {
        val s = Switch(this)
        s.text = text
        s.textSize = 14f
        s.setTextColor(C.TEXT)
        s.isChecked = Prefs.bool(this, key, def)
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, v -> Prefs.putBool(this, key, v) }
        return s
    }

    private fun slider(text: String, key: String, min: Int, max: Int, def: Int, unit: String): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val cur = Prefs.int(this, key, def)
        val tv = label("$text  $cur$unit", 13f, C.TEXT)
        tv.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = "$text  $v$unit"
                if (fromUser) Prefs.putInt(this@MainActivity, key, v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    // ---------- screen ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        scroll.addView(root)

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        head.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8), 0, 0, 0)
        val title = label("BULWARK", 26f, C.BRASS_HI, true)
        title.letterSpacing = 0.22f
        titles.addView(title)
        titles.addView(label("Performance watch for your games", 12f, C.TEXT_DIM))
        head.addView(titles)
        root.addView(head)

        // 1. overlay permission
        val c1 = card("1 · Overlay permission")
        tvOverlay = body("")
        c1.addView(tvOverlay)
        btnOverlay = button("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        c1.addView(btnOverlay)
        root.addView(c1)

        // 2. Shizuku
        val c2 = card("2 · Shizuku link (needed for FPS)")
        tvShizuku = body("")
        c2.addView(tvShizuku)
        btnShizuku = button("...") { shizukuAction() }
        c2.addView(btnShizuku)
        root.addView(c2)

        // 3. keep alive
        val c3 = card("3 · Stay alive in background")
        tvBattery = body("")
        c3.addView(tvBattery)
        btnBattery = button("Set battery to unrestricted") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (t: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        c3.addView(btnBattery)
        c3.addView(body("Some phones also have their own Autostart / Background activity switch. Open app settings and allow both, and lock the app in the recents list."))
        c3.addView(button("Open app settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        c3.addView(toggle("Start overlay after reboot", Prefs.BOOT, false))
        root.addView(c3)

        // 4. notifications
        val c4 = card("4 · Notification (keeps the service alive)")
        tvNotif = body("")
        c4.addView(tvNotif)
        btnNotif = button("Allow notifications") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        c4.addView(btnNotif)
        root.addView(c4)

        // 5. controls
        val c5 = card("Overlay")
        btnStart = button("START") { startStop() }
        c5.addView(btnStart)
        c5.addView(body("Tap the overlay to fold it. Drag to move. Long-press to open this screen."))
        c5.addView(label("TARGET FPS", 11f, C.BRASS, true))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (v in intArrayOf(30, 60, 90, 120)) {
            val b = Button(this)
            b.text = v.toString()
            b.isAllCaps = false
            b.setTextColor(C.TEXT)
            b.tag = v
            b.setOnClickListener { Prefs.putInt(this, Prefs.TARGET, v); refresh() }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), dp(6), dp(2), 0)
            row.addView(b, lp)
            chips.add(b)
        }
        c5.addView(row)
        c5.addView(slider("Opacity", Prefs.OPACITY, 40, 100, 92, "%"))
        c5.addView(slider("Size", Prefs.SCALE, 70, 140, 100, "%"))
        c5.addView(toggle("Frame-time graph", Prefs.GRAPH, true))
        c5.addView(toggle("CPU / RAM bars", Prefs.BARS, true))
        c5.addView(toggle("Clock / battery footer", Prefs.FOOTER, true))
        root.addView(c5)

        // 6. debug
        val c6 = card("Diagnostics")
        c6.addView(body("If FPS shows --, open a game for a few seconds, come back here and tap this. Send me what it says."))
        c6.addView(button("Show FPS reader report") {
            Thread {
                val txt = FpsClient.debugText(applicationContext)
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("FPS reader").setMessage(txt).setPositiveButton("OK", null).show()
                }
            }.start()
        })
        root.addView(c6)

        setContentView(scroll)
    }

    override fun onStart() {
        super.onStart()
        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
    }

    override fun onStop() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ---------- actions ----------

    private fun shizukuAction() {
        when (FpsClient.state(this)) {
            FpsClient.St.NOT_INSTALLED -> Toast.makeText(this, "Install Shizuku first, then come back.", Toast.LENGTH_LONG).show()
            FpsClient.St.NOT_RUNNING -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
            }
            FpsClient.St.NO_PERMISSION -> try { Shizuku.requestPermission(21) } catch (t: Throwable) { }
            FpsClient.St.READY -> Toast.makeText(this, "Shizuku is linked.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startStop() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow display over other apps first (card 1).", Toast.LENGTH_LONG).show()
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        btnStart.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val ov = Settings.canDrawOverlays(this)
        tvOverlay.text = if (ov) "GRANTED" else "REQUIRED - the overlay cannot show without it."
        tvOverlay.setTextColor(if (ov) C.GOOD else C.BAD)
        btnOverlay.visibility = if (ov) View.GONE else View.VISIBLE

        val st = FpsClient.state(this)
        val (msg, btn) = when (st) {
            FpsClient.St.NOT_INSTALLED -> "Shizuku is not installed. Overlay works, but FPS will show --." to "Shizuku missing"
            FpsClient.St.NOT_RUNNING -> "Shizuku is installed but not running. Open it and start it (wireless debugging)." to "Open Shizuku"
            FpsClient.St.NO_PERMISSION -> "Shizuku is running. Bulwark needs your permission." to "Grant Shizuku access"
            FpsClient.St.READY -> "LINKED - FPS reading is ready." to "Linked"
        }
        tvShizuku.text = msg
        tvShizuku.setTextColor(if (st == FpsClient.St.READY) C.GOOD else C.MID)
        btnShizuku.text = btn
        btnShizuku.visibility = if (st == FpsClient.St.READY) View.GONE else View.VISIBLE

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val free = pm.isIgnoringBatteryOptimizations(packageName)
        tvBattery.text = if (free) "UNRESTRICTED - good." else "Restricted - the system may close the overlay."
        tvBattery.setTextColor(if (free) C.GOOD else C.MID)
        btnBattery.visibility = if (free) View.GONE else View.VISIBLE

        val nOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        tvNotif.text = if (nOk) "ALLOWED." else "Not allowed - the overlay still runs, but the status notification is hidden."
        tvNotif.setTextColor(if (nOk) C.GOOD else C.MID)
        btnNotif.visibility = if (nOk) View.GONE else View.VISIBLE

        btnStart.text = if (OverlayService.running) "STAND DOWN (stop overlay)" else "START OVERLAY"
        btnStart.background = plateBg(if (OverlayService.running) C.SH_BAD else C.SH_GOOD, C.BRASS)

        val target = Prefs.int(this, Prefs.TARGET, 60)
        for (b in chips) {
            val on = (b.tag as Int) == target
            b.background = plateBg(if (on) C.BRASS_DIM else C.STEEL_LO, if (on) C.BRASS_HI else C.BRASS_DARK)
        }
    }
}
