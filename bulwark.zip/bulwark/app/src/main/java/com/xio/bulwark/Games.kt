package com.xio.bulwark

import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Process
import java.io.File
import java.util.Calendar

/** Installed games, play sessions, play time and per-game profiles. */
object Games {
    const val DAY = 86_400_000L

    class GameApp(val pkg: String, val name: String)

    class Session(
        val pkg: String, val start: Long, val end: Long, val avgFps: Float, val low: Float,
        val avgCpu: Float, val avgTemp: Float, val batDrop: Int, val wave: List<Float>
    ) {
        val ms: Long get() = end - start
    }

    // ---------- lists kept in settings ----------

    private fun set(c: Context, key: String): Set<String> =
        Prefs.str(c, key, "").split(",").filter { it.isNotEmpty() }.toSet()

    private fun putSet(c: Context, key: String, s: Set<String>) = Prefs.putStr(c, key, s.joinToString(","))

    fun hide(c: Context, pkg: String) {
        putSet(c, "g_hidden", set(c, "g_hidden") + pkg)
        putSet(c, "g_added", set(c, "g_added") - pkg)
        cache = null
    }

    fun add(c: Context, pkg: String) {
        putSet(c, "g_added", set(c, "g_added") + pkg)
        putSet(c, "g_hidden", set(c, "g_hidden") - pkg)
        cache = null
    }

    // ---------- detection ----------

    private var cache: List<GameApp>? = null
    private var cacheAt = 0L

    private fun launchables(c: Context): List<Pair<GameApp, Boolean>> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<Pair<GameApp, Boolean>>()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(i, 0)) {
            val ai = ri.activityInfo?.applicationInfo ?: continue
            val pkg = ai.packageName
            if (pkg == c.packageName || !seen.add(pkg)) continue
            val game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and 0x02000000) != 0
            out.add(Pair(GameApp(pkg, ri.loadLabel(pm).toString()), game))
        }
        return out
    }

    @Synchronized
    fun detect(c: Context, force: Boolean = false): List<GameApp> {
        val now = System.currentTimeMillis()
        val cc = cache
        if (cc != null && !force && now - cacheAt < 60_000L) return cc
        val manual = set(c, "g_added")
        val hidden = set(c, "g_hidden")
        val l = launchables(c).filter { (it.second || it.first.pkg in manual) && it.first.pkg !in hidden }
            .map { it.first }.sortedBy { it.name.lowercase() }
        cache = l
        cacheAt = now
        return l
    }

    /** Apps that are not on the games list yet (for adding one by hand). */
    fun others(c: Context): List<GameApp> {
        val have = detect(c).map { it.pkg }.toSet()
        return launchables(c).map { it.first }.filter { it.pkg !in have }.sortedBy { it.name.lowercase() }
    }

    // ---------- sessions ----------

    private fun file(c: Context) = File(c.filesDir, "sessions.txt")
    private var sess: List<Session> = emptyList()
    private var sessStamp = -1L

    @Synchronized
    fun sessions(c: Context): List<Session> {
        val f = file(c)
        val st = if (f.exists()) f.lastModified() + f.length() else 0L
        if (st != sessStamp) {
            sessStamp = st
            sess = if (!f.exists()) emptyList() else f.readLines().mapNotNull { line ->
                try {
                    val p = line.split("|")
                    Session(
                        p[0], p[1].toLong(), p[2].toLong(), p[3].toFloat(), p[4].toFloat(), p[5].toFloat(),
                        p[6].toFloat(), p[7].toInt(),
                        if (p[8].isEmpty()) emptyList() else p[8].split(",").map { it.toFloat() }
                    )
                } catch (t: Throwable) { null }
            }
        }
        return sess
    }

    @Synchronized
    fun addSession(c: Context, s: Session) {
        val line = s.pkg + "|" + s.start + "|" + s.end + "|" + s.avgFps + "|" + s.low + "|" + s.avgCpu + "|" +
            s.avgTemp + "|" + s.batDrop + "|" + s.wave.joinToString(",") { String.format(java.util.Locale.US, "%.0f", it) }
        file(c).appendText(line + "\n")
        sessStamp = -1L
    }

    // ---------- usage access (optional older history) ----------

    fun hasUsage(c: Context): Boolean = try {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (t: Throwable) { false }

    private val usageCache = HashMap<String, Pair<Long, Map<String, Long>>>()

    @Synchronized
    private fun usage(c: Context, b: Long, e: Long): Map<String, Long> {
        if (!hasUsage(c)) return emptyMap()
        // this call is slow, so remember the answer for a minute
        val key = b.toString() + ":" + (e / 60_000L)
        val now = System.currentTimeMillis()
        val hit = usageCache[key]
        if (hit != null && now - hit.first < 60_000L) return hit.second
        val m = try {
            val u = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            u.queryAndAggregateUsageStats(b, e).mapValues { it.value.totalTimeInForeground }
        } catch (t: Throwable) { emptyMap() }
        if (usageCache.size > 40) usageCache.clear()
        usageCache[key] = Pair(now, m)
        return m
    }

    /** Total play time for many games in one pass. */
    fun totals(c: Context, pkgs: List<String>): Map<String, Long> {
        val ses = sessions(c)
        val own = HashMap<String, Long>()
        for (s in ses) own[s.pkg] = (own[s.pkg] ?: 0L) + s.ms
        val nowMs = System.currentTimeMillis()
        val um = usage(c, nowMs - 365L * DAY, nowMs)
        val out = HashMap<String, Long>()
        for (p in pkgs) out[p] = maxOf((own[p] ?: 0L) + liveMs(p, 0L, Long.MAX_VALUE), um[p] ?: 0L)
        return out
    }

    // ---------- play time ----------

    fun dayStart(offsetDays: Int = 0): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        return cal.timeInMillis
    }

    private fun overlap(s: Long, e: Long, b: Long, f: Long): Long = maxOf(0L, minOf(e, f) - maxOf(s, b))

    private fun liveMs(pkg: String?, b: Long, f: Long): Long {
        val lp = Tracker.livePkg
        if (lp.isEmpty() || (pkg != null && lp != pkg)) return 0L
        return overlap(Tracker.liveStart, System.currentTimeMillis(), b, f)
    }

    fun total(c: Context, pkg: String): Long {
        val own = sessions(c).filter { it.pkg == pkg }.sumOf { it.ms } + liveMs(pkg, 0L, Long.MAX_VALUE)
        val u = usage(c, System.currentTimeMillis() - 365L * DAY, System.currentTimeMillis())[pkg] ?: 0L
        return maxOf(own, u)
    }

    fun allTotal(c: Context): Long = detect(c).sumOf { total(c, it.pkg) }

    /** Play time in [b, f) for one game, or for all games when pkg is null. */
    fun between(c: Context, pkg: String?, b: Long, f: Long): Long {
        val games = detect(c).map { it.pkg }.toSet()
        val own = sessions(c).filter { (pkg == null && it.pkg in games) || it.pkg == pkg }
            .sumOf { overlap(it.start, it.end, b, f) } + liveMs(pkg, b, f)
        val um = usage(c, b, f)
        val u = if (pkg != null) (um[pkg] ?: 0L) else games.sumOf { um[it] ?: 0L }
        return maxOf(own, u)
    }

    fun today(c: Context): Long = between(c, null, dayStart(), System.currentTimeMillis())

    /** Last 7 days, oldest first (today last). */
    fun week(c: Context, pkg: String?): LongArray =
        LongArray(7) { i -> between(c, pkg, dayStart(i - 6), dayStart(i - 5)) }

    fun lastPlayed(c: Context, pkg: String): Long {
        if (Tracker.livePkg == pkg) return System.currentTimeMillis()
        return sessions(c).filter { it.pkg == pkg }.maxOfOrNull { it.end } ?: 0L
    }

    fun fmt(ms: Long): String {
        val m = ms / 60_000L
        val h = m / 60
        return if (h > 0) "${h}h ${m % 60}m" else if (m > 0) "${m}m" else if (ms > 0) "<1m" else "0m"
    }

    fun ago(ts: Long): String {
        if (ts <= 0L) return "Never played"
        val m = (System.currentTimeMillis() - ts) / 60_000L
        return when {
            m < 2 -> "Just now"
            m < 60 -> "${m}m ago"
            m < 60 * 24 -> "${m / 60}h ago"
            else -> "${m / (60 * 24)}d ago"
        }
    }

    // ---------- per-game profile (applied automatically while that game is in front) ----------

    fun profTarget(c: Context, pkg: String) = Prefs.int(c, "gp_t_$pkg", 0)
    fun profStyle(c: Context, pkg: String) = Prefs.int(c, "gp_s_$pkg", -1)
    fun setProf(c: Context, pkg: String, target: Int, style: Int) {
        Prefs.putInt(c, "gp_t_$pkg", target)
        Prefs.putInt(c, "gp_s_$pkg", style)
    }

    fun enter(c: Context, pkg: String) {
        val t = profTarget(c, pkg)
        val st = profStyle(c, pkg)
        if (t == 0 && st < 0) return
        if (!Prefs.bool(c, "gb_on", false)) {
            Prefs.putInt(c, "gb_t", Prefs.int(c, Prefs.TARGET, 60))
            Prefs.putInt(c, "gb_s", Prefs.int(c, Prefs.STYLE, 0))
            Prefs.putBool(c, "gb_on", true)
        }
        if (t > 0) Prefs.putInt(c, Prefs.TARGET, t)
        if (st >= 0) Prefs.putInt(c, Prefs.STYLE, st)
    }

    fun leave(c: Context) {
        if (!Prefs.bool(c, "gb_on", false)) return
        Prefs.putInt(c, Prefs.TARGET, Prefs.int(c, "gb_t", 60))
        Prefs.putInt(c, Prefs.STYLE, Prefs.int(c, "gb_s", 0))
        Prefs.putBool(c, "gb_on", false)
    }
}

/** Watches which game is in front (fed by the overlay's reader) and stores a record when you stop playing. */
object Tracker {
    private class Cur(val pkg: String, val start: Long, val bat: Int) {
        var last = start
        var fpsSum = 0.0; var fpsN = 0
        var low = Float.MAX_VALUE
        var cpuSum = 0.0; var cpuN = 0
        var tempSum = 0.0; var tempN = 0
        var batEnd = bat
        val wave = ArrayList<Float>()
        var bSum = 0.0; var bN = 0; var bAt = start
    }

    @Volatile var livePkg = ""
    @Volatile var liveStart = 0L
    private var cur: Cur? = null
    private var gameSet: Set<String> = emptySet()
    private var setAt = 0L
    private var lastRemind = 0L

    fun feed(c: Context, d: FpsData, s: SysData?) {
        synchronized(this) {
            val now = System.currentTimeMillis()
            if (now - setAt > 120_000L) {
                gameSet = Games.detect(c).map { it.pkg }.toSet()
                setAt = now
            }
            val pkg = d.pkg
            val isGame = pkg.isNotEmpty() && pkg in gameSet
            if (isGame) {
                var cu = cur
                if (cu == null || cu.pkg != pkg) {
                    end(c)
                    Games.leave(c)
                    Games.enter(c, pkg)
                    Boost.autoStart(c, pkg)
                    cu = Cur(pkg, now, s?.bat ?: -1)
                    cur = cu
                    livePkg = pkg
                    liveStart = now
                }
                cu.last = now
                if (d.status == "OK" && d.fps > 0f) {
                    cu.fpsSum += d.fps; cu.fpsN++
                    if (d.low > 0f && d.low < cu.low) cu.low = d.low
                    cu.bSum += d.fps; cu.bN++
                    if (now - cu.bAt >= 20_000L && cu.bN > 0) {
                        cu.wave.add((cu.bSum / cu.bN).toFloat())
                        cu.bSum = 0.0; cu.bN = 0; cu.bAt = now
                    }
                }
                if (d.cpu >= 0f) { cu.cpuSum += d.cpu; cu.cpuN++ }
                if (s != null) {
                    if (s.temp > 0f) { cu.tempSum += s.temp; cu.tempN++ }
                    if (s.bat >= 0) cu.batEnd = s.bat
                }
                remind(c, now)
            } else {
                val cu = cur
                if (cu != null && now - cu.last > 45_000L) {
                    end(c)
                    Games.leave(c)
                }
            }
        }
    }

    /** Called when the overlay stops. */
    fun flush(c: Context) {
        synchronized(this) {
            end(c)
            Games.leave(c)
        }
    }

    private fun end(c: Context) {
        val cu = cur ?: return
        Boost.autoEnd(c)
        cur = null
        livePkg = ""
        liveStart = 0L
        if (cu.last - cu.start < 60_000L) return
        if (cu.bN > 0) cu.wave.add((cu.bSum / cu.bN).toFloat())
        var w: List<Float> = cu.wave
        if (w.size > 30) { val step = w.size / 30.0; w = (0 until 30).map { cu.wave[(it * step).toInt()] } }
        Games.addSession(
            c,
            Games.Session(
                cu.pkg, cu.start, cu.last,
                if (cu.fpsN > 0) (cu.fpsSum / cu.fpsN).toFloat() else 0f,
                if (cu.low == Float.MAX_VALUE) 0f else cu.low,
                if (cu.cpuN > 0) (cu.cpuSum / cu.cpuN).toFloat() else 0f,
                if (cu.tempN > 0) (cu.tempSum / cu.tempN).toFloat() else 0f,
                if (cu.bat >= 0 && cu.batEnd >= 0) maxOf(0, cu.bat - cu.batEnd) else 0,
                w
            )
        )
    }

    private fun remind(c: Context, now: Long) {
        if (now - lastRemind < 60_000L) return
        lastRemind = now
        val hours = Prefs.int(c, Prefs.REMIND, 2)
        if (hours <= 0) return
        val day = Games.dayStart().toString()
        if (Prefs.str(c, "remind_day", "") == day) return
        val played = Games.today(c)
        if (played < hours * 3_600_000L) return
        Prefs.putStr(c, "remind_day", day)
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("playtime", "Play time", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(c, 7, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = android.app.Notification.Builder(c, "playtime")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Play time reminder")
                .setContentText("You've played " + Games.fmt(played) + " today. Time for a break?")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(77, n)
        } catch (t: Throwable) { }
    }
}
