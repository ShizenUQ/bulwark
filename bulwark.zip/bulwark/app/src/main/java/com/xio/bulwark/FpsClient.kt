package com.xio.bulwark

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import rikka.shizuku.Shizuku

/** App-side connection to the shell service that Shizuku starts for us. */
object FpsClient {
    enum class St { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

    @Volatile private var svc: IShellService? = null
    @Volatile private var bindStart = 0L
    private var args: Shizuku.UserServiceArgs? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
            bindStart = 0L
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            bindStart = 0L
        }
    }

    fun state(c: Context): St {
        val alive = try { Shizuku.pingBinder() } catch (t: Throwable) { false }
        if (!alive) {
            val installed = try {
                c.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
            } catch (e: Exception) { false }
            return if (installed) St.NOT_RUNNING else St.NOT_INSTALLED
        }
        val ok = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (t: Throwable) { false }
        return if (ok) St.READY else St.NO_PERMISSION
    }

    private fun userArgs(c: Context): Shizuku.UserServiceArgs {
        var a = args
        if (a == null) {
            a = Shizuku.UserServiceArgs(ComponentName(c.packageName, ShellService::class.java.name))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)
                .tag("bulwark")
            args = a
        }
        return a!!
    }

    fun bind(c: Context) {
        if (svc != null) return
        val now = SystemClock.elapsedRealtime()
        if (bindStart != 0L && now - bindStart < 5000) return
        if (state(c) != St.READY) return
        bindStart = now
        try {
            Shizuku.bindUserService(userArgs(c), conn)
        } catch (t: Throwable) {
            bindStart = 0L
        }
    }

    fun unbind(c: Context) {
        try {
            Shizuku.unbindUserService(userArgs(c), conn, true)
        } catch (t: Throwable) { }
        svc = null
        bindStart = 0L
    }

    /** One reading of the game in front. Returns null if the link is not up. */
    fun sample(c: Context): String? {
        val s = svc
        if (s == null) { bind(c); return null }
        return try {
            s.sample(c.packageName)
        } catch (t: Throwable) {
            svc = null
            null
        }
    }

    fun debugText(c: Context): String {
        val st = state(c)
        val head = "Shizuku: $st\nlink: ${if (svc != null) "up" else "down"}\n\n"
        val s = svc ?: return head + "No shell link yet. Start the overlay with Shizuku running and allowed."
        return try {
            head + s.debug()
        } catch (t: Throwable) {
            head + "error: $t"
        }
    }
}
