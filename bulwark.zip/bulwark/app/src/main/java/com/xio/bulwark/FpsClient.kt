package com.xio.bulwark

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import rikka.shizuku.Shizuku

/**
 * Talks to Shizuku. Two ways to run commands as the shell user:
 *  1. Shizuku.newProcess (direct, no extra process to start) - tried first.
 *  2. A bound user service running inside Shizuku's shell process - used if 1 does not work.
 */
object FpsClient {
    enum class St { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

    @Volatile private var svc: IShellService? = null
    @Volatile private var bindStart = 0L
    @Volatile private var useService = false
    @Volatile private var lastLocalTry = 0L
    private var args: Shizuku.UserServiceArgs? = null

    private val mainH = Handler(Looper.getMainLooper())
    private val log = StringBuilder()

    @Synchronized
    private fun note(s: String) {
        log.append(SystemClock.elapsedRealtime() / 1000).append("s ").append(s).append('\n')
        if (log.length > 1800) log.delete(0, log.length - 1800)
    }

    // ---- way 1: direct remote process ----
    private fun remoteSh(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (t: Throwable) {
            val c = t.cause ?: t
            "ERR:$c"
        }
    }

    private val local = FpsEngine { remoteSh(it) }

    // ---- way 2: bound user service ----
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val ok = binder != null && binder.pingBinder()
            svc = if (ok) IShellService.Stub.asInterface(binder) else null
            note("service connected, alive = $ok")
            bindStart = 0L
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            note("service disconnected")
            svc = null
            bindStart = 0L
        }

        override fun onBindingDied(name: ComponentName?) {
            note("service binding died")
            svc = null
            bindStart = 0L
        }

        override fun onNullBinding(name: ComponentName?) {
            note("service null binding")
            bindStart = 0L
        }
    }

    fun state(c: Context): St {
        val alive = try { Shizuku.pingBinder() } catch (t: Throwable) { false }
        if (!alive) {
            val installed = try {
                c.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
            } catch (e: Exception) { false }
            return if (installed) St.NOT_RUNNING else St.NOT_INSTALLED
        }
        val ok = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (t: Throwable) { false }
        return if (ok) St.READY else St.NO_PERMISSION
    }

    private fun userArgs(c: Context): Shizuku.UserServiceArgs {
        var a = args
        if (a == null) {
            a = Shizuku.UserServiceArgs(ComponentName(c.packageName, ShellService::class.java.name))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)
                .tag("bulwark")
            args = a
        }
        return a!!
    }

    fun bind(c: Context) {
        if (svc != null) return
        val now = SystemClock.elapsedRealtime()
        if (bindStart != 0L && now - bindStart < 5000) return
        if (state(c) != St.READY) return
        bindStart = now
        val ctx = c.applicationContext
        mainH.post {
            try {
                note("bind requested")
                Shizuku.bindUserService(userArgs(ctx), conn)
            } catch (t: Throwable) {
                note("bind error: $t")
                bindStart = 0L
            }
        }
    }

    fun forceBind(c: Context) {
        bindStart = 0L
        useService = false
        lastLocalTry = 0L
        bind(c)
    }

    fun unbind(c: Context) {
        try {
            Shizuku.unbindUserService(userArgs(c), conn, true)
        } catch (t: Throwable) { }
        svc = null
        bindStart = 0L
    }

    /** One reading of the game in front. Returns null if nothing worked. */
    fun sample(c: Context): String? {
        if (state(c) != St.READY) return null
        val now = SystemClock.elapsedRealtime()
        if (!useService || now - lastLocalTry > 30000) {
            lastLocalTry = now
            val r = local.sample(c.packageName)
            if (!local.failed) {
                if (useService) { useService = false; note("direct mode works again") }
                return r
            }
            if (!useService) note("direct mode failed: ${local.error}")
            useService = true
        }
        val s = svc
        if (s == null) { bind(c); return null }
        return try {
            s.sample(c.packageName)
        } catch (t: Throwable) {
            svc = null
            null
        }
    }

    fun debugText(c: Context): String {
        val st = state(c)
        val sb = StringBuilder()
        sb.append("Shizuku: $st\n")
        sb.append("mode: ").append(if (useService) "service" else "direct").append('\n')
        sb.append("service link: ").append(if (svc != null) "up" else "down").append("\n\n")
        sb.append(local.dbg)
        if (useService) {
            try { svc?.debug()?.let { sb.append("\n\nservice says:\n").append(it) } } catch (t: Throwable) { }
        }
        sb.append("\n\nlog:\n").append(log)
        return sb.toString()
    }
}
