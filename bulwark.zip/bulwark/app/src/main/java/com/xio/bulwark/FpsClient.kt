package com.xio.bulwark

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import rikka.shizuku.Shizuku

/**
 * Talks to Shizuku. Two ways to run commands as the shell user:
 *  1. Shizuku.newProcess (direct, no extra process to start) - tried first.
 *  2. A bound user service running inside Shizuku's shell process - used if 1 does not work.
 */
object FpsClient {
    enum class St { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

    @Volatile private var svc: IShellService? = null
    @Volatile private var bindStart = 0L
    @Volatile private var fails = 0
    private var args: Shizuku.UserServiceArgs? = null

    private val mainH = Handler(Looper.getMainLooper())
    private val log = StringBuilder()

    @Synchronized
    private fun note(s: String) {
        log.append(SystemClock.elapsedRealtime() / 1000).append("s ").append(s).append('\n')
        if (log.length > 1800) log.delete(0, log.length - 1800)
    }

    // ---- way 1: direct remote process ----
    private fun remoteSh(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            var out = ""
            val reader = Thread { try { out = p.inputStream.bufferedReader().readText() } catch (e: Throwable) { } }
            reader.start()
            reader.join(3500)
            if (reader.isAlive) {                  // a command hung: kill it so the reader never freezes
                try { p.destroy() } catch (e: Throwable) { }
                reader.join(500)
                return "ERR:timeout"
            }
            try { p.waitFor() } catch (e: Throwable) { }
            out
        } catch (t: Throwable) {
            val c = t.cause ?: t
            "ERR:$c"
        }
    }

    private val local = FpsEngine { remoteSh(it) }

    // ---- way 2: bound user service ----
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val ok = binder != null && binder.pingBinder()
            svc = if (ok) IShellService.Stub.asInterface(binder) else null
            note("service connected, alive = $ok")
            bindStart = 0L
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            note("service disconnected")
            svc = null
            bindStart = 0L
        }

        override fun onBindingDied(name: ComponentName?) {
            note("service binding died")
            svc = null
            bindStart = 0L
        }

        override fun onNullBinding(name: ComponentName?) {
            note("service null binding")
            bindStart = 0L
        }
    }

    fun state(c: Context): St {
        val alive = try { Shizuku.pingBinder() } catch (t: Throwable) { false }
        if (!alive) {
            val installed = try {
                c.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
            } catch (e: Exception) { false }
            return if (installed) St.NOT_RUNNING else St.NOT_INSTALLED
        }
        val ok = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (t: Throwable) { false }
        return if (ok) St.READY else St.NO_PERMISSION
    }

    private fun userArgs(c: Context): Shizuku.UserServiceArgs {
        var a = args
        if (a == null) {
            a = Shizuku.UserServiceArgs(ComponentName(c.packageName, ShellService::class.java.name))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)
                .tag("bulwark")
            args = a
        }
        return a!!
    }

    fun bind(c: Context) {
        if (svc != null) return
        val now = SystemClock.elapsedRealtime()
        if (bindStart != 0L && now - bindStart < 5000) return
        if (state(c) != St.READY) return
        bindStart = now
        val ctx = c.applicationContext
        mainH.post {
            try {
                note("bind requested")
                Shizuku.bindUserService(userArgs(ctx), conn)
            } catch (t: Throwable) {
                note("bind error: $t")
                bindStart = 0L
            }
        }
    }

    fun forceBind(c: Context) {
        bindStart = 0L
        fails = 0
        bind(c)
    }

    fun unbind(c: Context) {
        try {
            Shizuku.unbindUserService(userArgs(c), conn, true)
        } catch (t: Throwable) { }
        svc = null
        bindStart = 0L
    }

    /** One reading of the game in front. Always returns the best data it has while Shizuku is ready. */
    fun sample(c: Context): String? {
        if (state(c) != St.READY) return null
        val r = local.sample(c.packageName)
        if (!local.failed) {
            if (fails > 0) note("direct mode ok again")
            fails = 0
            return r
        }
        fails++
        if (fails == 1) note("a direct command failed: ${local.error}")
        if (fails >= 3) {                       // only after several failures in a row try the backup path
            val s = svc
            if (s == null) bind(c) else {
                try {
                    val sr = s.sample(c.packageName)
                    if (sr != null) return sr
                } catch (t: Throwable) {
                    svc = null
                }
            }
        }
        return r
    }

    fun debugText(c: Context): String {
        val st = state(c)
        val sb = StringBuilder()
        sb.append("Shizuku: $st\n")
        sb.append("direct failures in a row: ").append(fails).append('\n')
        sb.append("service link: ").append(if (svc != null) "up" else "down").append("\n\n")
        sb.append(local.dbg)
        sb.append("\n\nlog:\n").append(log)
        return sb.toString()
    }
}
