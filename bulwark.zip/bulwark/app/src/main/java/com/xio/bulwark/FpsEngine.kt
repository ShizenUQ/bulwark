package com.xio.bulwark

import java.util.Locale

/**
 * Reads the frame timing of the game in front. `run` executes a shell command as the shell user
 * (through Shizuku) and returns its output, or a string starting with "ERR:" if it could not run.
 */
class FpsEngine(private val run: (String) -> String) {

    @Volatile var failed = false
    @Volatile var error = ""
    @Volatile var dbg = "no sample yet"

    private var pkg = ""
    private var layer = ""
    private var lastPkgCheck = 0L
    private var lastTs = 0L
    private var lastChange = 0L
    private var zeroTicks = 0
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var idInfo = ""

    private fun sh(cmd: String): String {
        val o = run(cmd)
        if (o.startsWith("ERR:")) { failed = true; error = o }
        return o
    }

    private fun foreground(): String {
        val out = sh("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        val re = Regex("u\\d+\\s+([A-Za-z0-9_.]+)/")
        for (line in out.lines()) {
            if (line.contains("mCurrentFocus") && !line.contains("=null")) {
                val m = re.find(line)
                if (m != null) return m.groupValues[1]
            }
        }
        for (line in out.lines()) {
            if (line.contains("mFocusedApp")) {
                val m = re.find(line)
                if (m != null) return m.groupValues[1]
            }
        }
        return ""
    }

    private fun latency(name: String): List<Long> {
        val out = sh("dumpsys SurfaceFlinger --latency '$name'")
        val res = ArrayList<Long>()
        val lines = out.lines()
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t <= 0L || t >= Long.MAX_VALUE / 2) continue
            res.add(t)
        }
        return res.distinct()
    }

    private fun findLayer(p: String): String {
        val all = sh("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
        val cands = all.filter {
            it.contains(p) && !it.startsWith("Background for") && !it.startsWith("Bounds for") &&
                !it.contains("Letterbox")
        }.sortedBy { if (it.contains("SurfaceView")) 0 else 1 }.take(5)
        var best = ""
        var bestLast = 0L
        var bestSize = 0
        for (c in cands) {
            val ts = latency(c)
            if (ts.isEmpty()) continue
            val last = ts.last()
            if (last > bestLast || (last == bestLast && ts.size > bestSize)) {
                best = c; bestLast = last; bestSize = ts.size
            }
        }
        dbg = "layers for $p:\n" + cands.joinToString("\n") + "\n-> chosen: " + best
        return best
    }

    private fun cpuUsage(): Float {
        return try {
            val line = sh("head -n 1 /proc/stat")
            val n = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (n.size < 5) return -1f
            val idle = n[3] + n[4]
            val total = n.sum()
            val first = prevTotal == 0L
            val dt = total - prevTotal
            val di = idle - prevIdle
            prevTotal = total; prevIdle = idle
            if (first || dt <= 0) -1f else (1f - di.toFloat() / dt.toFloat()).coerceIn(0f, 1f) * 100f
        } catch (t: Throwable) {
            -1f
        }
    }

    private fun pack(fps: Float, low: Float, ft: Float, cpu: Float, status: String, frames: List<Float>): String {
        return String.format(
            Locale.US, "%.1f|%.1f|%.2f|%.0f|%s|%s|%s|%s",
            fps, low, ft, cpu, pkg, status,
            frames.joinToString(",") { String.format(Locale.US, "%.1f", it) }, layer
        )
    }

    fun sample(own: String): String {
        failed = false
        return try {
            doSample(own)
        } catch (t: Throwable) {
            dbg = "sample crashed: $t"
            "-1|-1|-1|-1||ERR||"
        }
    }

    private fun doSample(own: String): String {
        if (idInfo.isEmpty()) idInfo = sh("id").trim()
        val nowMs = System.currentTimeMillis()
        val cpu = cpuUsage()

        if (pkg.isEmpty() || nowMs - lastPkgCheck > 2000) {
            lastPkgCheck = nowMs
            val np = foreground()
            if (np.isNotEmpty() && np != "com.android.systemui" && np != pkg) {
                pkg = np; layer = ""; lastTs = 0L; zeroTicks = 0
            }
        }
        if (pkg.isEmpty()) {
            dbg = "$idInfo\ncould not read the foreground app"
            return pack(-1f, -1f, -1f, cpu, "NOPKG", emptyList())
        }
        if (pkg == own) {
            dbg = "$idInfo\nforeground is Bulwark itself - switch to a game to read FPS"
            return pack(-1f, -1f, -1f, cpu, "SELF", emptyList())
        }

        if (layer.isEmpty() || zeroTicks >= 3) {
            layer = findLayer(pkg)
            zeroTicks = 0
        }
        if (layer.isEmpty()) return pack(-1f, -1f, -1f, cpu, "NOLAYER", emptyList())

        val ts = latency(layer)
        if (ts.size < 2) {
            zeroTicks++
            return pack(0f, 0f, 0f, cpu, "NOFRAMES", emptyList())
        }
        val lastT = ts.last()
        if (lastT != lastTs) { lastTs = lastT; lastChange = nowMs }
        if (nowMs - lastChange > 1800) {
            zeroTicks++
            return pack(0f, 0f, 0f, cpu, "STALE", emptyList())
        }

        val cut = lastT - 1_000_000_000L
        val win = ts.filter { it >= cut }
        val fps = if (win.size >= 2) (win.size - 1) * 1e9f / (win.last() - win.first()) else 0f
        val deltas = ts.zipWithNext { a, b -> (b - a) / 1e6f }
        val winDeltas = win.zipWithNext { a, b -> (b - a) / 1e6f }
        val ft = if (winDeltas.isNotEmpty()) winDeltas.average().toFloat() else 0f
        val sorted = deltas.sortedDescending()
        val worst = if (sorted.isEmpty()) 0f else sorted[(sorted.size * 0.01f).toInt().coerceAtMost(sorted.size - 1)]
        val low = if (worst > 0f) 1000f / worst else 0f
        val frames = deltas.takeLast(48)
        if (fps <= 0f) zeroTicks++ else zeroTicks = 0
        dbg = "$idInfo\npkg: $pkg\nlayer: $layer\nframes in buffer: ${ts.size}\nfps: ${String.format(Locale.US, "%.1f", fps)}\nstatus: OK"
        return pack(fps, low, ft, cpu, "OK", frames)
    }
}
