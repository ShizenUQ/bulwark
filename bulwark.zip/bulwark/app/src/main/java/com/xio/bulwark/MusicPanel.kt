package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.sin

/** One song in the list. */
class SongRow(ctx: Context, private val num: Int, private val title: String) : View(ctx) {
    var current = false
        set(v) { field = v; invalidate() }
    var onPick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var down = false

    init {
        isClickable = true
        setOnClickListener { onPick?.invoke() }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, ROW_DP))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        val t = Neon.now()
        r.set(4 * d, 2 * d, w - 4 * d, h - 2 * d)
        p.style = Paint.Style.FILL
        p.color = if (current) Neon.a(Neon.CYAN, 34) else if (down) Neon.a(Neon.CYAN, 22) else 0x0AFFFFFF
        c.drawRoundRect(r, 9 * d, 9 * d, p)
        if (current) {
            p.color = Neon.CYAN
            r.set(4 * d, 8 * d, 6.5f * d, h - 8 * d)
            c.drawRoundRect(r, 2 * d, 2 * d, p)
        }
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.textSize = 10 * d
        p.textAlign = Paint.Align.LEFT
        p.letterSpacing = 0f
        p.color = if (current) Neon.CYAN else 0xFF5F6B78.toInt()
        c.drawText(String.format("%02d", num), 14 * d, h / 2f + 3.5f * d, p)
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12.5f * d
        p.color = if (current) 0xFFFFFFFF.toInt() else 0xFFC9D3DD.toInt()
        val maxW = w - 36 * d - 40 * d
        val s = TextUtils.ellipsize(title, android.text.TextPaint(p), maxW, TextUtils.TruncateAt.END).toString()
        c.drawText(s, 38 * d, h / 2f + 4.4f * d, p)
        if (current) {
            val playing = Music.playing
            p.color = Neon.GREEN
            for (i in 0..3) {
                val k = if (playing) 0.35f + 0.65f * (0.5f + 0.5f * sin(t * (5f + i * 1.7f) + i * 1.3f)) else 0.25f
                val bh = 14 * d * k
                val x = w - 28 * d + i * 5 * d
                r.set(x, h / 2f + 7 * d - bh, x + 3 * d, h / 2f + 7 * d)
                c.drawRoundRect(r, 1.2f * d, 1.2f * d, p)
            }
            if (playing) postInvalidateDelayed(40)
        }
    }

    companion object { const val ROW_DP = 38f }
}

/**
 * The song list window. It hangs off the status overlay and is joined to it by an animated energy wire
 * (the wire is drawn at the top when the list is below the status, at the bottom when it is above).
 */
class MusicPanel(ctx: Context) : FrameLayout(ctx) {
    var wireX = 40f
    var wireOnTop = true
    var onPick: ((Int) -> Unit)? = null
    var onOutside: (() -> Unit)? = null

    private val d = Ui.dp(ctx, 1f)
    val wireZone = (14 * d).toInt()
    private val headH = (28 * d).toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val rows = ArrayList<SongRow>()
    private val scroll = ScrollView(ctx)
    private val list = LinearLayout(ctx)
    private var running = false
    private var count = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    init {
        setWillNotDraw(false)
        list.orientation = LinearLayout.VERTICAL
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        addView(scroll, LayoutParams(-1, -1))
    }

    /** Height in pixels the window should have for this many songs (about 4 rows visible, then it scrolls). */
    fun desiredHeight(n: Int): Int {
        val rowsShown = minOf(maxOf(n, 1), 4)
        return wireZone + headH + (rowsShown * ROWPX() + 10 * d).toInt()
    }

    private fun ROWPX() = SongRow.ROW_DP * d

    fun fill(songs: List<Song>) {
        count = songs.size
        list.removeAllViews()
        rows.clear()
        for ((i, s) in songs.withIndex()) {
            val row = SongRow(context, i + 1, s.title)
            row.onPick = { onPick?.invoke(i) }
            rows.add(row)
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        refreshCurrent()
        val top = if (wireOnTop) wireZone + headH else headH
        scroll.setPadding(0, top, 0, (6 * d).toInt())
        scroll.clipToPadding = true
        (scroll.layoutParams as LayoutParams).bottomMargin = if (wireOnTop) 0 else wireZone
    }

    fun refreshCurrent() {
        for ((i, row) in rows.withIndex()) row.current = i == Music.index
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val top = if (wireOnTop) wireZone.toFloat() else 0f
        val bot = if (wireOnTop) h.toFloat() else (h - wireZone).toFloat()
        r.set(d, top + d, w - d, bot - d)
        path.reset()
        path.addRoundRect(r, 16 * d, 16 * d, Path.Direction.CW)
        pm.setPath(path, false)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) onOutside?.invoke()
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = Neon.now()
        // body
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, 0xF2101A24.toInt(), 0xF2070C12.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Neon.a(Neon.CYAN, 90)
        c.drawPath(path, p)
        // header
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = 9 * d
        p.letterSpacing = 0.2f
        p.textAlign = Paint.Align.LEFT
        p.color = Neon.CYAN
        val hy = r.top + 19 * d
        c.drawText("PLAYLIST", 16 * d, hy, p)
        p.color = 0xFF6A7886.toInt()
        p.textAlign = Paint.Align.RIGHT
        c.drawText("$count TRACKS", w - 16 * d, hy, p)
        p.letterSpacing = 0f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Neon.a(Neon.CYAN, 36)
        c.drawLine(12 * d, r.top + headH - 2 * d, w - 12 * d, r.top + headH - 2 * d, p)
        // running light around the border
        val len = pm.length
        if (len > 0f) {
            val ph = (t * 0.22f) % 1f
            val sl = len * 0.14f
            val st = ph * len
            seg.reset()
            pm.getSegment(st, minOf(st + sl, len), seg, true)
            if (st + sl > len) pm.getSegment(0f, st + sl - len, seg, true)
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 3.4f * d
            p.color = Neon.a(Neon.CYAN, 40)
            c.drawPath(seg, p)
            p.strokeWidth = 1.4f * d
            p.color = Neon.a(Neon.CYAN, 230)
            c.drawPath(seg, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        // energy wire from the status to the list
        val y0 = if (wireOnTop) 0f else h
        val y1 = if (wireOnTop) wireZone.toFloat() else (h - wireZone)
        p.strokeWidth = 5f * d
        p.color = Neon.a(Neon.CYAN, 34)
        c.drawLine(wireX, y0, wireX, y1, p)
        p.strokeWidth = 1.6f * d
        p.color = Neon.a(Neon.CYAN, 200)
        // slightly crackling line
        val steps = 5
        var py = y0
        var px = wireX
        for (i in 1..steps) {
            val fy = y0 + (y1 - y0) * i / steps
            val jitter = if (i == steps) 0f else sin(t * 23f + i * 2.1f) * 1.8f * d
            c.drawLine(px, py, wireX + jitter, fy, p)
            px = wireX + jitter; py = fy
        }
        // travelling pulses
        p.style = Paint.Style.FILL
        for (k in 0..1) {
            val f = ((t * 1.3f + k * 0.5f) % 1f)
            val yy = y0 + (y1 - y0) * f
            p.color = Neon.a(Neon.GREEN, 230)
            c.drawCircle(wireX, yy, 2.2f * d, p)
            p.color = Neon.a(Neon.GREEN, 60)
            c.drawCircle(wireX, yy, 5f * d, p)
        }
        // end nodes
        p.color = Neon.CYAN
        c.drawCircle(wireX, y0, 2.6f * d, p)
        p.color = Neon.a(Neon.CYAN, 70)
        c.drawCircle(wireX, y1, 5f * d, p)
        p.color = Neon.CYAN
        c.drawCircle(wireX, y1, 2.4f * d, p)
    }
}
