package com.xio.bulwark

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Small custom controls for the Frameline app screens (everything is drawn by hand, no stock widgets). */
object Ui {
    val BG0 = 0xFF0A0D11.toInt()
    val BG1 = 0xFF121820.toInt()
    val CARD = 0xFF151B23.toInt()
    val EDGE = 0x24FFFFFF.toInt()

    fun dp(c: Context, v: Float): Float = v * c.resources.displayMetrics.density
    fun dpi(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density).roundToInt()

    fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val ar = (a shr 24 and 255) * (1 - k) + (b shr 24 and 255) * k
        val rr = (a shr 16 and 255) * (1 - k) + (b shr 16 and 255) * k
        val gg = (a shr 8 and 255) * (1 - k) + (b shr 8 and 255) * k
        val bb = (a and 255) * (1 - k) + (b and 255) * k
        return (ar.toInt() shl 24) or (rr.toInt() shl 16) or (gg.toInt() shl 8) or bb.toInt()
    }

    fun cardBg(c: Context, radius: Float = 18f): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(CARD)
        g.cornerRadius = dp(c, radius)
        g.setStroke(dpi(c, 1f), EDGE)
        return g
    }

    /** Slide-up + fade-in, one after another. */
    fun enter(views: List<View>, startDelay: Long = 0L) {
        for ((i, v) in views.withIndex()) {
            v.alpha = 0f
            v.translationY = 28f
            v.animate().alpha(1f).translationY(0f).setStartDelay(startDelay + i * 55L).setDuration(420)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
    }
}

/** On / off switch with a springy thumb. */
class PSwitch(ctx: Context) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private var pos = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    init {
        isClickable = true
        setOnClickListener {
            moveTo(!checked)
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(checked)
        }
    }

    private fun moveTo(v: Boolean) {
        checked = v
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pos, if (v) 1f else 0f)
        a.duration = 260
        a.interpolator = OvershootInterpolator(1.6f)
        a.addUpdateListener { pos = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    /** Set from code without calling onChange. */
    fun setChecked(v: Boolean) {
        if (v == checked) return
        moveTo(v)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(Ui.dpi(context, 50f), Ui.dpi(context, 30f))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = pos.coerceIn(0f, 1f)
        r.set(1f, 1f, w - 1f, h - 1f)
        p.style = Paint.Style.FILL
        p.color = Ui.mix(0xFF29313A.toInt(), 0xFF2BAE78.toInt(), t)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Ui.mix(0x30FFFFFF, 0x553DDC97, t)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        if (t > 0.02f) {
            p.strokeWidth = 4f
            p.color = Neon.a(Neon.CYAN, (46 * t).toInt())
            c.drawRoundRect(r, h / 2f, h / 2f, p)
        }
        val rad = h / 2f - 4f
        val cx = h / 2f + (w - h) * pos
        p.style = Paint.Style.FILL
        p.color = 0x55000000
        c.drawCircle(cx, h / 2f + 1.5f, rad, p)
        p.color = Ui.mix(0xFFB9C2CC.toInt(), 0xFFFFFFFF.toInt(), t)
        c.drawCircle(cx, h / 2f, rad, p)
    }
}

/** Slider with a filled track. */
class PSlider(ctx: Context, private val lo: Int, private val hi: Int) : View(ctx) {
    var value = lo
        private set
    var onValue: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    fun setValue(v: Int) {
        value = v.coerceIn(lo, hi)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 36f))
    }

    private fun pad() = Ui.dp(context, 12f)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val f = ((e.x - pad()) / max(1f, width - 2 * pad())).coerceIn(0f, 1f)
                val v = lo + (f * (hi - lo)).roundToInt()
                if (v != value) { value = v; onValue?.invoke(v); invalidate() }
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cy = height / 2f
        val x0 = pad()
        val x1 = w - pad()
        val f = (value - lo).toFloat() / (hi - lo)
        val tx = x0 + (x1 - x0) * f
        p.style = Paint.Style.FILL
        p.color = 0xFF29313A.toInt()
        r.set(x0, cy - 2.5f, x1, cy + 2.5f)
        c.drawRoundRect(r, 3f, 3f, p)
        p.shader = LinearGradient(x0, 0f, max(tx, x0 + 1f), 0f, 0xFF2BAE78.toInt(), 0xFF3DDC97.toInt(), Shader.TileMode.CLAMP)
        r.set(x0, cy - 2.5f, tx, cy + 2.5f)
        c.drawRoundRect(r, 3f, 3f, p)
        p.shader = null
        p.color = 0x663DDC97
        c.drawCircle(tx, cy, 11f, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(tx, cy, 7.5f, p)
    }
}

/** Pick-one control with a sliding highlight. */
class Segmented(ctx: Context, private val labels: List<String>) : View(ctx) {
    var selected = 0
        private set
    var onSelect: ((Int) -> Unit)? = null
    private var pill = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    fun select(i: Int, animate: Boolean = true) {
        if (i == selected && !animate) return
        selected = i
        anim?.cancel()
        if (!animate) { pill = i.toFloat(); invalidate(); return }
        val a = ValueAnimator.ofFloat(pill, i.toFloat())
        a.duration = 240
        a.interpolator = OvershootInterpolator(0.9f)
        a.addUpdateListener { pill = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 42f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            if (i != selected) {
                select(i)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                onSelect?.invoke(i)
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val seg = w / labels.size
        p.style = Paint.Style.FILL
        p.color = 0xFF0E1318.toInt()
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = Ui.EDGE
        r.set(0.5f, 0.5f, w - 0.5f, h - 0.5f)
        c.drawRoundRect(r, h / 2f, h / 2f, p)
        p.style = Paint.Style.FILL
        p.color = 0x333DDC97
        r.set(pill * seg + 4f, 4f, (pill + 1f) * seg - 4f, h - 4f)
        c.drawRoundRect(r, (h - 8f) / 2f, (h - 8f) / 2f, p)
        p.style = Paint.Style.STROKE
        p.color = 0x883DDC97.toInt()
        c.drawRoundRect(r, (h - 8f) / 2f, (h - 8f) / 2f, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = Ui.dp(context, 13f)
        for (i in labels.indices) {
            val near = max(0f, 1f - kotlin.math.abs(pill - i))
            p.color = Ui.mix(0xFF8B96A3.toInt(), 0xFFFFFFFF.toInt(), near)
            c.drawText(labels[i], seg * i + seg / 2f, h / 2f + p.textSize * 0.35f, p)
        }
    }
}

/** A small picture of one overlay design, tap to choose it. */
class DesignCard(ctx: Context, private val style: Int, private val name: String) : View(ctx) {
    var onPick: (() -> Unit)? = null
    private var sel = 0f
    private var selected = false
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()

    fun setSelected2(v: Boolean) {
        if (v == selected) return
        selected = v
        anim?.cancel()
        val a = ValueAnimator.ofFloat(sel, if (v) 1f else 0f)
        a.duration = 260
        a.addUpdateListener { sel = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 92f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onPick?.invoke()
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.color = Ui.mix(0xFF0E1318.toInt(), 0xFF12261F.toInt(), sel)
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, 14 * d, 14 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Ui.mix(Ui.EDGE, 0xCC3DDC97.toInt(), sel)
        r.set(0.6f * d, 0.6f * d, w - 0.6f * d, h - 0.6f * d)
        c.drawRoundRect(r, 14 * d, 14 * d, p)

        val cx = w / 2f
        val cy = h * 0.42f
        p.style = Paint.Style.FILL
        when (style) {
            0 -> {
                r.set(cx - 26 * d, cy - 15 * d, cx + 26 * d, cy + 15 * d)
                p.color = 0xFF1B2229.toInt()
                c.drawRoundRect(r, 6 * d, 6 * d, p)
                p.color = 0xFF3DDC97.toInt()
                r.set(cx - 22 * d, cy - 14 * d, cx - 8 * d, cy - 12.5f * d)
                c.drawRect(r, p)
                p.textSize = 13 * d
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                p.textAlign = Paint.Align.LEFT
                c.drawText("60", cx - 21 * d, cy + 6 * d, p)
                p.color = 0xFF3DDC97.toInt()
                for (i in 0 until 6) {
                    val bh = (4 + (i * 7 % 5)) * d
                    r.set(cx + (-2 + i * 4) * d, cy + 9 * d - bh, cx + (0.4f + i * 4) * d, cy + 9 * d)
                    c.drawRect(r, p)
                }
            }
            1 -> {
                r.set(cx - 15 * d, cy - 15 * d, cx + 15 * d, cy + 15 * d)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 4 * d
                p.strokeCap = Paint.Cap.ROUND
                p.color = 0xFF29313A.toInt()
                c.drawArc(r, 135f, 270f, false, p)
                p.color = 0xFF3DDC97.toInt()
                c.drawArc(r, 135f, 215f, false, p)
                p.strokeCap = Paint.Cap.BUTT
                p.style = Paint.Style.FILL
                p.color = 0xFFE6EDF3.toInt()
                p.textSize = 12 * d
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                c.drawText("60", cx, cy + 4.5f * d, p)
            }
            else -> {
                r.set(cx - 28 * d, cy - 10 * d, cx + 28 * d, cy + 10 * d)
                p.color = 0xFF1B2229.toInt()
                c.drawRoundRect(r, 10 * d, 10 * d, p)
                p.color = 0xFF3DDC97.toInt()
                c.drawCircle(cx - 19 * d, cy, 3 * d, p)
                p.color = 0xFFE6EDF3.toInt()
                p.textSize = 11 * d
                p.textAlign = Paint.Align.LEFT
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                c.drawText("60", cx - 12 * d, cy + 4 * d, p)
                p.color = 0xFF8B96A3.toInt()
                p.textSize = 7 * d
                c.drawText("16.6ms", cx + 2 * d, cy + 2.8f * d, p)
            }
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = 12 * d
        p.color = Ui.mix(0xFF8B96A3.toInt(), 0xFFFFFFFF.toInt(), sel)
        c.drawText(name, cx, h - 11 * d, p)
    }
}

/** Rounded button with a press effect. kind: 0 = main (green), 1 = quiet (outline), 2 = stop (red). */
class PButton(ctx: Context, var text: String, var kind: Int = 0) : View(ctx) {
    var onClick: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var heightDp = 48f

    constructor(ctx: Context, text: String, kind: Int, heightDp: Float) : this(ctx, text, kind) {
        this.heightDp = heightDp
    }

    init {
        isClickable = true
        setOnClickListener {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onClick?.invoke()
        }
    }

    fun set(t: String, k: Int) {
        text = t
        kind = k
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, heightDp))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        r.set(0f, 0f, w, h)
        val rad = h / 2f
        p.style = Paint.Style.FILL
        when (kind) {
            0 -> {
                p.shader = LinearGradient(0f, 0f, w, 0f, 0xFF2BAE78.toInt(), 0xFF3DDC97.toInt(), Shader.TileMode.CLAMP)
                c.drawRoundRect(r, rad, rad, p)
                p.shader = null
                val sx = ((SystemClock.uptimeMillis() % 2800L) / 2800f) * (w + 160f) - 80f
                p.shader = LinearGradient(sx - 40f, 0f, sx + 40f, 0f,
                    intArrayOf(0, 0x55FFFFFF, 0), null, Shader.TileMode.CLAMP)
                c.drawRoundRect(r, rad, rad, p)
                p.shader = null
                postInvalidateDelayed(40)
            }
            2 -> {
                p.shader = LinearGradient(0f, 0f, w, 0f, 0xFFB53A2D.toInt(), 0xFFFF5A4D.toInt(), Shader.TileMode.CLAMP)
                c.drawRoundRect(r, rad, rad, p)
                p.shader = null
            }
            else -> {
                p.color = 0xFF1A2129.toInt()
                c.drawRoundRect(r, rad, rad, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.2f
                p.color = 0x553DDC97
                r.set(0.6f, 0.6f, w - 0.6f, h - 0.6f)
                c.drawRoundRect(r, rad, rad, p)
                p.style = Paint.Style.FILL
            }
        }
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = Ui.dp(context, 14f)
        p.letterSpacing = 0.05f
        p.color = if (kind == 1) 0xFFE6EDF3.toInt() else 0xFF06110C.toInt()
        if (kind == 2) p.color = 0xFFFFFFFF.toInt()
        c.drawText(text, w / 2f, h / 2f + p.textSize * 0.35f, p)
        p.letterSpacing = 0f
    }
}

/** Bottom tab bar with a sliding highlight. Tabs that are not ready yet are dimmed and cannot be tapped. */
class NavBar(ctx: Context, private val labels: List<String>, private val enabled: List<Boolean>) : View(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    var selected = 0
        private set
    private var pill = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()

    fun select(i: Int) {
        if (i == selected) return
        selected = i
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pill, i.toFloat())
        a.duration = 300
        a.interpolator = OvershootInterpolator(1.1f)
        a.addUpdateListener { pill = it.animatedValue as Float; invalidate() }
        a.start()
        anim = a
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), Ui.dpi(context, 68f))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = (e.x / (width.toFloat() / labels.size)).toInt().coerceIn(0, labels.size - 1)
            if (enabled[i] && i != selected) {
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                select(i)
                onSelect?.invoke(i)
            }
        }
        return true
    }

    private fun icon(c: Canvas, i: Int, cx: Float, cy: Float, d: Float, col: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = col
        path.reset()
        val kind = when (labels[i]) { "Live" -> 0; "Games" -> 1; "Boost" -> 2; "Music" -> 4; else -> 3 }
        when (kind) {
            4 -> {
                path.moveTo(cx + 3 * d, cy + 4 * d)
                path.lineTo(cx + 3 * d, cy - 8 * d)
                path.lineTo(cx + 8 * d, cy - 6 * d)
                c.drawPath(path, p)
                r.set(cx - 6 * d, cy + 1 * d, cx + 3 * d, cy + 8 * d)
                c.drawOval(r, p)
            }
            0 -> {
                path.moveTo(cx - 9 * d, cy + 1 * d)
                path.lineTo(cx - 4 * d, cy + 1 * d)
                path.lineTo(cx - 1.5f * d, cy - 6 * d)
                path.lineTo(cx + 2.5f * d, cy + 7 * d)
                path.lineTo(cx + 5 * d, cy - 1 * d)
                path.lineTo(cx + 9 * d, cy - 1 * d)
                c.drawPath(path, p)
            }
            1 -> {
                for (a in 0..1) for (b in 0..1) {
                    r.set(cx - 8 * d + a * 9 * d, cy - 8 * d + b * 9 * d, cx - 1 * d + a * 9 * d, cy - 1 * d + b * 9 * d)
                    c.drawRoundRect(r, 2 * d, 2 * d, p)
                }
            }
            2 -> {
                path.moveTo(cx + 2 * d, cy - 9 * d)
                path.lineTo(cx - 6 * d, cy + 2 * d)
                path.lineTo(cx - 0.5f * d, cy + 2 * d)
                path.lineTo(cx - 2 * d, cy + 9 * d)
                path.lineTo(cx + 6 * d, cy - 2 * d)
                path.lineTo(cx + 0.5f * d, cy - 2 * d)
                path.close()
                c.drawPath(path, p)
            }
            else -> {
                for (k in 0..2) {
                    val y = cy - 6 * d + k * 6 * d
                    c.drawLine(cx - 9 * d, y, cx + 9 * d, y, p)
                    p.style = Paint.Style.FILL
                    val x = cx - 4 * d + ((k * 5) % 9) * d
                    c.drawCircle(x, y, 2.4f * d, p)
                    p.style = Paint.Style.STROKE
                }
            }
        }
        p.strokeCap = Paint.Cap.BUTT
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        p.style = Paint.Style.FILL
        p.color = 0xF0070B10.toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.color = Neon.a(Neon.CYAN, 50)
        c.drawRect(0f, 0f, w, 1f * d, p)
        val seg = w / labels.size
        val pulseN = 0.5f + 0.5f * kotlin.math.sin(Neon.now() * 3f)
        // glowing bar above the selected tab
        val bx = seg * pill + seg / 2f
        p.color = Neon.a(Neon.CYAN, (40 + 40 * pulseN).toInt())
        r.set(bx - 26 * d, 0f, bx + 26 * d, 5 * d)
        c.drawRoundRect(r, 3 * d, 3 * d, p)
        p.color = Neon.CYAN
        r.set(bx - 20 * d, 0f, bx + 20 * d, 2f * d)
        c.drawRoundRect(r, 2 * d, 2 * d, p)
        val pillW = min(seg - 14 * d, 76 * d)
        val pcx = seg * pill + seg / 2f
        p.color = 0x243DDC97
        r.set(pcx - pillW / 2f, 8 * d, pcx + pillW / 2f, h - 8 * d)
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * d
        p.color = 0x663DDC97
        c.drawRoundRect(r, 16 * d, 16 * d, p)
        for (i in labels.indices) {
            val near = max(0f, 1f - kotlin.math.abs(pill - i))
            val base = if (enabled[i]) 0xFF8B96A3.toInt() else 0xFF4A535E.toInt()
            val col = Ui.mix(base, 0xFF3DDC97.toInt(), near)
            val cx = seg * i + seg / 2f
            icon(c, i, cx, h * 0.38f, d, col)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 10.5f * d
            p.color = col
            c.drawText(labels[i], cx, h * 0.80f, p)
            if (!enabled[i]) {
                p.textSize = 6.5f * d
                p.color = 0xFF6A7480.toInt()
                p.letterSpacing = 0.12f
                c.drawText("SOON", cx + 13 * d, h * 0.22f, p)
                p.letterSpacing = 0f
            }
        }
        postInvalidateDelayed(50)
    }
}

/** The "game screen" behind the live preview. */
class PreviewBox(ctx: Context) : FrameLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val r = RectF()

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val rad = Ui.dp(context, 20f)
        clip.reset()
        r.set(0f, 0f, w.toFloat(), h.toFloat())
        clip.addRoundRect(r, rad, rad, Path.Direction.CW)
    }

    override fun dispatchDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = Ui.dp(context, 1f)
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, 0xF0121C26.toInt(), 0xF0070C11.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = 0x0DFFFFFF
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, p); x += 28 * d }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, p); y += 28 * d }
        p.style = Paint.Style.FILL
        p.textSize = 8.5f * d
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.letterSpacing = 0.2f
        p.color = Neon.a(Neon.CYAN, 150)
        p.textAlign = Paint.Align.LEFT
        c.drawText("LIVE PREVIEW", 14 * d, 20 * d, p)
        p.letterSpacing = 0f
        super.dispatchDraw(c)
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * d
        p.color = Ui.EDGE
        r.set(0.6f * d, 0.6f * d, w - 0.6f * d, h - 0.6f * d)
        c.drawRoundRect(r, 20 * d, 20 * d, p)
    }
}
