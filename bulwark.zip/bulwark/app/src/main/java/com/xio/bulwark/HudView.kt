package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The armor-plate HUD. Everything is drawn by hand in "design units" (1 unit = 1dp at 100% size).
 * Animation only runs while something is moving, so it stays cheap while a game is running.
 */
class HudView(private val ctx: Context) : View(ctx) {

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null

    private val dens = resources.displayMetrics.density
    private var sc = 1f
    private var showGraph = true
    private var showBars = true
    private var showFooter = true
    private var targetFps = 60

    private var data = FpsData.na("NOLINK")
    private var sys: SysData? = null

    private var dispFps = 0f
    private var expandT = 1f
    private var expandGoal = 1f
    private var reveal = 0f
    private var flash = 0f
    private var sheenStart = -100000L
    private var lastState = 0
    private var lastFrameT = 0L
    private var running = false

    // ---- paints (created once) ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val big = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val label = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    // ---- cached geometry ----
    private val plate = Path()
    private val inner = Path()
    private val shield = Path()
    private val sheen = Path()
    private val tmp = RectF()
    private var cachedW = -1f
    private var cachedH = -1f

    companion object {
        const val FULL_W = 214f
        const val PILL_W = 96f
        const val PILL_H = 38f
        const val SH_W = 44f
        const val SH_H = 54f
    }

    init {
        shield.moveTo(0f, 0f)
        shield.lineTo(SH_W, 0f)
        shield.lineTo(SH_W, 30f)
        shield.cubicTo(SH_W, 44f, SH_W * 0.7f, 50f, SH_W / 2f, SH_H)
        shield.cubicTo(SH_W * 0.3f, 50f, 0f, 44f, 0f, 30f)
        shield.close()
    }

    private val ticker = object : Runnable {
        override fun run() {
            advance()
            invalidate()
            if (needAnim()) postOnAnimation(this) else running = false
        }
    }

    private val sheenLoop = object : Runnable {
        override fun run() {
            sheenStart = SystemClock.uptimeMillis()
            kick()
            postDelayed(this, 9000)
        }
    }

    private fun kick() {
        if (!running) {
            running = true
            lastFrameT = SystemClock.uptimeMillis()
            postOnAnimation(ticker)
        }
    }

    private fun needAnim(): Boolean {
        val now = SystemClock.uptimeMillis()
        return reveal < 1f || expandT != expandGoal || flash > 0f ||
            (data.fps >= 0f && abs(dispFps - data.fps) > 0.01f) || now - sheenStart < 950
    }

    private fun advance() {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrameT).coerceIn(1L, 64L).toFloat()
        lastFrameT = now
        if (reveal < 1f) reveal = min(1f, reveal + dt / 480f)
        if (expandT != expandGoal) {
            val step = dt / 260f
            expandT = if (expandT < expandGoal) min(expandGoal, expandT + step) else max(expandGoal, expandT - step)
            requestLayout()
        }
        if (data.fps >= 0f) {
            val diff = data.fps - dispFps
            dispFps = if (abs(diff) < 0.4f) data.fps else dispFps + diff * min(1f, dt / 110f)
        } else dispFps = 0f
        if (flash > 0f) flash = max(0f, flash - dt / 750f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        reveal = 0f
        postDelayed(sheenLoop, 1400)
        kick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(sheenLoop)
        removeCallbacks(ticker)
        running = false
        super.onDetachedFromWindow()
    }

    // ---------------- public api ----------------

    fun applyPrefs() {
        val newSc = Prefs.int(ctx, Prefs.SCALE, 100) / 100f
        val g = Prefs.bool(ctx, Prefs.GRAPH, true)
        val b = Prefs.bool(ctx, Prefs.BARS, true)
        val f = Prefs.bool(ctx, Prefs.FOOTER, true)
        val t = Prefs.int(ctx, Prefs.TARGET, 60)
        val col = Prefs.bool(ctx, Prefs.COLLAPSED, false)
        val relayout = newSc != sc || g != showGraph || b != showBars || f != showFooter
        sc = newSc; showGraph = g; showBars = b; showFooter = f; targetFps = t
        val goal = if (col) 0f else 1f
        if (goal != expandGoal) { expandGoal = goal; kick() }
        alpha = Prefs.int(ctx, Prefs.OPACITY, 92) / 100f
        if (relayout) { cachedW = -1f; requestLayout() }
    }

    fun update(d: FpsData, s: SysData) {
        data = d
        sys = s
        val st = stateOf(d)
        if (st > lastState && lastState != 0) flash = 1f
        lastState = st
        kick()
        invalidate()
    }

    private fun toggle() {
        val collapse = expandGoal > 0.5f
        expandGoal = if (collapse) 0f else 1f
        Prefs.putBool(ctx, Prefs.COLLAPSED, collapse)
        kick()
    }

    /** 0 = no data, 1 = good, 2 = mid, 3 = bad */
    private fun stateOf(d: FpsData): Int {
        if (d.fps < 0f) return 0
        val r = d.fps / targetFps
        return if (r >= 0.9f) 1 else if (r >= 0.7f) 2 else 3
    }

    // ---------------- layout ----------------

    private fun fullH(): Float {
        var y = 66f
        if (showBars) y += 24f
        if (showFooter) y += 20f
        return y + 10f
    }

    private fun curW(): Float = PILL_W + (FULL_W - PILL_W) * expandT
    private fun curH(): Float = PILL_H + (fullH() - PILL_H) * expandT

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = dens * sc
        setMeasuredDimension((curW() * s).roundToInt(), (curH() * s).roundToInt())
    }

    private fun buildPlate(w: Float, h: Float) {
        if (w == cachedW && h == cachedH) return
        cachedW = w; cachedH = h
        val bigC = 10f
        val sm = 4f
        fun poly(p: Path, i: Float, tl: Float, tr: Float, br: Float, bl: Float) {
            p.reset()
            p.moveTo(i + tl, i)
            p.lineTo(w - i - tr, i)
            p.lineTo(w - i, i + tr)
            p.lineTo(w - i, h - i - br)
            p.lineTo(w - i - br, h - i)
            p.lineTo(i + bl, h - i)
            p.lineTo(i, h - i - bl)
            p.lineTo(i, i + tl)
            p.close()
        }
        poly(plate, 0.8f, bigC, sm, bigC, sm)
        poly(inner, 4f, bigC - 2.4f, sm - 1.2f, bigC - 2.4f, sm - 1.2f)
        body.shader = LinearGradient(0f, 0f, 0f, h, C.STEEL_HI, C.STEEL_LO, Shader.TileMode.CLAMP)
    }

    // ---------------- drawing ----------------

    override fun onDraw(canvas: Canvas) {
        val s = dens * sc
        val w = curW()
        val h = curH()
        canvas.save()
        canvas.scale(s, s)

        val rv = reveal * reveal * (3f - 2f * reveal)          // smoothstep: the "visor" opening
        canvas.clipRect(0f, h / 2f * (1f - rv), w, h / 2f * (1f + rv))

        buildPlate(w, h)

        // plate body
        canvas.drawPath(plate, body)
        line.strokeWidth = 1.6f
        line.color = C.BRASS
        canvas.drawPath(plate, line)
        line.strokeWidth = 0.8f
        line.color = C.BRASS_DARK
        canvas.drawPath(inner, line)
        rivet(canvas, 7.5f, 7.5f)
        rivet(canvas, w - 7.5f, 7.5f)
        rivet(canvas, 7.5f, h - 7.5f)
        rivet(canvas, w - 7.5f, h - 7.5f)

        if (expandT > 0.5f) drawFull(canvas, w) else drawPill(canvas)

        // steel sheen sweeping across
        val sp = (SystemClock.uptimeMillis() - sheenStart) / 900f
        if (sp in 0f..1f) {
            val cx = -30f + sp * (w + 60f)
            canvas.save()
            canvas.clipPath(plate)
            fill.style = Paint.Style.FILL
            sheen.reset()
            sheen.moveTo(cx, 0f); sheen.lineTo(cx + 26f, 0f); sheen.lineTo(cx + 12f, h); sheen.lineTo(cx - 14f, h); sheen.close()
            fill.color = 0x0CFFFFFF
            canvas.drawPath(sheen, fill)
            sheen.reset()
            sheen.moveTo(cx + 6f, 0f); sheen.lineTo(cx + 14f, 0f); sheen.lineTo(cx, h); sheen.lineTo(cx - 8f, h); sheen.close()
            fill.color = 0x18FFFFFF
            canvas.drawPath(sheen, fill)
            canvas.restore()
        }
        canvas.restore()
    }

    private fun rivet(c: Canvas, x: Float, y: Float) {
        fill.style = Paint.Style.FILL
        fill.color = 0xFF3A2F1B.toInt()
        c.drawCircle(x, y + 0.4f, 2.2f, fill)
        fill.color = C.BRASS_DIM
        c.drawCircle(x, y, 1.9f, fill)
        fill.color = C.BRASS_HI
        c.drawCircle(x - 0.5f, y - 0.5f, 0.8f, fill)
    }

    private fun shieldColor(st: Int) = when (st) {
        1 -> C.SH_GOOD; 2 -> C.SH_MID; 3 -> C.SH_BAD; else -> C.SH_NA
    }

    private fun accent(st: Int) = when (st) {
        1 -> C.GOOD; 2 -> C.MID; 3 -> C.BAD; else -> C.TEXT_DIM
    }

    private fun drawShield(c: Canvas, st: Int, small: Boolean) {
        fill.style = Paint.Style.FILL
        fill.color = shieldColor(st)
        c.drawPath(shield, fill)
        // top band
        c.save()
        c.clipPath(shield)
        fill.color = 0x55000000
        c.drawRect(0f, 0f, SH_W, 11f, fill)
        fill.color = 0x14FFFFFF
        c.drawRect(0f, 11f, SH_W / 2f, SH_H, fill)   // left half catches light
        c.restore()
        // rim, with an ember flash when things get worse
        if (flash > 0f) {
            line.color = C.BAD
            line.alpha = (flash * 110).toInt()
            line.strokeWidth = 5f
            c.drawPath(shield, line)
            line.alpha = 255
        }
        line.strokeWidth = 1.7f
        line.color = if (flash > 0f) blend(C.BRASS, C.BAD, flash) else C.BRASS
        c.drawPath(shield, line)
        if (!small) {
            txt.typeface = label
            txt.textSize = 6.5f
            txt.letterSpacing = 0.15f
            txt.color = C.BRASS_HI
            txt.textAlign = Paint.Align.CENTER
            c.drawText("FPS", SH_W / 2f, 8.2f, txt)
            txt.letterSpacing = 0f
        }
        val str = if (data.fps < 0f) "--" else dispFps.roundToInt().toString()
        txt.typeface = big
        txt.textAlign = Paint.Align.CENTER
        txt.textSize = if (str.length >= 3) 19f else 22f
        txt.setShadowLayer(1.2f, 0f, 1f, 0xCC000000.toInt())
        txt.color = C.TEXT
        c.drawText(str, SH_W / 2f, if (small) 36f else 38f, txt)
        txt.clearShadowLayer()
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = ((a shr 16 and 255) * (1 - t) + (b shr 16 and 255) * t).toInt()
        val g = ((a shr 8 and 255) * (1 - t) + (b shr 8 and 255) * t).toInt()
        val bl = ((a and 255) * (1 - t) + (b and 255) * t).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    private fun t(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, face: Typeface, al: Paint.Align) {
        txt.typeface = face
        txt.textSize = size
        txt.color = color
        txt.textAlign = al
        c.drawText(s, x, y, txt)
    }

    private fun drawPill(c: Canvas) {
        val st = stateOf(data)
        c.save()
        c.translate(8f, 5f)
        c.scale(0.5f, 0.5f)
        drawShield(c, st, true)
        c.restore()
        val ft = if (data.ft > 0f) String.format("%.1f", data.ft) else "--"
        t(c, "FRAME", 38f, 16f, 6.5f, C.BRASS, label, Paint.Align.LEFT)
        t(c, ft + " ms", 38f, 29f, 11f, accent(st), mono, Paint.Align.LEFT)
    }

    private fun drawFull(c: Canvas, w: Float) {
        val st = stateOf(data)
        val x0 = 66f
        val x1 = w - 10f

        // shield crest with the big FPS number
        c.save()
        c.translate(13f, 11f)
        drawShield(c, st, false)
        c.restore()

        // frame time / 1% low readout
        t(c, "FRAME", x0, 18f, 6.5f, C.BRASS, label, Paint.Align.LEFT)
        val ftS = if (data.ft > 0f) String.format("%.1f", data.ft) else "--"
        t(c, ftS, x0 + 31f, 18.5f, 10.5f, C.TEXT, mono, Paint.Align.LEFT)
        t(c, "ms", x0 + 31f + 7.2f * ftS.length + 1.5f, 18.5f, 6.5f, C.TEXT_DIM, label, Paint.Align.LEFT)
        val lowS = if (data.low > 0f) data.low.roundToInt().toString() else "--"
        t(c, lowS, x1, 18.5f, 10.5f, C.TEXT, mono, Paint.Align.RIGHT)
        t(c, "1% LOW", x1 - 7.2f * lowS.length - 3f, 18f, 6.5f, C.BRASS, label, Paint.Align.RIGHT)

        if (showGraph) drawGraph(c, x0, 25f, x1, 65f) else {
            t(c, if (data.ft > 0f) String.format("%.1f ms", data.ft) else "-- ms", x0, 50f, 17f, accent(st), mono, Paint.Align.LEFT)
            t(c, statusText(), x0, 62f, 7f, C.TEXT_DIM, label, Paint.Align.LEFT)
        }

        var y = 66f
        if (showBars) {
            y += 6f
            bar(c, 12f, y, 90f, "CPU", data.cpu / 100f, data.cpu >= 0f, String.format("%.0f%%", data.cpu))
            val ram = sys?.ram ?: -1f
            bar(c, 112f, y, 92f, "RAM", ram, ram >= 0f, String.format("%.0f%%", ram * 100f))
            y += 18f
        }
        if (showFooter) {
            y += 6f
            line.strokeWidth = 1f
            line.color = 0xFF0A0C0E.toInt()
            c.drawLine(10f, y, w - 10f, y, line)
            line.strokeWidth = 0.7f
            line.color = 0xFF3A424B.toInt()
            c.drawLine(10f, y + 1f, w - 10f, y + 1f, line)
            val sy = sys
            val fy = y + 11f
            t(c, sy?.clock ?: "--:--", 13f, fy, 7.5f, C.TEXT, mono, Paint.Align.LEFT)
            val bat = if (sy == null || sy.bat < 0) "--" else sy.bat.toString() + "%" + (if (sy.charging) "+" else "")
            val tp = if (sy == null || sy.temp <= 0f) "" else "  " + sy.temp.roundToInt() + "°C"
            t(c, "BAT $bat$tp", w / 2f + 4f, fy, 7.5f, C.TEXT_DIM, mono, Paint.Align.CENTER)
            t(c, sy?.session ?: "00:00:00", w - 13f, fy, 7.5f, C.BRASS_HI, mono, Paint.Align.RIGHT)
        }
    }

    private fun statusText(): String = when (data.status) {
        "OK" -> "LIVE"
        "SELF" -> "OPEN A GAME"
        "NOLINK" -> "SHIZUKU OFF"
        "STALE" -> "NO NEW FRAMES"
        "NOLAYER" -> "NO LAYER FOUND"
        else -> data.status
    }

    private fun bar(c: Canvas, x: Float, y: Float, w: Float, name: String, frac: Float, ok: Boolean, value: String) {
        t(c, name, x, y + 7f, 6.5f, C.BRASS, label, Paint.Align.LEFT)
        t(c, if (ok) value else "--", x + w, y + 7f, 7.5f, C.TEXT, mono, Paint.Align.RIGHT)
        val n = 12
        val gap = 1.4f
        val sw = (w - gap * (n - 1)) / n
        val filled = if (ok) (frac.coerceIn(0f, 1f) * n).roundToInt() else 0
        val col = if (frac < 0.6f) C.GOOD else if (frac < 0.85f) C.MID else C.BAD
        fill.style = Paint.Style.FILL
        for (i in 0 until n) {
            val sx = x + i * (sw + gap)
            fill.color = if (i < filled) col else C.EMPTY
            tmp.set(sx, y + 10.5f, sx + sw, y + 15.5f)
            c.drawRect(tmp, fill)
        }
    }

    private fun drawGraph(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val gh = y1 - y0
        fill.style = Paint.Style.FILL
        fill.color = C.SLIT
        tmp.set(x0, y0, x1, y1)
        c.drawRoundRect(tmp, 3f, 3f, fill)
        line.strokeWidth = 0.8f
        line.color = C.BRASS_DARK
        c.drawRoundRect(tmp, 3f, 3f, line)

        val targetFt = 1000f / targetFps
        val maxMs = targetFt * 2.2f
        val ty = y1 - 2f - (targetFt / maxMs).coerceAtMost(1f) * (gh - 4f)
        line.strokeWidth = 0.6f
        line.color = 0x88B8935A.toInt()
        var dx = x0 + 3f
        while (dx < x1 - 4f) { c.drawLine(dx, ty, dx + 2f, ty, line); dx += 4.5f }

        val fr = data.frames
        if (fr.isEmpty()) {
            line.strokeWidth = 0.8f
            line.color = C.EMPTY
            c.drawLine(x0 + 3f, y1 - 4f, x1 - 3f, y1 - 4f, line)
            return
        }
        val slots = 48
        val slotW = (x1 - x0 - 6f) / slots
        line.strokeWidth = max(0.9f, slotW * 0.62f)
        line.strokeCap = Paint.Cap.BUTT
        val n = min(slots, fr.size)
        for (i in 0 until n) {
            val ms = fr[fr.size - n + i]
            val hh = (ms / maxMs).coerceIn(0.05f, 1f) * (gh - 4f)
            line.color = if (ms <= targetFt * 1.2f) C.GOOD else if (ms <= targetFt * 1.7f) C.MID else C.BAD
            val bx = x1 - 3f - (n - i) * slotW + slotW / 2f
            c.drawLine(bx, y1 - 2f, bx, y1 - 2f - hh, line)
        }
    }

    // ---------------- touch ----------------

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f
    private val longRun = Runnable { longFired = true; onLong?.invoke() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY
                moved = false; longFired = false
                postDelayed(longRun, 600)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    moved = true
                    removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (moved) onDragEnd?.invoke() else if (!longFired) toggle()
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }
}
