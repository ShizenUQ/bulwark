package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/** Holds the drawn HUD plus the video box, and handles touch (tap = fold, drag = move, long-press / lock icon = lock). */
class HudRoot(private val ctx: Context) : FrameLayout(ctx) {

    val hud = HudView(ctx)
    private val vbox = MediaBox(ctx, 0)
    private val ibox = MediaBox(ctx, 1)
    private var soundOn = false
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private var vRect: Rect? = null
    private var iRect: Rect? = null
    private var galIdx = 0
    private var galCount = 0

    /** false = just a picture (used for the in-app preview): no touch, always muted. */
    var interactive = true

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onToggleLock: (() -> Unit)? = null
    /** 0 = open / close the song list, 1 = previous, 2 = play / pause, 3 = next. */
    var onMusic: ((Int) -> Unit)? = null

    init {
        addView(hud, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        vbox.visibility = View.GONE
        ibox.visibility = View.GONE
        addView(vbox, LayoutParams(1, 1))
        addView(ibox, LayoutParams(1, 1))
        setWillNotDraw(false)
        hud.onTick = { syncMedia() }
        ibox.onPos = { i, n -> galIdx = i; galCount = n; invalidate() }
    }

    fun applyPrefs() {
        vbox.load()
        ibox.load()
        val snd = Prefs.bool(ctx, Prefs.SOUND, false) && interactive
        vbox.configure(snd)
        soundOn = snd
        invalidate()
        hud.hasVideo = vbox.hasSource
        hud.hasImage = ibox.hasSource
        hud.applyPrefs()
    }

    fun update(d: FpsData, s: SysData) = hud.update(d, s)

    /** Pause / resume the clips (used when the app screen goes to the background). */
    fun setPlaying(p: Boolean) {
        if (vbox.visibility == View.VISIBLE) vbox.setActive(p)
        if (ibox.visibility == View.VISIBLE) ibox.setActive(p)
    }

    /** Lock icon spot in pixels (inside this view), or null. */
    fun lockRectPx(): Rect? {
        val r = hud.lockHit() ?: return null
        val s = hud.scalePx()
        return Rect((r.left * s).toInt(), (r.top * s).toInt(), (r.right * s).toInt(), (r.bottom * s).toInt())
    }

    /** Music buttons in pixels (inside this view), same order as onMusic. */
    fun musicRectsPx(): List<Rect> {
        val l = hud.musicHits() ?: return emptyList()
        val s = hud.scalePx()
        return l.map { Rect((it.left * s).toInt(), (it.top * s).toInt(), (it.right * s).toInt(), (it.bottom * s).toInt()) }
    }

    /** Tap area for "next picture" = the whole image screen (in pixels), or null. */
    fun soundRectPx(): Rect? {
        val r = iRect ?: return null
        if (ibox.visibility != View.VISIBLE) return null
        return Rect(r)
    }

    private fun sync1(box: MediaBox, r: Rect?, old: Rect?): Rect? {
        if (r != null && box.hasSource) {
            if (box.visibility != View.VISIBLE) {
                box.alpha = 0f
                box.visibility = View.VISIBLE
                box.setActive(true)
                box.animate().alpha(1f).setDuration(320).start()
                requestLayout()
            }
            if (old != r) requestLayout()
            return r
        } else if (box.visibility == View.VISIBLE) {
            box.animate().cancel()
            box.setActive(false)
            box.visibility = View.GONE
        }
        return null
    }

    private fun syncMedia() {
        vRect = sync1(vbox, hud.videoRect(), vRect)
        iRect = sync1(ibox, hud.imageRect(), iRect)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        hud.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        val v = vRect
        if (v != null && vbox.visibility == View.VISIBLE) {
            vbox.measure(MeasureSpec.makeMeasureSpec(v.width(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(v.height(), MeasureSpec.EXACTLY))
        }
        val i = iRect
        if (i != null && ibox.visibility == View.VISIBLE) {
            ibox.measure(MeasureSpec.makeMeasureSpec(i.width(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(i.height(), MeasureSpec.EXACTLY))
        }
        setMeasuredDimension(hud.measuredWidth, hud.measuredHeight)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        hud.layout(0, 0, hud.measuredWidth, hud.measuredHeight)
        val v = vRect
        if (v != null && vbox.visibility == View.VISIBLE) vbox.layout(v.left, v.top, v.right, v.bottom)
        val i = iRect
        if (i != null && ibox.visibility == View.VISIBLE) ibox.layout(i.left, i.top, i.right, i.bottom)
    }

    /** Segmented progress line along the bottom of the image screen: one piece per picture, the current one lit. */
    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val mr = iRect
        if (mr != null && ibox.visibility == View.VISIBLE && galCount > 1) {
            val s = hud.scalePx()
            ip.style = Paint.Style.STROKE
            ip.strokeWidth = maxOf(1.5f, 1.1f * s)
            ip.strokeCap = Paint.Cap.BUTT
            val x0 = mr.left + 5f * s
            val x1 = mr.right - 5f * s
            val gap = 1.2f * s
            val sw = (x1 - x0 - gap * (galCount - 1)) / galCount
            val y = mr.bottom - 3f * s
            for (i in 0 until galCount) {
                ip.color = if (i == galIdx) 0xFFFFFFFF.toInt() else 0x55FFFFFF
                val a = x0 + i * (sw + gap)
                c.drawLine(a, y, a + sw, y, ip)
            }
        }
    }

    // ---- touch ----
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f
    private val longRun = Runnable { longFired = true; onToggleLock?.invoke() }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = interactive

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY
                moved = false; longFired = false
                postDelayed(longRun, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    moved = true
                    removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (moved) onDragEnd?.invoke()
                else if (!longFired) {
                    val s = hud.scalePx()
                    val lr = hud.lockHit()
                    val sr = soundRectPx()
                    val mh = hud.musicHits()
                    val nh = hud.nyxHit()
                    var mi = -1
                    if (mh != null) for ((k, rc) in mh.withIndex()) if (rc.contains(e.x / s, e.y / s)) { mi = k; break }
                    if (mi >= 0) onMusic?.invoke(mi)
                    else if (sr != null && sr.contains(e.x.toInt(), e.y.toInt())) {
                        ibox.advance()
                    } else if (nh != null && nh.contains(e.x / s, e.y / s)) hud.nyxPoke()
                    else if (lr != null && lr.contains(e.x / s, e.y / s)) onToggleLock?.invoke() else hud.toggleFold()
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }
}
