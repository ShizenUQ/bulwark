package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/** Holds the drawn HUD plus the video box, and handles touch (tap = fold, drag = move, long-press / lock icon = lock). */
class HudRoot(private val ctx: Context) : FrameLayout(ctx) {

    val hud = HudView(ctx)
    private val media = MediaBox(ctx)
    private var soundOn = false
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mediaRect: Rect? = null

    /** false = just a picture (used for the in-app preview): no touch, always muted. */
    var interactive = true

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onToggleLock: (() -> Unit)? = null
    /** 0 = open / close the song list, 1 = previous, 2 = play / pause, 3 = next. */
    var onMusic: ((Int) -> Unit)? = null

    init {
        addView(hud, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        media.visibility = View.GONE
        addView(media, LayoutParams(1, 1))
        setWillNotDraw(false)
        hud.onTick = { syncMedia() }
    }

    fun applyPrefs() {
        media.load()
        val snd = Prefs.bool(ctx, Prefs.SOUND, false) && interactive
        media.configure(snd)
        soundOn = snd
        invalidate()
        hud.hasMedia = media.hasSource
        hud.applyPrefs()
    }

    fun update(d: FpsData, s: SysData) = hud.update(d, s)

    /** Pause / resume the video (used when the app screen goes to the background). */
    fun setPlaying(p: Boolean) {
        if (media.visibility == View.VISIBLE) media.setActive(p)
    }

    /** Lock icon spot in pixels (inside this view), or null. */
    fun lockRectPx(): Rect? {
        val r = hud.lockHit() ?: return null
        val s = hud.scalePx()
        return Rect((r.left * s).toInt(), (r.top * s).toInt(), (r.right * s).toInt(), (r.bottom * s).toInt())
    }

    /** Music buttons in pixels (inside this view), same order as onMusic. */
    fun musicRectsPx(): List<Rect> {
        val l = hud.musicHits() ?: return emptyList()
        val s = hud.scalePx()
        return l.map { Rect((it.left * s).toInt(), (it.top * s).toInt(), (it.right * s).toInt(), (it.bottom * s).toInt()) }
    }

    /** Tap area for mute / unmute = the whole video box (in pixels), or null. */
    fun soundRectPx(): Rect? {
        val mr = mediaRect ?: return null
        if (media.visibility != View.VISIBLE) return null
        return Rect(mr)
    }

    private fun syncMedia() {
        val r = hud.mediaRect()
        if (r != null && media.hasSource) {
            if (mediaRect != r) { mediaRect = r; requestLayout() }
            if (media.visibility != View.VISIBLE) {
                media.alpha = 0f
                media.visibility = View.VISIBLE
                media.setActive(true)
                media.animate().alpha(1f).setDuration(320).start()
                requestLayout()
            }
        } else if (media.visibility == View.VISIBLE) {
            media.animate().cancel()
            media.setActive(false)
            media.visibility = View.GONE
            mediaRect = null
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        hud.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        val r = mediaRect
        if (r != null && media.visibility == View.VISIBLE) {
            media.measure(
                MeasureSpec.makeMeasureSpec(r.width(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(r.height(), MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(hud.measuredWidth, hud.measuredHeight)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        hud.layout(0, 0, hud.measuredWidth, hud.measuredHeight)
        val mr = mediaRect
        if (mr != null && media.visibility == View.VISIBLE) media.layout(mr.left, mr.top, mr.right, mr.bottom)
    }

    /** Thin line along the bottom of the video box: green = sound on, dim = muted. */
    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        val mr = mediaRect
        if (mr != null && media.visibility == View.VISIBLE && interactive) {
            val s = hud.scalePx()
            ip.style = Paint.Style.STROKE
            ip.strokeWidth = maxOf(1.5f, 1.4f * s)
            ip.strokeCap = Paint.Cap.ROUND
            ip.color = if (soundOn) P.GOOD else 0x66FFFFFF
            val y = mr.bottom - ip.strokeWidth
            c.drawLine(mr.left + 4f * s, y, mr.right - 4f * s, y, ip)
        }
    }

    // ---- touch ----
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f
    private val longRun = Runnable { longFired = true; onToggleLock?.invoke() }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = interactive

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY
                moved = false; longFired = false
                postDelayed(longRun, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    moved = true
                    removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (moved) onDragEnd?.invoke()
                else if (!longFired) {
                    val s = hud.scalePx()
                    val lr = hud.lockHit()
                    val sr = soundRectPx()
                    val mh = hud.musicHits()
                    val nh = hud.nyxHit()
                    var mi = -1
                    if (mh != null) for ((k, rc) in mh.withIndex()) if (rc.contains(e.x / s, e.y / s)) { mi = k; break }
                    if (mi >= 0) onMusic?.invoke(mi)
                    else if (sr != null && sr.contains(e.x.toInt(), e.y.toInt())) {
                        Prefs.putBool(ctx, Prefs.SOUND, !Prefs.bool(ctx, Prefs.SOUND, false))
                        applyPrefs()
                    } else if (nh != null && nh.contains(e.x / s, e.y / s)) hud.nyxPoke()
                    else if (lr != null && lr.contains(e.x / s, e.y / s)) onToggleLock?.invoke() else hud.toggleFold()
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }
}
