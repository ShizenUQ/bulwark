package com.xio.bulwark

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/**
 * Nyx's portrait: a chibi girl with cyber cat-ear headphones, drawn in code on a 200x200 sheet.
 * Blinks, looks around, hair sways, bobs to the beat, mouth moves while she types. 13 moods (12 + neutral).
 */
object NyxChibi {
    private const val HAIR = 0xFF141C3F.toInt()
    private const val HAIR2 = 0xFF1E2A5E.toInt()
    private const val PK = 0xFFFF4FA3.toInt()
    private const val LASH = 0xFF2A1840.toInt()
    private const val DARK = 0xFF0E1630.toInt()
    private const val MOUTH = 0xFFC2467A.toInt()
    private const val MOUTH_IN = 0xFF7A1E4D.toInt()

    private fun m(c: Int, k: Float): Int =
        (c and 0x00FFFFFF) or ((((c ushr 24) * k.coerceIn(0f, 1f)).toInt()) shl 24)

    private fun pth(d: String, mir: Boolean): Path {
        val out = Path()
        val tk = Regex("[MLCQZ]|-?\\d+\\.?\\d*").findAll(d).map { it.value }.toList()
        var i = 0
        fun x(): Float { val v = tk[i++].toFloat(); return if (mir) 200f - v else v }
        fun y(): Float = tk[i++].toFloat()
        while (i < tk.size) {
            when (tk[i++]) {
                "M" -> { val a = x(); out.moveTo(a, y()) }
                "L" -> { val a = x(); out.lineTo(a, y()) }
                "C" -> { val a = x(); val b = y(); val c = x(); val d2 = y(); val e = x(); out.cubicTo(a, b, c, d2, e, y()) }
                "Q" -> { val a = x(); val b = y(); val c = x(); out.quadTo(a, b, c, y()) }
                "Z" -> out.close()
            }
        }
        return out
    }

    private val back by lazy { pth("M32,98 C26,44 68,16 100,16 C132,16 174,44 168,98 C170,128 166,156 150,170 C134,180 66,180 50,170 C34,156 30,128 32,98 Z", false) }
    private val tailL by lazy { pth("M44,100 C28,112 22,140 26,176 C36,170 42,150 52,128 Z", false) }
    private val tailR by lazy { pth("M44,100 C28,112 22,140 26,176 C36,170 42,150 52,128 Z", true) }
    private val earL by lazy { pth("M54,50 L46,10 L86,30 Z", false) }
    private val earR by lazy { pth("M54,50 L46,10 L86,30 Z", true) }
    private val inL by lazy { pth("M56,40 L52,22 L72,32 Z", false) }
    private val inR by lazy { pth("M56,40 L52,22 L72,32 Z", true) }
    private val face by lazy { pth("M46,92 C46,54 76,38 100,38 C124,38 154,54 154,92 C154,130 132,158 100,158 C68,158 46,130 46,92 Z", false) }
    private val bang by lazy { pth("M42,94 C40,46 76,28 100,28 C124,28 160,46 158,94 C152,72 140,60 126,58 C120,72 110,78 100,68 C90,78 80,72 74,58 C60,60 48,72 42,94 Z", false) }
    private val lockL by lazy { pth("M44,92 C42,112 44,128 52,142 C52,122 56,106 60,92 Z", false) }
    private val lockR by lazy { pth("M44,92 C42,112 44,128 52,142 C52,122 56,106 60,92 Z", true) }
    private val band by lazy { pth("M38,96 C34,22 166,22 162,96", false) }
    private val tmp = Path()
    private val rf = RectF()
    private val skin by lazy { LinearGradient(0f, 38f, 0f, 158f, 0xFFFFF3F8.toInt(), 0xFFF6D9EA.toInt(), Shader.TileMode.CLAMP) }
    private val iris by lazy {
        LinearGradient(0f, 88f, 0f, 122f, intArrayOf(0xFF7B5BFF.toInt(), 0xFF2FA8FF.toInt(), 0xFF19E6F2.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }

    private fun neon(c: Canvas, p: Paint, path: Path, fill: Int, rim: Int, w: Float, al: Float) {
        if (fill != 0) { p.style = Paint.Style.FILL; p.shader = null; p.color = m(fill, al); c.drawPath(path, p) }
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.shader = null
        p.strokeWidth = w * 3.2f
        p.color = m(rim, 0.22f * al)
        c.drawPath(path, p)
        p.strokeWidth = w
        p.color = m(rim, al)
        c.drawPath(path, p)
    }

    private fun line(c: Canvas, p: Paint, col: Int, w: Float, al: Float, x0: Float, y0: Float, x1: Float, y1: Float) {
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w; p.color = m(col, al)
        c.drawLine(x0, y0, x1, y1, p)
    }

    private fun lash(c: Canvas, p: Paint, cx: Float, cy: Float, w: Float, al: Float) {
        tmp.reset()
        tmp.moveTo(cx - 16f, cy - 4f); tmp.cubicTo(cx - 12f, cy - 19f, cx + 12f, cy - 19f, cx + 16f, cy - 4f)
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = w; p.color = m(LASH, al)
        c.drawPath(tmp, p)
    }

    private fun fillOval(c: Canvas, p: Paint, cx: Float, cy: Float, rx: Float, ry: Float, col: Int, al: Float) {
        rf.set(cx - rx, cy - ry, cx + rx, cy + ry)
        p.style = Paint.Style.FILL; p.shader = null; p.color = m(col, al)
        c.drawOval(rf, p)
    }

    private fun heart(path: Path, cx: Float, cy: Float, s: Float) {
        path.reset()
        path.moveTo(cx, cy + s)
        path.cubicTo(cx - s * 1.7f, cy - s * 0.1f, cx - s * 0.8f, cy - s * 1.35f, cx, cy - s * 0.45f)
        path.cubicTo(cx + s * 0.8f, cy - s * 1.35f, cx + s * 1.7f, cy - s * 0.1f, cx, cy + s)
        path.close()
    }

    private const val OPEN = 0
    private const val HAPPY = 1
    private const val LOVE = 2
    private const val STAR = 3
    private const val GT = 4
    private const val SLEEP = 5
    private const val CRY = 6
    private const val SMUG = 7
    private const val SHOCK = 8

    /** One eye centred on (cx,104). side -1 left, +1 right. */
    private fun eye(c: Canvas, p: Paint, kind: Int, cx: Float, side: Int, look: Float, blink: Float, al: Float, t: Float) {
        val cy = 104f
        val blinkable = kind != HAPPY && kind != GT && kind != SLEEP
        if (blinkable && blink > 0f) { c.save(); c.scale(1f, max(0.08f, 1f - blink), cx, cy) }
        when (kind) {
            OPEN, CRY, SMUG, STAR, LOVE, SHOCK -> {
                val big = kind == SHOCK
                fillOval(c, p, cx, cy, if (big) 16.5f else 15.5f, if (big) 19f else 18f, 0xFFFFFFFF.toInt(), al)
                when (kind) {
                    LOVE -> {
                        heart(tmp, cx, cy + 3f, 11f)
                        p.style = Paint.Style.FILL; p.shader = null; p.color = m(PK, al)
                        val k = 1f + 0.08f * sin(t * 8f)
                        c.save(); c.scale(k, k, cx, cy); c.drawPath(tmp, p); c.restore()
                        fillOval(c, p, cx - 5f, cy - 5f, 2.6f, 2.6f, 0xFFFFFFFF.toInt(), al)
                    }
                    STAR -> {
                        p.style = Paint.Style.FILL; p.shader = iris; p.color = m(0xFFFFFFFF.toInt(), al)
                        rf.set(cx - 12.5f, cy - 15f, cx + 12.5f, cy + 17f); c.drawOval(rf, p); p.shader = null
                        val s = 11f * (0.85f + 0.15f * sin(t * 9f))
                        tmp.reset()
                        tmp.moveTo(cx, cy - s); tmp.lineTo(cx + s * 0.3f, cy - s * 0.3f); tmp.lineTo(cx + s, cy)
                        tmp.lineTo(cx + s * 0.3f, cy + s * 0.3f); tmp.lineTo(cx, cy + s); tmp.lineTo(cx - s * 0.3f, cy + s * 0.3f)
                        tmp.lineTo(cx - s, cy); tmp.lineTo(cx - s * 0.3f, cy - s * 0.3f); tmp.close()
                        p.color = m(0xFFFFE27A.toInt(), al); c.drawPath(tmp, p)
                        fillOval(c, p, cx + 8f, cy - 10f, 2f, 2f, 0xFFFFFFFF.toInt(), al)
                    }
                    SHOCK -> {
                        fillOval(c, p, cx, cy, 6f, 7.5f, 0xFF1A0F33.toInt(), al)
                        fillOval(c, p, cx - 2f, cy - 2f, 2f, 2f, 0xFFFFFFFF.toInt(), al)
                    }
                    else -> {
                        val lx = cx + look + (if (kind == SMUG) 3f else 0f)
                        val ly = cy + (if (kind == SMUG) 4f else 2f)
                        p.style = Paint.Style.FILL; p.shader = iris; p.color = m(0xFFFFFFFF.toInt(), al)
                        rf.set(lx - 12f, ly - 15.5f, lx + 12f, ly + 15.5f)
                        c.save(); c.translate(0f, 0f); c.drawOval(rf, p); c.restore(); p.shader = null
                        fillOval(c, p, lx, ly + 1f, 5.8f, 9f, 0xFF1A0F33.toInt(), al)
                        fillOval(c, p, lx, ly + 11f, 8f, 3.5f, 0xFF6FF3FF.toInt(), 0.55f * al)
                        fillOval(c, p, lx - 4.5f, cy - 6f, 4.4f, 4.4f, 0xFFFFFFFF.toInt(), al)
                        fillOval(c, p, lx + 4.5f, cy + 6f, 2.2f, 2.2f, 0xFFFFFFFF.toInt(), al)
                        if (kind == CRY) {
                            fillOval(c, p, cx, cy + 12f, 12f, 4.5f, 0xFF8FEFFF.toInt(), 0.7f * al)
                            val f = (t * 0.9f + (if (side < 0) 0f else 0.4f)) % 1f
                            fillOval(c, p, cx + side * 6f, cy + 18f + f * 16f, 3f, 4.2f, 0xFF7FD8FF.toInt(), al * (1f - f * 0.7f))
                        }
                        if (kind == SMUG) {
                            p.style = Paint.Style.FILL; p.color = m(0xFFFBE6F1.toInt(), al)
                            rf.set(cx - 16f, cy - 20f, cx + 16f, cy - 2f); c.drawRect(rf, p)
                        }
                    }
                }
                if (kind == SMUG) line(c, p, LASH, 4.4f, al, cx - 16f, cy - 2f, cx + 16f, cy - 2f)
                else lash(c, p, cx, cy, 4.2f, al)
            }
            HAPPY -> {
                tmp.reset(); tmp.moveTo(cx - 14f, cy + 6f); tmp.quadTo(cx, cy - 16f, cx + 14f, cy + 6f)
                p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = 4.6f; p.color = m(LASH, al); c.drawPath(tmp, p)
            }
            GT -> {
                val o = if (side < 0) 1f else -1f
                tmp.reset(); tmp.moveTo(cx - 11f * o, cy - 11f); tmp.lineTo(cx + 9f * o, cy); tmp.lineTo(cx - 11f * o, cy + 11f)
                p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
                p.strokeWidth = 4.6f; p.color = m(LASH, al); c.drawPath(tmp, p)
            }
            SLEEP -> {
                tmp.reset(); tmp.moveTo(cx - 14f, cy - 2f); tmp.quadTo(cx, cy + 12f, cx + 14f, cy - 2f)
                p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = 4.4f; p.color = m(LASH, al); c.drawPath(tmp, p)
            }
        }
        if (blinkable && blink > 0f) c.restore()
    }

    private fun mouth(c: Canvas, p: Paint, kind: Int, talk: Float, t: Float, al: Float) {
        val op = if (talk > 0f) 0.35f + 0.65f * abs(sin(t * 13f)) else 0f
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 3f
        tmp.reset()
        if (talk > 0f && kind != 3 && kind != 4) {
            // open talking mouth
            tmp.moveTo(91f, 131f); tmp.quadTo(100f, 131f + 20f * op, 109f, 131f); tmp.close()
            p.style = Paint.Style.FILL; p.color = m(MOUTH_IN, al); c.drawPath(tmp, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.6f; p.color = m(MOUTH, al); c.drawPath(tmp, p)
            fillOval(c, p, 100f, 131f + 12f * op, 5f, 2.5f * op + 0.5f, 0xFFFF7FB0.toInt(), al)
            return
        }
        when (kind) {
            0 -> { tmp.moveTo(93f, 133f); tmp.quadTo(100f, 141f, 107f, 133f); p.color = m(MOUTH, al); c.drawPath(tmp, p) } // smile
            1 -> { // open smile
                tmp.moveTo(91f, 131f); tmp.quadTo(100f, 150f, 109f, 131f); tmp.close()
                p.style = Paint.Style.FILL; p.color = m(MOUTH_IN, al); c.drawPath(tmp, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.6f; p.color = m(MOUTH, al); c.drawPath(tmp, p)
                fillOval(c, p, 100f, 141f, 5f, 2.6f, 0xFFFF7FB0.toInt(), al)
            }
            2 -> { tmp.moveTo(92f, 132f); tmp.quadTo(96f, 138f, 100f, 132f); tmp.quadTo(104f, 138f, 108f, 132f); p.color = m(MOUTH, al); c.drawPath(tmp, p) } // cat
            3 -> { tmp.moveTo(91f, 134f); tmp.quadTo(94f, 129f, 97f, 134f); tmp.quadTo(100f, 139f, 103f, 134f); tmp.quadTo(106f, 129f, 109f, 134f); p.color = m(MOUTH, al); c.drawPath(tmp, p) } // wavy
            4 -> { // o
                fillOval(c, p, 100f, 136f, 6f, 8f, MOUTH_IN, al)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.6f; p.color = m(MOUTH, al); rf.set(94f, 128f, 106f, 144f); c.drawOval(rf, p)
            }
            5 -> { fillOval(c, p, 100f, 134f, 3.2f, 3.6f, MOUTH_IN, al) } // small
            6 -> { tmp.moveTo(92f, 135f); tmp.quadTo(104f, 140f, 111f, 130f); p.color = m(MOUTH, al); c.drawPath(tmp, p) } // smirk
            else -> { tmp.moveTo(92f, 139f); tmp.quadTo(100f, 129f, 108f, 139f); p.color = m(MOUTH, al); c.drawPath(tmp, p) } // cry
        }
    }

    /**
     * Draw her with the middle of the head at (cx,cy). s = scale of the 200 sheet. mood 0..11, 12 = neutral.
     * talk 0 or 1, bob 0..1 (beat), al overall opacity.
     */
    fun draw(c: Canvas, p: Paint, mood: Int, cx: Float, cy: Float, s: Float, t: Float, talk: Float, bob: Float, al: Float) {
        val rim = NyxArt.moodColor(mood)
        var el = OPEN; var er = OPEN; var mo = 0; var blush = 0.5f; var brow = true; var sweat = false; var tinyHeart = false
        when (mood) {
            0 -> { el = HAPPY; er = HAPPY; mo = 1; blush = 0.6f }
            1 -> { el = LOVE; er = LOVE; mo = 2; blush = 0.8f }
            2 -> { el = SMUG; er = SMUG; mo = 6 }
            3 -> { el = OPEN; er = HAPPY; mo = 0; blush = 0.6f }
            4 -> { el = SLEEP; er = SLEEP; mo = 5; blush = 0.4f }
            5 -> { el = OPEN; er = OPEN; mo = 3; blush = 0.3f }
            6 -> { el = SHOCK; er = SHOCK; mo = 4; blush = 0.3f; brow = false }
            7 -> { el = CRY; er = CRY; mo = 7 }
            8 -> { el = GT; er = GT; mo = 3; blush = 1f }
            9 -> { el = STAR; er = STAR; mo = 1; blush = 0.6f }
            10 -> { el = OPEN; er = OPEN; mo = 3; blush = 0.35f; sweat = true }
            11 -> { el = HAPPY; er = HAPPY; mo = 2; blush = 0.9f; tinyHeart = true }
            else -> { }
        }
        val ph = t % 3.9f
        val blink = if (ph > 3.62f) { val k = (ph - 3.62f) / 0.28f; if (k < 0.5f) k * 2f else (1f - k) * 2f } else 0f
        val look = sin(t * 0.9f) * 2.6f + (if (sin(t * 0.37f) > 0.85f) 3f else 0f)
        val shake = if (mood == 5) sin(t * 40f) * 1.2f else 0f
        val by = -bob * 4f + (if (talk > 0f) sin(t * 14f) * 0.7f else 0f)
        c.save()
        c.translate(cx - 100f * s + shake * s, cy - 95f * s + by * s)
        c.scale(s, s)
        val w = 3.3f
        val sw = sin(t * 1.7f) * 3.2f + bob * 4f
        // back hair + tails
        neon(c, p, back, HAIR, rim, w, al)
        c.save(); c.rotate(sw, 44f, 100f); neon(c, p, tailL, HAIR, rim, w, al)
        p.style = Paint.Style.FILL; p.shader = null; p.color = m(PK, al); c.drawCircle(27f, 174f, 5.5f, p); c.restore()
        c.save(); c.rotate(-sw, 156f, 100f); neon(c, p, tailR, HAIR, rim, w, al)
        p.style = Paint.Style.FILL; p.shader = null; p.color = m(PK, al); c.drawCircle(173f, 174f, 5.5f, p); c.restore()
        // ears (twitch on the beat)
        val tw = bob * 7f + (if (sin(t * 0.8f) > 0.96f) 5f else 0f)
        c.save(); c.rotate(-tw, 60f, 50f); neon(c, p, earL, HAIR2, rim, w, al)
        p.style = Paint.Style.FILL; p.shader = null; p.color = m(PK, 0.85f * al); c.drawPath(inL, p); c.restore()
        c.save(); c.rotate(tw, 140f, 50f); neon(c, p, earR, HAIR2, rim, w, al)
        p.style = Paint.Style.FILL; p.shader = null; p.color = m(PK, 0.85f * al); c.drawPath(inR, p); c.restore()
        // face
        p.style = Paint.Style.FILL; p.shader = skin; p.color = m(0xFFFFFFFF.toInt(), al); c.drawPath(face, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f; p.color = m(0xFFFFFFFF.toInt(), 0.35f * al); c.drawPath(face, p)
        // blush
        fillOval(c, p, 64f, 127f, 11f, 6.5f, PK, blush * al)
        fillOval(c, p, 136f, 127f, 11f, 6.5f, PK, blush * al)
        for (x in intArrayOf(58, 64, 70, 130, 136, 142)) line(c, p, 0xFFFFFFFF.toInt(), 1.6f, 0.7f * al, x.toFloat(), 124f, x + 3f, 130f)
        // eyes
        eye(c, p, el, 74f, -1, look, blink, al, t)
        eye(c, p, er, 126f, 1, look, blink, al, t)
        if (brow) {
            p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2.8f; p.color = m(0xFF3A2556.toInt(), al)
            if (mood == 5) { c.drawLine(56f, 72f, 90f, 84f, p); c.drawLine(144f, 72f, 110f, 84f, p) }
            else {
                tmp.reset(); tmp.moveTo(60f, 80f); tmp.quadTo(74f, 72f, 88f, 80f); c.drawPath(tmp, p)
                tmp.reset(); tmp.moveTo(112f, 80f); tmp.quadTo(126f, 72f, 140f, 80f); c.drawPath(tmp, p)
            }
        }
        mouth(c, p, mo, talk, t, al)
        fillOval(c, p, 100f, 122f, 1.6f, 1f, 0xFFD58AA8.toInt(), al)
        if (sweat) {
            val f = (t * 0.9f) % 1f
            tmp.reset(); tmp.moveTo(150f, 66f + f * 20f); tmp.quadTo(158f, 80f + f * 20f, 150f, 86f + f * 20f); tmp.quadTo(142f, 80f + f * 20f, 150f, 66f + f * 20f)
            p.style = Paint.Style.FILL; p.color = m(0xFF7FD8FF.toInt(), al * (1f - f * 0.6f)); c.drawPath(tmp, p)
        }
        // bangs and side locks
        neon(c, p, bang, HAIR, rim, w * 0.9f, al)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
        p.color = m(HAIR2, 0.9f * al)
        tmp.reset(); tmp.moveTo(70f, 52f); tmp.quadTo(84f, 38f, 100f, 36f); tmp.moveTo(104f, 36f); tmp.quadTo(122f, 40f, 134f, 52f)
        c.drawPath(tmp, p)
        p.strokeWidth = 2f; p.color = m(0xFF7B8DFF.toInt(), 0.7f * al)
        tmp.reset(); tmp.moveTo(62f, 58f); tmp.quadTo(74f, 48f, 90f, 46f); c.drawPath(tmp, p)
        neon(c, p, lockL, HAIR, rim, w * 0.8f, al)
        neon(c, p, lockR, HAIR, rim, w * 0.8f, al)
        // headphones
        p.style = Paint.Style.STROKE; p.strokeWidth = 9f; p.color = m(DARK, al); c.drawPath(band, p)
        p.strokeWidth = 8f; p.color = m(rim, 0.2f * al); c.drawPath(band, p)
        p.strokeWidth = 2.6f; p.color = m(rim, al); c.drawPath(band, p)
        val pulse = 0.55f + 0.45f * max(bob, 0.5f + 0.5f * sin(t * 3f))
        for (side in 0..1) {
            val x0 = if (side == 0) 22f else 156f
            rf.set(x0, 84f, x0 + 22f, 124f)
            p.style = Paint.Style.FILL; p.color = m(DARK, al); c.drawRoundRect(rf, 9f, 9f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = m(rim, 0.2f * al); c.drawRoundRect(rf, 9f, 9f, p)
            p.strokeWidth = 2.8f; p.color = m(rim, al); c.drawRoundRect(rf, 9f, 9f, p)
            val dx = x0 + 11f
            p.style = Paint.Style.FILL; p.color = m(PK, 0.3f * al * pulse); c.drawCircle(dx, 104f, 9f, p)
            p.color = m(PK, al); c.drawCircle(dx, 104f, 5f, p)
        }
        if (tinyHeart) {
            val k = 1f + 0.15f * max(0f, sin(t * 8f))
            heart(tmp, 100f, 150f, 5.5f * k)
            p.style = Paint.Style.FILL; p.color = m(PK, al); c.drawPath(tmp, p)
        }
        c.restore()
    }
}
