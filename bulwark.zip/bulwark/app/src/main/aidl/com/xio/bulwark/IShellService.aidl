package com.xio.bulwark;

interface IShellService {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
    String sample(String ownPkg) = 2;
    String debug() = 3;
}
