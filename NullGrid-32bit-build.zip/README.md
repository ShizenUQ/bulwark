# NullGrid (unofficial modified version)

32-bit Android build of a Minecraft: Java Edition launcher.

Based on Zalith Launcher 2 (https://github.com/ZalithLauncher/ZalithLauncher2),
commit b8275403823239f6a3d6ee1b93e9db5be68d2a2b, licensed GPL-3.0 with additional terms.
Not affiliated with or endorsed by its developers, Mojang or Microsoft.
All changes are listed in .github/workflows/build.yml.

## Build
1. Create a GitHub repository.
2. Add file > Create new file, name it .github/workflows/build.yml, paste the content, commit.
3. Actions tab > Build NullGrid (32-bit) > Run workflow.
4. When it finishes, download NullGrid-32bit-apk, unzip it, install the APK.

If it fails, open the red step and copy the last lines of the error.

## Sign-in
Microsoft sign-in needs your own OAuth client ID, saved as the repository secret
OAUTH_CLIENT_ID (Settings > Secrets and variables > Actions) before building.
