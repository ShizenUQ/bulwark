package com.lineengine3d

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import java.io.File

class Store(private val ctx: Context) {
    private val pdir = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val adir = File(ctx.filesDir, "assets").apply { mkdirs() }

    fun listProjects(): List<Project> =
        (pdir.listFiles() ?: emptyArray())
            .filter { it.extension == "json" }
            .mapNotNull { f -> runCatching { AppJson.decodeFromString<Project>(f.readText()) }.getOrNull() }
            .sortedByDescending { it.modified }

    fun load(id: String): Project? =
        runCatching { AppJson.decodeFromString<Project>(File(pdir, "$id.json").readText()) }.getOrNull()

    @Synchronized
    fun save(p: Project) {
        val tmp = File(pdir, "${p.id}.json.tmp")
        tmp.writeText(AppJson.encodeToString(p))
        tmp.renameTo(File(pdir, "${p.id}.json"))
    }

    fun delete(id: String) {
        File(pdir, "$id.json").delete()
    }

    fun listAssets(): List<Asset> =
        (adir.listFiles() ?: emptyArray())
            .filter { it.extension == "json" }
            .sortedBy { it.lastModified() }
            .mapNotNull { f -> runCatching { AppJson.decodeFromString<Asset>(f.readText()) }.getOrNull() }

    fun saveAsset(a: Asset) {
        File(adir, "${a.id}.json").writeText(AppJson.encodeToString(a))
    }

    fun deleteAsset(id: String) {
        File(adir, "$id.json").delete()
    }

    fun shareProject(p: Project): Intent = shareText(p.name, AppJson.encodeToString(p))

    private fun shareText(name: String, json: String): Intent {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "project" }
        val f = File(dir, "$safe.json")
        f.writeText(json)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        return Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "LineEngine3D: $name")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** Imports a project or an asset JSON. Returns a human readable result. */
    fun importJson(text: String): String {
        val proj = runCatching { AppJson.decodeFromString<Project>(text) }.getOrNull()
        if (proj != null) {
            val p = proj.copy(id = newId(), name = proj.name + " (imported)", modified = System.currentTimeMillis())
            save(p)
            return "Imported project \"${p.name}\""
        }
        val asset = runCatching { AppJson.decodeFromString<Asset>(text) }.getOrNull()
        if (asset != null && asset.entities.isNotEmpty()) {
            saveAsset(asset.copy(id = newId()))
            return "Imported asset \"${asset.name}\""
        }
        return "Not a valid LineEngine3D file"
    }
}
