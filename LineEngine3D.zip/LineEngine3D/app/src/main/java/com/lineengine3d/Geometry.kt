package com.lineengine3d

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object Geo {
    fun normal(p: List<V3>): V3 {
        var nx = 0f; var ny = 0f; var nz = 0f
        for (i in p.indices) {
            val a = p[i]; val b = p[(i + 1) % p.size]
            nx += (a.y - b.y) * (a.z + b.z)
            ny += (a.z - b.z) * (a.x + b.x)
            nz += (a.x - b.x) * (a.y + b.y)
        }
        return V3(nx, ny, nz).norm()
    }

    fun orientedNormal(p: List<V3>): V3 {
        val n = normal(p)
        val ax = abs(n.x); val ay = abs(n.y); val az = abs(n.z)
        return when {
            ax >= ay && ax >= az -> if (n.x < 0f) -n else n
            ay >= az -> if (n.y < 0f) -n else n
            else -> if (n.z < 0f) -n else n
        }
    }

    fun bounds(e: Entity): Pair<V3, V3>? {
        var mnx = Float.MAX_VALUE; var mny = Float.MAX_VALUE; var mnz = Float.MAX_VALUE
        var mxx = -Float.MAX_VALUE; var mxy = -Float.MAX_VALUE; var mxz = -Float.MAX_VALUE
        var any = false
        for (s in e.strokes) for (p in s.pts) {
            any = true
            mnx = min(mnx, p.x); mny = min(mny, p.y); mnz = min(mnz, p.z)
            mxx = max(mxx, p.x); mxy = max(mxy, p.y); mxz = max(mxz, p.z)
        }
        var i = 0
        val t = e.tris
        while (i + 2 < t.size) {
            any = true
            mnx = min(mnx, t[i]); mny = min(mny, t[i + 1]); mnz = min(mnz, t[i + 2])
            mxx = max(mxx, t[i]); mxy = max(mxy, t[i + 1]); mxz = max(mxz, t[i + 2])
            i += 3
        }
        return if (any) V3(mnx, mny, mnz) to V3(mxx, mxy, mxz) else null
    }

    private fun distPtSeg(p: V3, a: V3, b: V3): Float {
        val ab = b - a
        val l2 = ab.dot(ab)
        val t = if (l2 < 1e-12f) 0f else ((p - a).dot(ab) / l2).coerceIn(0f, 1f)
        return (a + ab * t - p).len()
    }

    fun simplify(p: List<V3>, eps: Float): List<V3> {
        if (p.size < 3) return p
        val keep = BooleanArray(p.size)
        keep[0] = true; keep[p.size - 1] = true
        dp(p, 0, p.size - 1, eps, keep)
        return p.filterIndexed { i, _ -> keep[i] }
    }

    private fun dp(p: List<V3>, a: Int, b: Int, eps: Float, keep: BooleanArray) {
        var md = 0f; var mi = -1
        for (i in a + 1 until b) {
            val d = distPtSeg(p[i], p[a], p[b])
            if (d > md) { md = d; mi = i }
        }
        if (mi >= 0 && md > eps) {
            keep[mi] = true
            dp(p, a, mi, eps, keep)
            dp(p, mi, b, eps, keep)
        }
    }

    private fun inTri(px: Float, py: Float, xs: FloatArray, ys: FloatArray, a: Int, b: Int, c: Int): Boolean {
        val d1 = (px - xs[b]) * (ys[a] - ys[b]) - (xs[a] - xs[b]) * (py - ys[b])
        val d2 = (px - xs[c]) * (ys[b] - ys[c]) - (xs[b] - xs[c]) * (py - ys[c])
        val d3 = (px - xs[a]) * (ys[c] - ys[a]) - (xs[c] - xs[a]) * (py - ys[a])
        val neg = d1 < 0f || d2 < 0f || d3 < 0f
        val pos = d1 > 0f || d2 > 0f || d3 > 0f
        return !(neg && pos)
    }

    fun triangulate(p: List<V3>, n: V3): IntArray {
        val cnt = p.size
        if (cnt < 3) return IntArray(0)
        val ref = if (abs(n.y) < 0.9f) V3.UP else V3(1f, 0f, 0f)
        val u = ref.cross(n).norm()
        val v = n.cross(u)
        val xs = FloatArray(cnt) { p[it].dot(u) }
        val ys = FloatArray(cnt) { p[it].dot(v) }
        var area = 0f
        for (i in 0 until cnt) {
            val j = (i + 1) % cnt
            area += xs[i] * ys[j] - xs[j] * ys[i]
        }
        val idx = ArrayList<Int>()
        if (area >= 0f) for (i in 0 until cnt) idx.add(i) else for (i in cnt - 1 downTo 0) idx.add(i)
        val out = ArrayList<Int>()
        var guard = cnt * cnt + 10
        while (idx.size > 3 && guard-- > 0) {
            var clipped = false
            for (k in idx.indices) {
                val ia = idx[(k + idx.size - 1) % idx.size]
                val ib = idx[k]
                val ic = idx[(k + 1) % idx.size]
                val cross = (xs[ib] - xs[ia]) * (ys[ic] - ys[ia]) - (ys[ib] - ys[ia]) * (xs[ic] - xs[ia])
                if (cross <= 1e-9f) continue
                var inside = false
                for (m in idx) {
                    if (m == ia || m == ib || m == ic) continue
                    if (inTri(xs[m], ys[m], xs, ys, ia, ib, ic)) { inside = true; break }
                }
                if (inside) continue
                out.add(ia); out.add(ib); out.add(ic)
                idx.removeAt(k)
                clipped = true
                break
            }
            if (!clipped) break
        }
        if (idx.size >= 3) {
            for (k in 1 until idx.size - 1) {
                out.add(idx[0]); out.add(idx[k]); out.add(idx[k + 1])
            }
        }
        return out.toIntArray()
    }

    fun extrude(e: Entity, h: Float, sym: Boolean): Entity {
        val strokes = ArrayList<Stroke>()
        val tr = FloatList()
        tr.addAll(e.tris)
        for (s in e.strokes) {
            if (!s.closed || s.pts.size < 3) { strokes.add(s); continue }
            val p = s.pts
            val n = orientedNormal(p)
            val d0 = if (sym) n * (-h / 2f) else V3.ZERO
            val d1 = if (sym) n * (h / 2f) else n * h
            val a = p.map { it + d0 }
            val b = p.map { it + d1 }
            strokes.add(Stroke(a, true))
            strokes.add(Stroke(b, true))
            val step = max(1, p.size / 16)
            var i = 0
            while (i < p.size) {
                strokes.add(Stroke(listOf(a[i], b[i])))
                i += step
            }
            for (k in p.indices) {
                val j = (k + 1) % p.size
                tr.quad(a[k], a[j], b[j], b[k])
            }
            val idx = triangulate(p, n)
            var k = 0
            while (k + 2 < idx.size) {
                tr.tri(a[idx[k]], a[idx[k + 1]], a[idx[k + 2]])
                tr.tri(b[idx[k]], b[idx[k + 1]], b[idx[k + 2]])
                k += 3
            }
        }
        return e.copy(strokes = strokes, tris = tr.toArray())
    }

    private fun rotAxis(p: V3, axis: Int, deg: Float): V3 {
        val c = cos(rad(deg)); val s = sin(rad(deg))
        return when (axis) {
            0 -> V3(p.x, p.y * c - p.z * s, p.y * s + p.z * c)
            1 -> V3(p.x * c + p.z * s, p.y, -p.x * s + p.z * c)
            else -> V3(p.x * c - p.y * s, p.x * s + p.y * c, p.z)
        }
    }

    fun revolve(e: Entity, axis: Int, segs: Int, deg: Float = 360f): Entity {
        val full = deg >= 359.9f
        val strokes = ArrayList<Stroke>()
        val tr = FloatList()
        tr.addAll(e.tris)
        val nSeg = segs.coerceIn(3, 48)
        for (s in e.strokes) {
            val p = s.pts
            if (p.size < 2) { strokes.add(s); continue }
            val prof = if (s.closed) p + p[0] else p
            val rc = if (full) nSeg else nSeg + 1
            val rings = Array(rc) { k ->
                val a = deg * k / nSeg
                prof.map { rotAxis(it, axis, a) }
            }
            val mStep = max(1, rc / 12)
            var k = 0
            while (k < rc) {
                strokes.add(Stroke(rings[k]))
                k += mStep
            }
            val stepI = max(1, prof.size / 16)
            var i = 0
            while (i < prof.size) {
                val pts = rings.map { it[i] }
                strokes.add(Stroke(pts, full))
                i += stepI
            }
            val lim = if (full) rc else rc - 1
            for (kk in 0 until lim) {
                val k2 = (kk + 1) % rc
                for (ii in 0 until prof.size - 1) {
                    tr.quad(rings[kk][ii], rings[k2][ii], rings[k2][ii + 1], rings[kk][ii + 1])
                }
            }
        }
        return e.copy(strokes = strokes, tris = tr.toArray())
    }
}
