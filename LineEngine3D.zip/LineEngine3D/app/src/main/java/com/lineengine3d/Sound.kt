package com.lineengine3d

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Pure-Kotlin procedural synth. Effects are generated once and replayed via static AudioTracks. */
class Sound {
    @Volatile var muted = false
    @Volatile var engineOn = false
    @Volatile var engineRpm = 0f

    private val sr = 22050
    private val tracks = HashMap<String, AudioTrack>()
    @Volatile private var running = false
    private var thread: Thread? = null

    private fun tone(f0: Float, f1: Float, dur: Float, wave: Int, vol: Float): ShortArray {
        val n = (sr * dur).toInt()
        val out = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / n
            val f = f0 + (f1 - f0) * t
            ph += 2.0 * PI * f / sr
            val s = when (wave) {
                0 -> sin(ph).toFloat()
                1 -> if (sin(ph) >= 0.0) 1f else -1f
                2 -> (((ph / (2.0 * PI)) % 1.0) * 2.0 - 1.0).toFloat()
                else -> Random.nextFloat() * 2f - 1f
            }
            val env = exp(-3.5f * t) * minOf(1f, t * 60f)
            out[i] = (s * env * vol * 32000f).toInt().toShort()
        }
        return out
    }

    private fun cat(vararg parts: ShortArray): ShortArray {
        val out = ShortArray(parts.sumOf { it.size })
        var p = 0
        for (a in parts) { System.arraycopy(a, 0, out, p, a.size); p += a.size }
        return out
    }

    private fun gen(kind: String): ShortArray = when (kind) {
        "jump" -> tone(280f, 620f, 0.18f, 0, 0.35f)
        "pickup" -> cat(tone(660f, 660f, 0.08f, 1, 0.25f), tone(990f, 1100f, 0.14f, 1, 0.25f))
        "door" -> cat(tone(130f, 80f, 0.25f, 2, 0.3f), tone(90f, 60f, 0.15f, 3, 0.12f))
        "locked" -> cat(tone(180f, 180f, 0.08f, 1, 0.3f), tone(140f, 140f, 0.12f, 1, 0.3f))
        "trigger" -> tone(440f, 520f, 0.1f, 1, 0.3f)
        "hurt" -> tone(240f, 70f, 0.32f, 2, 0.4f)
        "win" -> cat(
            tone(523f, 523f, 0.12f, 0, 0.35f), tone(659f, 659f, 0.12f, 0, 0.35f),
            tone(784f, 784f, 0.12f, 0, 0.35f), tone(1046f, 1046f, 0.4f, 0, 0.35f)
        )
        else -> tone(400f, 400f, 0.05f, 0, 0.2f)
    }

    fun play(kind: String) {
        if (muted) return
        try {
            val t = tracks.getOrPut(kind) {
                val data = gen(kind)
                val tr = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                tr.write(data, 0, data.size)
                tr
            }
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (_: Throwable) {
        }
    }

    fun startEngine() {
        if (running) return
        running = true
        thread = Thread {
            var track: AudioTrack? = null
            try {
                val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
                    .setAudioFormat(
                        AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(maxOf(min, 2048))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val buf = ShortArray(512)
                var ph = 0.0
                var ph2 = 0.0
                while (running) {
                    if (!engineOn || muted) {
                        Thread.sleep(40)
                        continue
                    }
                    val f = 38.0 + engineRpm * 110.0
                    for (i in buf.indices) {
                        ph += 2.0 * PI * f / sr
                        ph2 += 2.0 * PI * f * 2.01 / sr
                        val saw = ((ph / (2.0 * PI)) % 1.0) * 2.0 - 1.0
                        val s = 0.55 * saw + 0.3 * sin(ph2) + 0.15 * sin(ph * 0.5)
                        buf[i] = (s * 0.10 * 32000.0).toInt().toShort()
                    }
                    track.write(buf, 0, buf.size)
                }
            } catch (_: Throwable) {
            } finally {
                try { track?.stop() } catch (_: Throwable) {}
                try { track?.release() } catch (_: Throwable) {}
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun release() {
        running = false
        engineOn = false
        try { thread?.join(300) } catch (_: Throwable) {}
        for (t in tracks.values) {
            try { t.stop() } catch (_: Throwable) {}
            try { t.release() } catch (_: Throwable) {}
        }
        tracks.clear()
    }
}
