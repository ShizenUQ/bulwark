package com.lineengine3d

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

enum class Tool { Select, Polyline, Freehand, Rect, Circle, Eraser, Terrain, Stamp, Hinge }
enum class WPlane { Ground, Front, Side, Surface }
enum class GizmoMode { Move, Rotate, Scale }

class OrbitCam(
    var tx: Float = 0f, var ty: Float = 1f, var tz: Float = 0f,
    var yaw: Float = 35f, var pitch: Float = 30f, var dist: Float = 20f
) {
    fun eye(): V3 {
        val cp = cos(rad(pitch))
        return V3(tx + dist * cp * sin(rad(yaw)), ty + dist * sin(rad(pitch)), tz + dist * cp * cos(rad(yaw)))
    }
}

class Snap(val ents: List<Entity>, val heights: FloatArray)

val LOGIC_KINDS = listOf(
    "RigidBody", "Vehicle", "Wheel", "DoorHinge", "DriverSeat", "Mover", "Spinner",
    "PlayerSpawn", "Collectible", "Hazard", "TriggerPad", "GoalZone"
)

class Editor(val store: Store, private val base: Project) {
    val theme: Theme = Themes.get(base.theme)
    val worldSize = base.worldSize
    var name by mutableStateOf(base.name)
    var entities by mutableStateOf(base.entities)
    val terrain: TerrainData = base.terrain.dup()
    @Volatile var terrainVersion = 1
    var revision by mutableIntStateOf(0)
    var selected by mutableStateOf<Set<String>>(emptySet())

    var tool by mutableStateOf(Tool.Select)
    var plane by mutableStateOf(WPlane.Ground)
    var gizmo by mutableStateOf(GizmoMode.Move)
    var gridSnap by mutableStateOf(true)
    var vertexSnap by mutableStateOf(true)
    var gridSize by mutableFloatStateOf(0.5f)
    var mirror by mutableStateOf(false)
    var planeOffset by mutableFloatStateOf(0f)
    var showGrid by mutableStateOf(true)
    var showAxis by mutableStateOf(base.showAxis)
    var xray by mutableStateOf(false)
    var navMode by mutableStateOf(false)
    var multiSelect by mutableStateOf(false)
    var drawColor by mutableIntStateOf(theme.line)
    var drawWidth by mutableFloatStateOf(2.5f)
    var extrudeLen by mutableFloatStateOf(2f)
    var extrudeSym by mutableStateOf(false)
    var revAxis by mutableIntStateOf(1)
    var revSegs by mutableIntStateOf(16)
    var brush by mutableIntStateOf(0)
    var brushSize by mutableFloatStateOf(6f)
    var brushStrength by mutableFloatStateOf(0.5f)
    var boundary by mutableStateOf(base.boundary)
    var voidY by mutableFloatStateOf(base.voidY)
    var jitter by mutableStateOf(base.jitter)
    var stampAsset by mutableStateOf<Asset?>(null)
    var multiStamp by mutableStateOf(false)
    var randRot by mutableStateOf(false)
    var randScale by mutableStateOf(false)
    var assets by mutableStateOf(store.listAssets())
    var drawPts by mutableStateOf<List<V3>>(emptyList())
    var pickParent by mutableStateOf(false)
    var message by mutableStateOf("")
    var undoSize by mutableIntStateOf(0)
    var redoSize by mutableIntStateOf(0)

    @Volatile var cursor: V3? = null
    @Volatile var surfacePlane: Plane? = null
    @Volatile var previewA: V3? = null
    @Volatile var previewB: V3? = null
    var flattenTarget = 0f

    val cam = OrbitCam(dist = max(14f, base.worldSize * 0.25f)).also {
        val c = base.camera
        if (c.size >= 6) {
            it.tx = c[0]; it.ty = c[1]; it.tz = c[2]; it.yaw = c[3]; it.pitch = c[4]; it.dist = c[5]
        }
    }

    private var counter = base.entities.size
    private val undoStack = ArrayDeque<Snap>()
    private val redoStack = ArrayDeque<Snap>()

    // ------------------------------------------------------------ helpers
    private var wKey: List<Entity>? = null
    private var wVal: HashMap<String, FloatArray> = HashMap()

    @Synchronized
    fun worlds(): Map<String, FloatArray> {
        val e = entities
        if (e !== wKey) { wVal = computeWorlds(e); wKey = e }
        return wVal
    }

    fun ent(id: String) = entities.firstOrNull { it.id == id }
    val primary: Entity? get() = selected.firstOrNull()?.let { ent(it) }

    fun descendants(id: String): List<Entity> {
        val out = ArrayList<Entity>()
        val q = ArrayDeque<String>()
        q.add(id)
        var guard = 0
        while (q.isNotEmpty() && guard++ < 100000) {
            val c = q.removeFirst()
            for (e in entities) if (e.parentId == c) { out.add(e); q.add(e.id) }
        }
        return out
    }

    fun rootsOfSelection(): List<Entity> =
        entities.filter { it.id in selected && (it.parentId == null || it.parentId !in selected) }

    fun checkpoint() {
        undoStack.addLast(Snap(entities, terrain.heights.copyOf()))
        while (undoStack.size > 80) undoStack.removeFirst()
        redoStack.clear()
        sync()
    }

    private fun sync() { undoSize = undoStack.size; redoSize = redoStack.size }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(Snap(entities, terrain.heights.copyOf()))
        restore(undoStack.removeLast())
        sync()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(Snap(entities, terrain.heights.copyOf()))
        restore(redoStack.removeLast())
        sync()
    }

    private fun restore(s: Snap) {
        entities = s.ents
        if (!s.heights.contentEquals(terrain.heights)) {
            s.heights.copyInto(terrain.heights)
            terrainVersion++
        }
        selected = selected.filter { id -> s.ents.any { it.id == id } }.toSet()
        revision++
    }

    fun terrainChanged() { terrainVersion++; revision++ }

    fun selectTool(t: Tool) {
        cancelDraw()
        tool = t
        pickParent = false
    }

    fun cancelDraw() {
        drawPts = emptyList()
        cursor = null
        surfacePlane = null
        previewA = null
        previewB = null
    }

    fun finishPolyline(close: Boolean) {
        val p = drawPts
        if (p.size >= 2) addShape(listOf(Stroke(p, close && p.size >= 3)))
        cancelDraw()
    }

    fun removeLastPoint() {
        if (drawPts.isNotEmpty()) drawPts = drawPts.dropLast(1)
        if (drawPts.isEmpty()) surfacePlane = null
    }

    // ------------------------------------------------------------ shape creation
    fun addShape(world: List<Stroke>) {
        var strokes = world
        if (mirror) strokes = strokes + strokes.map { s -> Stroke(s.pts.map { V3(-it.x, it.y, it.z) }, s.closed) }
        val all = strokes.flatMap { it.pts }
        if (all.isEmpty()) return
        var c = V3.ZERO
        for (p in all) c += p
        c = c * (1f / all.size)
        val local = strokes.map { s -> Stroke(s.pts.map { it - c }, s.closed) }
        val e = Entity(
            id = newId(), name = "Shape ${++counter}", pos = c, strokes = local,
            color = drawColor, width = drawWidth
        )
        checkpoint()
        entities = entities + e
        selected = setOf(e.id)
        revision++
    }

    private fun replaceEntity(e: Entity) {
        entities = entities.map { if (it.id == e.id) e else it }
        revision++
    }

    fun extrude() {
        val e = primary ?: run { message = "Select a shape first"; return }
        if (e.strokes.none { it.closed }) {
            message = "Extrude needs a closed loop (Rectangle, Circle or closed Polyline)"
            return
        }
        checkpoint()
        replaceEntity(Geo.extrude(e, extrudeLen, extrudeSym))
        recenter(e.id)
    }

    fun revolve() {
        val e = primary ?: run { message = "Select a profile first"; return }
        if (e.strokes.isEmpty()) { message = "Nothing to revolve"; return }
        checkpoint()
        replaceEntity(Geo.revolve(e, revAxis, revSegs))
        recenter(e.id)
    }

    private fun shiftTris(t: FloatArray, c: V3): FloatArray {
        val o = FloatArray(t.size)
        var i = 0
        while (i + 2 < t.size) { o[i] = t[i] - c.x; o[i + 1] = t[i + 1] - c.y; o[i + 2] = t[i + 2] - c.z; i += 3 }
        return o
    }

    private fun shiftLogic(l: Logic, c: V3): Logic = when (l) {
        is Logic.DoorHinge -> l.copy(pivot = l.pivot - c)
        is Logic.DriverSeat -> l.copy(offset = l.offset - c)
        else -> l
    }

    fun recenter(id: String) {
        val e = ent(id) ?: return
        val b = Geo.bounds(e) ?: return
        val c = (b.first + b.second) * 0.5f
        if (c.len() < 1e-4f) return
        val worlds = computeWorlds(entities)
        val wm = worlds[id] ?: return
        val wd = M4.dir(wm, c)
        val pid = e.parentId
        val pm = if (pid != null) worlds[pid] else null
        val pd = if (pm != null) M4.dir(M4.inv(pm), wd) else wd
        entities = entities.map { x ->
            when {
                x.id == id -> x.copy(
                    pos = x.pos + pd,
                    strokes = x.strokes.map { s -> Stroke(s.pts.map { it - c }, s.closed) },
                    tris = shiftTris(x.tris, c),
                    logic = x.logic.map { shiftLogic(it, c) }
                )
                x.parentId == id -> x.copy(pos = x.pos - c)
                else -> x
            }
        }
        revision++
    }

    fun centerPivot() {
        val e = primary ?: return
        checkpoint()
        recenter(e.id)
    }

    // ------------------------------------------------------------ editing ops
    fun updateSelected(f: (Entity) -> Entity) {
        val s = selected
        entities = entities.map { if (it.id in s) f(it) else it }
        revision++
    }

    fun updateEntity(id: String, f: (Entity) -> Entity) {
        entities = entities.map { if (it.id == id) f(it) else it }
        revision++
    }

    fun applyColor(c: Int) {
        drawColor = c
        if (selected.isNotEmpty()) updateSelected { it.copy(color = c) }
    }

    fun applyWidth(w: Float) {
        drawWidth = w
        if (selected.isNotEmpty()) updateSelected { it.copy(width = w) }
    }

    fun deleteSelected() {
        if (selected.isEmpty()) return
        checkpoint()
        val ids = HashSet<String>()
        for (id in selected) { ids.add(id); for (d in descendants(id)) ids.add(d.id) }
        entities = entities.filter { it.id !in ids }
        selected = emptySet()
        revision++
    }

    private fun remapLogic(l: List<Logic>, map: Map<String, String>): List<Logic> =
        l.map { if (it is Logic.TriggerPad) it.copy(targetId = map[it.targetId] ?: it.targetId) else it }

    fun duplicate() {
        val roots = rootsOfSelection()
        if (roots.isEmpty()) return
        checkpoint()
        val add = ArrayList<Entity>()
        val newSel = LinkedHashSet<String>()
        for (r in roots) {
            val tree = listOf(r) + descendants(r.id)
            val map = tree.associate { it.id to newId() }
            for (t in tree) {
                val isRoot = t.id == r.id
                add.add(
                    t.copy(
                        id = map[t.id]!!,
                        parentId = if (isRoot) t.parentId else t.parentId?.let { map[it] },
                        pos = if (isRoot) t.pos + V3(1.5f, 0f, 0f) else t.pos,
                        name = if (isRoot) t.name + " copy" else t.name,
                        logic = remapLogic(t.logic, map)
                    )
                )
            }
            newSel.add(map[r.id]!!)
        }
        entities = entities + add
        selected = newSel
        revision++
    }

    fun group() {
        val roots = rootsOfSelection()
        if (roots.isEmpty()) return
        val pid = roots[0].parentId
        val same = roots.filter { it.parentId == pid }
        checkpoint()
        var c = V3.ZERO
        for (r in same) c += r.pos
        c = c * (1f / same.size)
        val g = Entity(id = newId(), name = "Group ${++counter}", parentId = pid, pos = c)
        val ids = same.map { it.id }.toSet()
        entities = entities.map { if (it.id in ids) it.copy(parentId = g.id, pos = it.pos - c) else it } + g
        selected = setOf(g.id)
        revision++
    }

    fun ungroup() {
        val g = primary ?: return
        val kids = entities.filter { it.parentId == g.id }
        if (kids.isEmpty()) { message = "Selected object has no children"; return }
        checkpoint()
        val gm = M4.trs(g.pos, g.rot, g.scl)
        val kidIds = kids.map { it.id }.toSet()
        var list = entities.map {
            if (it.id in kidIds) it.copy(
                parentId = g.parentId,
                pos = M4.pt(gm, it.pos),
                rot = it.rot + g.rot,
                scl = it.scl.mul(g.scl)
            ) else it
        }
        if (g.strokes.isEmpty() && g.tris.isEmpty() && g.logic.isEmpty()) list = list.filter { it.id != g.id }
        entities = list
        selected = kidIds
        revision++
    }

    private fun nz(v: Float) = if (abs(v) < 1e-4f) 1f else v

    private fun chainRot(id: String?, map: Map<String, Entity>): V3 {
        var r = V3.ZERO
        var c = id
        var g = 0
        while (c != null && g++ < 64) { val e = map[c] ?: break; r = r + e.rot; c = e.parentId }
        return r
    }

    private fun chainScl(id: String?, map: Map<String, Entity>): V3 {
        var s = V3.ONE
        var c = id
        var g = 0
        while (c != null && g++ < 64) { val e = map[c] ?: break; s = s.mul(e.scl); c = e.parentId }
        return s
    }

    private fun reparentInternal(childId: String, newParent: String?): Boolean {
        if (childId == newParent) return false
        if (newParent != null && descendants(childId).any { it.id == newParent }) {
            message = "Can't attach an object to its own child"
            return false
        }
        val worlds = computeWorlds(entities)
        val map = entities.associateBy { it.id }
        val wc = worlds[childId] ?: return false
        val wp = if (newParent != null) worlds[newParent] else null
        val newPos = if (wp != null) M4.pt(M4.inv(wp), M4.origin(wc)) else M4.origin(wc)
        val rW = chainRot(childId, map)
        val rP = if (newParent != null) chainRot(newParent, map) else V3.ZERO
        val sW = chainScl(childId, map)
        val sP = if (newParent != null) chainScl(newParent, map) else V3.ONE
        val newScl = V3(sW.x / nz(sP.x), sW.y / nz(sP.y), sW.z / nz(sP.z))
        entities = entities.map {
            if (it.id == childId) it.copy(parentId = newParent, pos = newPos, rot = rW - rP, scl = newScl) else it
        }
        revision++
        return true
    }

    fun attachSelectedTo(parentId: String) {
        val roots = rootsOfSelection().filter { it.id != parentId }
        if (roots.isEmpty()) return
        checkpoint()
        for (r in roots) reparentInternal(r.id, parentId)
        pickParent = false
    }

    fun detachSelected() {
        val roots = rootsOfSelection().filter { it.parentId != null }
        if (roots.isEmpty()) return
        checkpoint()
        for (r in roots) reparentInternal(r.id, null)
    }

    fun selectParent() {
        val pid = primary?.parentId ?: return
        selected = setOf(pid)
    }

    fun tapEntity(id: String?) {
        if (pickParent) {
            if (id != null) attachSelectedTo(id)
            pickParent = false
            return
        }
        if (id == null) { if (!multiSelect) selected = emptySet(); return }
        selected = if (multiSelect) (if (id in selected) selected - id else selected + id) else setOf(id)
    }

    fun toggleVisible(id: String) = updateEntity(id) { it.copy(visible = !it.visible) }

    fun rename(newName: String) {
        val id = primary?.id ?: return
        updateEntity(id) { it.copy(name = newName) }
    }

    // ------------------------------------------------------------ logic
    fun addLogic(kind: String) {
        val e = primary ?: run { message = "Select an object first"; return }
        val b = Geo.bounds(e)
        val l: Logic = when (kind) {
            "RigidBody" -> Logic.RigidBody()
            "Vehicle" -> Logic.Vehicle()
            "Wheel" -> Logic.Wheel(
                radius = if (b != null) max(0.1f, max(b.second.y - b.first.y, b.second.z - b.first.z) * 0.5f * e.scl.y) else 0.35f
            )
            "DoorHinge" -> Logic.DoorHinge(
                pivot = if (b != null) V3(b.first.x, (b.first.y + b.second.y) * 0.5f, (b.first.z + b.second.z) * 0.5f) else V3()
            )
            "DriverSeat" -> Logic.DriverSeat()
            "Mover" -> Logic.Mover()
            "Spinner" -> Logic.Spinner()
            "PlayerSpawn" -> Logic.PlayerSpawn()
            "Collectible" -> Logic.Collectible()
            "Hazard" -> Logic.Hazard()
            "TriggerPad" -> Logic.TriggerPad()
            else -> Logic.GoalZone()
        }
        if (e.logic.any { it::class == l::class }) { message = "$kind already attached"; return }
        checkpoint()
        updateEntity(e.id) { it.copy(logic = it.logic + l) }
    }

    fun replaceLogic(id: String, old: Logic, new: Logic) {
        updateEntity(id) { e -> e.copy(logic = e.logic.map { if (it === old) new else it }) }
    }

    fun removeLogic(id: String, old: Logic) {
        checkpoint()
        updateEntity(id) { e -> e.copy(logic = e.logic.filter { it !== old }) }
    }

    fun hingeFromBounds(left: Boolean) {
        val e = primary ?: return
        val d = e.find<Logic.DoorHinge>() ?: return
        val b = Geo.bounds(e) ?: return
        val pv = V3(if (left) b.first.x else b.second.x, (b.first.y + b.second.y) * 0.5f, (b.first.z + b.second.z) * 0.5f)
        replaceLogic(e.id, d, d.copy(pivot = pv))
    }

    fun setHingePivot(local: V3) {
        val e = primary ?: return
        val d = e.find<Logic.DoorHinge>() ?: run { message = "Add DoorHinge logic first"; return }
        checkpoint()
        replaceLogic(e.id, d, d.copy(pivot = local))
    }

    // ------------------------------------------------------------ assets
    fun saveAsset(name: String) {
        val r = primary ?: run { message = "Select an object or group first"; return }
        val tree = listOf(r) + descendants(r.id)
        val ents = tree.mapIndexed { i, t -> if (i == 0) t.copy(parentId = null, pos = V3.ZERO) else t }
        val a = Asset(newId(), name.ifBlank { r.name }, ents)
        store.saveAsset(a)
        assets = store.listAssets()
        message = "Saved asset \"${a.name}\""
    }

    fun deleteAsset(a: Asset) {
        store.deleteAsset(a.id)
        assets = store.listAssets()
        if (stampAsset?.id == a.id) stampAsset = null
    }

    fun placeAsset(a: Asset, x: Float, z: Float) {
        if (a.entities.isEmpty()) return
        val rotY = if (randRot) Random.nextFloat() * 360f else 0f
        val sc = if (randScale) 0.8f + Random.nextFloat() * 0.4f else 1f
        val map = a.entities.associate { it.id to newId() }
        val rootId = a.entities[0].id
        var ents = a.entities.map { t ->
            val isRoot = t.id == rootId
            t.copy(
                id = map[t.id]!!,
                parentId = if (isRoot) null else t.parentId?.let { map[it] },
                logic = remapLogic(t.logic, map),
                rot = if (isRoot) V3(t.rot.x, t.rot.y + rotY, t.rot.z) else t.rot,
                scl = if (isRoot) t.scl * sc else t.scl
            )
        }
        val worlds = computeWorlds(ents)
        var minY = Float.MAX_VALUE
        for (e in ents) {
            val m = worlds[e.id] ?: continue
            for (s in e.strokes) for (p in s.pts) minY = min(minY, M4.pt(m, p).y)
            var i = 0
            val t = e.tris
            while (i + 2 < t.size) { minY = min(minY, M4.pt(m, V3(t[i], t[i + 1], t[i + 2])).y); i += 3 }
        }
        if (minY == Float.MAX_VALUE) minY = 0f
        val th = terrain.heightAt(x, z).let { if (it <= OUT_H + 1f) 0f else it }
        val rootPos = V3(x, th - minY, z)
        ents = ents.map { if (it.id == map[rootId]) it.copy(pos = rootPos) else it }
        checkpoint()
        entities = entities + ents
        selected = setOf(map[rootId]!!)
        revision++
    }

    // ------------------------------------------------------------ terrain
    fun sculpt(x: Float, z: Float, spacingOk: Boolean) {
        if (brush == 4) {
            if (spacingOk) terrain.randomHill(x, z, brushSize, brushStrength)
        } else terrain.brush(brush, x, z, brushSize, brushStrength, flattenTarget)
        terrainChanged()
    }

    // ------------------------------------------------------------ misc
    fun selectionBounds(): Pair<V3, V3>? {
        val worlds = worlds()
        var mn = V3(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        var mx = V3(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        var any = false
        val ids = HashSet<String>()
        for (id in selected) { ids.add(id); for (d in descendants(id)) ids.add(d.id) }
        for (e in entities) {
            if (e.id !in ids) continue
            val m = worlds[e.id] ?: continue
            val b = Geo.bounds(e)
            val corners = if (b == null) listOf(V3.ZERO) else {
                val (a, c) = b
                listOf(
                    V3(a.x, a.y, a.z), V3(c.x, a.y, a.z), V3(a.x, c.y, a.z), V3(c.x, c.y, a.z),
                    V3(a.x, a.y, c.z), V3(c.x, a.y, c.z), V3(a.x, c.y, c.z), V3(c.x, c.y, c.z)
                )
            }
            for (p in corners) {
                val w = M4.pt(m, p)
                any = true
                mn = V3(min(mn.x, w.x), min(mn.y, w.y), min(mn.z, w.z))
                mx = V3(max(mx.x, w.x), max(mx.y, w.y), max(mx.z, w.z))
            }
        }
        return if (any) mn to mx else null
    }

    fun toProject(): Project = base.copy(
        name = name, entities = entities, terrain = terrain.dup(), boundary = boundary,
        voidY = voidY, showAxis = showAxis, jitter = jitter, modified = System.currentTimeMillis(),
        camera = listOf(cam.tx, cam.ty, cam.tz, cam.yaw, cam.pitch, cam.dist)
    )

    fun save() {
        try { store.save(toProject()) } catch (_: Throwable) {}
    }
}
