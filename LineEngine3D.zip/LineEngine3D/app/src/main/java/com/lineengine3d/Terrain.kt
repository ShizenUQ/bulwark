package com.lineengine3d

import kotlinx.serialization.Serializable
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

@Serializable
class TerrainData(
    val n: Int = 48,
    val size: Float = 100f,
    val heights: FloatArray = FloatArray((n + 1) * (n + 1))
) {
    val cell: Float get() = size / n
    val half: Float get() = size / 2f

    fun dup() = TerrainData(n, size, heights.copyOf())
    fun idx(i: Int, j: Int) = j * (n + 1) + i
    fun hv(i: Int, j: Int): Float = heights[idx(i.coerceIn(0, n), j.coerceIn(0, n))]

    fun heightAt(x: Float, z: Float): Float {
        val fx = (x + half) / cell
        val fz = (z + half) / cell
        if (fx < 0f || fz < 0f || fx > n || fz > n) return OUT_H
        val i = min(fx.toInt(), n - 1)
        val j = min(fz.toInt(), n - 1)
        val tx = fx - i
        val tz = fz - j
        val h00 = hv(i, j); val h10 = hv(i + 1, j); val h01 = hv(i, j + 1); val h11 = hv(i + 1, j + 1)
        return (h00 * (1 - tx) + h10 * tx) * (1 - tz) + (h01 * (1 - tx) + h11 * tx) * tz
    }

    fun normalAt(x: Float, z: Float): V3 {
        val e = cell * 0.5f
        val c = heightAt(x, z).let { if (it <= OUT_H + 1f) 0f else it }
        fun g(px: Float, pz: Float): Float {
            val h = heightAt(px, pz)
            return if (h <= OUT_H + 1f) c else h
        }
        return V3(g(x - e, z) - g(x + e, z), 2f * e, g(x, z - e) - g(x, z + e)).norm()
    }

    /** mode: 0 raise, 1 lower, 2 smooth, 3 flatten */
    fun brush(mode: Int, cx: Float, cz: Float, radius: Float, strength: Float, target: Float) {
        val i0 = floor((cx - radius + half) / cell).toInt().coerceIn(0, n)
        val i1 = ceil((cx + radius + half) / cell).toInt().coerceIn(0, n)
        val j0 = floor((cz - radius + half) / cell).toInt().coerceIn(0, n)
        val j1 = ceil((cz + radius + half) / cell).toInt().coerceIn(0, n)
        val copy = if (mode == 2) heights.copyOf() else heights
        for (j in j0..j1) for (i in i0..i1) {
            val x = -half + i * cell
            val z = -half + j * cell
            val dx = x - cx; val dz = z - cz
            val d = sqrt(dx * dx + dz * dz)
            if (d > radius) continue
            var f = 1f - d / radius
            f = f * f * (3f - 2f * f)
            val k = idx(i, j)
            when (mode) {
                0 -> heights[k] += strength * f * 0.04f * 6f
                1 -> heights[k] -= strength * f * 0.04f * 6f
                2 -> {
                    fun c(ii: Int, jj: Int) = copy[idx(ii.coerceIn(0, n), jj.coerceIn(0, n))]
                    val avg = (c(i - 1, j) + c(i + 1, j) + c(i, j - 1) + c(i, j + 1)) * 0.25f
                    heights[k] += (avg - copy[k]) * min(1f, f * strength * 1.2f)
                }
                else -> heights[k] += (target - heights[k]) * min(1f, f * strength)
            }
        }
    }

    fun hill(cx: Float, cz: Float, radius: Float, height: Float) {
        for (j in 0..n) for (i in 0..n) {
            val x = -half + i * cell
            val z = -half + j * cell
            val dx = x - cx; val dz = z - cz
            val d2 = (dx * dx + dz * dz) / (radius * radius)
            if (d2 > 4f) continue
            heights[idx(i, j)] += height * exp(-d2 * 2.5f)
        }
    }

    fun randomHill(cx: Float, cz: Float, radius: Float, strength: Float) {
        hill(cx, cz, radius, (0.5f + Random.nextFloat() * 1.5f) * strength * 2f)
    }

    fun buildLines(f: FBuf, th: Theme) {
        f.clear()
        val gr = cr(th.grid); val gg = cg(th.grid); val gb = cb(th.grid)
        val c = cell; val hf = half
        for (j in 0..n) for (i in 0 until n) {
            f.seg(-hf + i * c, hv(i, j), -hf + j * c, -hf + (i + 1) * c, hv(i + 1, j), -hf + j * c, gr, gg, gb, 0.5f, 1.2f)
        }
        for (i in 0..n) for (j in 0 until n) {
            f.seg(-hf + i * c, hv(i, j), -hf + j * c, -hf + i * c, hv(i, j + 1), -hf + (j + 1) * c, gr, gg, gb, 0.5f, 1.2f)
        }
        var mn = Float.MAX_VALUE
        var mx = -Float.MAX_VALUE
        for (h in heights) { if (h < mn) mn = h; if (h > mx) mx = h }
        if (mx - mn < 0.2f) return
        val step = if (mx - mn > 30f) 2f else 1f
        val cr2 = cr(th.contour); val cg2 = cg(th.contour); val cb2 = cb(th.contour)
        val px = FloatArray(8)
        var lvl = ceil(mn / step) * step
        while (lvl <= mx) {
            for (j in 0 until n) for (i in 0 until n) {
                val h00 = hv(i, j); val h10 = hv(i + 1, j); val h01 = hv(i, j + 1); val h11 = hv(i + 1, j + 1)
                if (min(min(h00, h10), min(h01, h11)) > lvl || max(max(h00, h10), max(h01, h11)) < lvl) continue
                val x0 = -hf + i * c
                val z0 = -hf + j * c
                var k = 0
                if ((h00 - lvl) * (h10 - lvl) < 0f) { val t = (lvl - h00) / (h10 - h00); px[k++] = x0 + t * c; px[k++] = z0 }
                if ((h10 - lvl) * (h11 - lvl) < 0f) { val t = (lvl - h10) / (h11 - h10); px[k++] = x0 + c; px[k++] = z0 + t * c }
                if ((h01 - lvl) * (h11 - lvl) < 0f) { val t = (lvl - h01) / (h11 - h01); px[k++] = x0 + t * c; px[k++] = z0 + c }
                if ((h00 - lvl) * (h01 - lvl) < 0f) { val t = (lvl - h00) / (h01 - h00); px[k++] = x0; px[k++] = z0 + t * c }
                if (k >= 4) f.seg(px[0], lvl + 0.03f, px[1], px[2], lvl + 0.03f, px[3], cr2, cg2, cb2, 0.95f, 1.8f)
                if (k >= 8) f.seg(px[4], lvl + 0.03f, px[5], px[6], lvl + 0.03f, px[7], cr2, cg2, cb2, 0.95f, 1.8f)
            }
            lvl += step
        }
    }

    fun buildTris(f: FBuf) {
        f.clear()
        val c = cell; val hf = half
        for (j in 0 until n) for (i in 0 until n) {
            val x0 = -hf + i * c; val x1 = x0 + c
            val z0 = -hf + j * c; val z1 = z0 + c
            val a = hv(i, j); val b = hv(i + 1, j); val d = hv(i, j + 1); val e = hv(i + 1, j + 1)
            f.tri(x0, a, z0, x1, b, z0, x0, d, z1)
            f.tri(x1, b, z0, x1, e, z1, x0, d, z1)
        }
    }
}
