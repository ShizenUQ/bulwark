package com.lineengine3d

import android.opengl.GLSurfaceView
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.util.Locale

@Composable
fun GLHost(
    renderer: GLRenderer,
    modifier: Modifier = Modifier,
    onTouch: ((MotionEvent, Int, Int) -> Boolean)? = null
) {
    val ctx = LocalContext.current
    val view = remember(renderer) {
        GLSurfaceView(ctx).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            if (onTouch != null) {
                setOnTouchListener { v, ev -> onTouch(ev, v.width, v.height) }
            }
        }
    }
    DisposableEffect(view) {
        val owner = ctx as? ComponentActivity
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_PAUSE) view.onPause()
            else if (ev == Lifecycle.Event.ON_RESUME) view.onResume()
        }
        owner?.lifecycle?.addObserver(obs)
        onDispose {
            owner?.lifecycle?.removeObserver(obs)
            view.onPause()
        }
    }
    AndroidView(factory = { view }, modifier = modifier)
}

@Composable
fun Pill(text: String, on: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val bg = if (on) MaterialTheme.colorScheme.primary else Color(0xFF2B3040)
    val fg = if (on) MaterialTheme.colorScheme.onPrimary else Color(0xFFDDE3F0)
    Box(
        Modifier
            .padding(2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (enabled) bg else Color(0xFF20232D))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) fg else Color(0xFF777C8A), fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun HRow(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        content = content
    )
}

@Composable
fun NumRow(label: String, value: Float, step: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFFB8C0D4), fontSize = 12.sp, modifier = Modifier.padding(end = 4.dp))
        Pill("−") { onChange(value - step) }
        Text(
            String.format(Locale.US, "%.2f", value), color = Color.White, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Pill("+") { onChange(value + step) }
    }
}
