package com.lineengine3d

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

private sealed class Screen {
    object Hub : Screen()
    class Edit(val ed: Editor) : Screen()
    class Play(val project: Project) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent { App() }
    }
}

@Composable
private fun App() {
    val scheme = darkColorScheme(
        primary = Color(0xFF4FC3F7), onPrimary = Color(0xFF00212E),
        background = Color(0xFF0E1118), surface = Color(0xFF151A26)
    )
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = scheme.background) {
            val ctx = LocalContext.current
            val store = remember { Store(ctx.applicationContext) }
            var screen by remember { mutableStateOf<Screen>(Screen.Hub) }
            when (val s = screen) {
                is Screen.Hub -> HubScreen(
                    store,
                    onEdit = { p -> screen = Screen.Edit(Editor(store, p)) },
                    onPlay = { p -> screen = Screen.Play(p) }
                )
                is Screen.Edit -> EditorScreen(s.ed) { screen = Screen.Hub }
                is Screen.Play -> {
                    androidx.activity.compose.BackHandler { screen = Screen.Hub }
                    PlayScreen(s.project) { screen = Screen.Hub }
                }
            }
        }
    }
}
