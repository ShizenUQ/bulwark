package com.lineengine3d

import android.opengl.Matrix
import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.sqrt

fun rad(d: Float) = d * 0.017453292f
fun deg(r: Float) = r * 57.29578f
fun cr(c: Int) = ((c shr 16) and 255) / 255f
fun cg(c: Int) = ((c shr 8) and 255) / 255f
fun cb(c: Int) = (c and 255) / 255f
const val OUT_H = -1e6f

@Serializable
data class V3(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = V3(x * s, y * s, z * s)
    operator fun unaryMinus() = V3(-x, -y, -z)
    fun mul(o: V3) = V3(x * o.x, y * o.y, z * o.z)
    fun dot(o: V3) = x * o.x + y * o.y + z * o.z
    fun cross(o: V3) = V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun len() = sqrt(x * x + y * y + z * z)
    fun norm(): V3 {
        val l = len()
        return if (l < 1e-8f) this else V3(x / l, y / l, z / l)
    }
    fun dist(o: V3) = (this - o).len()
    fun lerp(o: V3, t: Float) = V3(x + (o.x - x) * t, y + (o.y - y) * t, z + (o.z - z) * t)

    companion object {
        val ZERO = V3()
        val ONE = V3(1f, 1f, 1f)
        val UP = V3(0f, 1f, 0f)
    }
}

class Plane(val p: V3, val n: V3)

object M4 {
    fun identity(): FloatArray {
        val m = FloatArray(16)
        Matrix.setIdentityM(m, 0)
        return m
    }

    fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(16)
        Matrix.multiplyMM(o, 0, a, 0, b, 0)
        return o
    }

    fun inv(a: FloatArray): FloatArray {
        val o = FloatArray(16)
        return if (Matrix.invertM(o, 0, a, 0)) o else identity()
    }

    fun trs(p: V3, r: V3, s: V3, extra: FloatArray? = null): FloatArray {
        val m = identity()
        Matrix.translateM(m, 0, p.x, p.y, p.z)
        Matrix.rotateM(m, 0, r.y, 0f, 1f, 0f)
        Matrix.rotateM(m, 0, r.x, 1f, 0f, 0f)
        Matrix.rotateM(m, 0, r.z, 0f, 0f, 1f)
        val m2 = if (extra != null) mul(m, extra) else m
        Matrix.scaleM(m2, 0, s.x, s.y, s.z)
        return m2
    }

    fun trsMat(p: V3, rot: FloatArray, s: V3, extra: FloatArray?): FloatArray {
        val m = identity()
        Matrix.translateM(m, 0, p.x, p.y, p.z)
        var m2 = mul(m, rot)
        if (extra != null) m2 = mul(m2, extra)
        Matrix.scaleM(m2, 0, s.x, s.y, s.z)
        return m2
    }

    fun hinge(pv: V3, angDeg: Float): FloatArray {
        val m = identity()
        Matrix.translateM(m, 0, pv.x, pv.y, pv.z)
        Matrix.rotateM(m, 0, angDeg, 0f, 1f, 0f)
        Matrix.translateM(m, 0, -pv.x, -pv.y, -pv.z)
        return m
    }

    fun axisPivot(pv: V3, a: V3, d: Float): FloatArray {
        val m = identity()
        Matrix.translateM(m, 0, pv.x, pv.y, pv.z)
        Matrix.rotateM(m, 0, d, a.x, a.y, a.z)
        Matrix.translateM(m, 0, -pv.x, -pv.y, -pv.z)
        return m
    }

    fun axisAngle(a: V3, d: Float): FloatArray {
        val m = identity()
        Matrix.rotateM(m, 0, d, a.x, a.y, a.z)
        return m
    }

    fun wheel(steer: Float, spin: Float, axis: Int): FloatArray {
        val m = identity()
        Matrix.rotateM(m, 0, steer, 0f, 1f, 0f)
        when (axis) {
            0 -> Matrix.rotateM(m, 0, spin, 1f, 0f, 0f)
            1 -> Matrix.rotateM(m, 0, spin, 0f, 1f, 0f)
            else -> Matrix.rotateM(m, 0, spin, 0f, 0f, 1f)
        }
        return m
    }

    fun pt(m: FloatArray, v: V3) = V3(
        m[0] * v.x + m[4] * v.y + m[8] * v.z + m[12],
        m[1] * v.x + m[5] * v.y + m[9] * v.z + m[13],
        m[2] * v.x + m[6] * v.y + m[10] * v.z + m[14]
    )

    fun dir(m: FloatArray, v: V3) = V3(
        m[0] * v.x + m[4] * v.y + m[8] * v.z,
        m[1] * v.x + m[5] * v.y + m[9] * v.z,
        m[2] * v.x + m[6] * v.y + m[10] * v.z
    )

    fun origin(m: FloatArray) = V3(m[12], m[13], m[14])
}

class Quat(var w: Float = 1f, var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    fun rotate(v: V3): V3 {
        val tx = 2f * (y * v.z - z * v.y)
        val ty = 2f * (z * v.x - x * v.z)
        val tz = 2f * (x * v.y - y * v.x)
        return V3(
            v.x + w * tx + (y * tz - z * ty),
            v.y + w * ty + (z * tx - x * tz),
            v.z + w * tz + (x * ty - y * tx)
        )
    }

    fun conj() = Quat(w, -x, -y, -z)
    fun copy() = Quat(w, x, y, z)

    fun integrate(o: V3, dt: Float) {
        val h = 0.5f * dt
        val nw = w + h * (-o.x * x - o.y * y - o.z * z)
        val nx = x + h * (o.x * w + o.y * z - o.z * y)
        val ny = y + h * (o.y * w + o.z * x - o.x * z)
        val nz = z + h * (o.z * w + o.x * y - o.y * x)
        val l = sqrt(nw * nw + nx * nx + ny * ny + nz * nz)
        if (l < 1e-9f) return
        w = nw / l; x = nx / l; y = ny / l; z = nz / l
    }

    fun toMatrix(): FloatArray {
        val m = M4.identity()
        val xx = x * x; val yy = y * y; val zz = z * z
        val xy = x * y; val xz = x * z; val yz = y * z
        val wx = w * x; val wy = w * y; val wz = w * z
        m[0] = 1f - 2f * (yy + zz); m[1] = 2f * (xy + wz); m[2] = 2f * (xz - wy)
        m[4] = 2f * (xy - wz); m[5] = 1f - 2f * (xx + zz); m[6] = 2f * (yz + wx)
        m[8] = 2f * (xz + wy); m[9] = 2f * (yz - wx); m[10] = 1f - 2f * (xx + yy)
        return m
    }

    companion object {
        fun fromMatrix(m: FloatArray): Quat {
            val sx = sqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]).coerceAtLeast(1e-6f)
            val sy = sqrt(m[4] * m[4] + m[5] * m[5] + m[6] * m[6]).coerceAtLeast(1e-6f)
            val sz = sqrt(m[8] * m[8] + m[9] * m[9] + m[10] * m[10]).coerceAtLeast(1e-6f)
            val r00 = m[0] / sx; val r10 = m[1] / sx; val r20 = m[2] / sx
            val r01 = m[4] / sy; val r11 = m[5] / sy; val r21 = m[6] / sy
            val r02 = m[8] / sz; val r12 = m[9] / sz; val r22 = m[10] / sz
            val tr = r00 + r11 + r22
            val q = Quat()
            if (tr > 0f) {
                val s = sqrt(tr + 1f) * 2f
                q.w = 0.25f * s; q.x = (r21 - r12) / s; q.y = (r02 - r20) / s; q.z = (r10 - r01) / s
            } else if (r00 > r11 && r00 > r22) {
                val s = sqrt(1f + r00 - r11 - r22) * 2f
                q.w = (r21 - r12) / s; q.x = 0.25f * s; q.y = (r01 + r10) / s; q.z = (r02 + r20) / s
            } else if (r11 > r22) {
                val s = sqrt(1f + r11 - r00 - r22) * 2f
                q.w = (r02 - r20) / s; q.x = (r01 + r10) / s; q.y = 0.25f * s; q.z = (r12 + r21) / s
            } else {
                val s = sqrt(1f + r22 - r00 - r11) * 2f
                q.w = (r10 - r01) / s; q.x = (r02 + r20) / s; q.y = (r12 + r21) / s; q.z = 0.25f * s
            }
            return q
        }
    }
}

object Proj {
    fun toScreen(vp: FloatArray, x: Float, y: Float, z: Float, w: Int, h: Int, out: FloatArray): Boolean {
        val cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        val cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        val cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        if (cw < 0.05f) return false
        out[0] = (cx / cw * 0.5f + 0.5f) * w
        out[1] = (1f - (cy / cw * 0.5f + 0.5f)) * h
        out[2] = cw
        return true
    }

    private fun unp(inv: FloatArray, x: Float, y: Float, z: Float): V3 {
        val o = FloatArray(4)
        Matrix.multiplyMV(o, 0, inv, 0, floatArrayOf(x, y, z, 1f), 0)
        val iw = if (abs(o[3]) < 1e-9f) 1f else 1f / o[3]
        return V3(o[0] * iw, o[1] * iw, o[2] * iw)
    }

    fun ray(invVp: FloatArray, sx: Float, sy: Float, w: Int, h: Int): Pair<V3, V3> {
        val nx = sx / w * 2f - 1f
        val ny = 1f - sy / h * 2f
        val a = unp(invVp, nx, ny, -1f)
        val b = unp(invVp, nx, ny, 1f)
        return a to (b - a).norm()
    }

    fun distSeg(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax; val dy = by - ay
        val l2 = dx * dx + dy * dy
        var t = if (l2 < 1e-6f) 0f else ((px - ax) * dx + (py - ay) * dy) / l2
        t = t.coerceIn(0f, 1f)
        val qx = ax + dx * t - px; val qy = ay + dy * t - py
        return sqrt(qx * qx + qy * qy)
    }

    fun rayTri(o: V3, d: V3, a: V3, b: V3, c: V3): Float {
        val e1 = b - a; val e2 = c - a
        val p = d.cross(e2)
        val det = e1.dot(p)
        if (abs(det) < 1e-9f) return -1f
        val inv = 1f / det
        val tv = o - a
        val u = tv.dot(p) * inv
        if (u < 0f || u > 1f) return -1f
        val q = tv.cross(e1)
        val v = d.dot(q) * inv
        if (v < 0f || u + v > 1f) return -1f
        val t = e2.dot(q) * inv
        return if (t > 1e-4f) t else -1f
    }
}
