package com.lineengine3d

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Ready-made shape library. All shapes are unit sized, centred on X/Z, with their base at y = 0. */
enum class Prim(val label: String, val solid: Boolean, val rigid: Boolean) {
    Box("Box", true, true),
    Pyramid("Pyramid", true, false),
    Cone("Cone", true, false),
    Cylinder("Cylinder", true, true),
    Sphere("Sphere", true, true),
    Dome("Dome", true, false),
    Wedge("Ramp", true, false),
    Roof("Roof", true, false),
    Torus("Ring", true, false),
    Stairs("Stairs", true, false),
    Square("Square", false, false),
    Circle("Circle", false, false),
    Triangle("Triangle", false, false),
    Hexagon("Hexagon", false, false),
    Arch("Arch", false, false)
}

class PrimGeo(val strokes: List<Stroke>, val tris: FloatArray)

object Prims {
    private const val TAU = 6.2831853f

    private fun ring(r: Float, y: Float, n: Int, cx: Float = 0f, cz: Float = 0f): List<V3> =
        (0 until n).map { i ->
            val a = i.toFloat() / n * TAU
            V3(cx + cos(a) * r, y, cz + sin(a) * r)
        }

    private fun loop(p: List<V3>) = Stroke(p, true)
    private fun line(a: V3, b: V3) = Stroke(listOf(a, b), false)

    fun build(k: Prim): PrimGeo = when (k) {
        Prim.Box -> box()
        Prim.Pyramid -> pyramid()
        Prim.Cone -> cone()
        Prim.Cylinder -> cylinder()
        Prim.Sphere -> sphere(false)
        Prim.Dome -> sphere(true)
        Prim.Wedge -> prism(listOf(-0.5f to 0f, 0.5f to 0f, 0.5f to 1f), true)
        Prim.Roof -> prism(listOf(-0.5f to 0f, 0.5f to 0f, 0f to 1f), true)
        Prim.Torus -> torus()
        Prim.Stairs -> stairs()
        Prim.Square -> flat(listOf(V3(-0.5f, 0f, -0.5f), V3(0.5f, 0f, -0.5f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f)), true)
        Prim.Circle -> flat(ring(0.5f, 0f, 40), true)
        Prim.Triangle -> flat(listOf(V3(0f, 0f, -0.5f), V3(0.5f, 0f, 0.4f), V3(-0.5f, 0f, 0.4f)), true)
        Prim.Hexagon -> flat(ring(0.5f, 0f, 6), true)
        Prim.Arch -> arch()
    }

    private fun flat(p: List<V3>, closed: Boolean) = PrimGeo(listOf(Stroke(p, closed)), FloatArray(0))

    private fun arch(): PrimGeo {
        val pts = ArrayList<V3>()
        pts.add(V3(-0.5f, 0f, 0f))
        pts.add(V3(-0.5f, 0.4f, 0f))
        for (i in 1..24) {
            val a = PI.toFloat() - i.toFloat() / 24f * PI.toFloat()
            pts.add(V3(cos(a) * 0.5f, 0.4f + sin(a) * 0.5f, 0f))
        }
        pts.add(V3(0.5f, 0f, 0f))
        return PrimGeo(listOf(Stroke(pts, false)), FloatArray(0))
    }

    private fun box(): PrimGeo {
        val a = listOf(V3(-0.5f, 0f, -0.5f), V3(0.5f, 0f, -0.5f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f))
        val b = a.map { V3(it.x, 1f, it.z) }
        val s = ArrayList<Stroke>()
        s.add(loop(a)); s.add(loop(b))
        for (i in 0 until 4) s.add(line(a[i], b[i]))
        val t = FloatList()
        for (i in 0 until 4) { val j = (i + 1) % 4; t.quad(a[i], a[j], b[j], b[i]) }
        t.quad(a[0], a[1], a[2], a[3])
        t.quad(b[3], b[2], b[1], b[0])
        return PrimGeo(s, t.toArray())
    }

    private fun pyramid(): PrimGeo {
        val a = listOf(V3(-0.5f, 0f, -0.5f), V3(0.5f, 0f, -0.5f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f))
        val apex = V3(0f, 1f, 0f)
        val s = ArrayList<Stroke>()
        s.add(loop(a))
        for (p in a) s.add(line(p, apex))
        val t = FloatList()
        for (i in 0 until 4) t.tri(a[i], a[(i + 1) % 4], apex)
        t.quad(a[0], a[1], a[2], a[3])
        return PrimGeo(s, t.toArray())
    }

    private fun cone(): PrimGeo {
        val n = 24
        val a = ring(0.5f, 0f, n)
        val apex = V3(0f, 1f, 0f)
        val s = ArrayList<Stroke>()
        s.add(loop(a))
        for (i in 0 until n step 3) s.add(line(a[i], apex))
        val t = FloatList()
        val c = V3.ZERO
        for (i in 0 until n) { val j = (i + 1) % n; t.tri(a[i], a[j], apex); t.tri(c, a[j], a[i]) }
        return PrimGeo(s, t.toArray())
    }

    private fun cylinder(): PrimGeo {
        val n = 24
        val a = ring(0.5f, 0f, n)
        val b = ring(0.5f, 1f, n)
        val s = ArrayList<Stroke>()
        s.add(loop(a)); s.add(loop(b))
        for (i in 0 until n step 3) s.add(line(a[i], b[i]))
        val t = FloatList()
        val ca = V3.ZERO
        val cb = V3(0f, 1f, 0f)
        for (i in 0 until n) {
            val j = (i + 1) % n
            t.quad(a[i], a[j], b[j], b[i])
            t.tri(ca, a[j], a[i])
            t.tri(cb, b[i], b[j])
        }
        return PrimGeo(s, t.toArray())
    }

    private fun sphere(dome: Boolean): PrimGeo {
        val seg = 20
        val rows = if (dome) 6 else 12
        val maxLat = if (dome) PI.toFloat() / 2f else PI.toFloat() / 2f
        val minLat = if (dome) 0f else -PI.toFloat() / 2f
        val cy = if (dome) 0f else 0.5f
        val r = 0.5f
        fun pt(lat: Float, lon: Float) = V3(cos(lat) * cos(lon) * r, cy + sin(lat) * r, cos(lat) * sin(lon) * r)
        val t = FloatList()
        for (i in 0 until rows) {
            val l0 = minLat + (maxLat - minLat) * i / rows
            val l1 = minLat + (maxLat - minLat) * (i + 1) / rows
            for (j in 0 until seg) {
                val o0 = j.toFloat() / seg * TAU
                val o1 = (j + 1).toFloat() / seg * TAU
                t.quad(pt(l0, o0), pt(l0, o1), pt(l1, o1), pt(l1, o0))
            }
        }
        val s = ArrayList<Stroke>()
        val lats = if (dome) listOf(0f, 0.5f, 1.05f) else listOf(-0.8f, 0f, 0.8f)
        for (l in lats) s.add(loop((0 until 32).map { pt(l, it.toFloat() / 32f * TAU) }))
        for (m in 0 until 4) {
            val lon = m.toFloat() / 4f * PI.toFloat()
            val pts = ArrayList<V3>()
            val steps = 24
            val from = if (dome) 0f else -PI.toFloat() / 2f
            val to = if (dome) PI.toFloat() else PI.toFloat() * 1.5f
            // half-circle meridian pair (lon and lon + PI) in one stroke
            if (dome) {
                for (i in 0..steps) {
                    val a = i.toFloat() / steps * PI.toFloat()
                    val x = cos(a) * r
                    pts.add(V3(x * cos(lon), sin(a) * r, x * sin(lon)))
                }
            } else {
                for (i in 0..steps * 2) {
                    val a = from + i.toFloat() / (steps * 2) * (to - from)
                    val x = cos(a) * r
                    pts.add(V3(x * cos(lon), cy + sin(a) * r, x * sin(lon)))
                }
            }
            s.add(Stroke(pts, false))
        }
        if (dome) s.add(loop(ring(0.5f, 0f, 32)))
        return PrimGeo(s, t.toArray())
    }

    /** Extrudes a 2D profile. alongZ: profile is (x,y) extruded in z; otherwise profile is (z,y) extruded in x. */
    private fun prism(prof: List<Pair<Float, Float>>, alongZ: Boolean): PrimGeo {
        fun p(i: Int, side: Float): V3 {
            val (u, v) = prof[i]
            return if (alongZ) V3(u, v, side) else V3(side, v, u)
        }
        val n = prof.size
        val a = (0 until n).map { p(it, -0.5f) }
        val b = (0 until n).map { p(it, 0.5f) }
        val s = ArrayList<Stroke>()
        s.add(loop(a)); s.add(loop(b))
        for (i in 0 until n) s.add(line(a[i], b[i]))
        val t = FloatList()
        for (i in 0 until n) { val j = (i + 1) % n; t.quad(a[i], a[j], b[j], b[i]) }
        val nrm = Geo.normal(a)
        val idx = Geo.triangulate(a, nrm)
        var k = 0
        while (k + 2 < idx.size) {
            t.tri(a[idx[k]], a[idx[k + 1]], a[idx[k + 2]])
            t.tri(b[idx[k]], b[idx[k + 1]], b[idx[k + 2]])
            k += 3
        }
        return PrimGeo(s, t.toArray())
    }

    private fun stairs(): PrimGeo {
        val n = 5
        val prof = ArrayList<Pair<Float, Float>>()
        prof.add(-0.5f to 0f)
        for (i in 0 until n) {
            val z0 = -0.5f + i.toFloat() / n
            val z1 = -0.5f + (i + 1).toFloat() / n
            val h = (i + 1).toFloat() / n
            prof.add(z0 to h)
            prof.add(z1 to h)
        }
        prof.add(0.5f to 0f)
        return prism(prof, false)
    }

    /** Ring standing upright with its axle along X (matches the default Wheel spin axis). */
    private fun torus(): PrimGeo {
        val maj = 24
        val mino = 10
        val rr = 0.34f
        val r = 0.16f
        val cy = 0.5f
        fun pt(i: Int, j: Int): V3 {
            val a = i.toFloat() / maj * TAU
            val b = j.toFloat() / mino * TAU
            val rad = rr + r * cos(b)
            return V3(r * sin(b), cy + sin(a) * rad, cos(a) * rad)
        }
        val t = FloatList()
        for (i in 0 until maj) for (j in 0 until mino) {
            t.quad(pt(i, j), pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1))
        }
        val s = ArrayList<Stroke>()
        for (i in 0 until maj step 3) s.add(loop((0 until mino).map { pt(i, it) }))
        for (j in listOf(0, mino / 4, mino / 2, 3 * mino / 4)) s.add(loop((0 until maj).map { pt(it, j) }))
        return PrimGeo(s, t.toArray())
    }
}
