package com.lineengine3d

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.sqrt

@Composable
fun Joystick(modifier: Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    val cb by rememberUpdatedState(onMove)
    val density = LocalDensity.current.density
    val radius = 60f * density
    Box(
        modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { knob = Offset.Zero },
                onDragEnd = { knob = Offset.Zero; cb(0f, 0f) },
                onDragCancel = { knob = Offset.Zero; cb(0f, 0f) },
                onDrag = { change, drag ->
                    change.consume()
                    var k = knob + drag
                    val l = sqrt(k.x * k.x + k.y * k.y)
                    if (l > radius) k = Offset(k.x / l * radius, k.y / l * radius)
                    knob = k
                    cb(k.x / radius, -k.y / radius)
                }
            )
        },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(140.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color(0x33FFFFFF), radius = size.width / 2f)
            drawCircle(Color(0x66FFFFFF), radius = size.width / 2f, style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
            drawCircle(Color(0xAAFFFFFF), radius = size.width * 0.18f, center = c + knob)
        }
    }
}

@Composable
fun HoldButton(label: String, modifier: Modifier = Modifier, onHold: (Boolean) -> Unit) {
    var down by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onHold)
    Box(
        modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(if (down) Color(0xCC4FC3F7) else Color(0x66FFFFFF))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    down = true
                    cb(true)
                    tryAwaitRelease()
                    down = false
                    cb(false)
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun TapButton(label: String, modifier: Modifier = Modifier, size: Int = 76, onTap: () -> Unit) {
    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color(0x66FFFFFF))
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun PlayScreen(project: Project, onExit: () -> Unit) {
    val density = LocalDensity.current.density
    var gen by remember { mutableIntStateOf(0) }
    val sound = remember { Sound() }
    var muted by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { sound.release() } }
    val game = remember(gen) { Game(project, sound) }
    val renderer = remember(game) { GLRenderer(game, density) }
    val hud = game.hud

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        GLHost(renderer, Modifier.fillMaxSize())

        // look area (right side)
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.62f)
                .align(Alignment.CenterEnd)
                .pointerInput(game) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        game.look(drag.x, drag.y)
                    }
                }
        )

        // crosshair
        if (!hud.driving) {
            Canvas(Modifier.align(Alignment.Center).size(24.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                drawLine(Color(0xCCFFFFFF), Offset(c.x - 8f, c.y), Offset(c.x + 8f, c.y), 3f)
                drawLine(Color(0xCCFFFFFF), Offset(c.x, c.y - 8f), Offset(c.x, c.y + 8f), 3f)
            }
        }

        // HUD top
        Row(
            Modifier.fillMaxWidth().padding(8.dp).align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(
                Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0x88000000)).padding(8.dp)
            ) {
                Text("Score ${hud.score}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Time " + String.format(Locale.US, "%.1f", hud.time) + "s",
                    color = Color.White, fontSize = 13.sp
                )
                if (hud.keys.isNotEmpty()) Text("Keys: " + hud.keys.joinToString(", "), color = Color(0xFFFFE082), fontSize = 12.sp)
                if (hud.health < 100) Text("Health ${hud.health}", color = Color(0xFFFF8A80), fontSize = 12.sp)
            }
            Row {
                Pill(if (muted) "Unmute" else "Mute", on = muted) {
                    muted = !muted
                    sound.muted = muted
                }
                Pill("Stop ■") { onExit() }
            }
        }

        if (hud.msg.isNotBlank()) {
            Text(
                hud.msg, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 90.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0x99000000)).padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }

        // interaction prompt
        if (hud.prompt.isNotBlank() && !hud.complete) {
            Box(
                Modifier.align(Alignment.Center).padding(top = 90.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Color(0xCC1565C0))
                    .pointerInput(game) { detectTapGestures(onTap = { game.use() }) }
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text("[ ${hud.prompt} ]", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }

        // controls
        Joystick(
            Modifier.align(Alignment.BottomStart).padding(20.dp).size(160.dp)
        ) { x, y ->
            game.joyX = x
            game.joyY = y
        }
        if (!hud.driving) {
            TapButton("JUMP", Modifier.align(Alignment.BottomEnd).padding(24.dp)) { game.jump() }
        } else {
            Row(
                Modifier.align(Alignment.BottomEnd).padding(20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TapButton("EXIT CAR", size = 64) { game.exitCar() }
                    TapButton(if (hud.third) "1st" else "3rd", size = 64) { game.toggleView() }
                }
                HoldButton("BRAKE") { game.brake = it }
                HoldButton("GAS") { game.gas = it }
            }
        }

        if (hud.complete) {
            Box(Modifier.fillMaxSize().background(Color(0xAA000000)), contentAlignment = Alignment.Center) {
                Card {
                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("LEVEL COMPLETE!", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Time: " + String.format(Locale.US, "%.1f", hud.time) + " s", modifier = Modifier.padding(top = 8.dp))
                        Text("Score: ${hud.score}")
                        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { game.joyX = 0f; game.joyY = 0f; game.gas = false; game.brake = false; gen++ }) { Text("Restart") }
                            Button(onClick = onExit) { Text("Exit") }
                        }
                    }
                }
            }
        }
    }
}
