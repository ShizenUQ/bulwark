package com.lineengine3d

import android.opengl.Matrix
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

class Hud(
    val score: Int = 0,
    val time: Float = 0f,
    val keys: List<String> = emptyList(),
    val prompt: String = "",
    val driving: Boolean = false,
    val complete: Boolean = false,
    val health: Int = 100,
    val msg: String = "",
    val third: Boolean = false
)

class Node(val e: Entity) {
    var parent: Node? = null
    var pos: V3 = e.pos
    val rot: V3 = e.rot
    val scl: V3 = e.scl
    var extra: FloatArray? = null
    var rotMat: FloatArray? = null
    var detached = false
    var selfDyn = false
    var dynamic = false
    var visible = e.visible
    var world: FloatArray = M4.identity()
    var stamp = -1
    val bounds: Pair<V3, V3>? = Geo.bounds(e)
    var door: DoorRt? = null
    var mover: MoverRt? = null
}

class DoorRt(val n: Node, val d: Logic.DoorHinge) {
    var angle = d.minAngle
    var open = false
}

class MoverRt(val n: Node, val m: Logic.Mover) {
    val base: V3 = n.pos
    var t = 0f
    var s = 0f
    var active = m.startActive
}

class SpinRt(val n: Node, val s: Logic.Spinner) { var ang = 0f }
class SwayRt(val n: Node, val s: Logic.Sway) {
    val pivot: V3 = if (s.fromBase) {
        val b = n.bounds
        if (b != null) V3((b.first.x + b.second.x) * 0.5f, b.first.y, (b.first.z + b.second.z) * 0.5f) else V3()
    } else V3()
}
class BodyRt(val n: Node) { var vy = 0f }
class TrigRt(val n: Node, val t: Logic.TriggerPad) { var inside = false }

class WheelRt(val node: Node?, val w: Logic.Wheel, val rel: V3, val base: V3) {
    var spin = 0f
    var steer = 0f
    var travel = 0f
    var spinSign = 1f
}

class VehicleRt(val n: Node, val v: Logic.Vehicle) {
    var p = V3()
    var q = Quat()
    var vel = V3()
    var w = V3()
    val wheels = ArrayList<WheelRt>()
    var seat: Node? = null
    var fwdL = V3(0f, 0f, 1f)
    var halfLen = 1.5f
    var halfWid = 0.8f
    var centerH = 0.6f
    var rad = 0.6f
    var thr = 0f
    var brk = 0f
    var str = 0f
    var driver = false
    var initP = V3()
    var initQ = Quat()
    var vf = 0f
}

class Target(val door: DoorRt?, val veh: VehicleRt?)

class Box(val node: Node, val mn: V3, val mx: V3) {
    var solid = false
    var owner: Any? = null
    var body: BodyRt? = null
    var target: Target? = null
    private val o = FloatArray(3)
    private val r = FloatArray(9)
    private val t = FloatArray(3)
    var cx = 0f; var cy = 0f; var cz = 0f
    var hx = 0.1f; var hy = 0.1f; var hz = 0.1f
    var wx = 0f; var wy = 0f; var wz = 0f
    var rad = 1f

    fun update(m: FloatArray) {
        val sx = sqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]).coerceAtLeast(1e-6f)
        val sy = sqrt(m[4] * m[4] + m[5] * m[5] + m[6] * m[6]).coerceAtLeast(1e-6f)
        val sz = sqrt(m[8] * m[8] + m[9] * m[9] + m[10] * m[10]).coerceAtLeast(1e-6f)
        r[0] = m[0] / sx; r[1] = m[1] / sx; r[2] = m[2] / sx
        r[3] = m[4] / sy; r[4] = m[5] / sy; r[5] = m[6] / sy
        r[6] = m[8] / sz; r[7] = m[9] / sz; r[8] = m[10] / sz
        o[0] = m[12]; o[1] = m[13]; o[2] = m[14]
        cx = (mn.x + mx.x) * 0.5f * sx; cy = (mn.y + mx.y) * 0.5f * sy; cz = (mn.z + mx.z) * 0.5f * sz
        hx = max((mx.x - mn.x) * 0.5f * sx, 0.06f)
        hy = max((mx.y - mn.y) * 0.5f * sy, 0.06f)
        hz = max((mx.z - mn.z) * 0.5f * sz, 0.06f)
        wx = o[0] + r[0] * cx + r[3] * cy + r[6] * cz
        wy = o[1] + r[1] * cx + r[4] * cy + r[7] * cz
        wz = o[2] + r[2] * cx + r[5] * cy + r[8] * cz
        rad = sqrt(hx * hx + hy * hy + hz * hz)
    }

    private fun local(x: Float, y: Float, z: Float, out: FloatArray) {
        val dx = x - o[0]; val dy = y - o[1]; val dz = z - o[2]
        out[0] = dx * r[0] + dy * r[1] + dz * r[2] - cx
        out[1] = dx * r[3] + dy * r[4] + dz * r[5] - cy
        out[2] = dx * r[6] + dy * r[7] + dz * r[8] - cz
    }

    fun rel(p: V3): FloatArray {
        val a = FloatArray(3)
        local(p.x, p.y, p.z, a)
        return a
    }

    fun fromRel(a: FloatArray): V3 {
        val lx = a[0] + cx; val ly = a[1] + cy; val lz = a[2] + cz
        return V3(
            o[0] + r[0] * lx + r[3] * ly + r[6] * lz,
            o[1] + r[1] * lx + r[4] * ly + r[7] * lz,
            o[2] + r[2] * lx + r[5] * ly + r[8] * lz
        )
    }

    fun push(c: V3, rd: Float): V3? {
        val ddx = c.x - wx; val ddy = c.y - wy; val ddz = c.z - wz
        val reach = rad + rd
        if (ddx * ddx + ddy * ddy + ddz * ddz > reach * reach) return null
        local(c.x, c.y, c.z, t)
        val lx = t[0]; val ly = t[1]; val lz = t[2]
        val dx = lx - lx.coerceIn(-hx, hx)
        val dy = ly - ly.coerceIn(-hy, hy)
        val dz = lz - lz.coerceIn(-hz, hz)
        val d2 = dx * dx + dy * dy + dz * dz
        var nx = 0f; var ny = 0f; var nz = 0f; var depth = 0f
        if (d2 > 1e-10f) {
            if (d2 >= rd * rd) return null
            val d = sqrt(d2)
            nx = dx / d; ny = dy / d; nz = dz / d
            depth = rd - d
        } else {
            val px = hx - abs(lx); val py = hy - abs(ly); val pz = hz - abs(lz)
            if (px <= py && px <= pz) { nx = if (lx >= 0f) 1f else -1f; depth = px + rd }
            else if (py <= pz) { ny = if (ly >= 0f) 1f else -1f; depth = py + rd }
            else { nz = if (lz >= 0f) 1f else -1f; depth = pz + rd }
        }
        return V3(
            (r[0] * nx + r[3] * ny + r[6] * nz) * depth,
            (r[1] * nx + r[4] * ny + r[7] * nz) * depth,
            (r[2] * nx + r[5] * ny + r[8] * nz) * depth
        )
    }

    fun ray(org: V3, d: V3): Float {
        val ox = org.x - wx; val oy = org.y - wy; val oz = org.z - wz
        val proj = ox * d.x + oy * d.y + oz * d.z
        val cx2 = ox - d.x * proj; val cy2 = oy - d.y * proj; val cz2 = oz - d.z * proj
        if (cx2 * cx2 + cy2 * cy2 + cz2 * cz2 > rad * rad) return -1f
        local(org.x, org.y, org.z, t)
        val po = floatArrayOf(t[0], t[1], t[2])
        val pd = floatArrayOf(
            d.x * r[0] + d.y * r[1] + d.z * r[2],
            d.x * r[3] + d.y * r[4] + d.z * r[5],
            d.x * r[6] + d.y * r[7] + d.z * r[8]
        )
        val hh = floatArrayOf(hx, hy, hz)
        var t0 = 0f
        var t1 = 1e9f
        for (i in 0 until 3) {
            if (abs(pd[i]) < 1e-8f) {
                if (abs(po[i]) > hh[i]) return -1f
            } else {
                var a = (-hh[i] - po[i]) / pd[i]
                var b = (hh[i] - po[i]) / pd[i]
                if (a > b) { val s = a; a = b; b = s }
                if (a > t0) t0 = a
                if (b < t1) t1 = b
                if (t0 > t1) return -1f
            }
        }
        return t0
    }

    /** Top surface world height at (x,z), NaN when outside the footprint. */
    fun topAt(x: Float, z: Float): Float {
        local(x, o[1], z, t)
        if (abs(t[0]) > hx || abs(t[2]) > hz) return Float.NaN
        return o[1] + (cy + hy) * r[4]
    }

    fun bottomY(): Float = o[1] + (cy - hy) * r[4]
}

class Game(private val project: Project, private val sound: Sound) : RenderHost {
    override val lines = Array(4) { FBuf() }
    override val tris = Array(3) { FBuf() }
    override val theme: Theme = Themes.get(project.theme)
    override val xray: Boolean = false
    override val jitter: Float get() = if (project.jitter) 0.05f else 0f
    override val fogNear: Float get() = project.worldSize * 0.4f
    override val fogFar: Float get() = project.worldSize * 1.6f + 40f

    private val terrain = project.terrain
    private val gravity = project.gravity
    private val nodes = project.entities.map { Node(it) }
    private val byId = HashMap<String, Node>()
    private val doors = ArrayList<DoorRt>()
    private val movers = ArrayList<MoverRt>()
    private val spinners = ArrayList<SpinRt>()
    private val swayers = ArrayList<SwayRt>()
    private var swayT = 0f
    private val bodies = ArrayList<BodyRt>()
    private val vehicles = ArrayList<VehicleRt>()
    private val trigs = ArrayList<TrigRt>()
    private val boxes = ArrayList<Box>()
    private val solidBoxes = ArrayList<Box>()
    private val sensorBoxes = ArrayList<Box>()

    private val STEP = 1f / 120f
    private var acc = 0f
    private var stampN = 0
    private var built = false

    var hud by mutableStateOf(Hud())
        private set
    private var time = 0f
    private var score = 0
    private val keys = LinkedHashSet<String>()
    private var health = 100
    private var complete = false
    private var msg = ""
    private var msgT = 0f
    private var hudT = 0f
    private var hazCd = 0f

    // input
    @Volatile var joyX = 0f
    @Volatile var joyY = 0f
    @Volatile var gas = false
    @Volatile var brake = false
    @Volatile private var jumpReq = false
    @Volatile private var useReq = false
    @Volatile private var exitReq = false
    @Volatile private var viewReq = false
    private var lookX = 0f
    private var lookY = 0f

    @Synchronized fun look(dx: Float, dy: Float) { lookX += dx * 0.15f; lookY += dy * 0.15f }
    @Synchronized private fun takeLook(): Pair<Float, Float> { val r = lookX to lookY; lookX = 0f; lookY = 0f; return r }
    fun jump() { jumpReq = true }
    fun use() { useReq = true }
    fun exitCar() { exitReq = true }
    fun toggleView() { viewReq = true }

    // player
    private var pos = V3()
    private var vel = V3()
    private var yaw = 0f
    private var pitch = 0f
    private var onGround = false
    private var support: Box? = null
    private var spawn = V3()
    private var spawnYaw = 0f
    private var drv: VehicleRt? = null
    private var third = false
    private var target: Target? = null
    private var prompt = ""
    private val ph = floatArrayOf(0.35f, 0.9f, 1.45f)

    init {
        for (n in nodes) byId[n.e.id] = n
        for (n in nodes) {
            val pid = n.e.parentId
            n.parent = if (pid != null) byId[pid] else null
        }
        for (n in nodes) {
            val l = n.e.logic
            n.selfDyn = l.any {
                it is Logic.Mover || it is Logic.Spinner || it is Logic.Sway || it is Logic.DoorHinge || it is Logic.Wheel ||
                    it is Logic.Vehicle || it is Logic.Collectible || (it is Logic.RigidBody && it.dynamic)
            }
            if (l.any { it is Logic.PlayerSpawn }) n.visible = false
        }
        for (n in nodes) {
            var c: Node? = n
            var g = 0
            var d = false
            while (c != null && g++ < 64) { if (c.selfDyn) d = true; c = c.parent }
            n.dynamic = d
        }
        for (n in nodes) {
            val door = n.e.find<Logic.DoorHinge>()
            if (door != null) { val r = DoorRt(n, door); n.door = r; doors.add(r) }
            val mv = n.e.find<Logic.Mover>()
            if (mv != null) { val r = MoverRt(n, mv); n.mover = r; movers.add(r) }
            val sp = n.e.find<Logic.Spinner>()
            if (sp != null) spinners.add(SpinRt(n, sp))
            val sw = n.e.find<Logic.Sway>()
            if (sw != null) swayers.add(SwayRt(n, sw))
            val tp = n.e.find<Logic.TriggerPad>()
            if (tp != null) trigs.add(TrigRt(n, tp))
        }
        setupVehicles()
        setupBoxes()
        val spN = nodes.firstOrNull { it.e.find<Logic.PlayerSpawn>() != null }
        if (spN != null) {
            spawn = M4.origin(world(spN))
            spawnYaw = spN.e.find<Logic.PlayerSpawn>()?.yaw ?: 0f
        } else {
            val h = terrain.heightAt(0f, 0f)
            spawn = V3(0f, if (h <= OUT_H + 1f) 0f else h, 0f)
        }
        respawn(false)
    }

    private fun descendantsOf(n: Node): List<Node> = nodes.filter { x ->
        var c = x.parent
        var g = 0
        var found = false
        while (c != null && g++ < 64) { if (c === n) { found = true; break }; c = c.parent }
        found
    }

    private fun hasVehicleAncestor(n: Node): Boolean {
        var c = n.parent
        var g = 0
        while (c != null && g++ < 64) { if (c.e.find<Logic.Vehicle>() != null) return true; c = c.parent }
        return false
    }

    private fun targetOf(n: Node): Target? {
        var c: Node? = n
        var g = 0
        while (c != null && g++ < 64) {
            val d = c.door
            if (d != null) return Target(d, null)
            val v = vehOf(c)
            if (v != null) return Target(null, v)
            c = c.parent
        }
        return null
    }

    private fun vehOf(n: Node): VehicleRt? {
        for (v in vehicles) if (v.n === n) return v
        return null
    }

    private fun setupVehicles() {
        for (n in nodes) {
            val v = n.e.find<Logic.Vehicle>() ?: continue
            val vr = VehicleRt(n, v)
            val m = world(n)
            vr.p = M4.origin(m)
            vr.q = Quat.fromMatrix(m)
            vr.initP = vr.p
            vr.initQ = vr.q.copy()
            vr.fwdL = when (v.forward) {
                0 -> V3(0f, 0f, 1f)
                1 -> V3(0f, 0f, -1f)
                2 -> V3(1f, 0f, 0f)
                else -> V3(-1f, 0f, 0f)
            }
            val b = n.bounds
            val sc = n.scl
            var minY = -0.5f * sc.y
            if (b != null) {
                val ex = (b.second.x - b.first.x) * 0.5f * sc.x
                val ez = (b.second.z - b.first.z) * 0.5f * sc.z
                vr.halfLen = if (v.forward <= 1) ez else ex
                vr.halfWid = if (v.forward <= 1) ex else ez
                vr.centerH = (b.first.y + b.second.y) * 0.5f * sc.y + 0.1f
                minY = b.first.y * sc.y
            }
            vr.rad = max(0.45f, vr.halfWid * 0.85f)
            if (n.e.find<Logic.DriverSeat>() != null) vr.seat = n
            val up = V3.UP
            for (d in descendantsOf(n)) {
                val w = d.e.find<Logic.Wheel>()
                if (w != null) {
                    val wp = M4.origin(world(d))
                    val rel = vr.q.conj().rotate(wp - vr.p)
                    val wr = WheelRt(d, w, rel, d.pos)
                    val axis = when (w.axis) { 0 -> V3(1f, 0f, 0f); 1 -> V3(0f, 1f, 0f); else -> V3(0f, 0f, 1f) }
                    wr.spinSign = if (axis.dot(up.cross(vr.fwdL)) >= 0f) 1f else -1f
                    vr.wheels.add(wr)
                }
                if (d.e.find<Logic.DriverSeat>() != null && vr.seat == null) vr.seat = d
            }
            if (vr.wheels.isEmpty()) {
                val hl = vr.halfLen * 0.7f
                val hw = vr.halfWid * 0.8f
                for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1)) {
                    val rel = if (v.forward <= 1) V3(sx * hw, minY + 0.3f, sz * hl) else V3(sz * hl, minY + 0.3f, sx * hw)
                    val front = rel.dot(vr.fwdL) > 0f
                    val w = Logic.Wheel(radius = 0.3f, steerable = front, driven = true, axis = 0)
                    val wr = WheelRt(null, w, rel, V3())
                    wr.spinSign = 1f
                    vr.wheels.add(wr)
                }
            }
            n.detached = true
            vehicles.add(vr)
            n.rotMat = vr.q.toMatrix()
        }
    }

    private fun setupBoxes() {
        for (n in nodes) {
            val b = n.bounds ?: continue
            val e = n.e
            val inVeh = hasVehicleAncestor(n)
            val tgt = targetOf(n)
            val rigid = e.find<Logic.RigidBody>()
            val solid = !inVeh && (rigid != null || n.door != null || n.mover != null ||
                e.find<Logic.Spinner>() != null || vehOf(n) != null)
            val sensor = e.find<Logic.Collectible>() != null || e.find<Logic.Hazard>() != null ||
                e.find<Logic.TriggerPad>() != null || e.find<Logic.GoalZone>() != null
            if (!solid && !sensor && tgt == null) continue
            val box = Box(n, b.first, b.second)
            box.solid = solid
            box.target = tgt
            box.update(world(n))
            val vo = vehOf(n)
            if (vo != null) box.owner = vo
            else if (tgt?.veh != null) box.owner = tgt.veh
            if (rigid != null && rigid.dynamic && vo == null && n.parent == null) {
                val br = BodyRt(n)
                bodies.add(br)
                box.body = br
            }
            boxes.add(box)
            if (solid) solidBoxes.add(box)
            if (sensor) sensorBoxes.add(box)
        }
    }

    private fun world(n: Node): FloatArray {
        if (!n.dynamic && n.stamp >= 0) return n.world
        if (n.stamp == stampN) return n.world
        val rm = n.rotMat
        val local = if (rm != null) M4.trsMat(n.pos, rm, n.scl, n.extra) else M4.trs(n.pos, n.rot, n.scl, n.extra)
        val p = n.parent
        n.world = if (p != null && !n.detached) M4.mul(world(p), local) else local
        n.stamp = stampN
        return n.world
    }

    private fun showMsg(s: String) { msg = s; msgT = 2f; hudT = 1f }

    private fun respawn(hurt: Boolean) {
        val d = drv
        if (d != null) { d.driver = false; drv = null; sound.engineOn = false }
        pos = V3(spawn.x, spawn.y + 0.1f, spawn.z)
        vel = V3()
        yaw = spawnYaw
        pitch = 0f
        health = 100
        support = null
        if (hurt) sound.play("hurt")
    }

    private fun lookDir(): V3 {
        val yr = rad(yaw); val pr = rad(pitch)
        return V3(-sin(yr) * cos(pr), sin(pr), -cos(yr) * cos(pr))
    }

    private fun groundAt(x: Float, z: Float, maxY: Float, skip: Any?): Float {
        var g = terrain.heightAt(x, z)
        for (b in solidBoxes) {
            if (skip != null && b.owner === skip) continue
            val t = b.topAt(x, z)
            if (!t.isNaN() && t <= maxY && t > g) g = t
        }
        return g
    }

    // ---------------------------------------------------------------- tick
    override fun tick(dt0: Float) {
        val dt = min(dt0, 0.05f)
        val lk = takeLook()
        yaw -= lk.first
        pitch = (pitch - lk.second).coerceIn(-85f, 85f)
        if (exitReq) { exitReq = false; if (drv != null) leaveCar() }
        if (viewReq) { viewReq = false; third = !third; hudT = 1f }
        if (useReq) {
            useReq = false
            val t = target
            if (t != null && drv == null && !complete) {
                val d = t.door
                if (d != null) toggleDoor(d, false)
                val v = t.veh
                if (v != null) enterCar(v)
            }
        }
        acc += dt
        var n = 0
        while (acc >= STEP && n < 6) { step(STEP); acc -= STEP; n++ }
        if (n == 6) acc = 0f
        updateTarget()
        val d = drv
        if (d != null) {
            sound.engineOn = true
            sound.engineRpm = (0.12f + abs(d.vf) / d.v.maxSpeed * 0.85f + (if (d.thr > 0f) 0.12f else 0f)).coerceIn(0f, 1.2f)
        } else sound.engineOn = false
        hudT += dt
        if (hudT >= 0.1f) {
            hudT = 0f
            hud = Hud(score, time, keys.toList(), prompt, drv != null, complete, health, msg, third)
        }
    }

    private fun updateTarget() {
        target = null
        prompt = ""
        if (drv != null || complete) return
        val eye = V3(pos.x, pos.y + 1.65f, pos.z)
        val d = lookDir()
        var best = 4.2f
        var bb: Box? = null
        for (b in boxes) {
            if (!b.solid && b.target == null) continue
            val t = b.ray(eye, d)
            if (t >= 0f && t < best) { best = t; bb = b }
        }
        val tg = bb?.target ?: return
        target = tg
        val dr = tg.door
        if (dr != null) {
            val key = dr.d.requiredKeyId
            prompt = if (dr.open) "Close" else if (key.isNotBlank() && !keys.contains(key)) "Requires Key" else "Open"
        } else if (tg.veh != null) prompt = "Drive"
    }

    private fun toggleDoor(d: DoorRt, force: Boolean) {
        val key = d.d.requiredKeyId
        if (!force && !d.open && key.isNotBlank() && !keys.contains(key)) {
            showMsg("Requires Key")
            sound.play("locked")
            return
        }
        d.open = !d.open
        sound.play("door")
    }

    private fun enterCar(v: VehicleRt) {
        drv = v
        v.driver = true
        yaw = 0f
        pitch = 8f
        third = false
        sound.startEngine()
        hudT = 1f
    }

    private fun leaveCar() {
        val v = drv ?: return
        v.driver = false
        v.thr = 0f; v.brk = 0f; v.str = 0f
        val up = v.q.rotate(V3.UP)
        val right = v.q.rotate(v.fwdL).cross(up)
        val side = if (v.halfWid > 0f) v.halfWid + 1.2f else 2.2f
        var px = v.p.x - right.x * side
        var pz = v.p.z - right.z * side
        val lim = terrain.half - 0.5f
        px = px.coerceIn(-lim, lim); pz = pz.coerceIn(-lim, lim)
        val gh = groundAt(px, pz, v.p.y + 3f, v)
        pos = V3(px, if (gh <= OUT_H + 1f) v.p.y else gh + 0.05f, pz)
        vel = V3()
        pitch = 0f
        drv = null
        sound.engineOn = false
        hudT = 1f
    }

    // ---------------------------------------------------------------- simulation
    private fun step(dt: Float) {
        if (complete) return
        time += dt
        if (hazCd > 0f) hazCd -= dt
        val sup = support
        var supRel: FloatArray? = null
        if (sup != null && drv == null) supRel = sup.rel(pos)
        stampN++
        animate(dt)
        for (v in vehicles) stepVehicle(v, dt)
        for (b in boxes) if (b.node.dynamic) b.update(world(b.node))
        if (sup != null && supRel != null && drv == null) pos = sup.fromRel(supRel)
        val d = drv
        if (d != null) {
            val ctl = d
            ctl.thr = if (gas) 1f else 0f
            ctl.brk = if (brake) 1f else 0f
            val tgt = joyX.coerceIn(-1f, 1f)
            ctl.str += (tgt - ctl.str) * min(1f, 8f * dt)
            pos = d.p
            vel = V3()
        } else playerStep(dt)
        sensors()
        if (msgT > 0f) { msgT -= dt; if (msgT <= 0f) { msg = ""; hudT = 1f } }
    }

    private fun animate(dt: Float) {
        for (d in doors) {
            val tgt = if (d.open) d.d.maxAngle else d.d.minAngle
            val st = d.d.speed * dt
            d.angle += (tgt - d.angle).coerceIn(-st, st)
            val s = d.n.scl
            val pv = V3(d.d.pivot.x * s.x, d.d.pivot.y * s.y, d.d.pivot.z * s.z)
            d.n.extra = M4.hinge(pv, d.angle)
        }
        for (m in movers) {
            val len = max(m.m.offset.len(), 0.01f)
            val tt = len / max(m.m.speed, 0.01f)
            val s: Float
            if (m.m.pingPong) {
                if (m.active) m.t += dt
                s = 0.5f - 0.5f * cos(3.14159265f * m.t / tt)
            } else {
                val goal = if (m.active) 1f else 0f
                m.s += (goal - m.s).coerceIn(-dt / tt, dt / tt)
                s = m.s * m.s * (3f - 2f * m.s)
            }
            m.n.pos = m.base + m.m.offset * s
        }
        for (s in spinners) {
            s.ang += s.s.degPerSec * dt
            s.n.extra = M4.axisAngle(s.s.axis, s.ang)
        }
        swayT += dt
        for (s in swayers) {
            val ang = s.s.amplitude * sin(6.2831853f * (swayT * s.s.speed + s.s.phase))
            s.n.extra = M4.axisPivot(s.pivot, s.s.axis, ang)
        }
        for (b in bodies) {
            val box = boxes.firstOrNull { it.body === b } ?: continue
            b.vy -= gravity * dt
            var y = b.n.pos.y + b.vy * dt
            val bottomNow = box.bottomY() + (y - b.n.pos.y)
            val g = groundAt(box.wx, box.wz, bottomNow + 0.35f, box)
            if (g > OUT_H + 1f && bottomNow < g) { y += g - bottomNow; b.vy = 0f }
            b.n.pos = V3(b.n.pos.x, y, b.n.pos.z)
            if (y < project.voidY) { b.vy = 0f; b.n.pos = V3(b.n.pos.x, project.voidY + 60f, b.n.pos.z) }
        }
    }

    private fun playerStep(dt: Float) {
        val yr = rad(yaw)
        val fx = -sin(yr); val fz = -cos(yr)
        val rx = cos(yr); val rz = -sin(yr)
        val speed = 4.6f
        val wx = (fx * joyY + rx * joyX) * speed
        val wz = (fz * joyY + rz * joyX) * speed
        val k = if (onGround) min(1f, 14f * dt) else min(1f, 2.5f * dt)
        var vx = vel.x + (wx - vel.x) * k
        var vz = vel.z + (wz - vel.z) * k
        var vy = vel.y - gravity * dt
        if (jumpReq) {
            jumpReq = false
            if (onGround) {
                vy = sqrt(2f * gravity * 1.2f)
                onGround = false
                support = null
                sound.play("jump")
            }
        }
        vel = V3(vx, vy, vz)
        pos = pos + vel * dt

        onGround = false
        var sup: Box? = null
        val gh = terrain.heightAt(pos.x, pos.z)
        if (gh > OUT_H + 1f && pos.y <= gh) {
            pos = V3(pos.x, gh, pos.z)
            if (vel.y < 0f) vel = V3(vel.x, 0f, vel.z)
            onGround = true
        }
        for (iter in 0 until 2) {
            for (h in ph) {
                for (b in solidBoxes) {
                    val c = V3(pos.x, pos.y + h, pos.z)
                    var p = b.push(c, 0.35f) ?: continue
                    val pl = p.len()
                    if (pl > 0.4f) p = p * (0.4f / pl)
                    val nrm = p.norm()
                    val bd = b.body
                    if (bd != null) {
                        bd.n.pos = bd.n.pos + V3(-p.x, 0f, -p.z) * 0.6f
                        pos = pos + V3(p.x * 0.4f, p.y, p.z * 0.4f)
                    } else pos = pos + p
                    val vn = vel.dot(nrm)
                    if (vn < 0f) vel = vel - nrm * vn
                    if (nrm.y > 0.6f) { onGround = true; sup = b }
                    if (nrm.y < -0.6f && vel.y > 0f) vel = V3(vel.x, 0f, vel.z)
                }
            }
        }
        support = sup
        if (project.boundary) {
            val lim = terrain.half - 0.4f
            var nx = pos.x; var nz = pos.z
            if (nx < -lim) { nx = -lim; vel = V3(max(vel.x, 0f), vel.y, vel.z) }
            if (nx > lim) { nx = lim; vel = V3(min(vel.x, 0f), vel.y, vel.z) }
            if (nz < -lim) { nz = -lim; vel = V3(vel.x, vel.y, max(vel.z, 0f)) }
            if (nz > lim) { nz = lim; vel = V3(vel.x, vel.y, min(vel.z, 0f)) }
            pos = V3(nx, pos.y, nz)
        }
        if (pos.y < project.voidY) {
            showMsg("You fell!")
            respawn(true)
        }
    }

    private fun rotAbout(v: V3, axis: V3, ang: Float): V3 {
        val c = cos(ang); val s = sin(ang)
        return v * c + axis.cross(v) * s + axis * (axis.dot(v) * (1f - c))
    }

    private fun stepVehicle(v: VehicleRt, dt: Float) {
        val g = gravity
        val up = v.q.rotate(V3.UP)
        val fwd = v.q.rotate(v.fwdL)
        val nW = v.wheels.size
        val susp = v.v.suspension.coerceAtLeast(0.1f)
        val k = 2f * g / (nW * susp)
        val c = 1.6f * sqrt(k / nW)
        val vf = v.vel.dot(fwd)
        v.vf = vf
        var thr = if (v.driver) v.thr else 0f
        var brk = if (v.driver) v.brk else 1f
        if (v.driver && brk > 0f && thr <= 0f && vf < 0.8f) { thr = -0.6f; brk = 0f }
        val steerAng = rad(v.v.steerDeg) * v.str / (1f + abs(vf) * 0.05f)
        val nDriven = max(1, v.wheels.count { it.w.driven })
        var force = V3(0f, -g, 0f)
        var torque = V3.ZERO
        for (w in v.wheels) {
            val hub = v.p + v.q.rotate(w.rel)
            val org = hub + up * (susp * 0.5f)
            val gy = groundAt(org.x, org.z, org.y + 0.1f, v)
            val sa = if (w.w.steerable) steerAng else 0f
            w.steer = sa
            if (gy <= OUT_H + 1f) { w.travel = susp; continue }
            val dist = (org.y - gy) / max(up.y, 0.35f)
            val s = dist - w.w.radius
            w.travel = s.coerceIn(0f, susp)
            if (s >= susp) continue
            val comp = susp - s
            val cp = org - up * dist
            val rel = cp - v.p
            val vw = v.vel + v.w.cross(rel)
            var fn = k * comp - c * vw.y
            if (fn < 0f) fn = 0f
            fn = min(fn, 8f * g)
            val wf = rotAbout(fwd, up, sa)
            val wr = wf.cross(up)
            val vlong = vw.dot(wf)
            val vlat = vw.dot(wr)
            val maxF = 1.3f * fn
            val fl = (-vlat * 14f / nW).coerceIn(-maxF, maxF)
            var ff = 0f
            if (w.w.driven) ff += thr * v.v.accel / nDriven * max(0f, 1f - abs(vf) / v.v.maxSpeed)
            if (brk > 0f) ff += -sign(vlong) * min(abs(vlong) / dt / nW, 16f * brk / nW)
            ff += -vlong * 0.35f / nW
            ff = ff.coerceIn(-maxF, maxF)
            val tot = V3(0f, fn, 0f) + wr * fl + wf * ff
            force = force + tot
            torque = torque + rel.cross(tot)
        }
        v.vel = v.vel + force * dt
        var wv = v.w + torque * (dt / 0.9f)
        wv = wv * (1f - min(1f, 2.0f * dt))
        v.w = wv
        v.p = v.p + v.vel * dt
        v.q.integrate(v.w, dt)

        // wall collisions
        val upN = v.q.rotate(V3.UP)
        val fwdN = v.q.rotate(v.fwdL)
        for (off in floatArrayOf(-0.55f, 0f, 0.55f)) {
            val cc = v.p + fwdN * (off * v.halfLen) + upN * v.centerH
            for (b in solidBoxes) {
                if (b.owner === v) continue
                val push = b.push(cc, v.rad) ?: continue
                val ph2 = V3(push.x, 0f, push.z)
                if (ph2.len() < 1e-5f) continue
                v.p = v.p + ph2
                val nrm = ph2.norm()
                val vn = v.vel.dot(nrm)
                if (vn < 0f) v.vel = v.vel - nrm * (vn * 1.05f)
            }
        }
        if (project.boundary) {
            val lim = terrain.half - 1f
            var x = v.p.x; var z = v.p.z
            if (x < -lim) { x = -lim; v.vel = V3(max(v.vel.x, 0f), v.vel.y, v.vel.z) }
            if (x > lim) { x = lim; v.vel = V3(min(v.vel.x, 0f), v.vel.y, v.vel.z) }
            if (z < -lim) { z = -lim; v.vel = V3(v.vel.x, v.vel.y, max(v.vel.z, 0f)) }
            if (z > lim) { z = lim; v.vel = V3(v.vel.x, v.vel.y, min(v.vel.z, 0f)) }
            v.p = V3(x, v.p.y, z)
        }
        if (v.p.y < project.voidY) {
            v.p = v.initP + V3(0f, 0.5f, 0f)
            v.q = v.initQ.copy()
            v.vel = V3()
            v.w = V3()
        }

        // write visual transforms
        v.n.pos = v.p
        v.n.rotMat = v.q.toMatrix()
        v.n.detached = true
        val sy = if (abs(v.n.scl.y) < 1e-4f) 1f else v.n.scl.y
        for (w in v.wheels) {
            val wn = w.node ?: continue
            w.spin += w.spinSign * vf / max(w.w.radius, 0.05f) * dt * 57.29578f
            wn.pos = V3(w.base.x, w.base.y + (susp * 0.5f - w.travel) / sy, w.base.z)
            wn.extra = M4.wheel(deg(w.steer), w.spin, w.w.axis)
        }
    }

    private fun overlapsPlayer(b: Box): Boolean {
        val d = drv
        if (d != null) return b.push(d.p + d.q.rotate(V3.UP) * 0.8f, 1.4f) != null
        for (h in ph) if (b.push(V3(pos.x, pos.y + h, pos.z), 0.55f) != null) return true
        return false
    }

    private fun sensors() {
        for (b in sensorBoxes) {
            val n = b.node
            val e = n.e
            val hit = overlapsPlayer(b)
            val col = e.find<Logic.Collectible>()
            if (col != null && n.visible && hit) {
                n.visible = false
                score += col.value
                if (col.keyId.isNotBlank()) { keys.add(col.keyId); showMsg("Got key: ${col.keyId}") }
                sound.play("pickup")
                hudT = 1f
            }
            val hz = e.find<Logic.Hazard>()
            if (hz != null && hit && hazCd <= 0f) {
                hazCd = 0.8f
                health -= hz.damage
                sound.play("hurt")
                hudT = 1f
                if (health <= 0) { showMsg("Ouch!"); respawn(true) }
            }
            if (e.find<Logic.GoalZone>() != null && hit && !complete) {
                complete = true
                sound.play("win")
                hudT = 1f
                hud = Hud(score, time, keys.toList(), "", drv != null, true, health, msg, third)
            }
        }
        for (t in trigs) {
            val box = sensorBoxes.firstOrNull { it.node === t.n } ?: continue
            val hit = overlapsPlayer(box)
            if (hit && !t.inside) {
                val tn = byId[t.t.targetId]
                if (tn != null) {
                    val d = tn.door
                    if (d != null) toggleDoor(d, true)
                    val m = tn.mover
                    if (m != null) m.active = !m.active
                    sound.play("trigger")
                }
            }
            t.inside = hit
        }
    }

    // ---------------------------------------------------------------- render
    override fun camera(aspect: Float, view: FloatArray, proj: FloatArray, eye: FloatArray) {
        var ex = 0f; var ey = 0f; var ez = 0f
        var tx = 0f; var ty = 0f; var tz = 0f
        val d = drv
        if (d == null) {
            val dir = lookDir()
            ex = pos.x; ey = pos.y + 1.65f; ez = pos.z
            tx = ex + dir.x; ty = ey + dir.y; tz = ez + dir.z
        } else {
            val fw = d.q.rotate(d.fwdL)
            val heading = deg(atan2(-fw.x, -fw.z)) + yaw
            val hr = rad(heading)
            val pr = rad(pitch)
            val cp = cos(pr)
            val dir = V3(-sin(hr) * cp, sin(pr), -cos(hr) * cp)
            if (third) {
                ex = d.p.x + sin(hr) * 7.5f
                ez = d.p.z + cos(hr) * 7.5f
                val gh = terrain.heightAt(ex, ez)
                ey = max(d.p.y + 3f, (if (gh <= OUT_H + 1f) d.p.y else gh) + 0.6f)
                tx = d.p.x; ty = d.p.y + 1f; tz = d.p.z
            } else {
                val s = d.seat
                val off = s?.e?.find<Logic.DriverSeat>()?.offset ?: V3(0f, 1.1f, 0f)
                val ep = if (s != null) M4.pt(world(s), off) else d.p + d.q.rotate(off)
                ex = ep.x; ey = ep.y; ez = ep.z
                tx = ex + dir.x; ty = ey + dir.y; tz = ez + dir.z
            }
        }
        eye[0] = ex; eye[1] = ey; eye[2] = ez
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0f, 1f, 0f)
        Matrix.perspectiveM(proj, 0, 70f, aspect, 0.1f, 2500f)
    }

    override fun fill() {
        if (!built) {
            built = true
            terrain.buildLines(lines[0], theme)
            lines[0].version++
            terrain.buildTris(tris[0])
            tris[0].version++
            for (n in nodes) {
                if (n.dynamic || !n.visible) continue
                val m = world(n)
                emitStrokes(m, n.e, lines[1])
                emitTris(m, n.e, tris[1])
            }
            lines[1].version++
            tris[1].version++
        }
        lines[2].clear()
        tris[2].clear()
        for (n in nodes) {
            if (!n.dynamic || !n.visible) continue
            val m = world(n)
            emitStrokes(m, n.e, lines[2])
            emitTris(m, n.e, tris[2])
        }
        lines[2].version++
        tris[2].version++
    }

    override fun onSize(w: Int, h: Int) {}
}
