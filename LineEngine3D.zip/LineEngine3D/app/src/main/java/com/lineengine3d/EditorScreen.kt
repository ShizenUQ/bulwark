package com.lineengine3d

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.max

private val TAB_NAMES = listOf("Draw", "Edit", "Assets", "Terrain", "Inspect", "Tree", "View")

private fun fmt(v: Float) = String.format(Locale.US, "%.2f", v)

private fun hint(ed: Editor): String = when (ed.tool) {
    Tool.Select -> "1 finger: orbit  |  2 fingers: pan / zoom  |  tap: select"
    Tool.Polyline -> "Touch & drag to aim, release to drop a point. Tap first point to close."
    Tool.Freehand -> "Drag to sketch. Ending near the start closes the loop."
    Tool.Rect -> "Drag diagonally to draw a rectangle."
    Tool.Circle -> "Drag from the center outwards."
    Tool.Eraser -> "Drag over line segments to erase them."
    Tool.Terrain -> "Drag on the ground to sculpt."
    Tool.Stamp -> "Touch & drag to aim, release to place."
    Tool.Hinge -> "Tap the vertex on the selected door that should be the hinge."
}

@Composable
fun EditorScreen(ed: Editor, onExit: () -> Unit) {
    val density = LocalDensity.current.density
    val engine = remember { EditorEngine(ed, density) }
    val renderer = remember(engine) { GLRenderer(engine, density) }
    var playing by remember { mutableStateOf(false) }
    var showPanel by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var assetDialog by remember { mutableStateOf(false) }
    val playProject = remember(playing) { if (playing) ed.toProject() else null }

    LaunchedEffect(ed.revision) {
        delay(1500)
        withContext(Dispatchers.IO) { ed.save() }
    }
    DisposableEffect(Unit) { onDispose { ed.save() } }
    BackHandler {
        if (playing) playing = false else { ed.save(); onExit() }
    }
    LaunchedEffect(ed.message) {
        if (ed.message.isNotBlank()) { delay(2600); ed.message = "" }
    }

    if (playing && playProject != null) {
        PlayScreen(playProject) { playing = false }
    } else {
        Box(Modifier.fillMaxSize()) {
            GLHost(renderer, Modifier.fillMaxSize()) { ev, w, h -> engine.touch(ev, w, h) }

            Column(Modifier.align(Alignment.TopStart).fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xCC12151D)).padding(horizontal = 4.dp, vertical = 2.dp)
                        .pointerInput(Unit) { detectTapGestures { } },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Pill("←") { ed.save(); onExit() }
                    Text(
                        ed.name, color = Color.White, fontSize = 13.sp, maxLines = 1,
                        modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
                    )
                    Pill("Undo", enabled = ed.undoSize > 0) { ed.undo() }
                    Pill("Redo", enabled = ed.redoSize > 0) { ed.redo() }
                    Pill("Save") { ed.save(); ed.message = "Saved" }
                    Pill("▶ Play") { playing = true }
                }
                Row(Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        hint(ed), color = Color(0xFFB8C0D4), fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Pill(if (ed.navMode) "✋ Orbit ON" else "✋ Orbit", ed.navMode) { ed.navMode = !ed.navMode }
                }
                if (ed.tool == Tool.Polyline && ed.drawPts.isNotEmpty()) {
                    Row(Modifier.padding(horizontal = 6.dp)) {
                        Pill("✓ Finish") { ed.finishPolyline(false) }
                        Pill("⟲ Close loop") { ed.finishPolyline(true) }
                        Pill("↶ Pt") { ed.removeLastPoint() }
                        Pill("✕") { ed.cancelDraw() }
                    }
                }
                if (ed.pickParent) {
                    Text(
                        "Tap the new parent (viewport or Tree tab)", color = Color(0xFFFFD600), fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
                if (ed.message.isNotBlank()) {
                    Text(
                        ed.message, color = Color.White, fontSize = 13.sp,
                        modifier = Modifier.padding(8.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xCC1565C0)).padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xE60F1218))
                    .pointerInput(Unit) { detectTapGestures { } }
            ) {
                HRow {
                    Pill(if (showPanel) "▾" else "▴") { showPanel = !showPanel }
                    TAB_NAMES.forEachIndexed { i, n -> Pill(n, tab == i) { tab = i; showPanel = true } }
                }
                if (showPanel) {
                    Box(Modifier.fillMaxWidth().height(190.dp)) {
                        when (tab) {
                            0 -> DrawTab(ed)
                            1 -> EditTab(ed) { assetDialog = true }
                            2 -> AssetsTab(ed)
                            3 -> TerrainTab(ed)
                            4 -> InspectTab(ed)
                            5 -> TreeTab(ed)
                            else -> ViewTab(ed, engine)
                        }
                    }
                }
            }
        }
    }

    if (assetDialog) {
        var nm by remember { mutableStateOf(ed.primary?.name ?: "Asset") }
        AlertDialog(
            onDismissRequest = { assetDialog = false },
            title = { Text("Save as Asset") },
            text = {
                OutlinedTextField(value = nm, onValueChange = { nm = it }, singleLine = true, label = { Text("Asset name") })
            },
            confirmButton = { TextButton(onClick = { ed.saveAsset(nm); assetDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { assetDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Lbl(t: String) {
    Text(t, color = Color(0xFFB8C0D4), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp))
}

@Composable
private fun DrawTab(ed: Editor) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(6.dp)) {
        HRow {
            Pill("Select", ed.tool == Tool.Select) { ed.setTool(Tool.Select) }
            Pill("Polyline", ed.tool == Tool.Polyline) { ed.setTool(Tool.Polyline) }
            Pill("Freehand", ed.tool == Tool.Freehand) { ed.setTool(Tool.Freehand) }
            Pill("Rectangle", ed.tool == Tool.Rect) { ed.setTool(Tool.Rect) }
            Pill("Circle", ed.tool == Tool.Circle) { ed.setTool(Tool.Circle) }
            Pill("Eraser", ed.tool == Tool.Eraser) { ed.setTool(Tool.Eraser) }
        }
        HRow {
            Pill("Ground XZ", ed.plane == WPlane.Ground) { ed.plane = WPlane.Ground; ed.surfacePlane = null }
            Pill("Front XY", ed.plane == WPlane.Front) { ed.plane = WPlane.Front; ed.surfacePlane = null }
            Pill("Side YZ", ed.plane == WPlane.Side) { ed.plane = WPlane.Side; ed.surfacePlane = null }
            Pill("Surface Draw", ed.plane == WPlane.Surface) { ed.plane = WPlane.Surface; ed.surfacePlane = null }
            NumRow("Offset", ed.planeOffset, 0.5f) { ed.planeOffset = it }
        }
        HRow {
            Pill("Grid Snap", ed.gridSnap) { ed.gridSnap = !ed.gridSnap }
            Pill("Vertex Snap", ed.vertexSnap) { ed.vertexSnap = !ed.vertexSnap }
            Pill("Mirror X", ed.mirror) { ed.mirror = !ed.mirror }
            val sizes = listOf(0.25f, 0.5f, 1f, 2f)
            Pill("Grid ${fmt(ed.gridSize)}") { ed.gridSize = sizes[(sizes.indexOf(ed.gridSize) + 1) % sizes.size] }
        }
        HRow {
            Lbl("Extrude")
            NumRow("Len", ed.extrudeLen, 0.5f) { ed.extrudeLen = it }
            Pill("Symmetric", ed.extrudeSym) { ed.extrudeSym = !ed.extrudeSym }
            Pill("Extrude ▲") { ed.extrude() }
        }
        HRow {
            Lbl("Revolve")
            Pill("X", ed.revAxis == 0) { ed.revAxis = 0 }
            Pill("Y", ed.revAxis == 1) { ed.revAxis = 1 }
            Pill("Z", ed.revAxis == 2) { ed.revAxis = 2 }
            Pill("Seg −") { ed.revSegs = max(3, ed.revSegs - 2) }
            Lbl("${ed.revSegs}")
            Pill("+") { ed.revSegs = (ed.revSegs + 2).coerceAtMost(48) }
            Pill("Revolve ⟳") { ed.revolve() }
        }
    }
}

private val PALETTE = listOf(
    0xFFFFFFFF, 0xFF00E5FF, 0xFF69F0AE, 0xFFFFEB3B, 0xFFFF9800, 0xFFFF5252,
    0xFFFF40FF, 0xFF7C4DFF, 0xFF448AFF, 0xFF8D6E63, 0xFF9E9E9E, 0xFF2B2B2B
).map { it.toInt() }

@Composable
private fun EditTab(ed: Editor, onSaveAsset: () -> Unit) {
    var hue by remember { mutableFloatStateOf(190f) }
    var sat by remember { mutableFloatStateOf(1f) }
    var value by remember { mutableFloatStateOf(1f) }
    fun applyHsv() = ed.applyColor(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value)))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(6.dp)) {
        HRow {
            Pill("Move", ed.gizmo == GizmoMode.Move) { ed.gizmo = GizmoMode.Move; ed.setTool(Tool.Select) }
            Pill("Rotate", ed.gizmo == GizmoMode.Rotate) { ed.gizmo = GizmoMode.Rotate; ed.setTool(Tool.Select) }
            Pill("Scale", ed.gizmo == GizmoMode.Scale) { ed.gizmo = GizmoMode.Scale; ed.setTool(Tool.Select) }
            Pill("Multi-select", ed.multiSelect) { ed.multiSelect = !ed.multiSelect }
            Pill("Select Parent ↑") { ed.selectParent() }
        }
        HRow {
            Pill("Duplicate") { ed.duplicate() }
            Pill("Delete") { ed.deleteSelected() }
            Pill("Group") { ed.group() }
            Pill("Ungroup") { ed.ungroup() }
            Pill("Center Pivot") { ed.centerPivot() }
            Pill("Save as Asset") { onSaveAsset() }
        }
        HRow {
            Lbl("Color")
            PALETTE.forEach { c ->
                Box(
                    Modifier.padding(2.dp).size(26.dp).clip(RoundedCornerShape(6.dp)).background(Color(c))
                        .border(1.dp, Color(0xFF555B6B), RoundedCornerShape(6.dp))
                        .clickable { ed.applyColor(c) }
                )
            }
        }
        HRow {
            Lbl("H"); Slider(hue, { hue = it; applyHsv() }, Modifier.width(110.dp), valueRange = 0f..360f)
            Lbl("S"); Slider(sat, { sat = it; applyHsv() }, Modifier.width(80.dp), valueRange = 0f..1f)
            Lbl("V"); Slider(value, { value = it; applyHsv() }, Modifier.width(80.dp), valueRange = 0.2f..1f)
        }
        HRow {
            Lbl("Line width ${fmt(ed.drawWidth)}")
            Slider(ed.drawWidth, { ed.applyWidth(it) }, Modifier.width(180.dp), valueRange = 1f..12f)
        }
    }
}

@Composable
private fun AssetsTab(ed: Editor) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(6.dp)) {
        if (ed.assets.isEmpty()) {
            Lbl("No assets yet. Select an object or group, then Edit → Save as Asset.")
        } else {
            HRow {
                Lbl("Assets")
                ed.assets.forEach { a ->
                    Pill(a.name, ed.stampAsset?.id == a.id) { ed.setTool(Tool.Stamp); ed.stampAsset = a }
                }
            }
        }
        HRow {
            Pill("Multi-Stamp", ed.multiStamp) { ed.multiStamp = !ed.multiStamp }
            Pill("Random Rotation", ed.randRot) { ed.randRot = !ed.randRot }
            Pill("Random Scale 0.8–1.2×", ed.randScale) { ed.randScale = !ed.randScale }
        }
        HRow {
            Pill("Duplicate selected") { ed.duplicate() }
            val a = ed.stampAsset
            if (a != null) {
                Pill("Stop placing") { ed.stampAsset = null; ed.setTool(Tool.Select) }
                Pill("Delete asset “${a.name}”") { ed.deleteAsset(a) }
            }
        }
        Lbl("Tap an asset, then touch & drag in the viewport and release to place it on the terrain.")
    }
}

@Composable
private fun TerrainTab(ed: Editor) {
    val names = listOf("Raise", "Lower", "Smooth", "Flatten", "Random Hills")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(6.dp)) {
        HRow {
            names.forEachIndexed { i, n ->
                Pill(n, ed.tool == Tool.Terrain && ed.brush == i) { ed.brush = i; ed.setTool(Tool.Terrain) }
            }
            Pill("Stop sculpting") { ed.setTool(Tool.Select) }
        }
        HRow {
            Lbl("Size ${fmt(ed.brushSize)}")
            Slider(ed.brushSize, { ed.brushSize = it }, Modifier.width(160.dp), valueRange = 1f..30f)
            Lbl("Strength ${fmt(ed.brushStrength)}")
            Slider(ed.brushStrength, { ed.brushStrength = it }, Modifier.width(140.dp), valueRange = 0.1f..1f)
        }
        HRow {
            Pill("World Boundary", ed.boundary) { ed.boundary = !ed.boundary; ed.revision++ }
            NumRow("Void Y", ed.voidY, 5f) { ed.voidY = it; ed.revision++ }
        }
        HRow {
            Pill("Sketch Jitter", ed.jitter) { ed.jitter = !ed.jitter; ed.revision++ }
            Pill("Show Axis", ed.showAxis) { ed.showAxis = !ed.showAxis }
        }
    }
}

@Composable
private fun InspectTab(ed: Editor) {
    val e = ed.primary
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(6.dp)) {
        if (e == null) {
            Lbl("Select an object to edit its name and game logic.")
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = e.name, onValueChange = { ed.rename(it) }, singleLine = true,
                modifier = Modifier.width(210.dp), label = { Text("Name") }
            )
            Pill("Visible", e.visible) { ed.toggleVisible(e.id) }
            var menu by remember { mutableStateOf(false) }
            Box {
                Pill("+ Add Logic") { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    LOGIC_KINDS.forEach { k ->
                        DropdownMenuItem(text = { Text(k) }, onClick = { menu = false; ed.addLogic(k) })
                    }
                }
            }
        }
        e.logic.forEach { l -> LogicCard(ed, e, l) }
    }
}

@Composable
private fun LogicCard(ed: Editor, e: Entity, l: Logic) {
    fun upd(n: Logic) = ed.replaceLogic(e.id, l, n)
    Column(
        Modifier.padding(vertical = 3.dp).fillMaxWidth()
            .background(Color(0xFF1B2030), RoundedCornerShape(8.dp)).padding(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                l.label(), fontWeight = FontWeight.Bold, color = Color(0xFF80D8FF), fontSize = 13.sp,
                modifier = Modifier.weight(1f)
            )
            Pill("Remove") { ed.removeLogic(e.id, l) }
        }
        when (l) {
            is Logic.RigidBody -> HRow {
                Pill("Static", !l.dynamic) { upd(l.copy(dynamic = false)) }
                Pill("Dynamic", l.dynamic) { upd(l.copy(dynamic = true)) }
            }
            is Logic.Vehicle -> {
                HRow {
                    NumRow("Top speed", l.maxSpeed, 2f) { upd(l.copy(maxSpeed = max(2f, it))) }
                    NumRow("Accel", l.accel, 1f) { upd(l.copy(accel = max(1f, it))) }
                }
                HRow {
                    NumRow("Steer°", l.steerDeg, 2f) { upd(l.copy(steerDeg = max(5f, it))) }
                    NumRow("Suspension", l.suspension, 0.05f) { upd(l.copy(suspension = max(0.1f, it))) }
                }
                HRow {
                    Lbl("Forward")
                    listOf("+Z", "-Z", "+X", "-X").forEachIndexed { i, n -> Pill(n, l.forward == i) { upd(l.copy(forward = i)) } }
                }
            }
            is Logic.Wheel -> {
                HRow {
                    NumRow("Radius", l.radius, 0.05f) { upd(l.copy(radius = max(0.05f, it))) }
                    Pill("Steerable", l.steerable) { upd(l.copy(steerable = !l.steerable)) }
                    Pill("Driven", l.driven) { upd(l.copy(driven = !l.driven)) }
                }
                HRow {
                    Lbl("Spin axis")
                    listOf("X", "Y", "Z").forEachIndexed { i, n -> Pill(n, l.axis == i) { upd(l.copy(axis = i)) } }
                }
            }
            is Logic.DoorHinge -> {
                HRow {
                    NumRow("Min°", l.minAngle, 5f) { upd(l.copy(minAngle = it)) }
                    NumRow("Max°", l.maxAngle, 5f) { upd(l.copy(maxAngle = it)) }
                    NumRow("Speed", l.speed, 10f) { upd(l.copy(speed = max(10f, it))) }
                }
                HRow {
                    Pill("Hinge: left edge") { ed.hingeFromBounds(true) }
                    Pill("Hinge: right edge") { ed.hingeFromBounds(false) }
                    Pill("Pick vertex", ed.tool == Tool.Hinge) { ed.setTool(Tool.Hinge) }
                }
                Lbl("Pivot ${fmt(l.pivot.x)}, ${fmt(l.pivot.y)}, ${fmt(l.pivot.z)} (magenta line in viewport)")
                OutlinedTextField(
                    value = l.requiredKeyId, onValueChange = { upd(l.copy(requiredKeyId = it)) },
                    singleLine = true, label = { Text("Required key ID (optional)") }, modifier = Modifier.fillMaxWidth()
                )
            }
            is Logic.DriverSeat -> HRow {
                NumRow("X", l.offset.x, 0.1f) { upd(l.copy(offset = V3(it, l.offset.y, l.offset.z))) }
                NumRow("Y", l.offset.y, 0.1f) { upd(l.copy(offset = V3(l.offset.x, it, l.offset.z))) }
                NumRow("Z", l.offset.z, 0.1f) { upd(l.copy(offset = V3(l.offset.x, l.offset.y, it))) }
            }
            is Logic.Mover -> {
                HRow {
                    NumRow("dX", l.offset.x, 0.5f) { upd(l.copy(offset = V3(it, l.offset.y, l.offset.z))) }
                    NumRow("dY", l.offset.y, 0.5f) { upd(l.copy(offset = V3(l.offset.x, it, l.offset.z))) }
                    NumRow("dZ", l.offset.z, 0.5f) { upd(l.copy(offset = V3(l.offset.x, l.offset.y, it))) }
                }
                HRow {
                    NumRow("Speed", l.speed, 0.25f) { upd(l.copy(speed = max(0.1f, it))) }
                    Pill("Ping-pong", l.pingPong) { upd(l.copy(pingPong = !l.pingPong)) }
                    Pill("Starts active", l.startActive) { upd(l.copy(startActive = !l.startActive)) }
                }
            }
            is Logic.Spinner -> HRow {
                Lbl("Axis")
                Pill("X", l.axis.x == 1f) { upd(l.copy(axis = V3(1f, 0f, 0f))) }
                Pill("Y", l.axis.y == 1f) { upd(l.copy(axis = V3(0f, 1f, 0f))) }
                Pill("Z", l.axis.z == 1f) { upd(l.copy(axis = V3(0f, 0f, 1f))) }
                NumRow("°/s", l.degPerSec, 10f) { upd(l.copy(degPerSec = it)) }
            }
            is Logic.PlayerSpawn -> HRow {
                NumRow("Facing°", l.yaw, 15f) { upd(l.copy(yaw = it)) }
            }
            is Logic.Collectible -> {
                HRow { NumRow("Score", l.value.toFloat(), 5f) { upd(l.copy(value = it.toInt())) } }
                OutlinedTextField(
                    value = l.keyId, onValueChange = { upd(l.copy(keyId = it)) },
                    singleLine = true, label = { Text("Key ID (empty = plain score item)") }, modifier = Modifier.fillMaxWidth()
                )
            }
            is Logic.Hazard -> HRow {
                NumRow("Damage", l.damage.toFloat(), 10f) { upd(l.copy(damage = max(1f, it).toInt())) }
            }
            is Logic.TriggerPad -> {
                Lbl("Toggles target (door or mover):")
                val cands = ed.entities.filter { it.find<Logic.DoorHinge>() != null || it.find<Logic.Mover>() != null }
                if (cands.isEmpty()) Lbl("No doors or movers in the scene yet.")
                HRow {
                    cands.forEach { c -> Pill(c.name, l.targetId == c.id) { upd(l.copy(targetId = c.id)) } }
                }
            }
            is Logic.GoalZone -> Lbl("Touching this object ends the level with LEVEL COMPLETE!")
        }
    }
}

private fun flatten(ents: List<Entity>): List<Pair<Entity, Int>> {
    val ids = ents.map { it.id }.toSet()
    val kids = ents.groupBy { if (it.parentId != null && it.parentId in ids) it.parentId else null }
    val out = ArrayList<Pair<Entity, Int>>()
    fun rec(pid: String?, d: Int) {
        for (e in kids[pid] ?: emptyList()) {
            out.add(e to d)
            if (d < 32) rec(e.id, d + 1)
        }
    }
    rec(null, 0)
    return out
}

@Composable
private fun TreeTab(ed: Editor) {
    val flat = remember(ed.entities) { flatten(ed.entities) }
    Column(Modifier.fillMaxSize().padding(6.dp)) {
        HRow {
            Pill("Attach to…", ed.pickParent) { ed.pickParent = !ed.pickParent }
            Pill("Detach") { ed.detachSelected() }
            Pill("Select Parent ↑") { ed.selectParent() }
            Pill("Multi-select", ed.multiSelect) { ed.multiSelect = !ed.multiSelect }
        }
        if (flat.isEmpty()) Lbl("Scene is empty.")
        LazyColumn(Modifier.fillMaxSize()) {
            items(flat) { (e, depth) ->
                val sel = e.id in ed.selected
                val hasKids = ed.entities.any { it.parentId == e.id }
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (sel) Color(0xFF1E3A5F) else Color.Transparent)
                        .clickable { ed.tapEntity(e.id) }
                        .padding(start = (8 + depth * 16).dp, top = 2.dp, bottom = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val badges = if (e.logic.isEmpty()) "" else "  [" + e.logic.joinToString(",") { it.label() } + "]"
                    Text(
                        (if (hasKids) "▾ " else "• ") + e.name + badges,
                        color = if (e.visible) Color.White else Color(0xFF777C8A), fontSize = 12.sp,
                        modifier = Modifier.weight(1f), maxLines = 1
                    )
                    Pill(if (e.visible) "👁" else "–") { ed.toggleVisible(e.id) }
                }
            }
        }
    }
}

@Composable
private fun ViewTab(ed: Editor, engine: EditorEngine) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(6.dp)) {
        HRow {
            Lbl("Camera")
            Pill("Top") { engine.preset(0) }
            Pill("Front") { engine.preset(1) }
            Pill("Side") { engine.preset(2) }
            Pill("Focus Selected") { engine.focusSelected() }
        }
        HRow {
            Pill("X-Ray", ed.xray) { ed.xray = !ed.xray }
            Pill("Workplane Grid", ed.showGrid) { ed.showGrid = !ed.showGrid }
            Pill("Origin Axis", ed.showAxis) { ed.showAxis = !ed.showAxis; ed.revision++ }
        }
        Lbl("X-Ray shows every line through solid extruded / revolved shapes.")
    }
}
