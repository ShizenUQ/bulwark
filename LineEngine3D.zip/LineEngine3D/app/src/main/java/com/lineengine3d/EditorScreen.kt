package com.lineengine3d

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private enum class ETab(val ic: Ic, val label: String) {
    Draw(Ic.Draw, "Draw"),
    Shapes(Ic.Shapes, "Shapes"),
    Edit(Ic.Edit, "Edit"),
    Assets(Ic.Assets, "Assets"),
    Terrain(Ic.Terrain, "Terrain"),
    Inspect(Ic.Inspect, "Inspect"),
    Objects(Ic.Hierarchy, "Hierarchy"),
    View(Ic.View, "View")
}

private val PANEL = Color(0xE60F1218)
private val PANEL_SOFT = Color(0xCC12151D)

private fun fmt(v: Float) = String.format(Locale.US, "%.2f", v)

private fun hint(ed: Editor): String = when (ed.tool) {
    Tool.Select -> "Drag: orbit · 2 fingers: pan/zoom · tap: select"
    Tool.Polyline -> "Drag to aim, release to drop a point"
    Tool.Freehand -> "Drag to sketch"
    Tool.Rect -> "Drag diagonally"
    Tool.Circle -> "Drag from the center"
    Tool.Eraser -> "Drag over lines to erase"
    Tool.Terrain -> "Drag on the ground to sculpt"
    Tool.Stamp -> "Drag to aim, release to place"
    Tool.Hinge -> "Tap the door vertex to use as hinge"
    Tool.Shape -> "Drag to aim on terrain or a surface, release to place"
}

private fun Modifier.blockTouches(): Modifier = this.pointerInput(Unit) { detectTapGestures { } }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(ed: Editor, onExit: () -> Unit) {
    val density = LocalDensity.current.density
    val engine = remember { EditorEngine(ed, density) }
    val renderer = remember(engine) { GLRenderer(engine, density) }
    var playing by remember { mutableStateOf(false) }
    var tabIdx by remember { mutableIntStateOf(0) } // -1 = collapsed
    var hideUI by remember { mutableStateOf(false) }
    var interacting by remember { mutableStateOf(false) }
    var drawerShown by remember { mutableStateOf(true) }
    var settingsOpen by remember { mutableStateOf(false) }
    var assetDialog by remember { mutableStateOf(false) }
    var groupDialog by remember { mutableStateOf(false) }
    val playProject = remember(playing) { if (playing) ed.toProject() else null }

    LaunchedEffect(ed.revision) {
        delay(1500)
        withContext(Dispatchers.IO) { ed.save() }
    }
    DisposableEffect(Unit) { onDispose { ed.save() } }
    BackHandler {
        if (playing) playing = false else { ed.save(); onExit() }
    }
    LaunchedEffect(ed.message) {
        if (ed.message.isNotBlank()) { delay(2600); ed.message = "" }
    }
    LaunchedEffect(interacting) {
        if (interacting) drawerShown = false else { delay(350); drawerShown = true }
    }

    if (playing && playProject != null) {
        PlayScreen(playProject) { playing = false }
    } else {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val landscape = maxWidth > maxHeight
            GLHost(renderer, Modifier.fillMaxSize()) { ev, w, h ->
                when (ev.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> interacting = true
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> interacting = false
                }
                engine.touch(ev, w, h)
            }

            val tab: ETab? = ETab.values().getOrNull(tabIdx)
            val onTab: (Int) -> Unit = { i ->
                if (tabIdx == i) tabIdx = -1 else { tabIdx = i; settingsOpen = false }
            }

            if (hideUI) {
                Box(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                    IconPill(Ic.Eye, label = "Show UI") { hideUI = false }
                }
            } else {
                // top-left info pills: hint + orbit toggle
                Row(
                    Modifier.align(Alignment.TopStart).padding(start = if (landscape) 62.dp else 6.dp, top = if (landscape) 4.dp else 46.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        hint(ed), color = Color(0xFFD5DCEC), fontSize = 10.sp, maxLines = 1,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x99000000))
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                    IconPill(Ic.Orbit, on = ed.navMode, label = "Orbit") { ed.navMode = !ed.navMode }
                }

                // floating polyline controls
                if (ed.tool == Tool.Polyline && ed.drawPts.isNotEmpty()) {
                    Row(Modifier.align(Alignment.TopCenter).padding(top = if (landscape) 40.dp else 86.dp)) {
                        IconPill(Ic.Check, label = "Finish") { ed.finishPolyline(false) }
                        IconPill(Ic.Rect, label = "Close") { ed.finishPolyline(true) }
                        IconPill(Ic.Undo, label = "Pt") { ed.removeLastPoint() }
                        IconPill(Ic.Close) { ed.cancelDraw() }
                    }
                }
                if (ed.pickParent) {
                    Text(
                        "Tap the new parent in the viewport or Hierarchy", color = Color(0xFFFFD600), fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = if (landscape) 40.dp else 86.dp)
                            .clip(RoundedCornerShape(10.dp)).background(Color(0xAA000000)).padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                if (landscape) {
                    // ---------- left icon rail
                    Column(
                        Modifier.align(Alignment.CenterStart).fillMaxHeight().width(56.dp).background(PANEL)
                            .blockTouches().verticalScroll(rememberScrollState()).padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconBtn(Ic.Back, "Exit") { ed.save(); onExit() }
                        ETab.values().forEachIndexed { i, t -> IconBtn(t.ic, t.label, tabIdx == i) { onTab(i) } }
                        IconBtn(Ic.EyeOff, "Hide UI") { hideUI = true }
                    }
                    // ---------- floating drawer
                    AnimatedVisibility(
                        visible = drawerShown && tab != null,
                        enter = fadeIn(), exit = fadeOut(),
                        modifier = Modifier.align(Alignment.BottomStart).padding(start = 58.dp, bottom = 6.dp, top = 40.dp)
                    ) {
                        if (tab != null) {
                            Column(
                                Modifier.width(226.dp).heightIn(max = 300.dp).clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xD60F1218)).blockTouches()
                                    .verticalScroll(rememberScrollState()).padding(6.dp)
                            ) {
                                Text(tab.label, color = Color(0xFF80D8FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                TabTools(tab, ed, engine, true, { hideUI = true }, { groupDialog = true }, { assetDialog = true })
                                TabSettings(tab, ed)
                            }
                        }
                    }
                    // ---------- top-right actions
                    Row(Modifier.align(Alignment.TopEnd).padding(4.dp)) {
                        IconPill(Ic.Undo, enabled = ed.undoSize > 0) { ed.undo() }
                        IconPill(Ic.Redo, enabled = ed.redoSize > 0) { ed.redo() }
                        IconPill(Ic.Save) { ed.save(); ed.message = "Saved" }
                        IconPill(Ic.Play, label = "Play") { playing = true }
                    }
                } else {
                    // ---------- portrait: slim top bar
                    Row(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth().background(PANEL_SOFT).blockTouches().padding(horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconPill(Ic.Back) { ed.save(); onExit() }
                        Text(ed.name, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                        IconPill(Ic.Undo, enabled = ed.undoSize > 0) { ed.undo() }
                        IconPill(Ic.Redo, enabled = ed.redoSize > 0) { ed.redo() }
                        IconPill(Ic.Save) { ed.save(); ed.message = "Saved" }
                        IconPill(Ic.EyeOff) { hideUI = true }
                        IconPill(Ic.Play) { playing = true }
                    }
                    // ---------- bottom dock (max two compact rows)
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(PANEL).blockTouches()) {
                        AnimatedVisibility(visible = drawerShown && tab != null, enter = fadeIn(), exit = fadeOut()) {
                            if (tab != null) {
                                val full = tab == ETab.Inspect || tab == ETab.Objects
                                Column {
                                    if (settingsOpen && !full && hasSettings(tab)) {
                                        Column(
                                            Modifier.fillMaxWidth().heightIn(max = 170.dp).verticalScroll(rememberScrollState())
                                                .background(Color(0xFF181D2A)).padding(6.dp)
                                        ) { TabSettings(tab, ed) }
                                    }
                                    if (full) {
                                        Column(Modifier.fillMaxWidth().height(190.dp).verticalScroll(rememberScrollState()).padding(6.dp)) {
                                            TabTools(tab, ed, engine, true, { hideUI = true }, { groupDialog = true }, { assetDialog = true })
                                        }
                                    } else {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.weight(1f)) {
                                                TabTools(tab, ed, engine, false, { hideUI = true }, { groupDialog = true }, { assetDialog = true })
                                            }
                                            if (hasSettings(tab)) {
                                                IconBtn(Ic.Inspect, "Options", settingsOpen) { settingsOpen = !settingsOpen }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconBtn(if (tabIdx >= 0) Ic.Down else Ic.Up, if (tabIdx >= 0) "Hide" else "Tools") {
                                tabIdx = if (tabIdx >= 0) -1 else 0
                            }
                            ETab.values().forEachIndexed { i, t ->
                                IconBtn(t.ic, t.label, tabIdx == i, modifier = Modifier.weight(1f)) { onTab(i) }
                            }
                        }
                    }
                }
            }

            if (ed.message.isNotBlank()) {
                Text(
                    ed.message, color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = if (landscape) 4.dp else 84.dp)
                        .clip(RoundedCornerShape(8.dp)).background(Color(0xDD1565C0)).padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }

    if (assetDialog) {
        var nm by remember { mutableStateOf(ed.primary?.name ?: "Asset") }
        AlertDialog(
            onDismissRequest = { assetDialog = false },
            title = { Text("Save as Asset") },
            text = { OutlinedTextField(value = nm, onValueChange = { nm = it }, singleLine = true, label = { Text("Asset name") }) },
            confirmButton = { TextButton(onClick = { ed.saveAsset(nm); assetDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { assetDialog = false }) { Text("Cancel") } }
        )
    }
    if (groupDialog) {
        var nm by remember { mutableStateOf("Oak Tree") }
        AlertDialog(
            onDismissRequest = { groupDialog = false },
            title = { Text("Connect / Group") },
            text = {
                Column {
                    Text("Combine the selected shapes into one named object.", fontSize = 12.sp)
                    OutlinedTextField(
                        value = nm, onValueChange = { nm = it }, singleLine = true,
                        label = { Text("Object name (e.g. Race Car, House)") }, modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = { TextButton(onClick = { ed.group(nm); groupDialog = false }) { Text("Connect") } },
            dismissButton = { TextButton(onClick = { groupDialog = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- tab contents

private fun hasSettings(t: ETab) = when (t) {
    ETab.Draw, ETab.Shapes, ETab.Edit, ETab.Assets, ETab.Terrain -> true
    else -> false
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Bar(wrap: Boolean, content: @Composable () -> Unit) {
    if (wrap) {
        FlowRow(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) { content() }
    } else {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) { content() }
    }
}

@Composable
private fun TabTools(
    tab: ETab, ed: Editor, engine: EditorEngine, wrap: Boolean,
    hideUi: () -> Unit, onGroup: () -> Unit, onAsset: () -> Unit
) {
    when (tab) {
        ETab.Draw -> Bar(wrap) {
            IconBtn(Ic.Select, "Select", ed.tool == Tool.Select) { ed.selectTool(Tool.Select) }
            IconBtn(Ic.Line, "Line", ed.tool == Tool.Polyline) { ed.selectTool(Tool.Polyline) }
            IconBtn(Ic.Freehand, "Freehand", ed.tool == Tool.Freehand) { ed.selectTool(Tool.Freehand) }
            IconBtn(Ic.Rect, "Rectangle", ed.tool == Tool.Rect) { ed.selectTool(Tool.Rect) }
            IconBtn(Ic.Circle, "Circle", ed.tool == Tool.Circle) { ed.selectTool(Tool.Circle) }
            IconBtn(Ic.Eraser, "Eraser", ed.tool == Tool.Eraser) { ed.selectTool(Tool.Eraser) }
            IconBtn(Ic.Plane, "Ground XZ", ed.plane == WPlane.Ground) { ed.plane = WPlane.Ground; ed.surfacePlane = null }
            IconBtn(Ic.Plane, "Front XY", ed.plane == WPlane.Front) { ed.plane = WPlane.Front; ed.surfacePlane = null }
            IconBtn(Ic.Plane, "Side YZ", ed.plane == WPlane.Side) { ed.plane = WPlane.Side; ed.surfacePlane = null }
            IconBtn(Ic.Plane, "Surface", ed.plane == WPlane.Surface) { ed.plane = WPlane.Surface; ed.surfacePlane = null }
            IconBtn(Ic.Grid, "Grid snap", ed.gridSnap) { ed.gridSnap = !ed.gridSnap }
            IconBtn(Ic.Vertex, "Vertex snap", ed.vertexSnap) { ed.vertexSnap = !ed.vertexSnap }
            IconBtn(Ic.Mirror, "Mirror X", ed.mirror) { ed.mirror = !ed.mirror }
            IconBtn(Ic.Extrude, "Extrude") { ed.extrude() }
            IconBtn(Ic.Revolve, "Revolve") { ed.revolve() }
        }
        ETab.Shapes -> Bar(wrap) {
            for (k in Prim.values()) {
                IconBtn(k.icon(), k.label, ed.tool == Tool.Shape && ed.shapeKind == k) {
                    ed.shapeKind = k; ed.selectTool(Tool.Shape)
                }
            }
        }
        ETab.Edit -> Bar(wrap) {
            IconBtn(Ic.Select, "Select", ed.tool == Tool.Select && !ed.multiSelect) { ed.multiSelect = false; ed.selectTool(Tool.Select) }
            IconBtn(Ic.MultiSelect, "Multi", ed.multiSelect) { ed.multiSelect = !ed.multiSelect }
            IconBtn(Ic.Move, "Move", ed.gizmo == GizmoMode.Move) { ed.gizmo = GizmoMode.Move; ed.selectTool(Tool.Select) }
            IconBtn(Ic.Rotate, "Rotate", ed.gizmo == GizmoMode.Rotate) { ed.gizmo = GizmoMode.Rotate; ed.selectTool(Tool.Select) }
            IconBtn(Ic.Scale, "Scale", ed.gizmo == GizmoMode.Scale) { ed.gizmo = GizmoMode.Scale; ed.selectTool(Tool.Select) }
            IconBtn(Ic.Stretch, "Stretch", ed.gizmo == GizmoMode.Stretch) { ed.gizmo = GizmoMode.Stretch; ed.selectTool(Tool.Select) }
            IconBtn(Ic.Group, "Connect") { onGroup() }
            IconBtn(Ic.Ungroup, "Ungroup") { ed.ungroup() }
            IconBtn(Ic.Duplicate, "Duplicate") { ed.duplicate() }
            IconBtn(Ic.Array, "Array") { ed.arrayCopy(ed.arrayCount, ed.arrayOff) }
            IconBtn(Ic.Mirror, "Mirror X") { ed.mirrorCopy(0) }
            IconBtn(Ic.Mirror, "Mirror Z") { ed.mirrorCopy(2) }
            IconBtn(Ic.Drop, "Drop") { ed.snapToSurface() }
            IconBtn(Ic.Pivot, "Pivot") { ed.centerPivot() }
            IconBtn(Ic.Assets, "To asset") { onAsset() }
            IconBtn(Ic.Up, "Parent") { ed.selectParent() }
            IconBtn(Ic.Trash, "Delete") { ed.deleteSelected() }
        }
        ETab.Assets -> Bar(wrap) {
            if (ed.assets.isEmpty()) Lbl("No assets yet. Select an object, Edit › To asset.")
            for (a in ed.assets) {
                IconBtn(Ic.Assets, a.name.take(9), ed.stampAsset?.id == a.id) { ed.stampAsset = a; ed.selectTool(Tool.Stamp); ed.stampAsset = a }
            }
            IconBtn(Ic.Duplicate, "Duplicate") { ed.duplicate() }
            if (ed.stampAsset != null) {
                IconBtn(Ic.Close, "Stop") { ed.stampAsset = null; ed.selectTool(Tool.Select) }
                IconBtn(Ic.Trash, "Del asset") { ed.stampAsset?.let { ed.deleteAsset(it) } }
            }
        }
        ETab.Terrain -> Bar(wrap) {
            val icons = listOf(Ic.Up, Ic.Down, Ic.Freehand, Ic.Minus, Ic.Terrain)
            val names = listOf("Raise", "Lower", "Smooth", "Flatten", "Hills")
            names.forEachIndexed { i, n ->
                IconBtn(icons[i], n, ed.tool == Tool.Terrain && ed.brush == i) { ed.brush = i; ed.selectTool(Tool.Terrain) }
            }
            IconBtn(Ic.Select, "Done") { ed.selectTool(Tool.Select) }
        }
        ETab.Inspect -> InspectBody(ed)
        ETab.Objects -> HierarchyBody(ed, onGroup)
        ETab.View -> Bar(wrap) {
            IconBtn(Ic.Down, "Top") { engine.preset(0) }
            IconBtn(Ic.Orbit, "Front") { engine.preset(1) }
            IconBtn(Ic.Right, "Side") { engine.preset(2) }
            IconBtn(Ic.Vertex, "Focus") { engine.focusSelected() }
            IconBtn(Ic.Xray, "X-Ray", ed.xray) { ed.xray = !ed.xray }
            IconBtn(Ic.Grid, "Workplane", ed.showGrid) { ed.showGrid = !ed.showGrid }
            IconBtn(Ic.Axis, "Origin", ed.showAxis) { ed.showAxis = !ed.showAxis; ed.revision++ }
            IconBtn(Ic.EyeOff, "Hide UI") { hideUi() }
        }
    }
}

@Composable
private fun Lbl(t: String) {
    Text(t, color = Color(0xFFB8C0D4), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
}

private val PALETTE = listOf(
    0xFFFFFFFF, 0xFF00E5FF, 0xFF69F0AE, 0xFFFFEB3B, 0xFFFF9800, 0xFFFF5252,
    0xFFFF40FF, 0xFF7C4DFF, 0xFF448AFF, 0xFF8D6E63, 0xFF9E9E9E, 0xFF2B2B2B
).map { it.toInt() }

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TabSettings(tab: ETab, ed: Editor) {
    when (tab) {
        ETab.Draw -> Column {
            NumRow("Offset", ed.planeOffset, 0.5f) { ed.planeOffset = it }
            NumRow("Grid", ed.gridSize, 0.25f) { ed.gridSize = max(0.05f, it) }
            Lbl("Extrude")
            NumRow("Length", ed.extrudeLen, 0.5f) { ed.extrudeLen = max(0.1f, it) }
            Pill("Symmetric", ed.extrudeSym) { ed.extrudeSym = !ed.extrudeSym }
            Lbl("Revolve axis / segments")
            Row {
                Pill("X", ed.revAxis == 0) { ed.revAxis = 0 }
                Pill("Y", ed.revAxis == 1) { ed.revAxis = 1 }
                Pill("Z", ed.revAxis == 2) { ed.revAxis = 2 }
            }
            NumRow("Segs", ed.revSegs.toFloat(), 2f) { ed.revSegs = it.toInt().coerceIn(3, 48) }
        }
        ETab.Shapes -> Column {
            Pill("Keep placing", ed.multiStamp) { ed.multiStamp = !ed.multiStamp }
            Lbl("Place on terrain or on any object's surface. Use Edit › Stretch for X/Y/Z side-stretch.")
        }
        ETab.Edit -> Column {
            Pill("Stick to surface after move", ed.autoDrop) { ed.autoDrop = !ed.autoDrop }
            Lbl("Array / copy")
            NumRow("Count", ed.arrayCount.toFloat(), 1f) { ed.arrayCount = it.toInt().coerceIn(1, 50) }
            NumRow("Off X", ed.arrayOff.x, 0.5f) { ed.arrayOff = V3(it, ed.arrayOff.y, ed.arrayOff.z) }
            NumRow("Off Y", ed.arrayOff.y, 0.5f) { ed.arrayOff = V3(ed.arrayOff.x, it, ed.arrayOff.z) }
            NumRow("Off Z", ed.arrayOff.z, 0.5f) { ed.arrayOff = V3(ed.arrayOff.x, ed.arrayOff.y, it) }
            Lbl("Color")
            ColorPicker(ed)
            Lbl("Line width ${fmt(ed.drawWidth)}")
            Slider(ed.drawWidth, { ed.applyWidth(it) }, Modifier.fillMaxWidth(), valueRange = 1f..12f)
        }
        ETab.Assets -> Column {
            Pill("Multi-Stamp", ed.multiStamp) { ed.multiStamp = !ed.multiStamp }
            Pill("Random rotation", ed.randRot) { ed.randRot = !ed.randRot }
            Pill("Random scale 0.8–1.2", ed.randScale) { ed.randScale = !ed.randScale }
            Lbl("Pick an asset, then drag in the viewport and release to place it.")
        }
        ETab.Terrain -> Column {
            Lbl("Size ${fmt(ed.brushSize)}")
            Slider(ed.brushSize, { ed.brushSize = it }, Modifier.fillMaxWidth(), valueRange = 1f..30f)
            Lbl("Strength ${fmt(ed.brushStrength)}")
            Slider(ed.brushStrength, { ed.brushStrength = it }, Modifier.fillMaxWidth(), valueRange = 0.1f..1f)
            Pill("World boundary", ed.boundary) { ed.boundary = !ed.boundary; ed.revision++ }
            NumRow("Void Y", ed.voidY, 5f) { ed.voidY = it; ed.revision++ }
            Pill("Sketch jitter", ed.jitter) { ed.jitter = !ed.jitter; ed.revision++ }
        }
        else -> {}
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorPicker(ed: Editor) {
    var hue by remember { mutableFloatStateOf(190f) }
    var sat by remember { mutableFloatStateOf(1f) }
    var value by remember { mutableFloatStateOf(1f) }
    fun applyHsv() = ed.applyColor(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value)))
    FlowRow {
        PALETTE.forEach { c ->
            Box(
                Modifier.padding(2.dp).size(24.dp).clip(RoundedCornerShape(6.dp)).background(Color(c))
                    .border(1.dp, Color(0xFF555B6B), RoundedCornerShape(6.dp))
                    .clickable { ed.applyColor(c) }
            )
        }
    }
    Slider(hue, { hue = it; applyHsv() }, Modifier.fillMaxWidth(), valueRange = 0f..360f)
    Slider(sat, { sat = it; applyHsv() }, Modifier.fillMaxWidth(), valueRange = 0f..1f)
    Slider(value, { value = it; applyHsv() }, Modifier.fillMaxWidth(), valueRange = 0.2f..1f)
}

// ---------------------------------------------------------------- inspector

@Composable
private fun InspectBody(ed: Editor) {
    val e = ed.primary
    Column(Modifier.fillMaxWidth()) {
        if (e == null) {
            Lbl("Select an object (or a part inside a group) to edit its name, size and logic.")
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = e.name, onValueChange = { ed.rename(it) }, singleLine = true,
                modifier = Modifier.weight(1f), label = { Text("Name") }
            )
            IconPill(if (e.visible) Ic.Eye else Ic.EyeOff) { ed.toggleVisible(e.id) }
        }
        var menu by remember { mutableStateOf(false) }
        Box {
            IconPill(Ic.Plus, label = "Add Logic") { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                LOGIC_KINDS.forEach { k ->
                    DropdownMenuItem(text = { Text(k) }, onClick = { menu = false; ed.addLogic(k) })
                }
            }
        }
        e.logic.forEach { l -> LogicCard(ed, e, l) }
        TransformBlock(ed, e)
    }
}

@Composable
private fun TransformBlock(ed: Editor, e: Entity) {
    fun pos(v: V3) = ed.updateEntity(e.id) { it.copy(pos = v) }
    fun rot(v: V3) = ed.updateEntity(e.id) { it.copy(rot = v) }
    fun scl(v: V3) = ed.updateEntity(e.id) { it.copy(scl = v) }
    fun sc(v: Float) = if (abs(v) < 0.05f) 0.05f else v
    Column(Modifier.padding(top = 6.dp).fillMaxWidth().background(Color(0xFF1B2030), RoundedCornerShape(8.dp)).padding(6.dp)) {
        Text("Transform (stretch any axis)", color = Color(0xFF80D8FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        HRow {
            NumRow("X", e.pos.x, 0.25f) { pos(V3(it, e.pos.y, e.pos.z)) }
            NumRow("Y", e.pos.y, 0.25f) { pos(V3(e.pos.x, it, e.pos.z)) }
            NumRow("Z", e.pos.z, 0.25f) { pos(V3(e.pos.x, e.pos.y, it)) }
        }
        HRow {
            NumRow("Rot X", e.rot.x, 5f) { rot(V3(it, e.rot.y, e.rot.z)) }
            NumRow("Y", e.rot.y, 5f) { rot(V3(e.rot.x, it, e.rot.z)) }
            NumRow("Z", e.rot.z, 5f) { rot(V3(e.rot.x, e.rot.y, it)) }
        }
        HRow {
            NumRow("Size X", e.scl.x, 0.1f) { scl(V3(sc(it), e.scl.y, e.scl.z)) }
            NumRow("Y", e.scl.y, 0.1f) { scl(V3(e.scl.x, sc(it), e.scl.z)) }
            NumRow("Z", e.scl.z, 0.1f) { scl(V3(e.scl.x, e.scl.y, sc(it))) }
        }
    }
}

@Composable
private fun LogicCard(ed: Editor, e: Entity, l: Logic) {
    fun upd(n: Logic) = ed.replaceLogic(e.id, l, n)
    Column(
        Modifier.padding(vertical = 3.dp).fillMaxWidth()
            .background(Color(0xFF1B2030), RoundedCornerShape(8.dp)).padding(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                l.label(), fontWeight = FontWeight.Bold, color = Color(0xFF80D8FF), fontSize = 13.sp,
                modifier = Modifier.weight(1f)
            )
            IconPill(Ic.Trash) { ed.removeLogic(e.id, l) }
        }
        when (l) {
            is Logic.RigidBody -> HRow {
                Pill("Static", !l.dynamic) { upd(l.copy(dynamic = false)) }
                Pill("Dynamic", l.dynamic) { upd(l.copy(dynamic = true)) }
            }
            is Logic.Vehicle -> {
                HRow {
                    NumRow("Top speed", l.maxSpeed, 2f) { upd(l.copy(maxSpeed = max(2f, it))) }
                    NumRow("Accel", l.accel, 1f) { upd(l.copy(accel = max(1f, it))) }
                }
                HRow {
                    NumRow("Steer°", l.steerDeg, 2f) { upd(l.copy(steerDeg = max(5f, it))) }
                    NumRow("Suspension", l.suspension, 0.05f) { upd(l.copy(suspension = max(0.1f, it))) }
                }
                HRow {
                    Lbl("Forward")
                    listOf("+Z", "-Z", "+X", "-X").forEachIndexed { i, n -> Pill(n, l.forward == i) { upd(l.copy(forward = i)) } }
                }
            }
            is Logic.Wheel -> {
                HRow {
                    NumRow("Radius", l.radius, 0.05f) { upd(l.copy(radius = max(0.05f, it))) }
                    Pill("Steerable", l.steerable) { upd(l.copy(steerable = !l.steerable)) }
                    Pill("Driven", l.driven) { upd(l.copy(driven = !l.driven)) }
                }
                HRow {
                    Lbl("Spin axis")
                    listOf("X", "Y", "Z").forEachIndexed { i, n -> Pill(n, l.axis == i) { upd(l.copy(axis = i)) } }
                }
            }
            is Logic.DoorHinge -> {
                HRow {
                    NumRow("Min°", l.minAngle, 5f) { upd(l.copy(minAngle = it)) }
                    NumRow("Max°", l.maxAngle, 5f) { upd(l.copy(maxAngle = it)) }
                    NumRow("Speed", l.speed, 10f) { upd(l.copy(speed = max(10f, it))) }
                }
                HRow {
                    Pill("Hinge: left edge") { ed.hingeFromBounds(true) }
                    Pill("Hinge: right edge") { ed.hingeFromBounds(false) }
                    Pill("Pick vertex", ed.tool == Tool.Hinge) { ed.selectTool(Tool.Hinge) }
                }
                Lbl("Pivot ${fmt(l.pivot.x)}, ${fmt(l.pivot.y)}, ${fmt(l.pivot.z)} (magenta line in viewport)")
                OutlinedTextField(
                    value = l.requiredKeyId, onValueChange = { upd(l.copy(requiredKeyId = it)) },
                    singleLine = true, label = { Text("Required key ID (optional)") }, modifier = Modifier.fillMaxWidth()
                )
            }
            is Logic.DriverSeat -> HRow {
                NumRow("X", l.offset.x, 0.1f) { upd(l.copy(offset = V3(it, l.offset.y, l.offset.z))) }
                NumRow("Y", l.offset.y, 0.1f) { upd(l.copy(offset = V3(l.offset.x, it, l.offset.z))) }
                NumRow("Z", l.offset.z, 0.1f) { upd(l.copy(offset = V3(l.offset.x, l.offset.y, it))) }
            }
            is Logic.Mover -> {
                HRow {
                    NumRow("dX", l.offset.x, 0.5f) { upd(l.copy(offset = V3(it, l.offset.y, l.offset.z))) }
                    NumRow("dY", l.offset.y, 0.5f) { upd(l.copy(offset = V3(l.offset.x, it, l.offset.z))) }
                    NumRow("dZ", l.offset.z, 0.5f) { upd(l.copy(offset = V3(l.offset.x, l.offset.y, it))) }
                }
                HRow {
                    NumRow("Speed", l.speed, 0.25f) { upd(l.copy(speed = max(0.1f, it))) }
                    Pill("Ping-pong", l.pingPong) { upd(l.copy(pingPong = !l.pingPong)) }
                    Pill("Starts active", l.startActive) { upd(l.copy(startActive = !l.startActive)) }
                }
            }
            is Logic.Spinner -> HRow {
                Lbl("Axis")
                Pill("X", l.axis.x == 1f) { upd(l.copy(axis = V3(1f, 0f, 0f))) }
                Pill("Y", l.axis.y == 1f) { upd(l.copy(axis = V3(0f, 1f, 0f))) }
                Pill("Z", l.axis.z == 1f) { upd(l.copy(axis = V3(0f, 0f, 1f))) }
                NumRow("°/s", l.degPerSec, 10f) { upd(l.copy(degPerSec = it)) }
            }
            is Logic.Sway -> {
                HRow {
                    Lbl("Axis")
                    Pill("X", l.axis.x == 1f) { upd(l.copy(axis = V3(1f, 0f, 0f))) }
                    Pill("Y", l.axis.y == 1f) { upd(l.copy(axis = V3(0f, 1f, 0f))) }
                    Pill("Z", l.axis.z == 1f) { upd(l.copy(axis = V3(0f, 0f, 1f))) }
                }
                HRow {
                    NumRow("Speed Hz", l.speed, 0.1f) { upd(l.copy(speed = max(0.05f, it))) }
                    NumRow("Amp°", l.amplitude, 1f) { upd(l.copy(amplitude = max(0f, it))) }
                }
                HRow {
                    NumRow("Phase", l.phase, 0.1f) { upd(l.copy(phase = it)) }
                    Pill("Sway from base", l.fromBase) { upd(l.copy(fromBase = !l.fromBase)) }
                }
            }
            is Logic.PlayerSpawn -> HRow {
                NumRow("Facing°", l.yaw, 15f) { upd(l.copy(yaw = it)) }
            }
            is Logic.Collectible -> {
                HRow { NumRow("Score", l.value.toFloat(), 5f) { upd(l.copy(value = it.toInt())) } }
                OutlinedTextField(
                    value = l.keyId, onValueChange = { upd(l.copy(keyId = it)) },
                    singleLine = true, label = { Text("Key ID (empty = plain score item)") }, modifier = Modifier.fillMaxWidth()
                )
            }
            is Logic.Hazard -> HRow {
                NumRow("Damage", l.damage.toFloat(), 10f) { upd(l.copy(damage = max(1f, it).toInt())) }
            }
            is Logic.TriggerPad -> {
                Lbl("Toggles target (door or mover):")
                val cands = ed.entities.filter { it.find<Logic.DoorHinge>() != null || it.find<Logic.Mover>() != null }
                if (cands.isEmpty()) Lbl("No doors or movers in the scene yet.")
                HRow {
                    cands.forEach { c -> Pill(c.name, l.targetId == c.id) { upd(l.copy(targetId = c.id)) } }
                }
            }
            is Logic.GoalZone -> Lbl("Touching this object ends the level with LEVEL COMPLETE!")
        }
    }
}

// ---------------------------------------------------------------- hierarchy

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HierarchyBody(ed: Editor, onGroup: () -> Unit) {
    val ents = ed.entities
    val kidsMap = remember(ents) {
        val ids = ents.map { it.id }.toSet()
        ents.groupBy { if (it.parentId != null && it.parentId in ids) it.parentId else null }
    }
    Column(Modifier.fillMaxWidth()) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconBtn(Ic.MultiSelect, "Multi", ed.multiSelect) { ed.multiSelect = !ed.multiSelect }
            IconBtn(Ic.Group, "Connect") { onGroup() }
            IconBtn(Ic.Ungroup, "Ungroup") { ed.ungroup() }
            IconBtn(Ic.Down, "Attach to", ed.pickParent) { ed.pickParent = !ed.pickParent }
            IconBtn(Ic.Up, "Detach") { ed.detachSelected() }
            IconBtn(Ic.Left, "Parent") { ed.selectParent() }
            IconBtn(Ic.Duplicate, "Duplicate") { ed.duplicate() }
            IconBtn(Ic.Trash, "Delete") { ed.deleteSelected() }
        }
        if (ents.isEmpty()) Lbl("Scene is empty.")
        (kidsMap[null] ?: emptyList()).forEach { TreeNode(ed, kidsMap, it, 0) }
    }
}

@Composable
private fun TreeNode(ed: Editor, kidsMap: Map<String?, List<Entity>>, e: Entity, depth: Int) {
    val kids = kidsMap[e.id] ?: emptyList()
    val open = e.id in ed.expanded
    val sel = e.id in ed.selected
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
            .background(if (sel) Color(0xFF1E3A5F) else Color.Transparent)
            .clickable { ed.tapEntity(e.id) }
            .padding(start = (2 + depth * 14).dp, top = 1.dp, bottom = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (kids.isNotEmpty()) {
            Box(Modifier.size(28.dp).clickable { ed.toggleExpand(e.id) }, contentAlignment = Alignment.Center) {
                LIcon(if (open) Ic.Down else Ic.Right, size = 16.dp, tint = Color(0xFFB8C0D4))
            }
        } else Spacer(Modifier.size(28.dp))
        val badges = if (e.logic.isEmpty()) "" else "  [" + e.logic.joinToString(",") { it.label() } + "]"
        val count = if (kids.isNotEmpty()) " (${kids.size})" else ""
        Text(
            e.name + count + badges,
            color = if (e.visible) Color.White else Color(0xFF777C8A), fontSize = 12.sp,
            modifier = Modifier.weight(1f), maxLines = 1
        )
        Box(Modifier.size(28.dp).clickable { ed.toggleVisible(e.id) }, contentAlignment = Alignment.Center) {
            LIcon(if (e.visible) Ic.Eye else Ic.EyeOff, size = 16.dp, tint = Color(0xFFB8C0D4))
        }
    }
    if (open && depth < 24) kids.forEach { TreeNode(ed, kidsMap, it, depth + 1) }
}
