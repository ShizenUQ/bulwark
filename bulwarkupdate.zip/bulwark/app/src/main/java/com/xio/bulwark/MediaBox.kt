package com.xio.bulwark

import android.content.Context
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Build
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import java.io.File

/** The small looping video / gif / image box. Muted. Only plays while it is visible. */
class MediaBox(private val ctx: Context) : FrameLayout(ctx) {

    var hasSource = false
        private set

    private var type = ""
    private var loadedVer = -1
    private var active = false
    private var tv: TextureView? = null
    private var mp: MediaPlayer? = null
    private var img: ImageView? = null
    private var anim: Drawable? = null
    private var ready = false

    init {
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 7f * resources.displayMetrics.density)
            }
        }
        setBackgroundColor(0xFF000000.toInt())
    }

    fun file(): File = File(ctx.filesDir, "media.dat")

    /** Reload when the picked file changed. Cheap when nothing changed. */
    fun load() {
        val ver = Prefs.int(ctx, Prefs.MEDIA_VER, 0)
        if (ver == loadedVer) return
        loadedVer = ver
        releaseAll()
        val tp = Prefs.str(ctx, Prefs.MEDIA_TYPE, "")
        val f = file()
        if (tp.isEmpty() || !f.exists()) { hasSource = false; return }
        type = tp
        hasSource = true
        try {
            if (tp == "video") {
                val t = TextureView(ctx)
                t.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { if (active) startVideo() }
                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { releasePlayer(); return true }
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
                tv = t
                addView(t, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            } else {
                val iv = ImageView(ctx)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                img = iv
                addView(iv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
                val d: Drawable? = if (Build.VERSION.SDK_INT >= 28) {
                    ImageDecoder.decodeDrawable(ImageDecoder.createSource(f))
                } else {
                    Drawable.createFromPath(f.absolutePath)
                }
                if (d is AnimatedImageDrawable) d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                anim = d
                iv.setImageDrawable(d)
            }
        } catch (t: Throwable) {
            hasSource = false
        }
    }

    fun setActive(a: Boolean) {
        active = a
        if (type == "video") {
            if (a) { if (tv?.isAvailable == true) startVideo() } else releasePlayer()
        } else {
            val d = anim
            if (d is AnimatedImageDrawable) { if (a) d.start() else d.stop() }
        }
    }

    private fun startVideo() {
        if (mp != null) return
        val st = tv?.surfaceTexture ?: return
        try {
            val m = MediaPlayer()
            m.setDataSource(file().absolutePath)
            m.setSurface(Surface(st))
            m.isLooping = true
            m.setVolume(0f, 0f)
            m.setOnVideoSizeChangedListener { _, vw, vh -> fit(vw, vh) }
            m.setOnErrorListener { _, _, _ -> releasePlayer(); true }
            m.setOnPreparedListener { p -> ready = true; if (active) p.start() }
            m.prepareAsync()
            mp = m
        } catch (t: Throwable) {
            releasePlayer()
        }
    }

    private fun fit(vw: Int, vh: Int) {
        val t = tv ?: return
        t.post {
            val w = t.width.toFloat()
            val h = t.height.toFloat()
            if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return@post
            val va = vw.toFloat() / vh
            val ba = w / h
            val m = Matrix()
            if (va > ba) m.setScale(va / ba, 1f, w / 2f, h / 2f) else m.setScale(1f, ba / va, w / 2f, h / 2f)
            t.setTransform(m)
        }
    }

    private fun releasePlayer() {
        ready = false
        val m = mp ?: return
        mp = null
        try { m.setOnPreparedListener(null); m.stop() } catch (t: Throwable) { }
        try { m.release() } catch (t: Throwable) { }
    }

    private fun releaseAll() {
        releasePlayer()
        val d = anim
        if (d is AnimatedImageDrawable) d.stop()
        anim = null
        removeAllViews()
        tv = null
        img = null
        hasSource = false
    }
}
