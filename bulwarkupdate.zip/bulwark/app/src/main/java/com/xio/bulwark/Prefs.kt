package com.xio.bulwark

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bulwark", Context.MODE_PRIVATE)

    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    const val STYLE = "style"
    const val MODE = "mode"
    const val LOCKED = "locked"
    const val MEDIA_TYPE = "media_type"
    const val MEDIA_VER = "media_ver"
    const val X = "x"
    const val Y = "y"
    const val TARGET = "target"
    const val OPACITY = "opacity"
    const val SCALE = "scale"
    const val GRAPH = "graph"
    const val BARS = "bars"
    const val FOOTER = "footer"
    const val COLLAPSED = "collapsed"
    const val BOOT = "boot"
}
