package com.xio.bulwark

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The overlay drawing. Three designs (0 glass, 1 gauge, 2 pill) x three sizes (0 full, 1 compact, 2 dot).
 * Everything is drawn by hand in "design units" (1 unit = 1dp at 100% size). Touch lives in HudRoot.
 * Animation only runs while something is moving.
 */
class HudView(private val ctx: Context) : View(ctx) {

    var onTick: (() -> Unit)? = null
    var hasMedia = false
        set(v) {
            if (field != v) { field = v; if (prefsLoaded) retarget() }
        }
    var locked = false
        private set

    private val dens = resources.displayMetrics.density
    private var sc = 1f
    private var style = 0
    private var modePref = 0
    private var collapsed = false
    private var showGraph = true
    private var showBars = true
    private var showFooter = true
    private var targetFps = 60

    private var data = FpsData.na("NOLINK")
    private var sys: SysData? = null

    private var dispFps = 0f
    private var reveal = 0f
    private var flash = 0f
    private var sheenStart = -100000L
    private var lastState = 0
    private var lastFrameT = 0L
    private var running = false

    // size transition
    private var initialized = false
    private var prefsLoaded = false
    private var curW = 0f
    private var curH = 0f
    private var fromW = 0f
    private var fromH = 0f
    private var toW = 0f
    private var toH = 0f
    private var tAnim = 1f
    private var tgtStyle = 0
    private var tgtMode = 0
    private var shownStyle = 0
    private var shownMode = 0
    private var mediaWanted = false

    // paints
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val num = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val lab = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private val plate = Path()
    private val sheen = Path()
    private val tmp = RectF()
    private var cachedH = -1f

    companion object {
        const val GLASS_W = 188f
        const val GAUGE_W = 176f
        const val MEDIA_W = 60f
        const val MEDIA_H = 34f
    }

    // ---------------- loop ----------------

    private val ticker = object : Runnable {
        override fun run() {
            advance()
            invalidate()
            onTick?.invoke()
            if (needAnim()) postOnAnimation(this) else running = false
        }
    }

    private val sheenLoop = object : Runnable {
        override fun run() {
            sheenStart = SystemClock.uptimeMillis()
            kick()
            postDelayed(this, 9000)
        }
    }

    private fun kick() {
        if (!running) {
            running = true
            lastFrameT = SystemClock.uptimeMillis()
            postOnAnimation(ticker)
        }
    }

    private fun needAnim(): Boolean {
        val now = SystemClock.uptimeMillis()
        return reveal < 1f || tAnim < 1f || flash > 0f ||
            (data.fps >= 0f && abs(dispFps - data.fps) > 0.01f) || now - sheenStart < 950
    }

    private fun advance() {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrameT).coerceIn(1L, 64L).toFloat()
        lastFrameT = now
        if (reveal < 1f) reveal = min(1f, reveal + dt / 420f)
        if (tAnim < 1f) {
            tAnim = min(1f, tAnim + dt / 280f)
            val e = tAnim * tAnim * (3f - 2f * tAnim)
            curW = fromW + (toW - fromW) * e
            curH = fromH + (toH - fromH) * e
            if (tAnim >= 0.5f) { shownStyle = tgtStyle; shownMode = tgtMode }
            requestLayout()
        }
        if (data.fps >= 0f) {
            val diff = data.fps - dispFps
            dispFps = if (abs(diff) < 0.4f) data.fps else dispFps + diff * min(1f, dt / 110f)
        } else dispFps = 0f
        if (flash > 0f) flash = max(0f, flash - dt / 750f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        reveal = 0f
        postDelayed(sheenLoop, 1500)
        kick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(sheenLoop)
        removeCallbacks(ticker)
        running = false
        super.onDetachedFromWindow()
    }

    // ---------------- public api ----------------

    fun scalePx(): Float = dens * sc

    fun applyPrefs() {
        sc = Prefs.int(ctx, Prefs.SCALE, 100) / 100f
        style = Prefs.int(ctx, Prefs.STYLE, 0).coerceIn(0, 2)
        modePref = Prefs.int(ctx, Prefs.MODE, 0).coerceIn(0, 2)
        collapsed = Prefs.bool(ctx, Prefs.COLLAPSED, false)
        showGraph = Prefs.bool(ctx, Prefs.GRAPH, true)
        showBars = Prefs.bool(ctx, Prefs.BARS, true)
        showFooter = Prefs.bool(ctx, Prefs.FOOTER, true)
        targetFps = Prefs.int(ctx, Prefs.TARGET, 60)
        locked = Prefs.bool(ctx, Prefs.LOCKED, false)
        prefsLoaded = true
        retarget()
    }

    fun update(d: FpsData, s: SysData) {
        data = d
        sys = s
        val st = stateOf(d)
        if (st > lastState && lastState != 0) flash = 1f
        lastState = st
        kick()
        invalidate()
    }

    fun toggleFold() {
        collapsed = !collapsed
        Prefs.putBool(ctx, Prefs.COLLAPSED, collapsed)
        retarget()
    }

    /** Lock button area in design units, or null when it is not on screen. */
    fun lockHit(): RectF? {
        if (tAnim < 1f || reveal < 1f || shownMode != 0 || shownStyle == 2) return null
        return RectF(curW - 26f, 0f, curW, 22f)
    }

    /** Where the video box goes, in pixels, or null when it should be hidden. */
    fun mediaRect(): Rect? {
        if (!mediaWanted || tAnim < 1f || reveal < 1f || shownMode != 0) return null
        val s = scalePx()
        val r: RectF = when (shownStyle) {
            0 -> RectF(GLASS_W, 12f, GLASS_W + MEDIA_W, 12f + MEDIA_H)
            1 -> RectF(GAUGE_W, 21f, GAUGE_W + MEDIA_W, 21f + MEDIA_H)
            else -> RectF(baseSize(2, 0)[0] - 2f, 4f, baseSize(2, 0)[0] + 46f, 30f)
        }
        return Rect((r.left * s).roundToInt(), (r.top * s).roundToInt(), (r.right * s).roundToInt(), (r.bottom * s).roundToInt())
    }

    // ---------------- sizes ----------------

    private fun glassH() = if (showFooter) 88f else 70f
    private fun gaugeBe() = if (showBars) 76f else 68f
    private fun gaugeH() = gaugeBe() + (if (showFooter) 16f else 0f)

    private fun baseSize(st: Int, md: Int): FloatArray = when (st) {
        0 -> when (md) {
            0 -> floatArrayOf(GLASS_W, glassH())
            1 -> floatArrayOf(132f, 38f)
            else -> floatArrayOf(54f, 30f)
        }
        1 -> when (md) {
            0 -> floatArrayOf(GAUGE_W, gaugeH())
            1 -> floatArrayOf(120f, 62f)
            else -> floatArrayOf(46f, 46f)
        }
        else -> when (md) {
            0 -> floatArrayOf(if (showBars) 172f else 122f, 34f)
            1 -> floatArrayOf(108f, 34f)
            else -> floatArrayOf(46f, 30f)
        }
    }

    private fun mediaExtra(st: Int) = if (st == 2) 54f else 70f

    private fun retarget() {
        val eff = if (collapsed) 2 else modePref
        val med = hasMedia && eff == 0
        val bs = baseSize(style, eff)
        val w = bs[0] + (if (med) mediaExtra(style) else 0f)
        val h = bs[1]
        if (initialized && style == tgtStyle && eff == tgtMode && w == toW && h == toH && med == mediaWanted) return
        tgtStyle = style
        tgtMode = eff
        mediaWanted = med
        if (!initialized) {
            initialized = true
            curW = w; curH = h; fromW = w; fromH = h; toW = w; toH = h
            shownStyle = style; shownMode = eff
            tAnim = 1f
        } else {
            fromW = curW; fromH = curH; toW = w; toH = h
            tAnim = 0f
        }
        requestLayout()
        kick()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = scalePx()
        setMeasuredDimension((curW * s).roundToInt(), (curH * s).roundToInt())
    }

    // ---------------- helpers ----------------

    /** 0 = no data, 1 = good, 2 = mid, 3 = bad */
    private fun stateOf(d: FpsData): Int {
        if (d.fps < 0f) return 0
        val r = d.fps / targetFps
        return if (r >= 0.9f) 1 else if (r >= 0.7f) 2 else 3
    }

    private fun accent(st: Int) = when (st) {
        1 -> P.GOOD; 2 -> P.MID; 3 -> P.BAD; else -> P.DIM
    }

    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)
    private fun fpsStr() = if (data.fps < 0f) "--" else dispFps.roundToInt().toString()
    private fun ftStr() = if (data.ft > 0f) f1(data.ft) else "--"
    private fun lowStr() = if (data.low > 0f) data.low.roundToInt().toString() else "--"
    private fun cpuStr() = if (data.cpu >= 0f) data.cpu.roundToInt().toString() + "%" else "--"
    private fun ramFrac() = sys?.ram ?: -1f
    private fun ramStr() = if (ramFrac() >= 0f) (ramFrac() * 100f).roundToInt().toString() + "%" else "--"

    private fun statusText(): String = when (data.status) {
        "OK" -> "LIVE"
        "SELF" -> "OPEN A GAME"
        "NOLINK" -> "CONNECTING..."
        "STALE" -> "NO NEW FRAMES"
        "NOLAYER" -> "NO GAME LAYER"
        "NOPKG" -> "NO APP FOUND"
        else -> data.status
    }

    private fun t(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, face: Typeface, al: Paint.Align, ls: Float = 0f) {
        txt.typeface = face
        txt.textSize = size
        txt.color = color
        txt.textAlign = al
        txt.letterSpacing = ls
        c.drawText(s, x, y, txt)
    }

    // ---------------- drawing ----------------

    override fun onDraw(canvas: Canvas) {
        val w = curW
        val h = curH
        if (w <= 0f) return
        val s = scalePx()
        canvas.save()
        canvas.scale(s, s)
        var layer = -1
        if (reveal < 1f) {
            val e = reveal * reveal * (3f - 2f * reveal)
            val k = 0.88f + 0.12f * e
            canvas.scale(k, k, w / 2f, h / 2f)
            layer = canvas.saveLayerAlpha(0f, 0f, w, h, (255 * e).toInt())
        }
        val rad = when (shownStyle) { 0 -> 11f; 1 -> 16f; else -> min(h / 2f, 17f) }
        tmp.set(0.6f, 0.6f, w - 0.6f, h - 0.6f)
        plate.reset()
        plate.addRoundRect(tmp, rad, rad, Path.Direction.CW)
        if (abs(h - cachedH) > 0.4f) {
            body.shader = LinearGradient(0f, 0f, 0f, h, P.BG_TOP, P.BG_BOT, Shader.TileMode.CLAMP)
            cachedH = h
        }
        canvas.drawPath(plate, body)
        line.strokeWidth = 0.9f
        if (flash > 0f) { line.color = P.BAD; line.alpha = (50 + flash * 200).toInt() } else line.color = P.EDGE
        canvas.drawPath(plate, line)

        val st = stateOf(data)
        when (shownStyle) {
            0 -> drawGlass(canvas, w, h, st)
            1 -> drawGauge(canvas, w, h, st)
            else -> drawPill(canvas, w, h, st)
        }

        val sp = (SystemClock.uptimeMillis() - sheenStart) / 900f
        if (sp in 0f..1f) {
            val cx = -30f + sp * (w + 60f)
            canvas.save()
            canvas.clipPath(plate)
            sheen.reset()
            sheen.moveTo(cx, 0f); sheen.lineTo(cx + 9f, 0f); sheen.lineTo(cx - 5f, h); sheen.lineTo(cx - 14f, h); sheen.close()
            fill.color = 0x16FFFFFF
            canvas.drawPath(sheen, fill)
            canvas.restore()
        }
        if (layer >= 0) canvas.restoreToCount(layer)
        canvas.restore()
    }

    private fun lockIcon(c: Canvas, cx: Float, cy: Float) {
        val col = if (locked) P.MID else P.DIM
        fill.color = col
        tmp.set(cx - 4f, cy - 0.5f, cx + 4f, cy + 5f)
        c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
        line.color = col
        line.strokeWidth = 1.3f
        if (locked) {
            tmp.set(cx - 2.7f, cy - 5f, cx + 2.7f, cy + 1f)
            c.drawArc(tmp, 180f, 180f, false, line)
            c.drawLine(cx - 2.7f, cy - 2f, cx - 2.7f, cy, line)
            c.drawLine(cx + 2.7f, cy - 2f, cx + 2.7f, cy, line)
        } else {
            tmp.set(cx + 0.3f, cy - 6f, cx + 5.7f, cy)
            c.drawArc(tmp, 180f, 180f, false, line)
            c.drawLine(cx + 0.3f, cy - 3f, cx + 0.3f, cy - 0.5f, line)
        }
    }

    private fun miniBar(c: Canvas, x: Float, y: Float, w: Float, frac: Float) {
        fill.color = P.TRACK
        tmp.set(x, y, x + w, y + 2.4f)
        c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
        val f = frac.coerceIn(0f, 1f)
        if (f > 0.01f) {
            fill.color = if (f < 0.6f) P.GOOD else if (f < 0.85f) P.MID else P.BAD
            tmp.set(x, y, x + w * f, y + 2.4f)
            c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
        }
    }

    private fun footer(c: Canvas, w: Float, yLine: Float, yText: Float) {
        line.strokeWidth = 0.7f
        line.color = 0x22FFFFFF
        c.drawLine(10f, yLine, w - 10f, yLine, line)
        val sy = sys
        t(c, sy?.clock ?: "--:--", 12f, yText, 7.5f, P.TEXT, mono, Paint.Align.LEFT)
        val bat = if (sy == null || sy.bat < 0) "--" else sy.bat.toString() + "%" + (if (sy.charging) "+" else "")
        val tp = if (sy == null || sy.temp <= 0f) "" else "  " + sy.temp.roundToInt() + "°C"
        t(c, "BAT $bat$tp", w / 2f, yText, 7.5f, P.DIM, mono, Paint.Align.CENTER)
        t(c, sy?.session ?: "00:00:00", w - 12f, yText, 7.5f, P.LABEL, mono, Paint.Align.RIGHT)
    }

    private fun graph(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        val gh = y1 - y0
        fill.color = 0x40000000
        tmp.set(x0, y0, x1, y1)
        c.drawRoundRect(tmp, 3f, 3f, fill)
        val targetFt = 1000f / targetFps
        val maxMs = targetFt * 2.2f
        val ty = y1 - 2f - (targetFt / maxMs).coerceAtMost(1f) * (gh - 4f)
        line.strokeWidth = 0.6f
        line.color = 0x40FFFFFF
        var dx = x0 + 3f
        while (dx < x1 - 4f) { c.drawLine(dx, ty, dx + 2f, ty, line); dx += 4.5f }
        val fr = data.frames
        if (fr.isEmpty()) {
            line.strokeWidth = 0.8f
            line.color = P.TRACK
            c.drawLine(x0 + 3f, y1 - 4f, x1 - 3f, y1 - 4f, line)
            return
        }
        val slots = 48
        val slotW = (x1 - x0 - 6f) / slots
        line.strokeWidth = max(0.9f, slotW * 0.6f)
        val n = min(slots, fr.size)
        for (i in 0 until n) {
            val ms = fr[fr.size - n + i]
            val hh = (ms / maxMs).coerceIn(0.05f, 1f) * (gh - 4f)
            line.color = if (ms <= targetFt * 1.2f) P.GOOD else if (ms <= targetFt * 1.7f) P.MID else P.BAD
            val bx = x1 - 3f - (n - i) * slotW + slotW / 2f
            c.drawLine(bx, y1 - 2f, bx, y1 - 2f - hh, line)
        }
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, r: Float, sw: Float, acc: Int) {
        tmp.set(cx - r, cy - r, cx + r, cy + r)
        line.strokeWidth = sw
        line.strokeCap = Paint.Cap.ROUND
        line.color = P.TRACK
        c.drawArc(tmp, 135f, 270f, false, line)
        val frac = if (data.fps < 0f) 0f else (dispFps / targetFps).coerceIn(0f, 1f)
        if (flash > 0f) {
            line.color = P.BAD
            line.alpha = (flash * 90).toInt()
            line.strokeWidth = sw + 4f
            c.drawArc(tmp, 135f, 270f, false, line)
            line.strokeWidth = sw
        }
        if (frac > 0.01f) {
            line.color = acc
            c.drawArc(tmp, 135f, 270f * frac, false, line)
        }
        line.strokeCap = Paint.Cap.BUTT
    }

    // ---------------- design 0: glass ----------------

    private fun drawGlass(c: Canvas, w: Float, h: Float, st: Int) {
        val acc = accent(st)
        line.strokeWidth = 2f
        line.strokeCap = Paint.Cap.ROUND
        line.color = acc
        c.drawLine(14f, 1.4f, 40f, 1.4f, line)
        line.strokeCap = Paint.Cap.BUTT
        val str = fpsStr()
        when (shownMode) {
            2 -> {
                fill.color = acc
                tmp.set(8f, 8f, 10.5f, h - 8f)
                c.drawRoundRect(tmp, 1.2f, 1.2f, fill)
                t(c, str, w / 2f + 3f, h / 2f + 5.5f, 15f, P.TEXT, mono, Paint.Align.CENTER)
            }
            1 -> {
                t(c, str, 10f, 28f, 22f, acc, num, Paint.Align.LEFT)
                t(c, ftStr() + " ms", w - 10f, 17f, 8f, P.TEXT, mono, Paint.Align.RIGHT)
                t(c, "LOW " + lowStr(), w - 10f, 30f, 7f, P.DIM, mono, Paint.Align.RIGHT)
            }
            else -> {
                t(c, "FPS", 12f, 18f, 7f, P.LABEL, lab, Paint.Align.LEFT, 0.14f)
                t(c, str, 11f, 47f, if (str.length >= 3) 27f else 30f, acc, num, Paint.Align.LEFT)
                val ft = ftStr()
                t(c, ft, 72f, 19f, 9f, P.TEXT, mono, Paint.Align.LEFT)
                t(c, "ms", 72f + txt.measureText(ft) + 2f, 19f, 6.5f, P.DIM, lab, Paint.Align.LEFT)
                lockIcon(c, w - 13f, 11f)
                if (showGraph) graph(c, 72f, 25f, GLASS_W - 10f, 50f)
                else t(c, statusText(), 72f, 42f, 8f, P.DIM, lab, Paint.Align.LEFT, 0.1f)

                val labels = ArrayList<String>()
                val values = ArrayList<String>()
                val fracs = ArrayList<Float>()
                labels.add("LOW"); values.add(lowStr()); fracs.add(-1f)
                if (showBars) {
                    labels.add("CPU"); values.add(cpuStr()); fracs.add(if (data.cpu >= 0f) data.cpu / 100f else 0f)
                    labels.add("RAM"); values.add(ramStr()); fracs.add(max(0f, ramFrac()))
                }
                val colW = (w - 24f) / labels.size
                for (i in labels.indices) {
                    val x = 12f + i * colW
                    t(c, labels[i], x, 62f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                    t(c, values[i], x + 21f, 62f, 8.5f, P.TEXT, mono, Paint.Align.LEFT)
                    if (fracs[i] >= 0f) miniBar(c, x, 65f, colW - 12f, fracs[i])
                }
                if (showFooter) footer(c, w, 72f, 82f)
            }
        }
    }

    // ---------------- design 1: gauge ----------------

    private fun drawGauge(c: Canvas, w: Float, h: Float, st: Int) {
        val acc = accent(st)
        val str = fpsStr()
        when (shownMode) {
            2 -> {
                ring(c, 23f, 23f, 17f, 3.5f, acc)
                t(c, str, 23f, 27f, 12f, P.TEXT, num, Paint.Align.CENTER)
            }
            1 -> {
                ring(c, 32f, 31f, 20f, 4.5f, acc)
                t(c, str, 32f, 36.5f, if (str.length >= 3) 14f else 16f, P.TEXT, num, Paint.Align.CENTER)
                val xr = w - 10f
                t(c, "FRAME", 62f, 26f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, ftStr() + "ms", xr, 26f, 8.5f, P.TEXT, mono, Paint.Align.RIGHT)
                t(c, "1% LOW", 62f, 42f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, lowStr(), xr, 42f, 8.5f, P.TEXT, mono, Paint.Align.RIGHT)
            }
            else -> {
                ring(c, 36f, 38f, 24f, 5f, acc)
                t(c, str, 36f, 45f, if (str.length >= 3) 18f else 21f, P.TEXT, num, Paint.Align.CENTER)
                t(c, "FPS", 36f, 55f, 6f, P.LABEL, lab, Paint.Align.CENTER, 0.14f)
                lockIcon(c, w - 13f, 11f)
                val x0 = 74f
                val xr = GAUGE_W - 10f
                t(c, "FRAME", x0, 25f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, ftStr() + "ms", xr, 25f, 9f, P.TEXT, mono, Paint.Align.RIGHT)
                t(c, "1% LOW", x0, 39f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                t(c, lowStr(), xr, 39f, 9f, P.TEXT, mono, Paint.Align.RIGHT)
                if (showBars) {
                    t(c, "CPU", x0, 53f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                    t(c, cpuStr(), xr, 53f, 8f, P.TEXT, mono, Paint.Align.RIGHT)
                    miniBar(c, x0, 56f, xr - x0, if (data.cpu >= 0f) data.cpu / 100f else 0f)
                    t(c, "RAM", x0, 67f, 6.5f, P.LABEL, lab, Paint.Align.LEFT, 0.1f)
                    t(c, ramStr(), xr, 67f, 8f, P.TEXT, mono, Paint.Align.RIGHT)
                    miniBar(c, x0, 70f, xr - x0, max(0f, ramFrac()))
                }
                if (showFooter) {
                    val be = gaugeBe()
                    footer(c, w, be - 1f, be + 10f)
                }
            }
        }
    }

    // ---------------- design 2: pill ----------------

    private fun sep(c: Canvas, x: Float) {
        line.strokeWidth = 0.8f
        line.color = 0x30FFFFFF
        c.drawLine(x, 10f, x, 24f, line)
    }

    private fun drawPill(c: Canvas, w: Float, h: Float, st: Int) {
        val acc = accent(st)
        val str = fpsStr()
        when (shownMode) {
            2 -> {
                dot(c, 11f, h / 2f, acc)
                t(c, str, 19f, h / 2f + 4.5f, 13f, P.TEXT, num, Paint.Align.LEFT)
            }
            1 -> {
                dot(c, 12f, h / 2f, acc)
                t(c, str, 22f, 23f, 16f, P.TEXT, num, Paint.Align.LEFT)
                t(c, ftStr() + "ms", w - 10f, 21f, 8.5f, P.DIM, mono, Paint.Align.RIGHT)
            }
            else -> {
                dot(c, 12f, h / 2f, acc)
                var x = 22f
                t(c, str, x, 23f, 16f, P.TEXT, num, Paint.Align.LEFT)
                x += txt.measureText(str) + 3f
                t(c, "FPS", x, 21.5f, 6f, P.LABEL, lab, Paint.Align.LEFT, 0.12f)
                x += txt.measureText("FPS") + 8f
                sep(c, x)
                x += 7f
                val ft = ftStr() + "ms"
                t(c, ft, x, 21f, 8.5f, P.TEXT, mono, Paint.Align.LEFT)
                x += txt.measureText(ft) + 8f
                if (showBars) {
                    sep(c, x)
                    x += 7f
                    t(c, "CPU " + cpuStr(), x, 21f, 8.5f, P.DIM, mono, Paint.Align.LEFT)
                }
            }
        }
    }

    private fun dot(c: Canvas, x: Float, y: Float, col: Int) {
        if (flash > 0f) {
            fill.color = P.BAD
            fill.alpha = (flash * 90).toInt()
            c.drawCircle(x, y, 7f, fill)
        }
        fill.color = col
        c.drawCircle(x, y, 3.4f, fill)
    }
}
