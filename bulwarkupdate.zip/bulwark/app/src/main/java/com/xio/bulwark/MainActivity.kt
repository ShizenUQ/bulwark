package com.xio.bulwark

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import java.io.File
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var tvOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var tvShizuku: TextView
    private lateinit var btnShizuku: Button
    private lateinit var tvBattery: TextView
    private lateinit var btnBattery: Button
    private lateinit var tvNotif: TextView
    private lateinit var btnNotif: Button
    private lateinit var btnStart: Button
    private class Chip(val b: Button, val key: String, val v: Int, val def: Int)
    private val chips = ArrayList<Chip>()
    private lateinit var swLock: Switch
    private lateinit var tvMedia: TextView

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- small view helpers ----------

    private fun plateBg(fillColor: Int, stroke: Int, radius: Int = 6): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fillColor)
        g.cornerRadius = dp(radius).toFloat()
        g.setStroke(dp(1), stroke)
        return g
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        return t
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = plateBg(C.PANEL, C.BRASS_DARK)
        c.setPadding(dp(14), dp(12), dp(14), dp(14))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        val t = label(title.uppercase(), 11f, C.BRASS, true)
        t.letterSpacing = 0.18f
        c.addView(t)
        return c
    }

    private fun body(text: String): TextView {
        val t = label(text, 13f, C.TEXT_DIM)
        t.setPadding(0, dp(6), 0, dp(6))
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(C.TEXT)
        b.background = plateBg(C.STEEL_HI, C.BRASS)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(-1, dp(44))
        lp.topMargin = dp(6)
        b.layoutParams = lp
        return b
    }

    private fun toggle(text: String, key: String, def: Boolean): Switch {
        val s = Switch(this)
        s.text = text
        s.textSize = 14f
        s.setTextColor(C.TEXT)
        s.isChecked = Prefs.bool(this, key, def)
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, v -> Prefs.putBool(this, key, v) }
        return s
    }

    private fun slider(text: String, key: String, min: Int, max: Int, def: Int, unit: String): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val cur = Prefs.int(this, key, def)
        val tv = label("$text  $cur$unit", 13f, C.TEXT)
        tv.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = "$text  $v$unit"
                if (fromUser) Prefs.putInt(this@MainActivity, key, v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun chipRow(key: String, def: Int, opts: List<Pair<String, Int>>): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for ((name, v) in opts) {
            val b = Button(this)
            b.text = name
            b.isAllCaps = false
            b.setTextColor(C.TEXT)
            b.setOnClickListener { Prefs.putInt(this, key, v); refresh() }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), dp(6), dp(2), dp(6))
            row.addView(b, lp)
            chips.add(Chip(b, key, v, def))
        }
        return row
    }

    private fun setMedia(type: String, src: File?) {
        Prefs.putStr(this, Prefs.MEDIA_TYPE, type)
        Prefs.putInt(this, Prefs.MEDIA_VER, Prefs.int(this, Prefs.MEDIA_VER, 0) + 1)
        if (type.isEmpty()) File(filesDir, "media.dat").delete()
        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 31 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Loading...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: ""
                val type = when {
                    mime.startsWith("video") -> "video"
                    mime == "image/gif" || mime == "image/webp" -> "anim"
                    mime.startsWith("image") -> "image"
                    else -> ""
                }
                if (type.isEmpty()) throw RuntimeException("not a video or image")
                val out = File(filesDir, "media.dat")
                var total = 0L
                contentResolver.openInputStream(uri)!!.use { ins ->
                    out.outputStream().use { os ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > 80L * 1024 * 1024) throw RuntimeException("file too big (max 80 MB)")
                            os.write(buf, 0, n)
                        }
                    }
                }
                runOnUiThread { setMedia(type, out) }
            } catch (t: Throwable) {
                runOnUiThread { Toast.makeText(this, "Could not load: " + t.message, Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    // ---------- screen ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(32))
        scroll.addView(root)

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        head.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(8), 0, 0, 0)
        val title = label("BULWARK", 26f, C.BRASS_HI, true)
        title.letterSpacing = 0.22f
        titles.addView(title)
        titles.addView(label("Performance watch for your games", 12f, C.TEXT_DIM))
        head.addView(titles)
        root.addView(head)

        // 1. overlay permission
        val c1 = card("1 · Overlay permission")
        tvOverlay = body("")
        c1.addView(tvOverlay)
        btnOverlay = button("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        c1.addView(btnOverlay)
        root.addView(c1)

        // 2. Shizuku
        val c2 = card("2 · Shizuku link (needed for FPS)")
        tvShizuku = body("")
        c2.addView(tvShizuku)
        btnShizuku = button("...") { shizukuAction() }
        c2.addView(btnShizuku)
        root.addView(c2)

        // 3. keep alive
        val c3 = card("3 · Stay alive in background")
        tvBattery = body("")
        c3.addView(tvBattery)
        btnBattery = button("Set battery to unrestricted") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (t: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        c3.addView(btnBattery)
        c3.addView(body("Some phones also have their own Autostart / Background activity switch. Open app settings and allow both, and lock the app in the recents list."))
        c3.addView(button("Open app settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        c3.addView(toggle("Start overlay after reboot", Prefs.BOOT, false))
        root.addView(c3)

        // 4. notifications
        val c4 = card("4 · Notification (keeps the service alive)")
        tvNotif = body("")
        c4.addView(tvNotif)
        btnNotif = button("Allow notifications") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        c4.addView(btnNotif)
        root.addView(c4)

        // 5. overlay controls
        val c5 = card("Overlay")
        btnStart = button("START") { startStop() }
        c5.addView(btnStart)
        c5.addView(body("Tap = fold to a dot. Drag = move. Lock icon (or long-press) = lock in place. A locked overlay lets every touch through to the game; unlock with the small lock dot next to it, or from the notification."))
        swLock = toggle("Lock position (touch passes through)", Prefs.LOCKED, false)
        c5.addView(swLock)
        c5.addView(label("DESIGN", 11f, C.BRASS, true))
        c5.addView(chipRow(Prefs.STYLE, 0, listOf("Glass" to 0, "Gauge" to 1, "Pill" to 2)))
        c5.addView(label("SIZE", 11f, C.BRASS, true))
        c5.addView(chipRow(Prefs.MODE, 0, listOf("Full" to 0, "Compact" to 1, "Dot" to 2)))
        c5.addView(label("TARGET FPS", 11f, C.BRASS, true))
        c5.addView(chipRow(Prefs.TARGET, 60, listOf("30" to 30, "60" to 60, "90" to 90, "120" to 120)))
        c5.addView(slider("Opacity", Prefs.OPACITY, 40, 100, 92, "%"))
        c5.addView(slider("Size", Prefs.SCALE, 70, 140, 100, "%"))
        c5.addView(toggle("Frame-time graph", Prefs.GRAPH, true))
        c5.addView(toggle("CPU / RAM", Prefs.BARS, true))
        c5.addView(toggle("Clock / battery footer", Prefs.FOOTER, true))
        root.addView(c5)

        // video box
        val cm = card("Video box")
        tvMedia = body("")
        cm.addView(tvMedia)
        cm.addView(body("Pick a short clip (5-10 s is ideal), a GIF or an image. It loops silently in a small box when the overlay is full size."))
        cm.addView(button("Choose video / image") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*"))
            startActivityForResult(i, 31)
        })
        cm.addView(button("Remove") { setMedia("", null) })
        root.addView(cm)

        // 6. debug
        val c6 = card("Diagnostics")
        c6.addView(body("If FPS shows --, open a game for a few seconds, come back here and tap this. Send me what it says."))
        c6.addView(button("Show FPS reader report") {
            Thread {
                FpsClient.forceBind(applicationContext)
                try { Thread.sleep(2500) } catch (e: Exception) { }
                val txt = FpsClient.debugText(applicationContext)
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("FPS reader").setMessage(txt).setPositiveButton("OK", null).show()
                }
            }.start()
        })
        root.addView(c6)

        setContentView(scroll)
    }

    override fun onStart() {
        super.onStart()
        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
    }

    override fun onStop() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (t: Throwable) { }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ---------- actions ----------

    private fun shizukuAction() {
        when (FpsClient.state(this)) {
            FpsClient.St.NOT_INSTALLED -> Toast.makeText(this, "Install Shizuku first, then come back.", Toast.LENGTH_LONG).show()
            FpsClient.St.NOT_RUNNING -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
            }
            FpsClient.St.NO_PERMISSION -> try { Shizuku.requestPermission(21) } catch (t: Throwable) { }
            FpsClient.St.READY -> Toast.makeText(this, "Shizuku is linked.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startStop() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow display over other apps first (card 1).", Toast.LENGTH_LONG).show()
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        btnStart.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val ov = Settings.canDrawOverlays(this)
        tvOverlay.text = if (ov) "GRANTED" else "REQUIRED - the overlay cannot show without it."
        tvOverlay.setTextColor(if (ov) C.GOOD else C.BAD)
        btnOverlay.visibility = if (ov) View.GONE else View.VISIBLE

        val st = FpsClient.state(this)
        val (msg, btn) = when (st) {
            FpsClient.St.NOT_INSTALLED -> "Shizuku is not installed. Overlay works, but FPS will show --." to "Shizuku missing"
            FpsClient.St.NOT_RUNNING -> "Shizuku is installed but not running. Open it and start it (wireless debugging)." to "Open Shizuku"
            FpsClient.St.NO_PERMISSION -> "Shizuku is running. Bulwark needs your permission." to "Grant Shizuku access"
            FpsClient.St.READY -> "LINKED - FPS reading is ready." to "Linked"
        }
        tvShizuku.text = msg
        tvShizuku.setTextColor(if (st == FpsClient.St.READY) C.GOOD else C.MID)
        btnShizuku.text = btn
        btnShizuku.visibility = if (st == FpsClient.St.READY) View.GONE else View.VISIBLE

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val free = pm.isIgnoringBatteryOptimizations(packageName)
        tvBattery.text = if (free) "UNRESTRICTED - good." else "Restricted - the system may close the overlay."
        tvBattery.setTextColor(if (free) C.GOOD else C.MID)
        btnBattery.visibility = if (free) View.GONE else View.VISIBLE

        val nOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        tvNotif.text = if (nOk) "ALLOWED." else "Not allowed - the overlay still runs, but the status notification is hidden."
        tvNotif.setTextColor(if (nOk) C.GOOD else C.MID)
        btnNotif.visibility = if (nOk) View.GONE else View.VISIBLE

        btnStart.text = if (OverlayService.running) "STAND DOWN (stop overlay)" else "START OVERLAY"
        btnStart.background = plateBg(if (OverlayService.running) C.SH_BAD else C.SH_GOOD, C.BRASS)

        for (ch in chips) {
            val on = Prefs.int(this, ch.key, ch.def) == ch.v
            ch.b.background = plateBg(if (on) C.BRASS_DIM else C.STEEL_LO, if (on) C.BRASS_HI else C.BRASS_DARK)
        }
        swLock.isChecked = Prefs.bool(this, Prefs.LOCKED, false)
        val mt = Prefs.str(this, Prefs.MEDIA_TYPE, "")
        val mf = File(filesDir, "media.dat")
        tvMedia.text = if (mt.isEmpty() || !mf.exists()) "No clip chosen." else "Loaded: " + mt + " (" + (mf.length() / 1024) + " KB)"
        tvMedia.setTextColor(if (mt.isEmpty()) C.TEXT_DIM else C.GOOD)
    }
}
