package com.xio.bulwark

import android.content.Context
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/** Holds the drawn HUD plus the video box, and handles touch (tap = fold, drag = move, long-press / lock icon = lock). */
class HudRoot(private val ctx: Context) : FrameLayout(ctx) {

    val hud = HudView(ctx)
    private val media = MediaBox(ctx)
    private var mediaRect: Rect? = null

    var onDrag: ((Int, Int) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null
    var onToggleLock: (() -> Unit)? = null

    init {
        addView(hud, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        media.visibility = View.GONE
        addView(media, LayoutParams(1, 1))
        hud.onTick = { syncMedia() }
    }

    fun applyPrefs() {
        media.load()
        hud.hasMedia = media.hasSource
        hud.applyPrefs()
    }

    fun update(d: FpsData, s: SysData) = hud.update(d, s)

    private fun syncMedia() {
        val r = hud.mediaRect()
        if (r != null && media.hasSource) {
            if (mediaRect != r) { mediaRect = r; requestLayout() }
            if (media.visibility != View.VISIBLE) {
                media.alpha = 0f
                media.visibility = View.VISIBLE
                media.setActive(true)
                media.animate().alpha(1f).setDuration(320).start()
            }
        } else if (media.visibility == View.VISIBLE) {
            media.animate().cancel()
            media.setActive(false)
            media.visibility = View.GONE
            mediaRect = null
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        hud.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED)
        val r = mediaRect
        if (r != null && media.visibility == View.VISIBLE) {
            media.measure(
                MeasureSpec.makeMeasureSpec(r.width(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(r.height(), MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(hud.measuredWidth, hud.measuredHeight)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        hud.layout(0, 0, hud.measuredWidth, hud.measuredHeight)
        val mr = mediaRect
        if (mr != null && media.visibility == View.VISIBLE) media.layout(mr.left, mr.top, mr.right, mr.bottom)
    }

    // ---- touch ----
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var longFired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 1.5f
    private val longRun = Runnable { longFired = true; onToggleLock?.invoke() }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean = true

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY
                moved = false; longFired = false
                postDelayed(longRun, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    moved = true
                    removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke((e.rawX - lastX).toInt(), (e.rawY - lastY).toInt())
                lastX = e.rawX; lastY = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (moved) onDragEnd?.invoke()
                else if (!longFired) {
                    val s = hud.scalePx()
                    val lr = hud.lockHit()
                    if (lr != null && lr.contains(e.x / s, e.y / s)) onToggleLock?.invoke() else hud.toggleFold()
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }
}
