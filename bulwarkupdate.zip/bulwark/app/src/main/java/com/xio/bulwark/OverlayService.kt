package com.xio.bulwark

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.xio.bulwark.STOP"
        const val ACTION_TOGGLE_LOCK = "com.xio.bulwark.TOGGLE_LOCK"
        private const val CHANNEL = "bulwark_watch"
        private const val NOTIF_ID = 7
        private const val BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var root: HudRoot? = null
    private lateinit var lp: WindowManager.LayoutParams
    private var dot: DotView? = null
    private var dotLp: WindowManager.LayoutParams? = null
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var t0 = 0L
    private var screenOn = true

    private val loop = object : Runnable {
        override fun run() {
            val c = applicationContext
            val raw = try { FpsClient.sample(c) } catch (t: Throwable) { null }
            val data = FpsData.parse(raw)
            val sys = StatsReader.read(c, t0)
            main.post {
                root?.applyPrefs()
                applyWindowState()
                root?.update(data, sys)
            }
            if (screenOn) wh?.postDelayed(this, 500)
        }
    }

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; wh?.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; wh?.removeCallbacks(loop); wh?.post(loop) }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        t0 = SystemClock.elapsedRealtime()
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true
        registerReceiver(screenRx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        })
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        showOverlay()
        worker = HandlerThread("bulwark-sampler").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE_LOCK -> toggleLock()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        wh?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenRx) } catch (t: Throwable) { }
        dot?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        dot = null
        root?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        root = null
        FpsClient.unbind(applicationContext)
        super.onDestroy()
    }

    // ---------- overlay window ----------

    private fun showOverlay() {
        val dm = Resources.getSystem().displayMetrics
        val v = HudRoot(this)
        v.applyPrefs()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Prefs.int(this, Prefs.X, (24 * dm.density).toInt())
        lp.y = Prefs.int(this, Prefs.Y, (24 * dm.density).toInt())
        lp.alpha = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        v.onDrag = { dx, dy ->
            lp.x += dx
            lp.y += dy
            clamp(v)
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        v.onDragEnd = { snap(v) }
        v.onToggleLock = { toggleLock() }
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> posDot() }
        try {
            wm.addView(v, lp)
            root = v
        } catch (t: Throwable) {
            stopSelf()
        }
    }

    private fun clamp(v: View) {
        val dm = Resources.getSystem().displayMetrics
        val w = if (v.width > 0) v.width else 1
        val h = if (v.height > 0) v.height else 1
        lp.x = lp.x.coerceIn(0, maxOf(0, dm.widthPixels - w))
        lp.y = lp.y.coerceIn(0, maxOf(0, dm.heightPixels - h))
    }

    private fun snap(v: View) {
        val dm = Resources.getSystem().displayMetrics
        val margin = (10 * dm.density).toInt()
        val mid = lp.x + v.width / 2
        val target = if (mid < dm.widthPixels / 2) margin else maxOf(margin, dm.widthPixels - v.width - margin)
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
            }
            start()
        }
        Prefs.putInt(this, Prefs.X, target)
        Prefs.putInt(this, Prefs.Y, lp.y)
    }

    // ---------- lock ----------

    private fun toggleLock() {
        val now = !Prefs.bool(this, Prefs.LOCKED, false)
        Prefs.putBool(this, Prefs.LOCKED, now)
        root?.applyPrefs()
        applyWindowState()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (t: Throwable) { }
    }

    /** Locked = every touch passes through to the game (window opacity must stay at 80% or less on Android 12+). */
    private fun applyWindowState() {
        val v = root ?: return
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val op = Prefs.int(this, Prefs.OPACITY, 92) / 100f
        val flags = if (locked) BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else BASE_FLAGS
        val a = if (locked) min(op, 0.8f) else op
        if (lp.flags != flags || lp.alpha != a) {
            lp.flags = flags
            lp.alpha = a
            try { wm.updateViewLayout(v, lp) } catch (t: Throwable) { }
        }
        if (locked) showDot() else hideDot()
    }

    private fun showDot() {
        if (dot != null) { posDot(); return }
        val d = DotView(this)
        val sz = (30 * resources.displayMetrics.density).toInt()
        val l = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT)
        l.gravity = Gravity.TOP or Gravity.START
        d.onTap = { toggleLock() }
        try {
            wm.addView(d, l)
            dot = d
            dotLp = l
            posDot()
        } catch (t: Throwable) { }
    }

    private fun hideDot() {
        dot?.let { try { wm.removeView(it) } catch (t: Throwable) { } }
        dot = null
        dotLp = null
    }

    private fun posDot() {
        val d = dot ?: return
        val l = dotLp ?: return
        val r = root ?: return
        val dm = Resources.getSystem().displayMetrics
        val sz = l.width
        l.x = (lp.x + r.width - sz / 2).coerceIn(0, maxOf(0, dm.widthPixels - sz))
        l.y = (lp.y - sz / 2).coerceIn(0, maxOf(0, dm.heightPixels - sz))
        try { wm.updateViewLayout(d, l) } catch (t: Throwable) { }
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Overlay watch", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val lock = PendingIntent.getService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_TOGGLE_LOCK), PendingIntent.FLAG_IMMUTABLE
        )
        val locked = Prefs.bool(this, Prefs.LOCKED, false)
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Bulwark is running")
            .setContentText(if (locked) "Locked - touches pass through to the game." else "Unlocked - drag the overlay anywhere.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, if (locked) "Unlock" else "Lock", lock).build())
            .addAction(Notification.Action.Builder(icon, "Stop", stop).build())
            .build()
    }
}

/** Small round button shown next to a locked overlay so it can be unlocked with one tap. */
class DotView(ctx: Context) : View(ctx) {
    var onTap: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        p.style = Paint.Style.FILL
        p.color = 0xF01B2027.toInt()
        c.drawCircle(cx, cy, w / 2f - 1f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.045f
        p.color = P.MID
        c.drawCircle(cx, cy, w / 2f - 1.5f, p)
        // padlock
        val u = w / 30f
        p.style = Paint.Style.FILL
        r.set(cx - 5.5f * u, cy - 1f * u, cx + 5.5f * u, cy + 7f * u)
        c.drawRoundRect(r, 1.5f * u, 1.5f * u, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * u
        r.set(cx - 3.6f * u, cy - 7f * u, cx + 3.6f * u, cy + 1f * u)
        c.drawArc(r, 180f, 180f, false, p)
        c.drawLine(cx - 3.6f * u, cy - 3f * u, cx - 3.6f * u, cy, p)
        c.drawLine(cx + 3.6f * u, cy - 3f * u, cx + 3.6f * u, cy, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()
        return true
    }
}
