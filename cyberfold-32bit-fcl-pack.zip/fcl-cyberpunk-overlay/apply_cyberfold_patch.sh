#!/usr/bin/env bash
set -euo pipefail

FCL_DIR="${1:-fcl-source}"
OVERLAY_DIR="${2:-.}"

echo "Applying CyberFold 32-bit theme & configs into $FCL_DIR..."

RES_VAL_DIR="$FCL_DIR/FCL/src/main/res/values"
RES_DRW_DIR="$FCL_DIR/FCL/src/main/res/drawable"
ASSETS_CFG_DIR="$FCL_DIR/FCL/src/main/assets/cyberfold"

mkdir -p "$RES_VAL_DIR" "$RES_DRW_DIR" "$ASSETS_CFG_DIR"

cp "$OVERLAY_DIR/fcl-cyberpunk-overlay/res/values/cyberfold_colors.xml" "$RES_VAL_DIR/cyberfold_colors.xml"
cp "$OVERLAY_DIR/fcl-cyberpunk-overlay/res/values/cyberfold_themes.xml" "$RES_VAL_DIR/cyberfold_themes.xml"
cp "$OVERLAY_DIR/fcl-cyberpunk-overlay/res/drawable/bg_cyberfold_drawer.xml" "$RES_DRW_DIR/bg_cyberfold_drawer.xml"
cp "$OVERLAY_DIR/fcl-cyberpunk-overlay/res/drawable/bg_cyberfold_chamfer_key.xml" "$RES_DRW_DIR/bg_cyberfold_chamfer_key.xml"
cp "$OVERLAY_DIR/configs/fcl_32bit_1.12.2_optimized.json" "$ASSETS_CFG_DIR/fcl_32bit_1.12.2_optimized.json"
cp "$OVERLAY_DIR/controls/cyberfold_chamfered_layout.json" "$ASSETS_CFG_DIR/cyberfold_chamfered_layout.json"

echo "CyberFold overlay applied cleanly."
