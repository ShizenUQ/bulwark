# CyberFold 32 — Custom Fold Craft Launcher (32-Bit armeabi-v7a) Pack

This bundle contains your customized CyberFold theme overlays, modular floating HUD config, chamfered virtual keyboard JSON, 32-bit Forge 1.12.2 crash-prevention configs, and an automated GitHub Actions workflow to compile your 32-bit APK from `FCL-Team/FoldCraftLauncher`.

## How to Build & Download Your 32-Bit APK on GitHub

1. Create a new repository on GitHub (public or private).
2. Extract this ZIP and push all files (including `.github/workflows/build-fcl-32bit.yml`) to the `main` branch.
3. Open the **Actions** tab in your GitHub repository.
4. Select **Build CyberFold 32-Bit FCL APK** and click **Run workflow** (or let the push trigger it automatically).
5. Once finished, download **CyberFold-FCL-armeabi-v7a-APK** from the workflow Artifacts directly onto your Android phone and install the `.apk`.

## Applying Your 32-Bit 1.12.2 Forge Stability Files

- **Java Runtime**: Set instance runtime to **Java 8 (JRE 8)** — never JRE 17/21 for 1.12.2.
- **Renderer**: Use **HOLY-GL4ES** with `LIBGL_NOERROR=1`.
- **Memory Ceiling**: Heap capped at **896 MB** (`-Xss512k`, `-XX:MaxDirectMemorySize=128M`) so the 32-bit process stays safely under Android's ~1.2–1.5 GB virtual address space limit.
- **Config Files**: Copy `configs/splash.properties` and `configs/options.txt` into your instance's `.minecraft/config/` and `.minecraft/` folders, and import `controls/cyberfold_chamfered_layout.json` inside FCL's Controller Manager.
