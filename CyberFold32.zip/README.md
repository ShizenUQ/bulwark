# CyberFold 32 — Custom Fold Craft Launcher (32-Bit armeabi-v7a) Pack

This ZIP (`CyberFold32.zip`) patches **FCL-Team/FoldCraftLauncher (v1.3.4.9)** directly at build time—replacing stock sky-blue theme engine defaults, card/menu XML drawables, launcher wallpapers, virtual button styles, the in-game floating MenuView orb, and 32-bit Forge 1.12.2 JVM/memory caps.

## How to Build & Download Your 32-Bit APK on GitHub

1. Upload **`CyberFold32.zip`** directly to the **top level** of your repository (keep the exact filename).
2. Place **`.github/workflows/build-cyberfold-32bit.yml`** inside `.github/workflows/`.
3. Open **Actions** → **Build CyberFold 32 (32-bit)** → **Run workflow**.
4. Download **`CyberFold32-32bit-apk`** and install on your 32-bit Android phone.
