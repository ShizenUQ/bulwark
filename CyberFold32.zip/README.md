# CyberFold 32 — Custom Fold Craft Launcher (32-Bit armeabi-v7a) Pack

This ZIP (`CyberFold32.zip`) patches **FCL-Team/FoldCraftLauncher (v1.3.4.9)** with CyberFold 32's Home Command Center, 32-bit Forge 1.12.2 Optimizer, In-APK Crash Analyzer & Fixer, Cyber-Glass HUD & Chamfered Hex Badge, and launch-time 32-bit safety enforcement.

## How to Build & Download Your 32-Bit APK on GitHub

1. Upload **`CyberFold32.zip`** directly to the **top level** of your repository (keep the exact filename).
2. Place **`.github/workflows/build-cyberfold-32bit.yml`** inside `.github/workflows/`.
3. Open **Actions** → **Build CyberFold 32 (32-bit)** → **Run workflow**.
4. Download **`CyberFold32-32bit-apk`** and install on your 32-bit Android phone.
