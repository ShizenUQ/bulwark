# CyberFold 32 — Custom Fold Craft Launcher (32-Bit armeabi-v7a) Pack

This ZIP (`CyberFold32.zip`) is designed for direct GitHub Actions APK compilation against **FCL-Team/FoldCraftLauncher (v1.3.4.9)**.

## How to Build & Download Your 32-Bit APK on GitHub

1. Create a GitHub repository.
2. Upload **`CyberFold32.zip`** directly to the **top level** of your repository (do not rename it).
3. Add **`.github/workflows/build-cyberfold-32bit.yml`** (included inside this ZIP or downloaded from the CyberFold Studio Export tab) to your repository.
4. Go to the **Actions** tab, select **Build CyberFold 32 (32-bit)**, and click **Run workflow**.
5. Download the **`CyberFold32-32bit-apk`** artifact onto your 32-bit Android phone and install it.

## Applying Your 32-Bit 1.12.2 Forge Stability Files

- **Java Runtime**: Set instance runtime to **Java 8 (JRE 8)** — never JRE 17/21 for 1.12.2.
- **Renderer**: Use **HOLY-GL4ES** with `LIBGL_NOERROR=1`.
- **Memory Ceiling**: Heap capped at **896 MB** (`-Xss512k`, `-XX:MaxDirectMemorySize=128M`) so the 32-bit process stays safely under Android's ~1.2–1.5 GB virtual address space limit.
- **Config Files**: Copy `configs/splash.properties` and `configs/options.txt` into your instance's `.minecraft/config/` and `.minecraft/` folders, and import `controls/cyberfold_chamfered_layout.json` inside FCL's Controller Manager.
