package com.tungsten.fcl.cyberfold;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.mio.data.Renderer;
import com.mio.manager.RendererManager;
import com.tungsten.fcl.setting.GameOption;
import com.tungsten.fcl.setting.Profile;
import com.tungsten.fcl.setting.Profiles;
import com.tungsten.fcl.setting.VersionSetting;
import com.tungsten.fclauncher.utils.Architecture;
import com.tungsten.fclcore.util.io.FileUtils;
import com.tungsten.fclcore.util.platform.MemoryUtils;
import com.tungsten.fcllibrary.component.dialog.FCLAlertDialog;

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.Map;

/**
 * Native CyberFold 32 Runtime Optimizer & Crash Analyzer.
 * Built directly into the APK to stabilize 32-bit (armeabi-v7a) Forge 1.12.2 sessions.
 */
public final class CyberFoldOptimizer {
    private static final String PREF_NAME = "cyberfold";
    private static final String KEY_SAFE_MODE = "safe_mode_32bit";
    private static final String KEY_PENDING_FIX = "pending_32bit_fix";
    private static final int SAFE_CAP_MB = 896;

    private CyberFoldOptimizer() {}

    public static boolean isSafeGuardEnabled(Context context) {
        if (context == null) return true;
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_SAFE_MODE, true);
    }

    public static void setSafeGuardEnabled(Context context, boolean enabled) {
        if (context == null) return;
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SAFE_MODE, enabled)
                .apply();
    }

    public static String getShortBadge(Context context) {
        try {
            Profile profile = Profiles.getSelectedProfile();
            VersionSetting vs = profile.getVersionSetting();
            boolean heapSafe = !Architecture.is32BitsDevice() || vs.getMaxMemory() <= 960;
            boolean argsSafe = vs.getJavaArgs() != null && vs.getJavaArgs().contains("MaxDirectMemorySize");
            if (heapSafe && argsSafe && isSafeGuardEnabled(context)) {
                return "32B SAFE // " + vs.getMaxMemory() + "M";
            }
            return "TUNE 32-BIT (" + vs.getMaxMemory() + "M)";
        } catch (Throwable t) {
            return isSafeGuardEnabled(context) ? "GUARD ACTIVE" : "GUARD OFF";
        }
    }

    public static String getStatusText(Context context) {
        StringBuilder sb = new StringBuilder();
        try {
            Profile profile = Profiles.getSelectedProfile();
            String ver = profile.getSelectedVersion();
            VersionSetting vs = profile.getVersionSetting();
            boolean is32 = Architecture.is32BitsDevice();
            int totalRam = MemoryUtils.getTotalDeviceMemory(context);
            int freeRam = MemoryUtils.getFreeDeviceMemory(context);
            String rendererName = RendererManager.getRenderer(vs.getRenderer()).getName();
            boolean guardOn = isSafeGuardEnabled(context);

            sb.append("TARGET    : ").append(ver != null && !ver.isEmpty() ? ver : "No Version Selected").append("\n");
            sb.append("ABI / RAM : ").append(is32 ? "32-bit armeabi-v7a" : "64-bit ARM")
              .append(" (").append(freeRam).append("/").append(totalRam).append(" MB free)\n");
            sb.append("HEAP CAP  : ").append(vs.getMaxMemory()).append(" MB")
              .append(vs.getMaxMemory() > 960 ? "  [HIGH RISK ON 32-BIT]" : "  [SAFE CEILING]").append("\n");
            sb.append("RENDERER  : ").append(rendererName).append("\n");
            sb.append("32B GUARD : ").append(guardOn ? "ARMED (LIBGL_NOERROR + Splash Off + Mipmap 0)" : "DISABLED");

            if (ver != null && !ver.isEmpty()) {
                File runDir = profile.getRepository().getRunDirectory(ver);
                File splashFile = new File(new File(runDir, "config"), "splash.properties");
                boolean splashOff = splashFile.exists();
                sb.append("\nSPLASH    : ").append(splashOff ? "splash.properties ready" : "Not patched yet (Tap Optimize)");
            }
        } catch (Throwable t) {
            sb.append("Select or install a Minecraft version on the right dock to optimize 32-bit settings.");
        }
        return sb.toString();
    }

    public static String optimizeActiveProfile(Context context) {
        setSafeGuardEnabled(context, true);
        StringBuilder report = new StringBuilder();
        try {
            Profile profile = Profiles.getSelectedProfile();
            String ver = profile.getSelectedVersion();
            VersionSetting vs = profile.getVersionSetting();

            int oldHeap = vs.getMaxMemory();
            int targetHeap = Math.min(Math.max(oldHeap, 512), SAFE_CAP_MB);
            vs.setAutoMemory(false);
            vs.setMaxMemory(targetHeap);
            report.append("• Heap Cap: ").append(oldHeap).append(" MB -> ").append(targetHeap).append(" MB (32-bit virtual space safe)\n");

            String currentRenderer = vs.getRenderer();
            if (!Renderer.ID_GL4ES.equals(currentRenderer) && !Renderer.ID_NGGL4ES.equals(currentRenderer)) {
                vs.setRenderer(Renderer.ID_GL4ES);
                report.append("• Renderer: Switched to Holy-GL4ES (safest for 1.12.2 modded entities)\n");
            } else {
                report.append("• Renderer: Kept ").append(RendererManager.getRenderer(currentRenderer).getName()).append("\n");
            }

            String safeFlags = CyberFoldTheme.SAFE_JVM_ARGS;
            String existingArgs = vs.getJavaArgs() == null ? "" : vs.getJavaArgs().trim();
            if (!existingArgs.contains("-XX:MaxDirectMemorySize=")) {
                vs.setJavaArgs(existingArgs.isEmpty() ? safeFlags : existingArgs + " " + safeFlags);
                report.append("• JVM Guard Flags: Added -Xss512k, -XX:MaxDirectMemorySize=128M, G1GC, fml.readTimeout=120\n");
            } else {
                report.append("• JVM Guard Flags: Already hardened\n");
            }

            ensureLauncherEnv(context);
            report.append("• OpenGL Env: Forced LIBGL_NOERROR=1 & LIBGL_MIPMAP=0\n");

            if (ver != null && !ver.isEmpty()) {
                File runDir = profile.getRepository().getRunDirectory(ver);
                if (runDir != null) {
                    if (!runDir.exists()) runDir.mkdirs();
                    enforcePreLaunchSafety(context, runDir, null);
                    report.append("• Forge Splash & Video: Disabled splash.properties, set mipmapLevels=0 & entityShadows=false\n");
                }
                if (!vs.isUsesGlobal()) {
                    profile.getRepository().saveVersionSetting(ver);
                }
            }
        } catch (Throwable t) {
            report.append("• Applied global 32-bit guard preferences (").append(t.getMessage()).append(")");
        }
        return report.toString().trim();
    }

    private static void ensureLauncherEnv(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        String current = prefs.getString("env", "");
        StringBuilder updated = new StringBuilder();
        boolean hasNoErr = false;
        boolean hasMip = false;
        for (String line : current.split("\\n")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;
            if (trimmed.startsWith("LIBGL_NOERROR=")) {
                updated.append("LIBGL_NOERROR=1\n");
                hasNoErr = true;
            } else if (trimmed.startsWith("LIBGL_MIPMAP=")) {
                updated.append("LIBGL_MIPMAP=0\n");
                hasMip = true;
            } else {
                updated.append(trimmed).append("\n");
            }
        }
        if (!hasNoErr) updated.append("LIBGL_NOERROR=1\n");
        if (!hasMip) updated.append("LIBGL_MIPMAP=0\n");
        prefs.edit().putString("env", updated.toString().trim()).commit();
    }

    public static void enforcePreLaunchSafety(Context context, File runDir, GameOption existingOption) {
        if (!isSafeGuardEnabled(context) || runDir == null) return;
        try {
            File configDir = new File(runDir, "config");
            if (!configDir.exists()) configDir.mkdirs();
            FileUtils.writeText(new File(configDir, "splash.properties"), "enabled=false\n");

            GameOption opt = existingOption != null ? existingOption : new GameOption(runDir.getAbsolutePath());
            opt.set("mipmapLevels", "0");
            opt.set("entityShadows", "false");
            opt.set("useVbo", "true");
            opt.set("fancyGraphics", "false");
            if (existingOption == null) {
                opt.save();
            }
        } catch (Throwable ignored) {
        }
    }

    public static void applySafeEnv(Context context, Map<String, String> envMap) {
        if (context == null || envMap == null || !isSafeGuardEnabled(context)) return;
        envMap.put("LIBGL_NOERROR", "1");
        envMap.put("LIBGL_MIPMAP", "0");
    }

    public static String analyzeCrashLog(String log) {
        if (log == null || log.trim().isEmpty()) {
            return "=== CYBERFOLD 32 CRASH ANALYZER ===\nNo crash log text provided yet.";
        }
        String lower = log.toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder("=== CYBERFOLD 32 CRASH DIAGNOSIS ===\n");
        int issues = 0;

        if (lower.contains("shutting down internal server") || lower.contains("exception in server tick loop")) {
            issues++;
            sb.append("[!] Signature: 'Shutting down internal server' / Server Tick Fault\n")
              .append("    -> Caused by entity/tick failure or 32-bit virtual memory exhaustion while walking/loading chunks.\n");
        }
        if (lower.contains("outofmemoryerror") || lower.contains("direct buffer memory")
                || lower.contains("unable to create new native thread") || lower.contains("sigsegv")
                || lower.contains("native memory allocation")) {
            issues++;
            sb.append("[!] Signature: 32-Bit Native / Virtual Address Space Exhaustion\n")
              .append("    -> Keep heap <= 896 MB with -Xss512k & -XX:MaxDirectMemorySize=128M.\n");
        }
        if (lower.contains("openglexception") || lower.contains("gl_out_of_memory")
                || lower.contains("gl4es") || lower.contains("virgl") || lower.contains("framebuffers")) {
            issues++;
            sb.append("[!] Signature: OpenGL / Entity Shader State Abort\n")
              .append("    -> Switch to Holy-GL4ES, keep LIBGL_NOERROR=1, set mipmapLevels=0 & entityShadows=false.\n");
        }
        if (lower.contains("ticking entity") || lower.contains("ticking block entity")
                || lower.contains("playerinteractevent") || lower.contains("rightclickblock")) {
            issues++;
            sb.append("[!] Signature: Modded Entity / Interaction Tick Crash\n")
              .append("    -> Pair 32-bit Safe Guard with VanillaFix + FoamFix (1.12.2) so faulty entity ticks do not kill the server.\n");
        }
        if (lower.contains("unsupportedclassversionerror") || lower.contains("class file version")) {
            issues++;
            sb.append("[!] Signature: Wrong Java Runtime Version\n")
              .append("    -> Forge 1.12.2 requires Java 8 (JRE 8), not JRE 17/21.\n");
        }
        if (issues == 0) {
            sb.append("[OK] No known 32-bit fatal crash signature matched in header. Safe Guard remains recommended.\n");
        }
        sb.append("====================================");
        return sb.toString();
    }

    public static String scanLatestCrashOrLog(Context context) {
        StringBuilder out = new StringBuilder();
        try {
            Profile profile = Profiles.getSelectedProfile();
            String ver = profile.getSelectedVersion();
            out.append(getStatusText(context)).append("\n\n");
            if (ver != null && !ver.isEmpty()) {
                File runDir = profile.getRepository().getRunDirectory(ver);
                File crashDir = new File(runDir, "crash-reports");
                File targetFile = null;
                if (crashDir.isDirectory()) {
                    File[] files = crashDir.listFiles((d, n) -> n.endsWith(".txt"));
                    if (files != null && files.length > 0) {
                        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
                        targetFile = files[0];
                    }
                }
                if (targetFile == null) {
                    File latestLog = new File(new File(runDir, "logs"), "latest.log");
                    if (latestLog.isFile()) targetFile = latestLog;
                }
                if (targetFile != null) {
                    out.append("Scanned File: ").append(targetFile.getName()).append("\n\n");
                    String content = FileUtils.readText(targetFile);
                    if (content.length() > 64000) {
                        content = content.substring(content.length() - 64000);
                    }
                    out.append(analyzeCrashLog(content));
                } else {
                    out.append("No crash-reports or latest.log found for ").append(ver).append(" yet.");
                }
            }
        } catch (Throwable t) {
            out.append("Scan error: ").append(t.getMessage());
        }
        return out.toString();
    }

    public static void showOptimizerDialog(Context context, Runnable onApplied) {
        String msg = getStatusText(context) + "\n\nTap 'Optimize Now' to apply 32-bit Safe Heap (<= " + SAFE_CAP_MB
                + " MB), Holy-GL4ES, LIBGL_NOERROR=1, safe JVM GC/stack args, and Forge splash/mipmap optimization.";
        FCLAlertDialog.Builder builder = new FCLAlertDialog.Builder(context);
        builder.setAlertLevel(FCLAlertDialog.AlertLevel.INFO);
        builder.setTitle("CyberFold 32-Bit Forge Optimizer");
        builder.setMessage(msg);
        builder.setPositiveButton("Optimize Now", () -> {
            String summary = optimizeActiveProfile(context);
            if (onApplied != null) onApplied.run();
            FCLAlertDialog.Builder done = new FCLAlertDialog.Builder(context);
            done.setAlertLevel(FCLAlertDialog.AlertLevel.INFO);
            done.setTitle("32-Bit Optimization Applied");
            done.setMessage(summary);
            done.setPositiveButton("OK", null);
            done.create().show();
        });
        builder.setNegativeButton("Close", null);
        builder.create().show();
    }

    public static void showCrashScanDialog(Context context, Runnable onApplied) {
        String scanResult = scanLatestCrashOrLog(context);
        FCLAlertDialog.Builder builder = new FCLAlertDialog.Builder(context);
        builder.setAlertLevel(FCLAlertDialog.AlertLevel.INFO);
        builder.setTitle("CyberFold 32 Crash Scanner");
        builder.setMessage(scanResult);
        builder.setPositiveButton("Apply 32-Bit Fix", () -> {
            optimizeActiveProfile(context);
            if (onApplied != null) onApplied.run();
            Toast.makeText(context, "CyberFold 32-bit fixes applied!", Toast.LENGTH_SHORT).show();
        });
        builder.setNegativeButton("Close", null);
        builder.create().show();
    }

    public static void schedulePendingFix(Context context) {
        if (context == null) return;
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SAFE_MODE, true)
                .putBoolean(KEY_PENDING_FIX, true)
                .commit();
        ensureLauncherEnv(context);
    }

    public static void applyPendingFixIfNeeded(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_PENDING_FIX, false)) {
            prefs.edit().putBoolean(KEY_PENDING_FIX, false).commit();
            optimizeActiveProfile(context);
            Toast.makeText(context, "CyberFold 32: 32-Bit Crash Fix Applied", Toast.LENGTH_LONG).show();
        }
    }
}
