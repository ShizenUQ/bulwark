#!/usr/bin/env python3
import re
import shutil
from pathlib import Path

def upsert_color(xml_text: str, name: str, value: str) -> str:
    pattern = rf'(<color\s+name="{re.escape(name)}"[^>]*>)([^<]*)(</color>)'
    if re.search(pattern, xml_text):
        return re.sub(pattern, rf'\g<1>{value}\g<3>', xml_text, count=1)
    return xml_text

def main():
    src_root = Path.cwd()
    patch_root = Path(__file__).resolve().parent

    print(f"[CyberFold 32] Patching FCL source in: {src_root}")

    java_target = src_root / "FCL" / "src" / "main" / "java" / "com" / "tungsten" / "fcl" / "cyberfold"
    res_val_target = src_root / "FCL" / "src" / "main" / "res" / "values"
    res_drw_target = src_root / "FCL" / "src" / "main" / "res" / "drawable"
    assets_target = src_root / "FCL" / "src" / "main" / "assets" / "cyberfold"

    for d in (java_target, res_val_target, res_drw_target, assets_target):
        d.mkdir(parents=True, exist_ok=True)

    shutil.copy2(patch_root / "CyberFoldTheme.java", java_target / "CyberFoldTheme.java")

    overlay_val = patch_root / "fcl-cyberpunk-overlay" / "res" / "values"
    for xml_file in overlay_val.glob("*.xml"):
        shutil.copy2(xml_file, res_val_target / xml_file.name)

    overlay_drw = patch_root / "fcl-cyberpunk-overlay" / "res" / "drawable"
    for xml_file in overlay_drw.glob("*.xml"):
        shutil.copy2(xml_file, res_drw_target / xml_file.name)

    for folder in ("configs", "controls"):
        src_folder = patch_root / folder
        if src_folder.exists():
            for item in src_folder.iterdir():
                if item.is_file():
                    shutil.copy2(item, assets_target / item.name)

    # Safely update existing primary/accent colors in colors.xml without creating duplicates
    fcl_colors = res_val_target / "colors.xml"
    if fcl_colors.exists():
        content = fcl_colors.read_text(encoding="utf-8")
        updated = upsert_color(content, "colorPrimary", "#00E5FF")
        updated = upsert_color(updated, "colorAccent", "#FF2A85")
        updated = upsert_color(updated, "colorSecondary", "#FF2A85")
        if updated != content:
            fcl_colors.write_text(updated, encoding="utf-8")
            print("[CyberFold 32] Updated existing FCL accent tokens in colors.xml.")

    print("[CyberFold 32] Patch applied cleanly.")

if __name__ == "__main__":
    main()
