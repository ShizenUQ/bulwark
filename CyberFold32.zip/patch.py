#!/usr/bin/env python3
import re
import shutil
from pathlib import Path

PRIMARY_HEX = "#00E5FF"
SECONDARY_HEX = "#FF2A85"
GLASS_ALPHA = 194
SAFE_32_RAM = 896
SAFE_JVM_ARGS = "-Dfml.readTimeout=120 -Dcyberfold.safeHeapMb=896"

def replace_once(path: Path, old: str, new: str, label: str) -> bool:
    if not path.exists():
        print(f"[CyberFold 32] WARN missing {path}")
        return False
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    old_norm = old.replace("\r\n", "\n")
    if old_norm in text:
        path.write_text(text.replace(old_norm, new, 1), encoding="utf-8")
        print(f"[CyberFold 32] Patched {label}")
        return True
    print(f"[CyberFold 32] SKIP {label} (pattern not matched)")
    return False

def replace_all(path: Path, old: str, new: str, label: str) -> bool:
    if not path.exists():
        print(f"[CyberFold 32] WARN missing {path}")
        return False
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    old_norm = old.replace("\r\n", "\n")
    if old_norm in text:
        path.write_text(text.replace(old_norm, new), encoding="utf-8")
        print(f"[CyberFold 32] Patched {label}")
        return True
    print(f"[CyberFold 32] SKIP {label} (pattern not matched)")
    return False

def upsert_color(xml_text: str, name: str, value: str) -> str:
    pattern = rf'(<color\s+name="{re.escape(name)}"[^>]*>)([^<]*)(</color>)'
    if re.search(pattern, xml_text):
        return re.sub(pattern, rf'\g<1>{value}\g<3>', xml_text, count=1)
    return xml_text

def main():
    src_root = Path.cwd()
    patch_root = Path(__file__).resolve().parent
    fcl_main = src_root / "FCL" / "src" / "main"
    java_root = fcl_main / "java"
    res_val_target = fcl_main / "res" / "values"
    res_night_target = fcl_main / "res" / "values-night"
    res_drw_target = fcl_main / "res" / "drawable"
    res_lay_target = fcl_main / "res" / "layout"
    assets_target = fcl_main / "assets" / "cyberfold"

    primary_bare = PRIMARY_HEX.lstrip("#")
    secondary_bare = SECONDARY_HEX.lstrip("#")

    print(f"[CyberFold 32] Deep-patching FCL source + features in: {src_root}")

    cyber_pkg = java_root / "com" / "tungsten" / "fcl" / "cyberfold"
    for d in (cyber_pkg, res_val_target, res_night_target, res_drw_target, res_lay_target, assets_target):
        d.mkdir(parents=True, exist_ok=True)

    # 1. Install CyberFoldTheme.java, CyberFoldOptimizer.java, & bundled assets
    shutil.copy2(patch_root / "CyberFoldTheme.java", cyber_pkg / "CyberFoldTheme.java")
    shutil.copy2(patch_root / "CyberFoldOptimizer.java", cyber_pkg / "CyberFoldOptimizer.java")
    for folder in ("configs", "controls"):
        src_folder = patch_root / folder
        if src_folder.exists():
            for item in src_folder.iterdir():
                if item.is_file():
                    shutil.copy2(item, assets_target / item.name)

    # 2. Replace launcher wallpapers (light & dark) and floating MenuView orb image
    bg_cyber = patch_root / "assets" / "background_cyber.jpg"
    if bg_cyber.exists():
        shutil.copy2(bg_cyber, res_drw_target / "background_dark.jpg")
        shutil.copy2(bg_cyber, res_drw_target / "background_light.jpg")
        print("[CyberFold 32] Replaced background_dark.jpg & background_light.jpg")

    orb_cyber = patch_root / "assets" / "cyberfold_orb.jpg"
    if orb_cyber.exists():
        shutil.copy2(orb_cyber, res_drw_target / "cyberfold_orb.jpg")
        print("[CyberFold 32] Installed cyberfold_orb.jpg")

    # 3. Overwrite XML drawables & color overlays
    overlay_val = patch_root / "fcl-cyberpunk-overlay" / "res" / "values"
    for xml_file in overlay_val.glob("*.xml"):
        shutil.copy2(xml_file, res_val_target / xml_file.name)

    overlay_drw = patch_root / "fcl-cyberpunk-overlay" / "res" / "drawable"
    for xml_file in overlay_drw.glob("*.xml"):
        shutil.copy2(xml_file, res_drw_target / xml_file.name)

    # 4. Update FCL colors.xml, values-night/colors.xml, & strings.xml
    fcl_colors = res_val_target / "colors.xml"
    if fcl_colors.exists():
        txt = fcl_colors.read_text(encoding="utf-8")
        for k, v in [
            ("default_theme_color", "#0A1424"),
            ("default_theme_color_dark", "#080E1A"),
            ("ui_bg_color", "#CC0B111E"),
            ("right_menu_color", "#D9080D18"),
            ("icon_background_color", "#0E1626"),
            ("primary_text", "#F1F5F9"),
            ("dialog_background", "#E60B111E"),
        ]:
            txt = upsert_color(txt, k, v)
        fcl_colors.write_text(txt, encoding="utf-8")
        print("[CyberFold 32] Updated values/colors.xml")

    fcl_night_colors = res_night_target / "colors.xml"
    if fcl_night_colors.exists():
        txt = fcl_night_colors.read_text(encoding="utf-8")
        txt = upsert_color(txt, "primary_text", "#F1F5F9")
        txt = upsert_color(txt, "dialog_background", "#E60B111E")
        fcl_night_colors.write_text(txt, encoding="utf-8")
        print("[CyberFold 32] Updated values-night/colors.xml")

    strings_xml = res_val_target / "strings.xml"
    replace_once(
        strings_xml,
        '<string name="app_name" translatable="false">Fold Craft Launcher</string>',
        '<string name="app_name" translatable="false">CyberFold 32</string>',
        "strings.xml app_name"
    )
    replace_once(
        strings_xml,
        "</resources>",
        """    <string name="cyberfold_opt_title">CyberFold 32-Bit Forge Optimizer</string>
    <string name="cyberfold_opt_desc">Cap 32-bit heap &lt;= 896M, force Holy-GL4ES + LIBGL_NOERROR, disable Forge splash &amp; optimize JVM flags.</string>
    <string name="cyberfold_fix_crash_btn">Fix 32-Bit Crash</string>
</resources>""",
        "strings.xml cyberfold strings"
    )

    # 5. Patch ThemePreference.kt & ThemeEngine.kt & ThemeData.kt
    theme_pref = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "theme" / "ThemePreference.kt"
    replace_once(theme_pref, "0xFF7797CF.toInt()", "0xFF0A1424.toInt()", "ThemePreference light color")
    replace_once(theme_pref, "0xFF4E77C1.toInt()", "0xFF0A1424.toInt()", "ThemePreference dark color")
    replace_once(theme_pref, "0xFF000000.toInt()", f"0xFF{primary_bare}.toInt()", "ThemePreference color2")
    replace_once(theme_pref, "0xFFFFFFFF.toInt()", f"0xFF{primary_bare}.toInt()", "ThemePreference color2Dark")
    replace_once(theme_pref, "val colorAlpha: Int = 255", f"val colorAlpha: Int = {GLASS_ALPHA}", "ThemePreference colorAlpha")

    theme_engine = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "theme" / "ThemeEngine.kt"
    replace_once(theme_engine, '.getInt("themeMode", 0)', '.getInt("themeMode", 2)', "ThemeEngine force dark default")

    theme_data = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "theme" / "ThemeData.kt"
    replace_once(theme_data, "deriveColor(getColor(), brighten = true)", "Color.argb(colorAlpha, 14, 22, 40)", "ThemeData ltColor smoked glass")
    replace_once(theme_data, "deriveColor(getColor(), brighten = false)", f'Color.parseColor("{PRIMARY_HEX}")', "ThemeData dkColor neon cyan")
    replace_once(theme_data, "if (ColorUtils.calculateLuminance(getColor()) >= 0.5) Color.BLACK else Color.WHITE", "0xFFF1F5F9.toInt()", "ThemeData autoTint white")
    replace_once(theme_data, "if (ColorUtils.calculateLuminance(getColor()) >= 0.5) 0x99000000.toInt() else 0x99FFFFFF.toInt()", "0xAA94A3B8.toInt()", "ThemeData autoHintTint")
    replace_once(theme_data, "ltColor or 0xFF000000.toInt()", f'Color.parseColor("{PRIMARY_HEX}")', "ThemeData opaqueLtColor")
    replace_once(theme_data, "getColor() or 0xFF000000.toInt()", "0xFF64748B.toInt()", "ThemeData opaqueColor")

    # 6. Patch FCLConstraintLayout.kt, FCLLinearLayout.java, FCLButton.java, FCLTabLayout.java, FCLDynamicIsland.java
    fcl_constraint = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLConstraintLayout.kt"
    replace_once(
        fcl_constraint,
        """        ThemeEngine.getInstance().registerEvent(this) {
            if (autoTint) {
                setBackgroundTintList(
                    ColorStateList(
                        arrayOf<IntArray?>(intArrayOf()),
                        intArrayOf(ThemeEngine.getInstance().getTheme().ltColor)
                    )
                )
            }
        }""",
        f"""        ThemeEngine.getInstance().registerEvent(this) {{
            if (autoTint) {{
                val glass = android.graphics.drawable.GradientDrawable().apply {{
                    setColor(ThemeEngine.getInstance().getTheme().ltColor)
                    setStroke(
                        com.tungsten.fcllibrary.util.ConvertUtils.dip2px(context, 1f),
                        android.graphics.Color.parseColor("#59{primary_bare}")
                    )
                    cornerRadius = com.tungsten.fcllibrary.util.ConvertUtils.dip2px(context, 6f).toFloat()
                }}
                setBackgroundTintList(null)
                background = android.graphics.drawable.RippleDrawable(
                    ColorStateList.valueOf(android.graphics.Color.parseColor("#33{primary_bare}")),
                    glass,
                    glass
                )
            }}
        }}""",
        "FCLConstraintLayout cyber-glass border"
    )

    fcl_linear = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLLinearLayout.java"
    replace_once(
        fcl_linear,
        "setBackgroundTintList(new ColorStateList(new int[][] { { } }, new int[] { ThemeEngine.getInstance().getTheme().getLtColor() }));",
        f"""android.graphics.drawable.GradientDrawable glass = new android.graphics.drawable.GradientDrawable();
                glass.setColor(ThemeEngine.getInstance().getTheme().getLtColor());
                glass.setStroke(com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 1f), android.graphics.Color.parseColor("#59{primary_bare}"));
                glass.setCornerRadius(com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 6f));
                setBackgroundTintList(null);
                setBackground(glass);""",
        "FCLLinearLayout cyber-glass border"
    )

    fcl_button = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLButton.java"
    replace_once(
        fcl_button,
        """    public void setRipple() {
        setBackgroundDrawable(getContext().getDrawable(R.drawable.fcl_button));
        int[][] state = {
                {

                }
        };
        int[] color = {
                ThemeEngine.getInstance().getTheme().getColor()
        };
        setBackgroundTintList(new ColorStateList(state, color));
        applyTextColor(ThemeEngine.getInstance().getTheme().getAutoTint());
    }""",
        f"""    public void setRipple() {{
        drawableNormal.setColor(0xC20B1324);
        drawableNormal.setStroke(ConvertUtils.dip2px(getContext(), 1.2f), Color.parseColor("{PRIMARY_HEX}"));
        setBackgroundTintList(null);
        setBackgroundDrawable(new android.graphics.drawable.RippleDrawable(
                ColorStateList.valueOf(Color.parseColor("#44{primary_bare}")),
                drawableNormal,
                drawableNormal
        ));
        applyTextColor(0xFFF1F5F9);
    }}""",
        "FCLButton setRipple cyber-glass"
    )
    replace_all(
        fcl_button,
        "drawableNormal.setColor(Color.TRANSPARENT);",
        f'drawableNormal.setColor(0xB80B1324); drawableNormal.setStroke(ConvertUtils.dip2px(getContext(), 1.2f), Color.parseColor("{PRIMARY_HEX}"));',
        "FCLButton cyber fill+stroke"
    )
    replace_all(
        fcl_button,
        "drawablePress.setColor(ThemeEngine.getInstance().getTheme().getLtColor());",
        f'drawablePress.setColor(Color.parseColor("{SECONDARY_HEX}"));',
        "FCLButton press glow"
    )
    replace_once(fcl_button, "applyTextColor(ThemeEngine.getInstance().getTheme().getOpaqueLtColor());", "applyTextColor(0xFFF1F5F9);", "FCLButton normal text color")
    replace_all(fcl_button, "applyTextColor(ThemeEngine.getInstance().getTheme().getAutoTint());", "applyTextColor(0xFF080B12);", "FCLButton press text color")
    replace_once(fcl_button, "applyTextColor(ThemeEngine.getInstance().getTheme().getLtColor());", "applyTextColor(0xFFF1F5F9);", "FCLButton release text color")
    replace_all(fcl_button, "ConvertUtils.dip2px(getContext(), 8)", "ConvertUtils.dip2px(getContext(), 4)", "FCLButton crisp chamfer radius")

    fcl_tab = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLTabLayout.java"
    replace_once(
        fcl_tab,
        "followTheme ? ThemeEngine.getInstance().getTheme().getAutoTint() : Color.GRAY",
        "0xFF94A3B8",
        "FCLTabLayout unselected text"
    )
    replace_once(
        fcl_tab,
        "setBackgroundTintList(new ColorStateList(bgState, bgColor));",
        f"""android.graphics.drawable.GradientDrawable tabGlass = new android.graphics.drawable.GradientDrawable();
                tabGlass.setColor(ThemeEngine.getInstance().getTheme().getLtColor());
                tabGlass.setStroke(com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 1f), android.graphics.Color.parseColor("#59{primary_bare}"));
                float tabR = com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 6f);
                tabGlass.setCornerRadii(new float[]{{tabR, tabR, tabR, tabR, 0f, 0f, 0f, 0f}});
                setBackgroundTintList(null);
                setBackground(tabGlass);""",
        "FCLTabLayout cyber-glass strip"
    )

    fcl_island = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLDynamicIsland.java"
    replace_once(
        fcl_island,
        """        outlinePath = new Path();
        outlinePath.moveTo(offset + (height / 2), offset);
        outlinePath.arcTo(offset, offset, offset + height, offset + height, 270, -180, false);
        outlinePath.lineTo(offset + width - (height / 2), height + offset);
        outlinePath.arcTo(offset + width - height, offset, width + offset, height + offset, 90, -180, false);
        outlinePath.lineTo(offset + (height / 2), offset);""",
        """        float cut = Math.min(height * 0.36f, width * 0.25f);
        outlinePath = new Path();
        outlinePath.moveTo(offset + cut, offset);
        outlinePath.lineTo(offset + width - cut, offset);
        outlinePath.lineTo(offset + width, offset + cut);
        outlinePath.lineTo(offset + width, offset + height - cut);
        outlinePath.lineTo(offset + width - cut, offset + height);
        outlinePath.lineTo(offset + cut, offset + height);
        outlinePath.lineTo(offset, offset + height - cut);
        outlinePath.lineTo(offset, offset + cut);
        outlinePath.close();""",
        "FCLDynamicIsland chamfered hex badge"
    )
    replace_all(
        fcl_island,
        "outlinePaint.setStrokeWidth(ConvertUtils.dip2px(getContext(), 3));",
        "outlinePaint.setStrokeWidth(ConvertUtils.dip2px(getContext(), 1.5f));",
        "FCLDynamicIsland crisp rim width"
    )

    # 7. Overhaul activity_main.xml & MainActivity.kt (Top Cyber Command Rail + Full-Width Stage + Bottom Launch Dock)
    act_main_xml = res_lay_target / "activity_main.xml"
    act_main_xml.write_text(f"""<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/background"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:transitionName="background"
    tools:context=".activity.MainActivity">

    <VideoView
        android:id="@+id/video_view"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

    <!-- Top Cyber Command Rail (replaces FCL's left vertical sidebar) -->
    <androidx.constraintlayout.widget.ConstraintLayout
        android:id="@+id/left_menu"
        android:layout_width="0dp"
        android:layout_height="46dp"
        android:layout_marginStart="10dp"
        android:layout_marginTop="6dp"
        android:layout_marginEnd="10dp"
        android:background="@drawable/bg_game_menu"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:elevation="100dp"
        android:paddingStart="10dp"
        android:paddingEnd="10dp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent">

        <ImageView
            android:id="@+id/cyberfold_logo"
            android:layout_width="26dp"
            android:layout_height="26dp"
            android:scaleType="centerCrop"
            android:src="@drawable/cyberfold_orb"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/home"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="8dp"
            android:src="@drawable/ic_baseline_home_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/cyberfold_logo"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/manage"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="4dp"
            android:src="@drawable/ic_baseline_build_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/home"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/download"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="4dp"
            android:src="@drawable/ic_baseline_cloud_download_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/manage"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/controller"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="4dp"
            android:src="@drawable/ic_baseline_videogame_asset_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/download"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/multiplayer"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="4dp"
            android:src="@drawable/ic_outline_account_tree_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/controller"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/setting"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="4dp"
            android:src="@drawable/ic_baseline_settings_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/multiplayer"
            app:layout_constraintTop_toTopOf="parent" />

        <com.tungsten.fcllibrary.component.view.FCLMenuView
            android:id="@+id/back"
            android:layout_width="36dp"
            android:layout_height="36dp"
            android:layout_marginStart="4dp"
            android:src="@drawable/ic_baseline_arrow_back_24"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintStart_toEndOf="@id/setting"
            app:layout_constraintTop_toTopOf="parent" />

    </androidx.constraintlayout.widget.ConstraintLayout>

    <!-- Full-Width Cyber Workspace -->
    <androidx.viewpager2.widget.ViewPager2
        android:id="@+id/ui_layout"
        android:layout_width="0dp"
        android:layout_height="0dp"
        android:layout_marginHorizontal="6dp"
        android:layout_marginVertical="4dp"
        app:layout_constraintBottom_toTopOf="@id/right_menu"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@id/left_menu" />

    <!-- Bottom Tactical Launch Dock (replaces FCL's right 25% column) -->
    <androidx.constraintlayout.widget.ConstraintLayout
        android:id="@+id/right_menu"
        android:layout_width="0dp"
        android:layout_height="70dp"
        android:layout_marginStart="10dp"
        android:layout_marginEnd="10dp"
        android:layout_marginBottom="6dp"
        android:background="@drawable/bg_right_menu"
        android:clipChildren="false"
        android:clipToPadding="false"
        android:elevation="100dp"
        android:paddingStart="10dp"
        android:paddingEnd="10dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent">

        <androidx.constraintlayout.widget.ConstraintLayout
            android:id="@+id/right_menu_content"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:clipChildren="false"
            android:clipToPadding="false"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent">

            <com.mio.ui.view.WaveProgressView
                android:id="@+id/download_wave_progress"
                android:layout_width="0dp"
                android:layout_height="4dp"
                android:visibility="gone"
                app:layout_constraintEnd_toEndOf="parent"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toTopOf="parent" />

            <androidx.constraintlayout.widget.ConstraintLayout
                android:id="@+id/account"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:background="?android:attr/selectableItemBackgroundBorderless"
                android:clickable="true"
                android:clipChildren="false"
                android:clipToPadding="false"
                android:focusable="true"
                android:paddingEnd="8dp"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toTopOf="parent">

                <com.tungsten.fcllibrary.component.view.FCLImageView
                    android:id="@+id/avatar"
                    android:layout_width="38dp"
                    android:layout_height="38dp"
                    android:elevation="50dp"
                    android:focusable="true"
                    android:stateListAnimator="@xml/anim_scale_large"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintStart_toStartOf="parent"
                    app:layout_constraintTop_toTopOf="parent" />

                <com.tungsten.fcllibrary.component.view.FCLTextView
                    android:id="@+id/account_name"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:maxWidth="130dp"
                    android:singleLine="true"
                    android:text="@string/account_state_no_account"
                    android:textSize="13sp"
                    android:textStyle="bold"
                    app:layout_constraintBottom_toTopOf="@id/account_hint"
                    app:layout_constraintStart_toEndOf="@id/avatar"
                    app:layout_constraintTop_toTopOf="parent"
                    app:layout_constraintVertical_chainStyle="packed"
                    app:use_theme_color="true" />

                <com.tungsten.fcllibrary.component.view.FCLTextView
                    android:id="@+id/account_hint"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:maxWidth="130dp"
                    android:singleLine="true"
                    android:text="@string/account_state_add"
                    android:textSize="10sp"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintStart_toEndOf="@id/avatar"
                    app:layout_constraintTop_toBottomOf="@id/account_name"
                    app:use_theme_color="true" />
            </androidx.constraintlayout.widget.ConstraintLayout>

            <androidx.constraintlayout.widget.ConstraintLayout
                android:id="@+id/version_card"
                android:layout_width="0dp"
                android:layout_height="48dp"
                android:layout_marginStart="8dp"
                android:layout_marginEnd="10dp"
                android:clickable="true"
                android:focusable="true"
                android:paddingStart="8dp"
                android:paddingTop="4dp"
                android:paddingEnd="4dp"
                android:paddingBottom="4dp"
                android:stateListAnimator="@xml/anim_scale"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintEnd_toStartOf="@id/start"
                app:layout_constraintStart_toEndOf="@id/account"
                app:layout_constraintTop_toTopOf="parent">

                <com.tungsten.fcllibrary.component.view.FCLImageView
                    android:id="@+id/icon"
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:scaleType="fitCenter"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintStart_toStartOf="parent"
                    app:layout_constraintTop_toTopOf="parent" />

                <com.tungsten.fcllibrary.component.view.FCLTextView
                    android:id="@+id/version_name"
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:ellipsize="marquee"
                    android:marqueeRepeatLimit="marquee_forever"
                    android:singleLine="true"
                    android:textSize="13sp"
                    android:textStyle="bold"
                    app:layout_constraintBottom_toTopOf="@id/version_hint"
                    app:layout_constraintEnd_toStartOf="@id/go_setting"
                    app:layout_constraintStart_toEndOf="@id/icon"
                    app:layout_constraintTop_toTopOf="parent"
                    app:layout_constraintVertical_chainStyle="packed"
                    app:use_theme_color="true"
                    tools:text="1.12.2-Forge" />

                <com.tungsten.fcllibrary.component.view.FCLTextView
                    android:id="@+id/version_hint"
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_marginStart="8dp"
                    android:ellipsize="end"
                    android:singleLine="true"
                    android:textSize="10sp"
                    android:visibility="gone"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintEnd_toStartOf="@id/go_setting"
                    app:layout_constraintStart_toEndOf="@id/icon"
                    app:layout_constraintTop_toBottomOf="@id/version_name"
                    app:use_theme_color="true"
                    tools:text="1.12.2, Forge" />

                <com.tungsten.fcllibrary.component.view.FCLImageButton
                    android:id="@+id/go_setting"
                    android:layout_width="28dp"
                    android:layout_height="28dp"
                    android:src="@drawable/ic_baseline_settings_24"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintEnd_toEndOf="parent"
                    app:layout_constraintTop_toTopOf="parent"
                    app:no_padding="true"
                    app:use_theme_color="true" />

                <com.tungsten.fcllibrary.component.view.FCLProgressBar
                    android:id="@+id/version_progress"
                    android:layout_width="wrap_content"
                    android:layout_height="0dp"
                    android:orientation="horizontal"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintEnd_toEndOf="parent"
                    app:layout_constraintStart_toStartOf="parent"
                    app:layout_constraintTop_toTopOf="parent" />
            </androidx.constraintlayout.widget.ConstraintLayout>

            <androidx.constraintlayout.widget.ConstraintLayout
                android:id="@+id/start"
                android:layout_width="wrap_content"
                android:layout_height="46dp"
                android:clickable="true"
                android:elevation="200dp"
                android:focusable="true"
                android:minWidth="128dp"
                android:paddingStart="16dp"
                android:paddingEnd="16dp"
                android:stateListAnimator="@xml/anim_scale"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintEnd_toEndOf="parent"
                app:layout_constraintTop_toTopOf="parent">

                <com.tungsten.fcllibrary.component.view.FCLImageView
                    android:id="@+id/icon_start"
                    android:layout_width="18dp"
                    android:layout_height="18dp"
                    android:layout_marginEnd="6dp"
                    android:background="@drawable/ic_start"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintEnd_toStartOf="@id/text_start"
                    app:layout_constraintHorizontal_chainStyle="packed"
                    app:layout_constraintStart_toStartOf="parent"
                    app:layout_constraintTop_toTopOf="parent"
                    app:use_theme_color="true" />

                <com.tungsten.fcllibrary.component.view.FCLTextView
                    android:id="@+id/text_start"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:gravity="center"
                    android:text="@string/launch"
                    android:textSize="15sp"
                    android:textStyle="bold"
                    app:layout_constraintBottom_toBottomOf="parent"
                    app:layout_constraintEnd_toEndOf="parent"
                    app:layout_constraintStart_toEndOf="@id/icon_start"
                    app:layout_constraintTop_toTopOf="parent"
                    app:use_theme_color="true" />
            </androidx.constraintlayout.widget.ConstraintLayout>
        </androidx.constraintlayout.widget.ConstraintLayout>

        <com.mio.ui.view.DownloadSlidePanel
            android:id="@+id/download_panel"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:visibility="invisible"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent" />
    </androidx.constraintlayout.widget.ConstraintLayout>

    <!-- Chamfered Page Tag Docked Top-Right Inside Header Rail -->
    <com.tungsten.fcllibrary.component.view.FCLDynamicIsland
        android:id="@+id/title"
        android:layout_width="wrap_content"
        android:layout_height="34dp"
        android:layout_marginEnd="10dp"
        android:elevation="120dp"
        android:stateListAnimator="@null"
        app:layout_constraintBottom_toBottomOf="@id/left_menu"
        app:layout_constraintEnd_toEndOf="@id/left_menu"
        app:layout_constraintTop_toTopOf="@id/left_menu" />

</androidx.constraintlayout.widget.ConstraintLayout>
""", encoding="utf-8")
    print("[CyberFold 32] Wrote Top-Rail + Bottom-Dock activity_main.xml")

    main_act = java_root / "com" / "tungsten" / "fcl" / "activity" / "MainActivity.kt"
    replace_once(
        main_act,
        """                    leftMenu.background = GradientDrawable().apply {
                        setColor(ThemeEngine.getInstance().getTheme().getColor())
                        shape = GradientDrawable.RECTANGLE
                        ConvertUtils.dip2px(this@MainActivity, 8f).toFloat().apply {
                            cornerRadii = floatArrayOf(0f, 0f, this, this, this, this, 0f, 0f)
                        }
                    }""",
        f"""                    leftMenu.background = GradientDrawable().apply {{
                        setColor(Color.argb(232, 8, 13, 24))
                        setStroke(ConvertUtils.dip2px(this@MainActivity, 1.4f), Color.parseColor("{PRIMARY_HEX}"))
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = ConvertUtils.dip2px(this@MainActivity, 8f).toFloat()
                    }}
                    rightMenu.background = GradientDrawable().apply {{
                        setColor(Color.argb(236, 8, 13, 24))
                        setStroke(ConvertUtils.dip2px(this@MainActivity, 1.4f), Color.parseColor("#80{primary_bare}"))
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = ConvertUtils.dip2px(this@MainActivity, 8f).toFloat()
                    }}
                    versionCard.background = GradientDrawable().apply {{
                        setColor(Color.argb(204, 14, 22, 40))
                        setStroke(ConvertUtils.dip2px(this@MainActivity, 1f), Color.parseColor("#66{primary_bare}"))
                        cornerRadius = ConvertUtils.dip2px(this@MainActivity, 6f).toFloat()
                    }}""",
        "MainActivity cyber top rail & bottom dock styling"
    )
    replace_once(
        main_act,
        "                        if (inRightMenu(twoFingerStartX) && inRightMenu(secondFingerStartX)) {",
        "                        if (false && inRightMenu(twoFingerStartX) && inRightMenu(secondFingerStartX)) {",
        "MainActivity keep bottom launch dock pinned"
    )
    replace_once(
        main_act,
        """    private fun fixSkinViewerPosition(fix: Boolean) {
        val ui = UIManager.instance.currentUI""",
        """    private fun fixSkinViewerPosition(fix: Boolean) {
        return
        val ui = UIManager.instance.currentUI""",
        "MainActivity preserve CyberFold Home split proportions"
    )
    replace_once(
        main_act,
        """    private fun createBackground(): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ConvertUtils.dip2px(this@MainActivity, 8f).toFloat()
            setStroke(
                ConvertUtils.dip2px(this@MainActivity, 1f),
                ThemeEngine.getInstance().getTheme().getColor2()
            )
        }
    }""",
        f"""    private fun createBackground(): GradientDrawable {{
        return GradientDrawable().apply {{
            setColor(Color.argb(232, 12, 22, 42))
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ConvertUtils.dip2px(this@MainActivity, 6f).toFloat()
            setStroke(
                ConvertUtils.dip2px(this@MainActivity, 1.5f),
                Color.parseColor("{SECONDARY_HEX}")
            )
        }}
    }}""",
        "MainActivity createBackground Launch button"
    )
    replace_once(
        main_act,
        """    private fun playAnim() {
        binding.apply {
            val speed = ThemeEngine.getInstance().getTheme().animationSpeed
            AnimUtil.playTranslationX(
                listOf(leftMenu),
                speed * 100L,
                -100f,
                0f
            ).forEach {
                it.interpolator(BounceInterpolator()).start()
            }
            AnimUtil.playTranslationX(
                listOf(rightMenu),
                speed * 100L,
                100f,
                0f
            ).forEach {
                it.interpolator(BounceInterpolator()).start()
            }
            AnimUtil.playTranslationY(
                listOf(start, versionCard),
                speed * 100L,
                -200f,
                0f
            ).forEachIndexed { index, objectAnimator ->
                objectAnimator.interpolator(BounceInterpolator()).startAfter((index + 1) * 100L)
            }
            AnimUtil.playTranslationY(
                listOf(home, manage, download, controller, multiplayer, setting, back),
                speed * 100L,
                -300f,
                0f
            ).forEachIndexed { index, objectAnimator ->
                objectAnimator.interpolator(BounceInterpolator()).startAfter((index + 1) * 100L)
            }
            AnimUtil.playTranslationX(
                listOf(home, manage, download, controller, multiplayer, setting, back),
                speed * 100L,
                -100f,
                0f
            ).forEachIndexed { index, objectAnimator ->
                objectAnimator.interpolator(BounceInterpolator()).startAfter((index + 1) * 100L)
            }
        }
    }""",
        """    private fun playAnim() {
        binding.apply {
            val speed = ThemeEngine.getInstance().getTheme().animationSpeed
            AnimUtil.playTranslationY(
                listOf(leftMenu),
                speed * 90L,
                -80f,
                0f
            ).forEach {
                it.interpolator(BounceInterpolator()).start()
            }
            AnimUtil.playTranslationY(
                listOf(rightMenu),
                speed * 90L,
                80f,
                0f
            ).forEach {
                it.interpolator(BounceInterpolator()).start()
            }
        }
    }""",
        "MainActivity top-down & bottom-up cyber slide animation"
    )

    # 8. Overhaul Home Screen (ui_main.xml + MainUI.java) with real CyberFold 32 Command Center!
    ui_main_xml = res_lay_target / "ui_main.xml"
    ui_main_xml.write_text(f"""<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="12dp">

    <!-- CyberFold 32 Home Command Center (32-bit Optimizer, Crash Scanner, Safe Guard) -->
    <androidx.constraintlayout.widget.ConstraintLayout
        android:id="@+id/cyberfold_deck"
        android:layout_width="0dp"
        android:layout_height="0dp"
        android:background="@drawable/bg_cyber_deck"
        android:padding="14dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintWidth_percent="0.60">

        <com.tungsten.fcllibrary.component.view.FCLTextView
            android:id="@+id/cyberfold_header"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:singleLine="true"
            android:text="CYBERFOLD 32 // 32-BIT FORGE DECK"
            android:textColor="{PRIMARY_HEX}"
            android:textSize="14sp"
            android:textStyle="bold"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent" />

        <View
            android:id="@+id/cyberfold_divider"
            android:layout_width="0dp"
            android:layout_height="1dp"
            android:layout_marginTop="8dp"
            android:background="#59{primary_bare}"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/cyberfold_header" />

        <ScrollView
            android:id="@+id/cyberfold_scroll"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:layout_marginTop="8dp"
            android:layout_marginBottom="10dp"
            app:layout_constraintBottom_toTopOf="@id/cyberfold_btn_optimize"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/cyberfold_divider">

            <com.tungsten.fcllibrary.component.view.FCLTextView
                android:id="@+id/cyberfold_status_text"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:fontFamily="monospace"
                android:lineSpacingExtra="3dp"
                android:text="Initializing CyberFold 32-bit telemetry..."
                android:textColor="#E2E8F0"
                android:textSize="11sp" />
        </ScrollView>

        <com.tungsten.fcllibrary.component.view.FCLButton
            android:id="@+id/cyberfold_btn_optimize"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginBottom="8dp"
            android:text="APPLY SAFE 32-BIT HEAP CAP (MAX 896M)"
            android:textSize="12sp"
            app:layout_constraintBottom_toTopOf="@id/cyberfold_btn_scan"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:ripple="true" />

        <com.tungsten.fcllibrary.component.view.FCLButton
            android:id="@+id/cyberfold_btn_scan"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginEnd="6dp"
            android:text="SCAN CRASHES"
            android:textSize="11sp"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintEnd_toStartOf="@id/cyberfold_btn_guard"
            app:layout_constraintStart_toStartOf="parent"
            app:ripple="true" />

        <com.tungsten.fcllibrary.component.view.FCLButton
            android:id="@+id/cyberfold_btn_guard"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_marginStart="6dp"
            android:text="GUARD: ON"
            android:textSize="11sp"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toEndOf="@id/cyberfold_btn_scan"
            app:ripple="true" />

    </androidx.constraintlayout.widget.ConstraintLayout>

    <androidx.appcompat.widget.LinearLayoutCompat
        android:id="@+id/announcement_container"
        android:layout_width="0dp"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:visibility="gone"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintWidth_percent="0.60">

        <androidx.appcompat.widget.LinearLayoutCompat
            android:id="@+id/announcement_layout"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            android:layout_weight="1"
            android:background="@drawable/bg_container_white"
            android:orientation="vertical">

            <com.tungsten.fcllibrary.component.view.FCLTextView
                android:id="@+id/title"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="center"
                android:padding="10dp"
                android:singleLine="true"
                android:text="@string/announcement"
                app:auto_text_tint="true" />

            <View
                android:layout_width="match_parent"
                android:layout_height="1dp"
                android:background="#59{primary_bare}" />

            <ScrollView
                android:layout_width="match_parent"
                android:layout_height="0dp"
                android:layout_weight="1">

                <com.tungsten.fcllibrary.component.view.FCLTextView
                    android:id="@+id/announcement"
                    android:layout_width="match_parent"
                    android:layout_height="wrap_content"
                    android:autoLink="web"
                    android:padding="10dp"
                    android:textColorLink="{PRIMARY_HEX}"
                    app:auto_text_tint="true" />
            </ScrollView>

            <View
                android:layout_width="match_parent"
                android:layout_height="1dp"
                android:background="#59{primary_bare}" />

            <com.tungsten.fcllibrary.component.view.FCLTextView
                android:id="@+id/date"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_gravity="center"
                android:padding="10dp"
                android:singleLine="true"
                android:text="@string/update_date"
                app:auto_text_tint="true" />
        </androidx.appcompat.widget.LinearLayoutCompat>

        <com.tungsten.fcllibrary.component.view.FCLButton
            android:id="@+id/hide"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="10dp"
            android:text="@string/button_hide"
            app:ripple="true" />
    </androidx.appcompat.widget.LinearLayoutCompat>

    <com.mio.skin.SkinViewer
        android:id="@+id/skin_viewer"
        android:layout_width="0dp"
        android:layout_height="0dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintHeight_percent="0.82"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintWidth_percent="0.38" />
</androidx.constraintlayout.widget.ConstraintLayout>
""", encoding="utf-8")
    print("[CyberFold 32] Wrote CyberFold Command Center ui_main.xml")

    main_ui = java_root / "com" / "tungsten" / "fcl" / "ui" / "main" / "MainUI.java"
    replace_once(
        main_ui,
        "import com.tungsten.fcl.R;",
        """import android.widget.Toast;
import com.tungsten.fcl.R;
import com.tungsten.fcl.cyberfold.CyberFoldOptimizer;
import com.tungsten.fcl.setting.Profiles;""",
        "MainUI CyberFold imports"
    )
    replace_once(
        main_ui,
        "    private FCLButton hide;",
        """    private FCLButton hide;
    private View cyberfoldDeck;
    private FCLTextView cyberfoldStatusText;
    private FCLButton cyberfoldBtnOptimize;
    private FCLButton cyberfoldBtnScan;
    private FCLButton cyberfoldBtnGuard;""",
        "MainUI CyberFold fields"
    )
    replace_once(
        main_ui,
        "        hide.setOnClickListener(this);",
        """        hide.setOnClickListener(this);
        cyberfoldDeck = findViewById(R.id.cyberfold_deck);
        cyberfoldStatusText = findViewById(R.id.cyberfold_status_text);
        cyberfoldBtnOptimize = findViewById(R.id.cyberfold_btn_optimize);
        cyberfoldBtnScan = findViewById(R.id.cyberfold_btn_scan);
        cyberfoldBtnGuard = findViewById(R.id.cyberfold_btn_guard);
        CyberFoldOptimizer.applyPendingFixIfNeeded(getContext());
        if (cyberfoldBtnOptimize != null) {
            cyberfoldBtnOptimize.setOnClickListener(v -> CyberFoldOptimizer.showOptimizerDialog(getContext(), this::refreshCyberFoldDeck));
        }
        if (cyberfoldBtnScan != null) {
            cyberfoldBtnScan.setOnClickListener(v -> CyberFoldOptimizer.showCrashScanDialog(getContext(), this::refreshCyberFoldDeck));
        }
        if (cyberfoldBtnGuard != null) {
            cyberfoldBtnGuard.setOnClickListener(v -> {
                boolean next = !CyberFoldOptimizer.isSafeGuardEnabled(getContext());
                CyberFoldOptimizer.setSafeGuardEnabled(getContext(), next);
                refreshCyberFoldDeck();
                Toast.makeText(getContext(), next ? "CyberFold 32-Bit Guard ARMED" : "CyberFold 32-Bit Guard DISABLED", Toast.LENGTH_SHORT).show();
            });
        }
        Profiles.addSelectedProfileListener(this::refreshCyberFoldDeck);
        refreshCyberFoldDeck();""",
        "MainUI CyberFold deck wiring"
    )
    replace_once(
        main_ui,
        """    @Override
    public void onResume() {
        super.onResume();""",
        """    private void refreshCyberFoldDeck() {
        Schedulers.androidUIThread().execute(() -> {
            if (cyberfoldStatusText != null) {
                cyberfoldStatusText.setText(CyberFoldOptimizer.getStatusText(getContext()));
            }
            if (cyberfoldBtnGuard != null) {
                cyberfoldBtnGuard.setText(CyberFoldOptimizer.isSafeGuardEnabled(getContext()) ? "GUARD: ON" : "GUARD: OFF");
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshCyberFoldDeck();""",
        "MainUI refreshCyberFoldDeck onResume"
    )
    replace_once(
        main_ui,
        "                        announcementContainer.setVisibility(View.VISIBLE);",
        "                        if (cyberfoldDeck != null) cyberfoldDeck.setVisibility(View.GONE); announcementContainer.setVisibility(View.VISIBLE);",
        "MainUI announcement hide deck"
    )
    replace_once(
        main_ui,
        """    private void hideAnnouncement() {
        announcementContainer.setVisibility(View.GONE);""",
        """    private void hideAnnouncement() {
        announcementContainer.setVisibility(View.GONE);
        if (cyberfoldDeck != null) cyberfoldDeck.setVisibility(View.VISIBLE);""",
        "MainUI hideAnnouncement restore deck"
    )

    # 9. Patch Game Settings (VersionSettingAdapter.kt & VersionSettingPage.kt)
    vsa = java_root / "com" / "tungsten" / "fcl" / "ui" / "manage" / "VersionSettingAdapter.kt"
    replace_once(
        vsa,
        """    // 特殊开关行
    SPECIAL,""",
        """    // 特殊开关行
    CYBERFOLD_OPTIMIZER,
    SPECIAL,""",
        "VersionSettingTag CYBERFOLD_OPTIMIZER"
    )
    replace_once(
        vsa,
        """        if (globalSetting || enableSpecific) {
            result += Row.ValueRow(""",
        """        if (globalSetting || enableSpecific) {
            result += Row.ValueRow(
                R.string.cyberfold_opt_title,
                { com.tungsten.fcl.cyberfold.CyberFoldOptimizer.getShortBadge(context) },
                VersionSettingTag.CYBERFOLD_OPTIMIZER,
                null,
                descriptionRes = R.string.cyberfold_opt_desc,
                group = SettingGroup.Common
            )
            result += Row.ValueRow(""",
        "VersionSettingAdapter CyberFold Optimizer row"
    )
    replace_once(
        vsa,
        """        ThemeEngine.getInstance().registerEvent(holder.itemView) {
            holder.itemView.backgroundTintList =
                ColorStateList.valueOf(ThemeEngine.getInstance().getTheme().ltColor)
        }""",
        """        ThemeEngine.getInstance().registerEvent(holder.itemView) {
            holder.itemView.backgroundTintList = null
        }""",
        "VersionSettingAdapter preserve cyan card strokes"
    )

    vsp = java_root / "com" / "tungsten" / "fcl" / "ui" / "manage" / "VersionSettingPage.kt"
    replace_once(
        vsp,
        "        when (tag) {",
        """        when (tag) {
            VersionSettingTag.CYBERFOLD_OPTIMIZER -> {
                com.tungsten.fcl.cyberfold.CyberFoldOptimizer.showOptimizerDialog(context) {
                    loadVersion(profile, versionId)
                }
            }""",
        "VersionSettingPage CYBERFOLD_OPTIMIZER click handler"
    )

    # 10. Patch FCLGameLauncher.java & FCLauncher.java (Real launch-time 32-bit safety enforcement)
    fcl_game_launcher = java_root / "com" / "tungsten" / "fcl" / "game" / "FCLGameLauncher.java"
    replace_once(
        fcl_game_launcher,
        """        fixOptions(gameOption);
        gameOption.save();""",
        """        fixOptions(gameOption);
        com.tungsten.fcl.cyberfold.CyberFoldOptimizer.enforcePreLaunchSafety(context, repository.getRunDirectory(version.getId()), gameOption);
        gameOption.save();""",
        "FCLGameLauncher enforcePreLaunchSafety"
    )

    fcl_launcher = java_root / "com" / "tungsten" / "fclauncher" / "FCLauncher.java"
    replace_once(
        fcl_launcher,
        """        addCustomEnv(config, envMap);
        printTaskTitle(bridge, "Env Map");""",
        """        addCustomEnv(config, envMap);
        com.tungsten.fcl.cyberfold.CyberFoldOptimizer.applySafeEnv(config.getContext(), envMap);
        printTaskTitle(bridge, "Env Map");""",
        "FCLauncher applySafeEnv"
    )

    # 11. Patch In-Game Floating HUD & Drawers (MenuView.kt, ControlButtonStyle.java, GameMenu.java, view_game_menu.xml, menu_left.xml)
    menu_view = java_root / "com" / "tungsten" / "fcl" / "control" / "view" / "MenuView.kt"
    replace_once(menu_view, "color = Color.DKGRAY", f'color = Color.parseColor("{PRIMARY_HEX}")', "MenuView cyan ring")
    replace_once(menu_view, "R.drawable.img_app", "R.drawable.cyberfold_orb", "MenuView cyberfold_orb")
    replace_once(
        menu_view,
        """            destRect = Rect(
                ConvertUtils.dip2px(context, 6f),
                ConvertUtils.dip2px(context, 6f),
                ConvertUtils.dip2px(context, 34f),
                ConvertUtils.dip2px(context, 34f),
            )""",
        """            destRect = Rect(
                ConvertUtils.dip2px(context, 8f),
                ConvertUtils.dip2px(context, 8f),
                ConvertUtils.dip2px(context, 32f),
                ConvertUtils.dip2px(context, 32f),
            )""",
        "MenuView emblem inset"
    )
    replace_once(menu_view, "areaPaint.color = context.getColor(R.color.ui_bg_color)", "areaPaint.color = 0xE6142038.toInt()", "MenuView pressed fill")
    replace_once(menu_view, "areaPaint.color = Color.TRANSPARENT", "areaPaint.color = 0xCC080B12.toInt()", "MenuView obsidian fill")

    btn_style = java_root / "com" / "tungsten" / "fcl" / "control" / "data" / "ControlButtonStyle.java"
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "strokeWidth", 10)', 'new SimpleIntegerProperty(this, "strokeWidth", 15)', "ControlButtonStyle strokeWidth")
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "strokeColor", Color.DKGRAY)', f'new SimpleIntegerProperty(this, "strokeColor", Color.parseColor("{PRIMARY_HEX}"))', "ControlButtonStyle cyan stroke")
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "cornerRadius", 100)', 'new SimpleIntegerProperty(this, "cornerRadius", 40)', "ControlButtonStyle chamfer corner")
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "fillColor", Color.TRANSPARENT)', 'new SimpleIntegerProperty(this, "fillColor", 0x990A1120)', "ControlButtonStyle glass fill")

    view_game_menu = res_lay_target / "view_game_menu.xml"
    replace_once(
        view_game_menu,
        """        <com.mio.ui.view.DraggableTextView
            android:id="@+id/fps"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerHorizontal="true"
            android:layout_centerVertical="true"
            android:gravity="start"
            android:textStyle="bold"
            app:save_key="fps"
            app:use_theme_color="true" />

        <com.mio.ui.view.DraggableTextView
            android:id="@+id/memory"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerHorizontal="true"
            android:layout_centerVertical="true"
            android:gravity="start"
            android:textStyle="bold"
            app:save_key="memory"
            app:use_theme_color="true" />""",
        """        <com.mio.ui.view.DraggableTextView
            android:id="@+id/fps"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerHorizontal="true"
            android:layout_centerVertical="true"
            android:background="@drawable/bg_cyber_hud_chip"
            android:fontFamily="monospace"
            android:gravity="start"
            android:paddingHorizontal="8dp"
            android:paddingVertical="3dp"
            android:textSize="11sp"
            android:textStyle="bold"
            app:save_key="fps"
            app:use_theme_color="true" />

        <com.mio.ui.view.DraggableTextView
            android:id="@+id/memory"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_centerHorizontal="true"
            android:layout_centerVertical="true"
            android:background="@drawable/bg_cyber_hud_chip"
            android:fontFamily="monospace"
            android:gravity="start"
            android:paddingHorizontal="8dp"
            android:paddingVertical="3dp"
            android:textSize="11sp"
            android:textStyle="bold"
            app:save_key="memory"
            app:use_theme_color="true" />""",
        "view_game_menu.xml cyber HUD chips"
    )

    game_menu = java_root / "com" / "tungsten" / "fcl" / "control" / "GameMenu.java"
    replace_once(
        game_menu,
        'fpsText.setText("FPS:" + FCLBridge.getFps())',
        'fpsText.setText("FPS // " + FCLBridge.getFps())',
        "GameMenu cyber FPS readout"
    )
    replace_once(
        game_menu,
        'memoryText.setText("Mem(" + usage + "%): " + usedMemory + " / " + totalMemory + " MB")',
        'memoryText.setText("32B MEM // " + usedMemory + "/" + totalMemory + " MB (" + usage + "%)")',
        "GameMenu cyber MEM readout"
    )

    menu_left = res_lay_target / "menu_left.xml"
    replace_once(
        menu_left,
        'android:text="@string/menu_controls"',
        'android:text="CYBERFOLD // CONTROLS"',
        "menu_left.xml CyberFold header"
    )

    # 12. Patch JVMCrashActivity.kt & activity_jvm_crash.xml (In-APK Crash Analyzer + One-Tap 32-Bit Fix)
    crash_xml = res_lay_target / "activity_jvm_crash.xml"
    replace_once(
        crash_xml,
        """    <com.tungsten.fcllibrary.component.view.FCLButton
        android:id="@+id/restart"
        style="@style/FCLCrashButton"
        android:text="@string/crash_reporter_restart"
        app:layout_constraintBottom_toTopOf="@+id/close"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toEndOf="@+id/split" />""",
        """    <com.tungsten.fcllibrary.component.view.FCLButton
        android:id="@+id/cyberfold_fix_crash"
        style="@style/FCLCrashButton"
        android:text="@string/cyberfold_fix_crash_btn"
        app:layout_constraintBottom_toTopOf="@+id/restart"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toEndOf="@+id/split" />

    <com.tungsten.fcllibrary.component.view.FCLButton
        android:id="@+id/restart"
        style="@style/FCLCrashButton"
        android:text="@string/crash_reporter_restart"
        app:layout_constraintBottom_toTopOf="@+id/close"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toEndOf="@+id/split" />""",
        "activity_jvm_crash.xml Fix 32-Bit Crash button"
    )

    jvm_crash = java_root / "com" / "tungsten" / "fcl" / "activity" / "JVMCrashActivity.kt"
    replace_once(
        jvm_crash,
        "        binding.restart.setOnClickListener(this)",
        """        binding.cyberfoldFixCrash.setOnClickListener(this)
        binding.restart.setOnClickListener(this)""",
        "JVMCrashActivity bind cyberfoldFixCrash"
    )
    replace_once(
        jvm_crash,
        '        errorLines.forEach { it: String? -> binding.error.append(it + "\\n") }',
        """        binding.error.append(com.tungsten.fcl.cyberfold.CyberFoldOptimizer.analyzeCrashLog(log) + "\\n\\n")
        errorLines.forEach { it: String? -> binding.error.append(it + "\\n") }""",
        "JVMCrashActivity prepend CyberFold diagnosis"
    )
    replace_once(
        jvm_crash,
        "        if (v === binding.restart) {",
        """        if (v === binding.cyberfoldFixCrash) {
            com.tungsten.fcl.cyberfold.CyberFoldOptimizer.schedulePendingFix(this)
            binding.restart.performClick()
            return
        }
        if (v === binding.restart) {""",
        "JVMCrashActivity handle Fix 32-Bit Crash click"
    )

    # 13. Keep 32-bit default RAM allocation safe without injecting risky JVM flags
    mem_utils = java_root / "com" / "tungsten" / "fclcore" / "util" / "platform" / "MemoryUtils.java"
    if mem_utils.exists():
        print("[CyberFold 32] Preserved MemoryUtils safe 32-bit default (768 MB)")

    print("[CyberFold 32] All source, Top-Rail/Bottom-Dock layout, and safe 32-bit patches complete.")

if __name__ == "__main__":
    main()
