#!/usr/bin/env python3
import re
import shutil
from pathlib import Path

PRIMARY_HEX = "#00E5FF"
SECONDARY_HEX = "#FF2A85"
GLASS_ALPHA = 194
SAFE_32_RAM = 896
SAFE_JVM_ARGS = "-Xms512M -Xmx896M -Xss512k -XX:MaxDirectMemorySize=128M -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=150 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1ReservePercent=15 -XX:InitiatingHeapOccupancyPercent=15 -Dfml.readTimeout=120 -Dfml.ignoreInvalidMinecraftCertificates=true -Dfml.ignorePatchDiscrepancies=true -Dorg.lwjgl.opengl.Window.undecorated=true"

def replace_once(path: Path, old: str, new: str, label: str) -> bool:
    if not path.exists():
        print(f"[CyberFold 32] WARN missing {path}")
        return False
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    old_norm = old.replace("\r\n", "\n")
    if old_norm in text:
        path.write_text(text.replace(old_norm, new, 1), encoding="utf-8")
        print(f"[CyberFold 32] Patched {label}")
        return True
    print(f"[CyberFold 32] SKIP {label} (pattern not matched)")
    return False

def replace_all(path: Path, old: str, new: str, label: str) -> bool:
    if not path.exists():
        print(f"[CyberFold 32] WARN missing {path}")
        return False
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    old_norm = old.replace("\r\n", "\n")
    if old_norm in text:
        path.write_text(text.replace(old_norm, new), encoding="utf-8")
        print(f"[CyberFold 32] Patched {label}")
        return True
    print(f"[CyberFold 32] SKIP {label} (pattern not matched)")
    return False

def upsert_color(xml_text: str, name: str, value: str) -> str:
    pattern = rf'(<color\s+name="{re.escape(name)}"[^>]*>)([^<]*)(</color>)'
    if re.search(pattern, xml_text):
        return re.sub(pattern, rf'\g<1>{value}\g<3>', xml_text, count=1)
    return xml_text

def main():
    src_root = Path.cwd()
    patch_root = Path(__file__).resolve().parent
    fcl_main = src_root / "FCL" / "src" / "main"
    java_root = fcl_main / "java"
    res_val_target = fcl_main / "res" / "values"
    res_night_target = fcl_main / "res" / "values-night"
    res_drw_target = fcl_main / "res" / "drawable"
    assets_target = fcl_main / "assets" / "cyberfold"

    primary_bare = PRIMARY_HEX.lstrip("#")
    secondary_bare = SECONDARY_HEX.lstrip("#")

    print(f"[CyberFold 32] Deep-patching FCL source in: {src_root}")

    cyber_pkg = java_root / "com" / "tungsten" / "fcl" / "cyberfold"
    for d in (cyber_pkg, res_val_target, res_night_target, res_drw_target, assets_target):
        d.mkdir(parents=True, exist_ok=True)

    # 1. Install CyberFoldTheme.java & assets
    shutil.copy2(patch_root / "CyberFoldTheme.java", cyber_pkg / "CyberFoldTheme.java")
    for folder in ("configs", "controls"):
        src_folder = patch_root / folder
        if src_folder.exists():
            for item in src_folder.iterdir():
                if item.is_file():
                    shutil.copy2(item, assets_target / item.name)

    # 2. Replace launcher wallpapers (light & dark) and floating MenuView orb image
    bg_cyber = patch_root / "assets" / "background_cyber.jpg"
    if bg_cyber.exists():
        shutil.copy2(bg_cyber, res_drw_target / "background_dark.jpg")
        shutil.copy2(bg_cyber, res_drw_target / "background_light.jpg")
        print("[CyberFold 32] Replaced background_dark.jpg & background_light.jpg")

    orb_cyber = patch_root / "assets" / "cyberfold_orb.jpg"
    if orb_cyber.exists():
        shutil.copy2(orb_cyber, res_drw_target / "cyberfold_orb.jpg")
        print("[CyberFold 32] Installed cyberfold_orb.jpg")

    # 3. Overwrite XML drawables & color overlays
    overlay_val = patch_root / "fcl-cyberpunk-overlay" / "res" / "values"
    for xml_file in overlay_val.glob("*.xml"):
        shutil.copy2(xml_file, res_val_target / xml_file.name)

    overlay_drw = patch_root / "fcl-cyberpunk-overlay" / "res" / "drawable"
    for xml_file in overlay_drw.glob("*.xml"):
        shutil.copy2(xml_file, res_drw_target / xml_file.name)

    # 4. Update FCL colors.xml & values-night/colors.xml & app_name
    fcl_colors = res_val_target / "colors.xml"
    if fcl_colors.exists():
        txt = fcl_colors.read_text(encoding="utf-8")
        for k, v in [
            ("default_theme_color", "#0A1424"),
            ("default_theme_color_dark", "#080E1A"),
            ("ui_bg_color", "#CC0B111E"),
            ("right_menu_color", "#D9080D18"),
            ("icon_background_color", "#0E1626"),
            ("primary_text", "#F1F5F9"),
            ("dialog_background", "#E60B111E"),
        ]:
            txt = upsert_color(txt, k, v)
        fcl_colors.write_text(txt, encoding="utf-8")
        print("[CyberFold 32] Updated values/colors.xml")

    fcl_night_colors = res_night_target / "colors.xml"
    if fcl_night_colors.exists():
        txt = fcl_night_colors.read_text(encoding="utf-8")
        txt = upsert_color(txt, "primary_text", "#F1F5F9")
        txt = upsert_color(txt, "dialog_background", "#E60B111E")
        fcl_night_colors.write_text(txt, encoding="utf-8")
        print("[CyberFold 32] Updated values-night/colors.xml")

    strings_xml = res_val_target / "strings.xml"
    replace_once(
        strings_xml,
        '<string name="app_name" translatable="false">Fold Craft Launcher</string>',
        '<string name="app_name" translatable="false">CyberFold 32</string>',
        "strings.xml app_name"
    )

    # 5. Patch ThemePreference.kt (eliminate stock #7797CF / #4E77C1 sky-blue defaults!)
    theme_pref = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "theme" / "ThemePreference.kt"
    replace_once(theme_pref, "0xFF7797CF.toInt()", "0xFF0A1424.toInt()", "ThemePreference light color")
    replace_once(theme_pref, "0xFF4E77C1.toInt()", "0xFF0A1424.toInt()", "ThemePreference dark color")
    replace_once(theme_pref, "0xFF000000.toInt()", f"0xFF{primary_bare}.toInt()", "ThemePreference color2")
    replace_once(theme_pref, "0xFFFFFFFF.toInt()", f"0xFF{primary_bare}.toInt()", "ThemePreference color2Dark")
    replace_once(theme_pref, "val colorAlpha: Int = 255", f"val colorAlpha: Int = {GLASS_ALPHA}", "ThemePreference colorAlpha")

    # 6. Patch ThemeEngine.kt (force Cyber Dark Mode = 2 by default)
    theme_engine = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "theme" / "ThemeEngine.kt"
    replace_once(theme_engine, '.getInt("themeMode", 0)', '.getInt("themeMode", 2)', "ThemeEngine force dark default")

    # 7. Patch ThemeData.kt (smoked glass ltColor + Neon Cyan dkColor + crisp white text)
    theme_data = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "theme" / "ThemeData.kt"
    replace_once(theme_data, "deriveColor(getColor(), brighten = true)", "Color.argb(colorAlpha, 14, 22, 40)", "ThemeData ltColor smoked glass")
    replace_once(theme_data, "deriveColor(getColor(), brighten = false)", f'Color.parseColor("{PRIMARY_HEX}")', "ThemeData dkColor neon cyan")
    replace_once(theme_data, "if (ColorUtils.calculateLuminance(getColor()) >= 0.5) Color.BLACK else Color.WHITE", "0xFFF1F5F9.toInt()", "ThemeData autoTint white")
    replace_once(theme_data, "if (ColorUtils.calculateLuminance(getColor()) >= 0.5) 0x99000000.toInt() else 0x99FFFFFF.toInt()", "0xAA94A3B8.toInt()", "ThemeData autoHintTint")
    replace_once(theme_data, "ltColor or 0xFF000000.toInt()", f'Color.parseColor("{PRIMARY_HEX}")', "ThemeData opaqueLtColor")
    replace_once(theme_data, "getColor() or 0xFF000000.toInt()", "0xFF64748B.toInt()", "ThemeData opaqueColor")

    # 8. Patch FCLConstraintLayout.kt & FCLLinearLayout.java (genuine cyber-glass surface + Neon Cyan hairline border)
    fcl_constraint = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLConstraintLayout.kt"
    replace_once(
        fcl_constraint,
        """        ThemeEngine.getInstance().registerEvent(this) {
            if (autoTint) {
                setBackgroundTintList(
                    ColorStateList(
                        arrayOf<IntArray?>(intArrayOf()),
                        intArrayOf(ThemeEngine.getInstance().getTheme().ltColor)
                    )
                )
            }
        }""",
        f"""        ThemeEngine.getInstance().registerEvent(this) {{
            if (autoTint) {{
                val glass = android.graphics.drawable.GradientDrawable().apply {{
                    setColor(ThemeEngine.getInstance().getTheme().ltColor)
                    setStroke(
                        com.tungsten.fcllibrary.util.ConvertUtils.dip2px(context, 1f),
                        android.graphics.Color.parseColor("#59{primary_bare}")
                    )
                    cornerRadius = com.tungsten.fcllibrary.util.ConvertUtils.dip2px(context, 6f).toFloat()
                }}
                setBackgroundTintList(null)
                background = android.graphics.drawable.RippleDrawable(
                    ColorStateList.valueOf(android.graphics.Color.parseColor("#33{primary_bare}")),
                    glass,
                    glass
                )
            }}
        }}""",
        "FCLConstraintLayout cyber-glass border"
    )

    fcl_linear = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLLinearLayout.java"
    replace_once(
        fcl_linear,
        "setBackgroundTintList(new ColorStateList(new int[][] { { } }, new int[] { ThemeEngine.getInstance().getTheme().getLtColor() }));",
        f"""android.graphics.drawable.GradientDrawable glass = new android.graphics.drawable.GradientDrawable();
                glass.setColor(ThemeEngine.getInstance().getTheme().getLtColor());
                glass.setStroke(com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 1f), android.graphics.Color.parseColor("#59{primary_bare}"));
                glass.setCornerRadius(com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 6f));
                setBackgroundTintList(null);
                setBackground(glass);""",
        "FCLLinearLayout cyber-glass border"
    )

    # 9. Patch FCLButton.java (cyber-glass fill + Neon Cyan border + magenta press + ripple support)
    fcl_button = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLButton.java"
    replace_once(
        fcl_button,
        """    public void setRipple() {
        setBackgroundDrawable(getContext().getDrawable(R.drawable.fcl_button));
        int[][] state = {
                {

                }
        };
        int[] color = {
                ThemeEngine.getInstance().getTheme().getColor()
        };
        setBackgroundTintList(new ColorStateList(state, color));
        applyTextColor(ThemeEngine.getInstance().getTheme().getAutoTint());
    }""",
        f"""    public void setRipple() {{
        drawableNormal.setColor(0xC20B1324);
        drawableNormal.setStroke(ConvertUtils.dip2px(getContext(), 1.2f), Color.parseColor("{PRIMARY_HEX}"));
        setBackgroundTintList(null);
        setBackgroundDrawable(new android.graphics.drawable.RippleDrawable(
                ColorStateList.valueOf(Color.parseColor("#44{primary_bare}")),
                drawableNormal,
                drawableNormal
        ));
        applyTextColor(0xFFF1F5F9);
    }}""",
        "FCLButton setRipple cyber-glass"
    )
    replace_all(
        fcl_button,
        "drawableNormal.setColor(Color.TRANSPARENT);",
        f'drawableNormal.setColor(0xB80B1324); drawableNormal.setStroke(ConvertUtils.dip2px(getContext(), 1.2f), Color.parseColor("{PRIMARY_HEX}"));',
        "FCLButton cyber fill+stroke"
    )
    replace_all(
        fcl_button,
        "drawablePress.setColor(ThemeEngine.getInstance().getTheme().getLtColor());",
        f'drawablePress.setColor(Color.parseColor("{SECONDARY_HEX}"));',
        "FCLButton press glow"
    )
    replace_once(fcl_button, "applyTextColor(ThemeEngine.getInstance().getTheme().getOpaqueLtColor());", "applyTextColor(0xFFF1F5F9);", "FCLButton normal text color")
    replace_all(fcl_button, "applyTextColor(ThemeEngine.getInstance().getTheme().getAutoTint());", "applyTextColor(0xFF080B12);", "FCLButton press text color")
    replace_once(fcl_button, "applyTextColor(ThemeEngine.getInstance().getTheme().getLtColor());", "applyTextColor(0xFFF1F5F9);", "FCLButton release text color")
    replace_all(fcl_button, "ConvertUtils.dip2px(getContext(), 8)", "ConvertUtils.dip2px(getContext(), 4)", "FCLButton crisp chamfer radius")

    # 10. Patch FCLTabLayout.java (smoked glass tab header + Neon Cyan hairline + glowing cyan indicator)
    fcl_tab = java_root / "com" / "tungsten" / "fcllibrary" / "component" / "view" / "FCLTabLayout.java"
    replace_once(
        fcl_tab,
        "followTheme ? ThemeEngine.getInstance().getTheme().getAutoTint() : Color.GRAY",
        "0xFF94A3B8",
        "FCLTabLayout unselected text"
    )
    replace_once(
        fcl_tab,
        "setBackgroundTintList(new ColorStateList(bgState, bgColor));",
        f"""android.graphics.drawable.GradientDrawable tabGlass = new android.graphics.drawable.GradientDrawable();
                tabGlass.setColor(ThemeEngine.getInstance().getTheme().getLtColor());
                tabGlass.setStroke(com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 1f), android.graphics.Color.parseColor("#59{primary_bare}"));
                float tabR = com.tungsten.fcllibrary.util.ConvertUtils.dip2px(getContext(), 6f);
                tabGlass.setCornerRadii(new float[]{{tabR, tabR, tabR, tabR, 0f, 0f, 0f, 0f}});
                setBackgroundTintList(null);
                setBackground(tabGlass);""",
        "FCLTabLayout cyber-glass strip"
    )

    # 11. Patch MainActivity.kt (obsidian glass sidebar + Neon Cyan border + styled versionCard & start button)
    main_act = java_root / "com" / "tungsten" / "fcl" / "activity" / "MainActivity.kt"
    replace_once(
        main_act,
        """                    leftMenu.background = GradientDrawable().apply {
                        setColor(ThemeEngine.getInstance().getTheme().getColor())
                        shape = GradientDrawable.RECTANGLE
                        ConvertUtils.dip2px(this@MainActivity, 8f).toFloat().apply {
                            cornerRadii = floatArrayOf(0f, 0f, this, this, this, this, 0f, 0f)
                        }
                    }""",
        f"""                    leftMenu.background = GradientDrawable().apply {{
                        setColor(Color.argb(230, 8, 13, 24))
                        setStroke(ConvertUtils.dip2px(this@MainActivity, 1.4f), Color.parseColor("{PRIMARY_HEX}"))
                        shape = GradientDrawable.RECTANGLE
                        ConvertUtils.dip2px(this@MainActivity, 6f).toFloat().apply {{
                            cornerRadii = floatArrayOf(0f, 0f, this, this, this, this, 0f, 0f)
                        }}
                    }}
                    versionCard.background = GradientDrawable().apply {{
                        setColor(Color.argb(204, 14, 22, 40))
                        setStroke(ConvertUtils.dip2px(this@MainActivity, 1f), Color.parseColor("#66{primary_bare}"))
                        cornerRadius = ConvertUtils.dip2px(this@MainActivity, 6f).toFloat()
                    }}""",
        "MainActivity cyber-glass sidebar & versionCard"
    )
    replace_once(
        main_act,
        """    private fun createBackground(): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ConvertUtils.dip2px(this@MainActivity, 8f).toFloat()
            setStroke(
                ConvertUtils.dip2px(this@MainActivity, 1f),
                ThemeEngine.getInstance().getTheme().getColor2()
            )
        }
    }""",
        f"""    private fun createBackground(): GradientDrawable {{
        return GradientDrawable().apply {{
            setColor(Color.argb(232, 12, 22, 42))
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ConvertUtils.dip2px(this@MainActivity, 6f).toFloat()
            setStroke(
                ConvertUtils.dip2px(this@MainActivity, 1.5f),
                Color.parseColor("{SECONDARY_HEX}")
            )
        }}
    }}""",
        "MainActivity createBackground Launch button"
    )

    # 12. Patch MenuView.kt (in-game floating CyberFold emblem + glowing Neon Cyan ring)
    menu_view = java_root / "com" / "tungsten" / "fcl" / "control" / "view" / "MenuView.kt"
    replace_once(menu_view, "color = Color.DKGRAY", f'color = Color.parseColor("{PRIMARY_HEX}")', "MenuView cyan ring")
    replace_once(menu_view, "R.drawable.img_app", "R.drawable.cyberfold_orb", "MenuView cyberfold_orb")
    replace_once(
        menu_view,
        """            destRect = Rect(
                ConvertUtils.dip2px(context, 6f),
                ConvertUtils.dip2px(context, 6f),
                ConvertUtils.dip2px(context, 34f),
                ConvertUtils.dip2px(context, 34f),
            )""",
        """            destRect = Rect(
                ConvertUtils.dip2px(context, 8f),
                ConvertUtils.dip2px(context, 8f),
                ConvertUtils.dip2px(context, 32f),
                ConvertUtils.dip2px(context, 32f),
            )""",
        "MenuView emblem inset"
    )
    replace_once(menu_view, "areaPaint.color = context.getColor(R.color.ui_bg_color)", "areaPaint.color = 0xE6142038.toInt()", "MenuView pressed fill")
    replace_once(menu_view, "areaPaint.color = Color.TRANSPARENT", "areaPaint.color = 0xCC080B12.toInt()", "MenuView obsidian fill")

    # 13. Patch ControlButtonStyle.java (cyber-glass translucent virtual touch keys with Neon Cyan rim)
    btn_style = java_root / "com" / "tungsten" / "fcl" / "control" / "data" / "ControlButtonStyle.java"
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "strokeWidth", 10)', 'new SimpleIntegerProperty(this, "strokeWidth", 15)', "ControlButtonStyle strokeWidth")
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "strokeColor", Color.DKGRAY)', f'new SimpleIntegerProperty(this, "strokeColor", Color.parseColor("{PRIMARY_HEX}"))', "ControlButtonStyle cyan stroke")
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "cornerRadius", 100)', 'new SimpleIntegerProperty(this, "cornerRadius", 40)', "ControlButtonStyle chamfer corner")
    replace_once(btn_style, 'new SimpleIntegerProperty(this, "fillColor", Color.TRANSPARENT)', 'new SimpleIntegerProperty(this, "fillColor", 0x990A1120)', "ControlButtonStyle glass fill")

    # 14. Patch MemoryUtils.java & VersionSetting.kt (32-bit armeabi-v7a Forge 1.12.2 crash prevention)
    mem_utils = java_root / "com" / "tungsten" / "fclcore" / "util" / "platform" / "MemoryUtils.java"
    replace_all(mem_utils, "Architecture.is32BitsDevice() ? 768 :", f"Architecture.is32BitsDevice() ? {SAFE_32_RAM} :", "MemoryUtils 32-bit safe RAM cap")

    ver_setting = java_root / "com" / "tungsten" / "fcl" / "setting" / "VersionSetting.kt"
    replace_once(
        ver_setting,
        'var javaArgs: String = ""',
        f'var javaArgs: String = if (com.tungsten.fclauncher.utils.Architecture.is32BitsDevice()) "{SAFE_JVM_ARGS}" else ""',
        "VersionSetting 32-bit safe JVM args"
    )

    print("[CyberFold 32] All source, UI, and 32-bit stability patches complete.")

if __name__ == "__main__":
    main()
