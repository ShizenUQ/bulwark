package com.lineengine3d

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke as DStroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

enum class Ic {
    Select, MultiSelect, Line, Shapes, Rect, Circle, Freehand, Eraser, Extrude, Revolve,
    Move, Rotate, Scale, Stretch, Group, Ungroup, Duplicate, Assets, Terrain, Inspect,
    Hierarchy, Orbit, Snap, Mirror, Eye, EyeOff, Undo, Redo, Save, Play, Stop, Draw, Edit,
    View, Grid, Array, Drop, Trash, Plus, Minus, Up, Down, Left, Right, Back, Xray, Axis,
    Check, Close, Pivot, Cube, Vertex, Plane, Mute, Door,
    PBox, PPyramid, PCone, PCylinder, PSphere, PDome, PWedge, PRoof, PTorus, PStairs,
    PSquare, PCircle, PTriangle, PHexagon, PArch,
    PCapsule, POcta, PGem, PHexPrism, PTunnel, PL, PPlus, PFrustum, PSpiral, PPipe,
    FBox, FTri, FCircle, FHex, FTrap, FRing, FArch, FHalf, FL, FCross, FStar, FRamp,
    Cells, Window, Style, Fps
}

fun Prim.icon(): Ic = when (this) {
    Prim.Box -> Ic.PBox
    Prim.Pyramid -> Ic.PPyramid
    Prim.Cone -> Ic.PCone
    Prim.Cylinder -> Ic.PCylinder
    Prim.Sphere -> Ic.PSphere
    Prim.Dome -> Ic.PDome
    Prim.Wedge -> Ic.PWedge
    Prim.Roof -> Ic.PRoof
    Prim.Torus -> Ic.PTorus
    Prim.Stairs -> Ic.PStairs
    Prim.Square -> Ic.PSquare
    Prim.Circle -> Ic.PCircle
    Prim.Triangle -> Ic.PTriangle
    Prim.Hexagon -> Ic.PHexagon
    Prim.Arch -> Ic.PArch
    Prim.Capsule -> Ic.PCapsule
    Prim.Octa -> Ic.POcta
    Prim.Gem -> Ic.PGem
    Prim.HexPrism -> Ic.PHexPrism
    Prim.Tunnel -> Ic.PTunnel
    Prim.LBlock -> Ic.PL
    Prim.PlusBlock -> Ic.PPlus
    Prim.Frustum -> Ic.PFrustum
    Prim.Spiral -> Ic.PSpiral
    Prim.Pipe -> Ic.PPipe
    Prim.FBox -> Ic.FBox
    Prim.FTri -> Ic.FTri
    Prim.FCircle -> Ic.FCircle
    Prim.FHex -> Ic.FHex
    Prim.FTrap -> Ic.FTrap
    Prim.FRing -> Ic.FRing
    Prim.FArch -> Ic.FArch
    Prim.FHalf -> Ic.FHalf
    Prim.FL -> Ic.FL
    Prim.FCross -> Ic.FCross
    Prim.FStar -> Ic.FStar
    Prim.FRamp -> Ic.FRamp
}

@Composable
fun LIcon(ic: Ic, modifier: Modifier = Modifier, tint: Color = Color.White, size: Dp = 22.dp) {
    Canvas(modifier.size(size)) { drawIc(ic, tint) }
}

private fun DrawScope.drawIc(ic: Ic, tint: Color) {
    val s = this.size.minDimension / 24f
    val st = DStroke(width = 1.7f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun poly(vararg v: Float, closed: Boolean = false) {
        val p = Path()
        p.moveTo(v[0] * s, v[1] * s)
        var i = 2
        while (i + 1 < v.size) { p.lineTo(v[i] * s, v[i + 1] * s); i += 2 }
        if (closed) p.close()
        drawPath(p, tint, style = st)
    }
    fun circ(x: Float, y: Float, r: Float, fill: Boolean = false) {
        drawCircle(tint, r * s, Offset(x * s, y * s), style = if (fill) Fill else st)
    }
    fun arc(cx: Float, cy: Float, r: Float, start: Float, sweep: Float) {
        drawArc(tint, start, sweep, false, Offset((cx - r) * s, (cy - r) * s), Size(2 * r * s, 2 * r * s), style = st)
    }
    fun ell(cx: Float, cy: Float, rx: Float, ry: Float) {
        drawOval(tint, Offset((cx - rx) * s, (cy - ry) * s), Size(2 * rx * s, 2 * ry * s), style = st)
    }
    fun arrow(x1: Float, y1: Float, x2: Float, y2: Float, h: Float = 3.2f) {
        poly(x1, y1, x2, y2)
        val a = atan2(y2 - y1, x2 - x1)
        val l = a + 2.6f
        val r = a - 2.6f
        poly(x2 + cos(l) * h, y2 + sin(l) * h, x2, y2, x2 + cos(r) * h, y2 + sin(r) * h)
    }
    fun rect(x: Float, y: Float, w: Float, h: Float) = poly(x, y, x + w, y, x + w, y + h, x, y + h, closed = true)

    when (ic) {
        Ic.Select -> poly(6f, 3f, 6f, 19f, 10f, 15f, 13f, 21f, 15.5f, 20f, 12.5f, 14f, 18f, 14f, closed = true)
        Ic.MultiSelect -> {
            rect(3f, 3f, 11f, 11f); rect(10f, 10f, 11f, 11f); poly(8.5f, 6f, 8.5f, 11f); poly(6f, 8.5f, 11f, 8.5f)
        }
        Ic.Line -> { poly(4f, 19f, 9f, 8f, 15f, 15f, 20f, 5f); circ(4f, 19f, 1.6f, true); circ(9f, 8f, 1.6f, true); circ(15f, 15f, 1.6f, true); circ(20f, 5f, 1.6f, true) }
        Ic.Shapes -> { poly(3f, 20f, 9f, 8f, 15f, 20f, closed = true); rect(13f, 4f, 8f, 8f); circ(17f, 17f, 3.5f) }
        Ic.Rect -> rect(4f, 6f, 16f, 12f)
        Ic.Circle -> circ(12f, 12f, 8f)
        Ic.Freehand -> poly(3f, 15f, 6f, 8f, 9f, 16f, 12f, 8f, 15f, 15f, 18f, 9f, 21f, 12f)
        Ic.Eraser -> { poly(5f, 15f, 14f, 4f, 20f, 9f, 11f, 20f, closed = true); poly(5f, 15f, 11f, 20f); poly(3f, 21f, 21f, 21f) }
        Ic.Extrude -> { rect(4f, 14f, 12f, 7f); poly(4f, 14f, 8f, 10f, 20f, 10f, 20f, 17f, 16f, 21f); poly(16f, 14f, 20f, 10f); arrow(10f, 8f, 10f, 2.5f) }
        Ic.Revolve -> { ell(12f, 15f, 8f, 3.2f); poly(12f, 3f, 12f, 21f); arrow(17f, 6f, 20f, 9.5f) }
        Ic.Move -> { arrow(12f, 12f, 12f, 3f); arrow(12f, 12f, 12f, 21f); arrow(12f, 12f, 3f, 12f); arrow(12f, 12f, 21f, 12f) }
        Ic.Rotate -> { arc(12f, 12f, 8f, -50f, 280f); arrow(17.5f, 5f, 19.5f, 8.5f) }
        Ic.Scale -> { rect(4f, 10f, 10f, 10f); arrow(11f, 13f, 20f, 4f); poly(14f, 4f, 20f, 4f, 20f, 10f) }
        Ic.Stretch -> { arrow(12f, 12f, 3f, 12f); arrow(12f, 12f, 21f, 12f); poly(3f, 6f, 3f, 18f); poly(21f, 6f, 21f, 18f) }
        Ic.Group -> { rect(3f, 3f, 9f, 9f); rect(12f, 12f, 9f, 9f); poly(12f, 7.5f, 16.5f, 7.5f, 16.5f, 12f) }
        Ic.Ungroup -> { rect(3f, 3f, 8f, 8f); rect(13f, 13f, 8f, 8f); poly(13f, 8f, 16f, 8f); poly(8f, 13f, 8f, 16f) }
        Ic.Duplicate -> { rect(8f, 8f, 12f, 12f); poly(16f, 8f, 16f, 4f, 4f, 4f, 4f, 16f, 8f, 16f) }
        Ic.Assets -> { poly(12f, 3f, 20f, 7.5f, 20f, 16.5f, 12f, 21f, 4f, 16.5f, 4f, 7.5f, closed = true); poly(4f, 7.5f, 12f, 12f, 20f, 7.5f); poly(12f, 12f, 12f, 21f) }
        Ic.Terrain -> { poly(2f, 19f, 8f, 8f, 12f, 14f, 16f, 6f, 22f, 19f, closed = true); poly(5f, 19f, 8f, 14f, 11f, 19f) }
        Ic.Inspect -> { poly(4f, 7f, 20f, 7f); poly(4f, 17f, 20f, 17f); circ(9f, 7f, 2.4f); circ(15f, 17f, 2.4f) }
        Ic.Hierarchy -> { rect(9f, 2.5f, 6f, 5f); rect(2.5f, 16.5f, 6f, 5f); rect(15.5f, 16.5f, 6f, 5f); poly(12f, 7.5f, 12f, 12f); poly(5.5f, 16.5f, 5.5f, 12f, 18.5f, 12f, 18.5f, 16.5f) }
        Ic.Orbit -> { ell(12f, 12f, 9f, 4f); circ(12f, 12f, 2.2f, true); arrow(19f, 15f, 20f, 13f, 2.5f) }
        Ic.Snap -> { poly(5f, 4f, 5f, 13f); poly(19f, 4f, 19f, 13f); arc(12f, 13f, 7f, 0f, 180f); poly(5f, 7f, 9f, 7f); poly(15f, 7f, 19f, 7f) }
        Ic.Mirror -> { poly(12f, 2f, 12f, 22f); poly(9f, 6f, 3f, 12f, 9f, 18f, closed = true); poly(15f, 6f, 21f, 12f, 15f, 18f, closed = true) }
        Ic.Eye -> { poly(2f, 12f, 7f, 6.5f, 12f, 5f, 17f, 6.5f, 22f, 12f, 17f, 17.5f, 12f, 19f, 7f, 17.5f, 2f, 12f); circ(12f, 12f, 3f) }
        Ic.EyeOff -> { poly(2f, 12f, 7f, 6.5f, 12f, 5f, 17f, 6.5f, 22f, 12f, 17f, 17.5f, 12f, 19f, 7f, 17.5f, 2f, 12f); poly(4f, 20f, 20f, 4f) }
        Ic.Undo -> { poly(8f, 5f, 4f, 9f, 8f, 13f); poly(4f, 9f, 14f, 9f); arc(14f, 14f, 5f, -90f, 180f) }
        Ic.Redo -> { poly(16f, 5f, 20f, 9f, 16f, 13f); poly(20f, 9f, 10f, 9f); arc(10f, 14f, 5f, -90f, -180f) }
        Ic.Save -> { poly(4f, 4f, 17f, 4f, 20f, 7f, 20f, 20f, 4f, 20f, closed = true); poly(8f, 4f, 8f, 9f, 15f, 9f, 15f, 4f); rect(7f, 14f, 10f, 6f) }
        Ic.Play -> poly(7f, 4f, 20f, 12f, 7f, 20f, closed = true)
        Ic.Stop -> rect(6f, 6f, 12f, 12f)
        Ic.Draw -> { poly(4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f, closed = true); poly(14f, 6f, 18f, 10f) }
        Ic.Edit -> { poly(4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f, closed = true); poly(14f, 6f, 18f, 10f) }
        Ic.View -> { ell(12f, 12f, 9f, 5.5f); circ(12f, 12f, 2.5f, true) }
        Ic.Grid -> { poly(8f, 3f, 8f, 21f); poly(16f, 3f, 16f, 21f); poly(3f, 8f, 21f, 8f); poly(3f, 16f, 21f, 16f) }
        Ic.Array -> { rect(2f, 8f, 6f, 8f); rect(9f, 8f, 6f, 8f); rect(16f, 8f, 6f, 8f) }
        Ic.Drop -> { arrow(12f, 3f, 12f, 16f); poly(4f, 21f, 20f, 21f); poly(6f, 17f, 6f, 21f); poly(18f, 17f, 18f, 21f) }
        Ic.Trash -> { poly(4f, 7f, 20f, 7f); poly(9f, 7f, 9f, 4f, 15f, 4f, 15f, 7f); poly(6f, 7f, 7f, 21f, 17f, 21f, 18f, 7f) }
        Ic.Plus -> { poly(12f, 5f, 12f, 19f); poly(5f, 12f, 19f, 12f) }
        Ic.Minus -> poly(5f, 12f, 19f, 12f)
        Ic.Up -> poly(6f, 15f, 12f, 9f, 18f, 15f)
        Ic.Down -> poly(6f, 9f, 12f, 15f, 18f, 9f)
        Ic.Left -> poly(15f, 6f, 9f, 12f, 15f, 18f)
        Ic.Right -> poly(9f, 6f, 15f, 12f, 9f, 18f)
        Ic.Back -> arrow(20f, 12f, 4f, 12f, 4.5f)
        Ic.Xray -> { poly(4f, 8f, 12f, 4f, 20f, 8f, 20f, 17f, 12f, 21f, 4f, 17f, closed = true); poly(4f, 8f, 12f, 12f, 20f, 8f); poly(12f, 12f, 12f, 21f) }
        Ic.Axis -> { arrow(5f, 19f, 5f, 4f); arrow(5f, 19f, 20f, 19f); arrow(5f, 19f, 13f, 12f) }
        Ic.Check -> poly(4f, 12f, 10f, 18f, 20f, 6f)
        Ic.Close -> { poly(5f, 5f, 19f, 19f); poly(19f, 5f, 5f, 19f) }
        Ic.Pivot -> { circ(12f, 12f, 3f, true); poly(12f, 2f, 12f, 7f); poly(12f, 17f, 12f, 22f); poly(2f, 12f, 7f, 12f); poly(17f, 12f, 22f, 12f) }
        Ic.Cube -> { poly(4f, 8f, 12f, 4f, 20f, 8f, 20f, 17f, 12f, 21f, 4f, 17f, closed = true); poly(4f, 8f, 12f, 12f, 20f, 8f); poly(12f, 12f, 12f, 21f) }
        Ic.Vertex -> { circ(12f, 12f, 3f, true); circ(12f, 12f, 8f) }
        Ic.Plane -> poly(3f, 17f, 8f, 7f, 21f, 7f, 16f, 17f, closed = true)
        Ic.Mute -> { poly(4f, 9f, 8f, 9f, 13f, 4f, 13f, 20f, 8f, 15f, 4f, 15f, closed = true); poly(16f, 9f, 21f, 15f); poly(21f, 9f, 16f, 15f) }
        Ic.Door -> { rect(6f, 3f, 12f, 18f); circ(15f, 12f, 1.1f, true) }
        Ic.PBox -> { rect(5f, 9f, 11f, 11f); poly(5f, 9f, 9f, 5f, 20f, 5f, 20f, 16f, 16f, 20f); poly(16f, 9f, 20f, 5f) }
        Ic.PPyramid -> { poly(12f, 3f, 21f, 19f, 12f, 21f, 3f, 19f, closed = true); poly(12f, 3f, 12f, 21f) }
        Ic.PCone -> { poly(12f, 3f, 20f, 18f); poly(12f, 3f, 4f, 18f); ell(12f, 18f, 8f, 3f) }
        Ic.PCylinder -> { ell(12f, 6f, 7f, 2.6f); poly(5f, 6f, 5f, 18f); poly(19f, 6f, 19f, 18f); drawArc(tint, 0f, 180f, false, Offset(5f * s, 15.4f * s), Size(14f * s, 5.2f * s), style = st) }
        Ic.PSphere -> { circ(12f, 12f, 9f); ell(12f, 12f, 9f, 3.4f); ell(12f, 12f, 3.4f, 9f) }
        Ic.PDome -> { arc(12f, 18f, 9f, 180f, 180f); poly(3f, 18f, 21f, 18f); drawArc(tint, 0f, 180f, false, Offset(3f * s, 15f * s), Size(18f * s, 6f * s), style = st) }
        Ic.PWedge -> poly(3f, 19f, 21f, 19f, 21f, 6f, closed = true)
        Ic.PRoof -> { poly(3f, 19f, 21f, 19f, 12f, 6f, closed = true); poly(12f, 6f, 17f, 3f, 21f, 14f); poly(21f, 19f, 21f, 14f) }
        Ic.PTorus -> { ell(12f, 12f, 9f, 7f); ell(12f, 12f, 3.6f, 2.6f) }
        Ic.PStairs -> poly(3f, 20f, 3f, 16f, 8f, 16f, 8f, 12f, 13f, 12f, 13f, 8f, 18f, 8f, 18f, 4f, 21f, 4f, 21f, 20f, closed = true)
        Ic.PSquare -> rect(5f, 5f, 14f, 14f)
        Ic.PCircle -> circ(12f, 12f, 8f)
        Ic.PTriangle -> poly(12f, 4f, 21f, 19f, 3f, 19f, closed = true)
        Ic.PHexagon -> poly(7f, 4f, 17f, 4f, 22f, 12f, 17f, 20f, 7f, 20f, 2f, 12f, closed = true)
        Ic.PArch -> { poly(5f, 21f, 5f, 12f); poly(19f, 21f, 19f, 12f); arc(12f, 12f, 7f, 180f, 180f) }
        Ic.PCapsule -> { arc(12f, 8f, 5f, 180f, 180f); arc(12f, 16f, 5f, 0f, 180f); poly(7f, 8f, 7f, 16f); poly(17f, 8f, 17f, 16f); ell(12f, 12f, 5f, 1.6f) }
        Ic.POcta -> { poly(12f, 2.5f, 20f, 12f, 12f, 21.5f, 4f, 12f, closed = true); poly(4f, 12f, 20f, 12f); poly(12f, 2.5f, 12f, 21.5f) }
        Ic.PGem -> { poly(7f, 4f, 17f, 4f, 22f, 10f, 12f, 21f, 2f, 10f, closed = true); poly(2f, 10f, 22f, 10f); poly(7f, 4f, 9f, 10f, 12f, 21f); poly(17f, 4f, 15f, 10f, 12f, 21f) }
        Ic.PHexPrism -> { poly(7f, 6f, 17f, 6f, 21f, 9f, 17f, 12f, 7f, 12f, 3f, 9f, closed = true); poly(3f, 9f, 3f, 18f, 7f, 21f, 17f, 21f, 21f, 18f, 21f, 9f); poly(7f, 12f, 7f, 21f); poly(17f, 12f, 17f, 21f) }
        Ic.PTunnel -> { poly(3f, 21f, 3f, 12f); arc(12f, 12f, 9f, 180f, 180f); poly(21f, 12f, 21f, 21f); poly(8f, 21f, 8f, 12f); arc(12f, 12f, 4f, 180f, 180f); poly(16f, 12f, 16f, 21f); poly(3f, 21f, 8f, 21f); poly(16f, 21f, 21f, 21f) }
        Ic.PL -> { poly(4f, 20f, 20f, 20f, 20f, 13f, 11f, 13f, 11f, 4f, 4f, 4f, closed = true) }
        Ic.PPlus -> { poly(9f, 3f, 15f, 3f, 15f, 9f, 21f, 9f, 21f, 15f, 15f, 15f, 15f, 21f, 9f, 21f, 9f, 15f, 3f, 15f, 3f, 9f, 9f, 9f, closed = true) }
        Ic.PFrustum -> { poly(3f, 20f, 8f, 5f, 16f, 5f, 21f, 20f, closed = true); ell(12f, 5f, 4f, 1.4f) }
        Ic.PSpiral -> { poly(3f, 20f, 3f, 16f, 8f, 16f, 8f, 12f, 13f, 12f, 13f, 8f, 18f, 8f, 18f, 4f); arc(12f, 20f, 9f, 180f, 180f) }
        Ic.PPipe -> { ell(12f, 6f, 8f, 3f); ell(12f, 6f, 4.5f, 1.6f); poly(4f, 6f, 4f, 18f); poly(20f, 6f, 20f, 18f); drawArc(tint, 0f, 180f, false, Offset(4f * s, 15f * s), Size(16f * s, 6f * s), style = st) }
        Ic.FBox -> { rect(4f, 4f, 16f, 16f); poly(9.3f, 4f, 9.3f, 20f); poly(14.6f, 4f, 14.6f, 20f); poly(4f, 9.3f, 20f, 9.3f); poly(4f, 14.6f, 20f, 14.6f) }
        Ic.FTri -> { poly(12f, 4f, 21f, 19f, 3f, 19f, closed = true); poly(7.5f, 11.5f, 16.5f, 11.5f); poly(12f, 4f, 12f, 19f) }
        Ic.FCircle -> { circ(12f, 12f, 8f); poly(4f, 12f, 20f, 12f); poly(12f, 4f, 12f, 20f) }
        Ic.FHex -> { poly(7f, 4f, 17f, 4f, 22f, 12f, 17f, 20f, 7f, 20f, 2f, 12f, closed = true); poly(2f, 12f, 22f, 12f) }
        Ic.FTrap -> { poly(2f, 19f, 22f, 19f, 17f, 5f, 7f, 5f, closed = true); poly(4.5f, 12f, 19.5f, 12f) }
        Ic.FRing -> { circ(12f, 12f, 9f); circ(12f, 12f, 4.5f) }
        Ic.FArch -> { poly(5f, 21f, 5f, 12f); arc(12f, 12f, 7f, 180f, 180f); poly(19f, 12f, 19f, 21f); poly(5f, 21f, 19f, 21f); poly(12f, 5f, 12f, 21f) }
        Ic.FHalf -> { arc(12f, 17f, 9f, 180f, 180f); poly(3f, 17f, 21f, 17f); poly(12f, 8f, 12f, 17f) }
        Ic.FL -> { poly(4f, 20f, 20f, 20f, 20f, 13f, 11f, 13f, 11f, 4f, 4f, 4f, closed = true); poly(4f, 13f, 11f, 13f) }
        Ic.FCross -> { poly(9f, 3f, 15f, 3f, 15f, 9f, 21f, 9f, 21f, 15f, 15f, 15f, 15f, 21f, 9f, 21f, 9f, 15f, 3f, 15f, 3f, 9f, 9f, 9f, closed = true); poly(9f, 9f, 15f, 15f) }
        Ic.FStar -> poly(12f, 2.5f, 14.6f, 9.2f, 21.5f, 9.4f, 16f, 13.8f, 18f, 21f, 12f, 16.8f, 6f, 21f, 8f, 13.8f, 2.5f, 9.4f, 9.4f, 9.2f, closed = true)
        Ic.FRamp -> { poly(3f, 20f, 21f, 20f, 21f, 5f, closed = true); poly(12f, 20f, 12f, 12.5f); poly(16.5f, 20f, 16.5f, 8.7f) }
        Ic.Cells -> { rect(3f, 3f, 18f, 18f); poly(9f, 3f, 9f, 21f); poly(15f, 3f, 15f, 21f); poly(3f, 9f, 21f, 9f); poly(3f, 15f, 21f, 15f); poly(10.5f, 10.5f, 13.5f, 13.5f); poly(13.5f, 10.5f, 10.5f, 13.5f) }
        Ic.Window -> { rect(3f, 3f, 18f, 18f); rect(8f, 8f, 8f, 8f); poly(12f, 8f, 12f, 16f); poly(8f, 12f, 16f, 12f) }
        Ic.Style -> { poly(3f, 12f, 7f, 12f); poly(10f, 12f, 14f, 12f); poly(17f, 12f, 21f, 12f); circ(5f, 19f, 1f, true); circ(12f, 19f, 1f, true); circ(19f, 19f, 1f, true) }
        Ic.Fps -> { arc(12f, 15f, 8f, 180f, 180f); poly(12f, 15f, 17f, 9f); poly(4f, 15f, 20f, 15f) }
    }
}

/** Icon with a tiny micro-label underneath, used on the rail and docks. */
@Composable
fun IconBtn(
    ic: Ic,
    label: String,
    on: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg = if (on) Color(0xFF4FC3F7) else Color(0x00000000)
    val fg = when {
        !enabled -> Color(0xFF5B6070)
        on -> Color(0xFF00212E)
        else -> Color(0xFFDDE3F0)
    }
    Column(
        modifier.clip(RoundedCornerShape(10.dp)).background(bg).clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        LIcon(ic, tint = fg, size = 20.dp)
        Text(label, color = fg, fontSize = 9.sp, maxLines = 1, textAlign = TextAlign.Center, lineHeight = 10.sp)
    }
}

/** Icon-only round button for tiny floating controls. */
@Composable
fun IconPill(ic: Ic, on: Boolean = false, enabled: Boolean = true, label: String? = null, onClick: () -> Unit) {
    val bg = if (on) Color(0xFF4FC3F7) else Color(0xFF1B2030)
    val fg = when {
        !enabled -> Color(0xFF5B6070)
        on -> Color(0xFF00212E)
        else -> Color(0xFFDDE3F0)
    }
    Row(
        Modifier.padding(2.dp).clip(RoundedCornerShape(18.dp)).background(bg)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 9.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        LIcon(ic, tint = fg, size = 18.dp)
        if (label != null) Text(label, color = fg, fontSize = 11.sp, maxLines = 1)
    }
}
