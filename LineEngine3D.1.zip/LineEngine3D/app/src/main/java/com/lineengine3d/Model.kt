package com.lineengine3d

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.util.UUID

val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    classDiscriminator = "kind"
}

fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

class Theme(
    val name: String,
    val bg: Int,
    val line: Int,
    val grid: Int,
    val contour: Int,
    val dark: Boolean
)

object Themes {
    val list = listOf(
        Theme("Blueprint", 0xFF0B2545.toInt(), 0xFFE8F1FF.toInt(), 0xFF3E7CB1.toInt(), 0xFF7FD1FF.toInt(), true),
        Theme("Cyber Neon", 0xFF07050F.toInt(), 0xFF00F5FF.toInt(), 0xFF7A1FA2.toInt(), 0xFFFF2BD6.toInt(), true),
        Theme("Paper Sketch", 0xFFF4EDE0.toInt(), 0xFF2B2B2B.toInt(), 0xFFB5AA98.toInt(), 0xFF7A5C3E.toInt(), false)
    )

    fun get(n: String): Theme = list.firstOrNull { it.name == n } ?: list[0]
}

@Serializable
data class Stroke(val pts: List<V3>, val closed: Boolean = false)

@Serializable
sealed class Logic {
    @Serializable @SerialName("rigid")
    data class RigidBody(val dynamic: Boolean = false) : Logic()

    @Serializable @SerialName("vehicle")
    data class Vehicle(
        val maxSpeed: Float = 22f,
        val accel: Float = 9f,
        val steerDeg: Float = 32f,
        val suspension: Float = 0.35f,
        val forward: Int = 0
    ) : Logic()

    @Serializable @SerialName("wheel")
    data class Wheel(
        val radius: Float = 0.35f,
        val steerable: Boolean = false,
        val driven: Boolean = true,
        val axis: Int = 0
    ) : Logic()

    @Serializable @SerialName("door")
    data class DoorHinge(
        val pivot: V3 = V3(),
        val minAngle: Float = 0f,
        val maxAngle: Float = 90f,
        val speed: Float = 120f,
        val requiredKeyId: String = ""
    ) : Logic()

    @Serializable @SerialName("seat")
    data class DriverSeat(val offset: V3 = V3(0f, 0.9f, 0f)) : Logic()

    @Serializable @SerialName("mover")
    data class Mover(
        val offset: V3 = V3(0f, 3f, 0f),
        val speed: Float = 1.5f,
        val pingPong: Boolean = true,
        val startActive: Boolean = true
    ) : Logic()

    @Serializable @SerialName("spinner")
    data class Spinner(val axis: V3 = V3(0f, 1f, 0f), val degPerSec: Float = 60f) : Logic()

    @Serializable @SerialName("sway")
    data class Sway(
        val axis: V3 = V3(0f, 0f, 1f),
        val speed: Float = 0.6f,
        val amplitude: Float = 6f,
        val phase: Float = 0f,
        val fromBase: Boolean = true
    ) : Logic()

    @Serializable @SerialName("jump")
    data class JumpPad(val power: Float = 12f) : Logic()

    @Serializable @SerialName("tele")
    data class Teleporter(val targetId: String = "") : Logic()

    @Serializable @SerialName("check")
    data class Checkpoint(val dummy: Int = 0) : Logic()

    @Serializable @SerialName("ladder")
    data class Ladder(val speed: Float = 3.2f) : Logic()

    @Serializable @SerialName("wind")
    data class Wind(val dir: V3 = V3(1f, 0f, 0f), val force: Float = 6f) : Logic()

    @Serializable @SerialName("timed")
    data class TimedPlatform(val onSec: Float = 2f, val offSec: Float = 1.5f, val phase: Float = 0f) : Logic()

    @Serializable @SerialName("water")
    data class Water(val dummy: Int = 0) : Logic()

    @Serializable @SerialName("spawn")
    data class PlayerSpawn(val yaw: Float = 0f) : Logic()

    @Serializable @SerialName("collect")
    data class Collectible(val value: Int = 10, val keyId: String = "") : Logic()

    @Serializable @SerialName("hazard")
    data class Hazard(val damage: Int = 100) : Logic()

    @Serializable @SerialName("trigger")
    data class TriggerPad(val targetId: String = "") : Logic()

    @Serializable @SerialName("goal")
    data class GoalZone(val dummy: Boolean = true) : Logic()
}

fun Logic.label(): String = when (this) {
    is Logic.RigidBody -> "RigidBody"
    is Logic.Vehicle -> "Vehicle"
    is Logic.Wheel -> "Wheel"
    is Logic.DoorHinge -> "DoorHinge"
    is Logic.DriverSeat -> "DriverSeat"
    is Logic.Mover -> "Mover"
    is Logic.Spinner -> "Spinner"
    is Logic.Sway -> "Sway"
    is Logic.JumpPad -> "JumpPad"
    is Logic.Teleporter -> "Teleporter"
    is Logic.Checkpoint -> "Checkpoint"
    is Logic.Ladder -> "Ladder"
    is Logic.Wind -> "Wind"
    is Logic.TimedPlatform -> "TimedPlatform"
    is Logic.Water -> "Water"
    is Logic.PlayerSpawn -> "PlayerSpawn"
    is Logic.Collectible -> "Collectible"
    is Logic.Hazard -> "Hazard"
    is Logic.TriggerPad -> "TriggerPad"
    is Logic.GoalZone -> "GoalZone"
}

@Serializable
data class Entity(
    val id: String,
    val name: String = "Object",
    val parentId: String? = null,
    val pos: V3 = V3(),
    val rot: V3 = V3(),
    val scl: V3 = V3(1f, 1f, 1f),
    val strokes: List<Stroke> = emptyList(),
    val tris: FloatArray = FloatArray(0),
    val color: Int = -1,
    val width: Float = 2.5f,
    val logic: List<Logic> = emptyList(),
    val visible: Boolean = true,
    val panel: PanelSpec? = null,
    val style: Int = 0
)

/** Flat panel made of removable cells. Cell index = row * cols + col over the local XZ square [-0.5, 0.5]. */
@Serializable
data class PanelSpec(val cols: Int = 4, val rows: Int = 4, val removed: List<Int> = emptyList())

inline fun <reified T : Logic> Entity.find(): T? {
    for (l in logic) if (l is T) return l
    return null
}

@Serializable
data class Project(
    val id: String,
    val name: String,
    val theme: String = "Blueprint",
    val worldSize: Float = 100f,
    val gravity: Float = 9.8f,
    val entities: List<Entity> = emptyList(),
    val terrain: TerrainData,
    val boundary: Boolean = true,
    val infinite: Boolean = false,
    val renderDist: Float = 300f,
    val voidY: Float = -30f,
    val showAxis: Boolean = true,
    val jitter: Boolean = false,
    val modified: Long = 0L,
    val camera: List<Float> = emptyList()
)

@Serializable
data class Asset(val id: String, val name: String, val entities: List<Entity>)

fun computeWorlds(list: List<Entity>): HashMap<String, FloatArray> {
    val byId = HashMap<String, Entity>()
    for (e in list) byId[e.id] = e
    val out = HashMap<String, FloatArray>()
    fun w(e: Entity, depth: Int): FloatArray {
        val c = out[e.id]
        if (c != null) return c
        val local = M4.trs(e.pos, e.rot, e.scl)
        val pid = e.parentId
        val p = if (pid != null) byId[pid] else null
        val m = if (p != null && depth < 64) M4.mul(w(p, depth + 1), local) else local
        out[e.id] = m
        return m
    }
    for (e in list) w(e, 0)
    return out
}

class FloatList(cap: Int = 256) {
    var a = FloatArray(cap)
    var n = 0
    private fun ensure(extra: Int) {
        if (n + extra > a.size) a = a.copyOf(maxOf(a.size * 2, n + extra))
    }
    fun add(v: V3) {
        ensure(3); a[n++] = v.x; a[n++] = v.y; a[n++] = v.z
    }
    fun tri(p: V3, q: V3, r: V3) {
        add(p); add(q); add(r)
    }
    fun quad(p: V3, q: V3, r: V3, s: V3) {
        tri(p, q, r); tri(p, r, s)
    }
    fun addAll(f: FloatArray) {
        ensure(f.size); System.arraycopy(f, 0, a, n, f.size); n += f.size
    }
    fun toArray(): FloatArray = a.copyOf(n)
}
