package com.lineengine3d

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Ready-made shape library. All shapes are unit sized, centred on X/Z, with their base at y = 0. */
enum class PCat { Solid, Panel, Line }

enum class Prim(val label: String, val cat: PCat, val rigid: Boolean) {
    Box("Box", PCat.Solid, true),
    Pyramid("Pyramid", PCat.Solid, false),
    Cone("Cone", PCat.Solid, false),
    Cylinder("Cylinder", PCat.Solid, true),
    Sphere("Sphere", PCat.Solid, true),
    Dome("Dome", PCat.Solid, false),
    Wedge("Ramp", PCat.Solid, false),
    Roof("Roof", PCat.Solid, false),
    Torus("Ring", PCat.Solid, false),
    Stairs("Stairs", PCat.Solid, false),
    Capsule("Capsule", PCat.Solid, false),
    Octa("Octahedron", PCat.Solid, false),
    Gem("Gem", PCat.Solid, false),
    HexPrism("Hex Pillar", PCat.Solid, true),
    Tunnel("Tunnel", PCat.Solid, false),
    LBlock("L Block", PCat.Solid, true),
    PlusBlock("Plus Block", PCat.Solid, true),
    Frustum("Tower", PCat.Solid, false),
    Spiral("Spiral Stairs", PCat.Solid, false),
    Pipe("Pipe", PCat.Solid, false),
    FBox("Flat Box", PCat.Panel, true),
    FTri("Flat Triangle", PCat.Panel, true),
    FCircle("Flat Circle", PCat.Panel, true),
    FHex("Flat Hexagon", PCat.Panel, true),
    FTrap("Flat Trapezoid", PCat.Panel, true),
    FRing("Flat Ring", PCat.Panel, true),
    FArch("Flat Arch", PCat.Panel, true),
    FHalf("Flat Half Disk", PCat.Panel, true),
    FL("Flat L", PCat.Panel, true),
    FCross("Flat Cross", PCat.Panel, true),
    FStar("Flat Star", PCat.Panel, true),
    FRamp("Flat Ramp Side", PCat.Panel, true),
    Square("Square", PCat.Line, false),
    Circle("Circle", PCat.Line, false),
    Triangle("Triangle", PCat.Line, false),
    Hexagon("Hexagon", PCat.Line, false),
    Arch("Arch", PCat.Line, false);

    val solid: Boolean get() = cat == PCat.Solid
}

class PrimGeo(val strokes: List<Stroke>, val tris: FloatArray)

object Prims {
    private const val TAU = 6.2831853f

    private fun ring(r: Float, y: Float, n: Int, cx: Float = 0f, cz: Float = 0f): List<V3> =
        (0 until n).map { i ->
            val a = i.toFloat() / n * TAU
            V3(cx + cos(a) * r, y, cz + sin(a) * r)
        }

    private fun loop(p: List<V3>) = Stroke(p, true)
    private fun line(a: V3, b: V3) = Stroke(listOf(a, b), false)

    fun build(k: Prim): PrimGeo = when (k) {
        Prim.Box -> box()
        Prim.Pyramid -> pyramid()
        Prim.Cone -> cone()
        Prim.Cylinder -> cylinder()
        Prim.Sphere -> sphere(false)
        Prim.Dome -> sphere(true)
        Prim.Wedge -> prism(listOf(-0.5f to 0f, 0.5f to 0f, 0.5f to 1f), true)
        Prim.Roof -> prism(listOf(-0.5f to 0f, 0.5f to 0f, 0f to 1f), true)
        Prim.Torus -> torus()
        Prim.Stairs -> stairs()
        Prim.Capsule -> capsule()
        Prim.Octa -> lathe(listOf(0f to 0f, 0.5f to 0.5f, 0f to 1f), 4, false, false)
        Prim.Gem -> lathe(listOf(0f to 0f, 0.3f to 0.3f, 0.5f to 0.55f, 0.3f to 0.8f, 0f to 1f), 6, false, false)
        Prim.HexPrism -> lathe(listOf(0.5f to 0f, 0.5f to 1f), 6, true, true)
        Prim.Tunnel -> prism(tunnelProfile(), true)
        Prim.LBlock -> prism(listOf(-0.5f to 0f, 0.5f to 0f, 0.5f to 0.4f, -0.1f to 0.4f, -0.1f to 1f, -0.5f to 1f), true)
        Prim.PlusBlock -> prism(plusProfile().map { it.first to (it.second + 0.5f) }, true)
        Prim.Frustum -> lathe(listOf(0.5f to 0f, 0.22f to 1f), 4, true, true)
        Prim.Spiral -> spiral()
        Prim.Pipe -> pipe()
        Prim.FBox -> Panels.build(PanelSpec(4, 4)).let { PrimGeo(it.first, it.second) }
        Prim.FTri -> fill(listOf(V3(0f, 0f, -0.5f), V3(0.5f, 0f, 0.4f), V3(-0.5f, 0f, 0.4f)))
        Prim.FCircle -> fill(ring(0.5f, 0f, 36))
        Prim.FHex -> fill(ring(0.5f, 0f, 6))
        Prim.FTrap -> fill(listOf(V3(-0.5f, 0f, 0.4f), V3(0.5f, 0f, 0.4f), V3(0.3f, 0f, -0.4f), V3(-0.3f, 0f, -0.4f)))
        Prim.FRing -> flatRing()
        Prim.FArch -> {
            val pts = ArrayList<V3>()
            pts.add(V3(-0.5f, 0f, 0.5f)); pts.add(V3(-0.5f, 0f, -0.1f))
            for (i in 1..23) { val a = Math.PI.toFloat() - i.toFloat() / 24f * Math.PI.toFloat(); pts.add(V3(cos(a) * 0.5f, 0f, -0.1f - sin(a) * 0.4f)) }
            pts.add(V3(0.5f, 0f, -0.1f)); pts.add(V3(0.5f, 0f, 0.5f))
            fill(pts)
        }
        Prim.FHalf -> fill((0..24).map { val a = it.toFloat() / 24f * Math.PI.toFloat(); V3(cos(a) * 0.5f, 0f, 0.25f - sin(a) * 0.5f) })
        Prim.FL -> fill(listOf(V3(-0.5f, 0f, -0.5f), V3(0f, 0f, -0.5f), V3(0f, 0f, 0f), V3(0.5f, 0f, 0f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f)))
        Prim.FCross -> fill(plusProfile().map { V3(it.first, 0f, it.second) })
        Prim.FStar -> fill((0 until 10).map {
            val a = -1.5707964f + it.toFloat() / 10f * TAU
            val r = if (it % 2 == 0) 0.5f else 0.21f
            V3(cos(a) * r, 0f, sin(a) * r)
        })
        Prim.FRamp -> fill(listOf(V3(-0.5f, 0f, 0.5f), V3(0.5f, 0f, 0.5f), V3(0.5f, 0f, -0.5f)))
        Prim.Square -> flat(listOf(V3(-0.5f, 0f, -0.5f), V3(0.5f, 0f, -0.5f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f)), true)
        Prim.Circle -> flat(ring(0.5f, 0f, 40), true)
        Prim.Triangle -> flat(listOf(V3(0f, 0f, -0.5f), V3(0.5f, 0f, 0.4f), V3(-0.5f, 0f, 0.4f)), true)
        Prim.Hexagon -> flat(ring(0.5f, 0f, 6), true)
        Prim.Arch -> arch()
    }

    private fun flat(p: List<V3>, closed: Boolean) = PrimGeo(listOf(Stroke(p, closed)), FloatArray(0))

    private fun arch(): PrimGeo {
        val pts = ArrayList<V3>()
        pts.add(V3(-0.5f, 0f, 0f))
        pts.add(V3(-0.5f, 0.4f, 0f))
        for (i in 1..24) {
            val a = PI.toFloat() - i.toFloat() / 24f * PI.toFloat()
            pts.add(V3(cos(a) * 0.5f, 0.4f + sin(a) * 0.5f, 0f))
        }
        pts.add(V3(0.5f, 0f, 0f))
        return PrimGeo(listOf(Stroke(pts, false)), FloatArray(0))
    }

    private fun box(): PrimGeo {
        val a = listOf(V3(-0.5f, 0f, -0.5f), V3(0.5f, 0f, -0.5f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f))
        val b = a.map { V3(it.x, 1f, it.z) }
        val s = ArrayList<Stroke>()
        s.add(loop(a)); s.add(loop(b))
        for (i in 0 until 4) s.add(line(a[i], b[i]))
        val t = FloatList()
        for (i in 0 until 4) { val j = (i + 1) % 4; t.quad(a[i], a[j], b[j], b[i]) }
        t.quad(a[0], a[1], a[2], a[3])
        t.quad(b[3], b[2], b[1], b[0])
        return PrimGeo(s, t.toArray())
    }

    private fun pyramid(): PrimGeo {
        val a = listOf(V3(-0.5f, 0f, -0.5f), V3(0.5f, 0f, -0.5f), V3(0.5f, 0f, 0.5f), V3(-0.5f, 0f, 0.5f))
        val apex = V3(0f, 1f, 0f)
        val s = ArrayList<Stroke>()
        s.add(loop(a))
        for (p in a) s.add(line(p, apex))
        val t = FloatList()
        for (i in 0 until 4) t.tri(a[i], a[(i + 1) % 4], apex)
        t.quad(a[0], a[1], a[2], a[3])
        return PrimGeo(s, t.toArray())
    }

    private fun cone(): PrimGeo {
        val n = 24
        val a = ring(0.5f, 0f, n)
        val apex = V3(0f, 1f, 0f)
        val s = ArrayList<Stroke>()
        s.add(loop(a))
        for (i in 0 until n step 3) s.add(line(a[i], apex))
        val t = FloatList()
        val c = V3.ZERO
        for (i in 0 until n) { val j = (i + 1) % n; t.tri(a[i], a[j], apex); t.tri(c, a[j], a[i]) }
        return PrimGeo(s, t.toArray())
    }

    private fun cylinder(): PrimGeo {
        val n = 24
        val a = ring(0.5f, 0f, n)
        val b = ring(0.5f, 1f, n)
        val s = ArrayList<Stroke>()
        s.add(loop(a)); s.add(loop(b))
        for (i in 0 until n step 3) s.add(line(a[i], b[i]))
        val t = FloatList()
        val ca = V3.ZERO
        val cb = V3(0f, 1f, 0f)
        for (i in 0 until n) {
            val j = (i + 1) % n
            t.quad(a[i], a[j], b[j], b[i])
            t.tri(ca, a[j], a[i])
            t.tri(cb, b[i], b[j])
        }
        return PrimGeo(s, t.toArray())
    }

    private fun sphere(dome: Boolean): PrimGeo {
        val seg = 20
        val rows = if (dome) 6 else 12
        val maxLat = if (dome) PI.toFloat() / 2f else PI.toFloat() / 2f
        val minLat = if (dome) 0f else -PI.toFloat() / 2f
        val cy = if (dome) 0f else 0.5f
        val r = 0.5f
        fun pt(lat: Float, lon: Float) = V3(cos(lat) * cos(lon) * r, cy + sin(lat) * r, cos(lat) * sin(lon) * r)
        val t = FloatList()
        for (i in 0 until rows) {
            val l0 = minLat + (maxLat - minLat) * i / rows
            val l1 = minLat + (maxLat - minLat) * (i + 1) / rows
            for (j in 0 until seg) {
                val o0 = j.toFloat() / seg * TAU
                val o1 = (j + 1).toFloat() / seg * TAU
                t.quad(pt(l0, o0), pt(l0, o1), pt(l1, o1), pt(l1, o0))
            }
        }
        val s = ArrayList<Stroke>()
        val lats = if (dome) listOf(0f, 0.5f, 1.05f) else listOf(-0.8f, 0f, 0.8f)
        for (l in lats) s.add(loop((0 until 32).map { pt(l, it.toFloat() / 32f * TAU) }))
        for (m in 0 until 4) {
            val lon = m.toFloat() / 4f * PI.toFloat()
            val pts = ArrayList<V3>()
            val steps = 24
            val from = if (dome) 0f else -PI.toFloat() / 2f
            val to = if (dome) PI.toFloat() else PI.toFloat() * 1.5f
            // half-circle meridian pair (lon and lon + PI) in one stroke
            if (dome) {
                for (i in 0..steps) {
                    val a = i.toFloat() / steps * PI.toFloat()
                    val x = cos(a) * r
                    pts.add(V3(x * cos(lon), sin(a) * r, x * sin(lon)))
                }
            } else {
                for (i in 0..steps * 2) {
                    val a = from + i.toFloat() / (steps * 2) * (to - from)
                    val x = cos(a) * r
                    pts.add(V3(x * cos(lon), cy + sin(a) * r, x * sin(lon)))
                }
            }
            s.add(Stroke(pts, false))
        }
        if (dome) s.add(loop(ring(0.5f, 0f, 32)))
        return PrimGeo(s, t.toArray())
    }

    /** Extrudes a 2D profile. alongZ: profile is (x,y) extruded in z; otherwise profile is (z,y) extruded in x. */
    private fun prism(prof: List<Pair<Float, Float>>, alongZ: Boolean): PrimGeo {
        fun p(i: Int, side: Float): V3 {
            val (u, v) = prof[i]
            return if (alongZ) V3(u, v, side) else V3(side, v, u)
        }
        val n = prof.size
        val a = (0 until n).map { p(it, -0.5f) }
        val b = (0 until n).map { p(it, 0.5f) }
        val s = ArrayList<Stroke>()
        s.add(loop(a)); s.add(loop(b))
        for (i in 0 until n) s.add(line(a[i], b[i]))
        val t = FloatList()
        for (i in 0 until n) { val j = (i + 1) % n; t.quad(a[i], a[j], b[j], b[i]) }
        val nrm = Geo.normal(a)
        val idx = Geo.triangulate(a, nrm)
        var k = 0
        while (k + 2 < idx.size) {
            t.tri(a[idx[k]], a[idx[k + 1]], a[idx[k + 2]])
            t.tri(b[idx[k]], b[idx[k + 1]], b[idx[k + 2]])
            k += 3
        }
        return PrimGeo(s, t.toArray())
    }

    private fun stairs(): PrimGeo {
        val n = 5
        val prof = ArrayList<Pair<Float, Float>>()
        prof.add(-0.5f to 0f)
        for (i in 0 until n) {
            val z0 = -0.5f + i.toFloat() / n
            val z1 = -0.5f + (i + 1).toFloat() / n
            val h = (i + 1).toFloat() / n
            prof.add(z0 to h)
            prof.add(z1 to h)
        }
        prof.add(0.5f to 0f)
        return prism(prof, false)
    }

    /** Ring standing upright with its axle along X (matches the default Wheel spin axis). */
    private fun torus(): PrimGeo {
        val maj = 24
        val mino = 10
        val rr = 0.34f
        val r = 0.16f
        val cy = 0.5f
        fun pt(i: Int, j: Int): V3 {
            val a = i.toFloat() / maj * TAU
            val b = j.toFloat() / mino * TAU
            val rad = rr + r * cos(b)
            return V3(r * sin(b), cy + sin(a) * rad, cos(a) * rad)
        }
        val t = FloatList()
        for (i in 0 until maj) for (j in 0 until mino) {
            t.quad(pt(i, j), pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1))
        }
        val s = ArrayList<Stroke>()
        for (i in 0 until maj step 3) s.add(loop((0 until mino).map { pt(i, it) }))
        for (j in listOf(0, mino / 4, mino / 2, 3 * mino / 4)) s.add(loop((0 until maj).map { pt(it, j) }))
        return PrimGeo(s, t.toArray())
    }

    private fun fill(poly: List<V3>): PrimGeo {
        val nrm = Geo.normal(poly)
        val idx = Geo.triangulate(poly, nrm)
        val t = FloatList()
        var k = 0
        while (k + 2 < idx.size) { t.tri(poly[idx[k]], poly[idx[k + 1]], poly[idx[k + 2]]); k += 3 }
        return PrimGeo(listOf(Stroke(poly, true)), t.toArray())
    }

    private fun flatRing(): PrimGeo {
        val n = 36
        val o = ring(0.5f, 0f, n)
        val i = ring(0.26f, 0f, n)
        val t = FloatList()
        for (k in 0 until n) { val j = (k + 1) % n; t.quad(o[k], o[j], i[j], i[k]) }
        return PrimGeo(listOf(Stroke(o, true), Stroke(i, true)), t.toArray())
    }

    private fun plusProfile(): List<Pair<Float, Float>> {
        val a = 0.17f
        return listOf(
            -a to -0.5f, a to -0.5f, a to -a, 0.5f to -a, 0.5f to a, a to a,
            a to 0.5f, -a to 0.5f, -a to a, -0.5f to a, -0.5f to -a, -a to -a
        )
    }

    private fun tunnelProfile(): List<Pair<Float, Float>> {
        val pts = ArrayList<Pair<Float, Float>>()
        val pi = Math.PI.toFloat()
        pts.add(-0.5f to 0f)
        pts.add(-0.5f to 0.5f)
        for (i in 1..11) { val a = pi - i.toFloat() / 12f * pi; pts.add(cos(a) * 0.5f to 0.5f + sin(a) * 0.5f) }
        pts.add(0.5f to 0.5f)
        pts.add(0.5f to 0f)
        pts.add(0.3f to 0f)
        pts.add(0.3f to 0.5f)
        for (i in 1..11) { val a = i.toFloat() / 12f * pi; pts.add(cos(a) * 0.3f to 0.5f + sin(a) * 0.3f) }
        pts.add(-0.3f to 0.5f)
        pts.add(-0.3f to 0f)
        return pts
    }

    /** Surface of revolution. profile = (radius, y) bottom to top. */
    private fun lathe(prof: List<Pair<Float, Float>>, seg: Int, capBottom: Boolean, capTop: Boolean): PrimGeo {
        fun pt(k: Int, i: Int): V3 {
            val a = i.toFloat() / seg * TAU + (if (seg == 4 || seg == 6) 0.5235988f else 0f)
            return V3(cos(a) * prof[k].first, prof[k].second, sin(a) * prof[k].first)
        }
        val t = FloatList()
        for (k in 0 until prof.size - 1) for (i in 0 until seg) {
            val j = (i + 1) % seg
            t.quad(pt(k, i), pt(k, j), pt(k + 1, j), pt(k + 1, i))
        }
        if (capBottom) { val c = V3(0f, prof.first().second, 0f); for (i in 0 until seg) t.tri(c, pt(0, (i + 1) % seg), pt(0, i)) }
        if (capTop) { val l = prof.size - 1; val c = V3(0f, prof[l].second, 0f); for (i in 0 until seg) t.tri(c, pt(l, i), pt(l, (i + 1) % seg)) }
        val s = ArrayList<Stroke>()
        for (k in prof.indices) if (prof[k].first > 0.001f) s.add(Stroke((0 until seg).map { pt(k, it) }, true))
        val every = if (seg <= 8) 1 else 4
        var i = 0
        while (i < seg) { s.add(Stroke(prof.indices.map { pt(it, i) }, false)); i += every }
        return PrimGeo(s, t.toArray())
    }

    private fun capsule(): PrimGeo {
        val r = 0.36f
        val prof = ArrayList<Pair<Float, Float>>()
        val half = Math.PI.toFloat() / 2f
        for (i in 0..5) { val lat = -half + i.toFloat() / 5f * half; prof.add(cos(lat) * r to 0.36f + sin(lat) * r) }
        for (i in 0..5) { val lat = i.toFloat() / 5f * half; prof.add(cos(lat) * r to 0.64f + sin(lat) * r) }
        return lathe(prof, 16, false, false)
    }

    private fun pipe(): PrimGeo {
        val n = 24
        val ob = ring(0.5f, 0f, n); val ot = ring(0.5f, 1f, n)
        val ib = ring(0.36f, 0f, n); val it2 = ring(0.36f, 1f, n)
        val t = FloatList()
        for (k in 0 until n) {
            val j = (k + 1) % n
            t.quad(ob[k], ob[j], ot[j], ot[k])
            t.quad(ib[j], ib[k], it2[k], it2[j])
            t.quad(ot[k], ot[j], it2[j], it2[k])
            t.quad(ob[j], ob[k], ib[k], ib[j])
        }
        val s = arrayListOf(loop(ob), loop(ot), loop(ib), loop(it2))
        for (k in 0 until n step 4) { s.add(line(ob[k], ot[k])); s.add(line(ib[k], it2[k])) }
        return PrimGeo(s, t.toArray())
    }

    private fun spiral(): PrimGeo {
        val n = 12
        val t = FloatList()
        val s = ArrayList<Stroke>()
        for (k in 0 until n) {
            val a0 = k.toFloat() / n * TAU
            val a1 = (k + 1).toFloat() / n * TAU
            val h = (k + 1).toFloat() / n
            fun p(r: Float, a: Float, y: Float) = V3(cos(a) * r, y, sin(a) * r)
            val io = p(0.1f, a0, h); val oo = p(0.5f, a0, h); val o1 = p(0.5f, a1, h); val i1 = p(0.1f, a1, h)
            val bo = p(0.1f, a0, 0f); val bb = p(0.5f, a0, 0f); val b1 = p(0.5f, a1, 0f); val bi = p(0.1f, a1, 0f)
            t.quad(io, oo, o1, i1)
            t.quad(oo, bb, b1, o1)
            t.quad(io, i1, bi, bo)
            t.quad(io, bo, bb, oo)
            t.quad(i1, o1, b1, bi)
            s.add(Stroke(listOf(io, oo, o1, i1), true))
            s.add(Stroke(listOf(oo, bb), false))
        }
        return PrimGeo(s, t.toArray())
    }
}


/** Builds geometry for flat panels made of a grid of removable cells. */
object Panels {
    private fun present(spec: PanelSpec, rem: Set<Int>, c: Int, r: Int): Boolean =
        c in 0 until spec.cols && r in 0 until spec.rows && (r * spec.cols + c) !in rem

    fun build(spec: PanelSpec): Pair<List<Stroke>, FloatArray> {
        val rem = spec.removed.toSet()
        val cols = spec.cols; val rows = spec.rows
        fun x(c: Int) = -0.5f + c.toFloat() / cols
        fun z(r: Int) = -0.5f + r.toFloat() / rows
        val t = FloatList()
        for (r in 0 until rows) {
            var c = 0
            while (c < cols) {
                if (!present(spec, rem, c, r)) { c++; continue }
                var e = c
                while (e + 1 < cols && present(spec, rem, e + 1, r)) e++
                t.quad(V3(x(c), 0f, z(r)), V3(x(e + 1), 0f, z(r)), V3(x(e + 1), 0f, z(r + 1)), V3(x(c), 0f, z(r + 1)))
                c = e + 1
            }
        }
        val s = ArrayList<Stroke>()
        // horizontal boundary lines (between rows r-1 and r)
        for (r in 0..rows) {
            var c = 0
            while (c < cols) {
                val edge = present(spec, rem, c, r - 1) != present(spec, rem, c, r)
                if (!edge) { c++; continue }
                var e = c
                while (e + 1 < cols && (present(spec, rem, e + 1, r - 1) != present(spec, rem, e + 1, r))) e++
                s.add(Stroke(listOf(V3(x(c), 0f, z(r)), V3(x(e + 1), 0f, z(r))), false))
                c = e + 1
            }
        }
        for (c in 0..cols) {
            var r = 0
            while (r < rows) {
                val edge = present(spec, rem, c - 1, r) != present(spec, rem, c, r)
                if (!edge) { r++; continue }
                var e = r
                while (e + 1 < rows && (present(spec, rem, c - 1, e + 1) != present(spec, rem, c, e + 1))) e++
                s.add(Stroke(listOf(V3(x(c), 0f, z(r)), V3(x(c), 0f, z(e + 1))), false))
                r = e + 1
            }
        }
        return s to t.toArray()
    }

    /** merged solid rectangles (local min, max) used for collision; holes stay walkable */
    fun rects(spec: PanelSpec): List<Pair<V3, V3>> {
        val rem = spec.removed.toSet()
        val out = ArrayList<Pair<V3, V3>>()
        for (r in 0 until spec.rows) {
            var c = 0
            while (c < spec.cols) {
                if (!present(spec, rem, c, r)) { c++; continue }
                var e = c
                while (e + 1 < spec.cols && present(spec, rem, e + 1, r)) e++
                out.add(
                    V3(-0.5f + c.toFloat() / spec.cols, -0.02f, -0.5f + r.toFloat() / spec.rows) to
                        V3(-0.5f + (e + 1).toFloat() / spec.cols, 0.02f, -0.5f + (r + 1).toFloat() / spec.rows)
                )
                c = e + 1
            }
        }
        return out
    }

    fun cellIndex(spec: PanelSpec, lx: Float, lz: Float): Int {
        if (lx < -0.5f || lx > 0.5f || lz < -0.5f || lz > 0.5f) return -1
        val c = ((lx + 0.5f) * spec.cols).toInt().coerceIn(0, spec.cols - 1)
        val r = ((lz + 0.5f) * spec.rows).toInt().coerceIn(0, spec.rows - 1)
        return r * spec.cols + c
    }

    fun apply(e: Entity, spec: PanelSpec): Entity {
        val g = build(spec)
        return e.copy(panel = spec, strokes = g.first, tris = g.second)
    }
}
