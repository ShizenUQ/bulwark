package com.lineengine3d

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Growable float buffer. Lines: 11 floats per segment (A xyz, B xyz, rgba, width). Tris: 9 floats per triangle. */
class FBuf(cap: Int = 8192) {
    var a = FloatArray(cap)
    var n = 0
    var version = 0

    fun clear() { n = 0 }

    private fun ensure(extra: Int) {
        if (n + extra > a.size) a = a.copyOf(maxOf(a.size * 2, n + extra))
    }

    fun seg(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float,
            r: Float, g: Float, b: Float, al: Float, w: Float) {
        ensure(11)
        val o = a
        var i = n
        o[i++] = ax; o[i++] = ay; o[i++] = az
        o[i++] = bx; o[i++] = by; o[i++] = bz
        o[i++] = r; o[i++] = g; o[i++] = b; o[i++] = al
        o[i++] = w
        n = i
    }

    fun seg(p: V3, q: V3, c: Int, al: Float, w: Float) =
        seg(p.x, p.y, p.z, q.x, q.y, q.z, cr(c), cg(c), cb(c), al, w)

    fun tri(ax: Float, ay: Float, az: Float, bx: Float, by: Float, bz: Float, cx: Float, cy: Float, cz: Float) {
        ensure(9)
        val o = a
        var i = n
        o[i++] = ax; o[i++] = ay; o[i++] = az
        o[i++] = bx; o[i++] = by; o[i++] = bz
        o[i++] = cx; o[i++] = cy; o[i++] = cz
        n = i
    }
}

private fun tx(m: FloatArray, x: Float, y: Float, z: Float) = m[0] * x + m[4] * y + m[8] * z + m[12]
private fun ty(m: FloatArray, x: Float, y: Float, z: Float) = m[1] * x + m[5] * y + m[9] * z + m[13]
private fun tz(m: FloatArray, x: Float, y: Float, z: Float) = m[2] * x + m[6] * y + m[10] * z + m[14]

fun emitStrokes(m: FloatArray, e: Entity, lb: FBuf, alpha: Float = 1f) {
    val r = cr(e.color); val g = cg(e.color); val b = cb(e.color)
    for (s in e.strokes) {
        val p = s.pts
        val cnt = p.size
        if (cnt < 2) continue
        val last = if (s.closed) cnt else cnt - 1
        for (i in 0 until last) {
            val a = p[i]
            val c = p[(i + 1) % cnt]
            if (e.style != 0) {
                val ax = tx(m, a.x, a.y, a.z); val ay = ty(m, a.x, a.y, a.z); val az = tz(m, a.x, a.y, a.z)
                val cx = tx(m, c.x, c.y, c.z); val cy = ty(m, c.x, c.y, c.z); val cz = tz(m, c.x, c.y, c.z)
                val dx = cx - ax; val dy = cy - ay; val dz = cz - az
                val len = kotlin.math.sqrt(dx * dx + dy * dy + dz * dz)
                val on = if (e.style == 1) 0.5f else 0.07f
                val period = if (e.style == 1) 0.85f else 0.38f
                var t = 0f
                var guard = 0
                while (t < len && guard++ < 400) {
                    val t1 = kotlin.math.min(t + on, len)
                    val k0 = t / len; val k1 = t1 / len
                    lb.seg(ax + dx * k0, ay + dy * k0, az + dz * k0, ax + dx * k1, ay + dy * k1, az + dz * k1, r, g, b, alpha, e.width)
                    t += period
                }
                continue
            }
            lb.seg(
                tx(m, a.x, a.y, a.z), ty(m, a.x, a.y, a.z), tz(m, a.x, a.y, a.z),
                tx(m, c.x, c.y, c.z), ty(m, c.x, c.y, c.z), tz(m, c.x, c.y, c.z),
                r, g, b, alpha, e.width
            )
        }
    }
}

fun emitTris(m: FloatArray, e: Entity, tb: FBuf) {
    val t = e.tris
    var i = 0
    while (i + 8 < t.size) {
        tb.tri(
            tx(m, t[i], t[i + 1], t[i + 2]), ty(m, t[i], t[i + 1], t[i + 2]), tz(m, t[i], t[i + 1], t[i + 2]),
            tx(m, t[i + 3], t[i + 4], t[i + 5]), ty(m, t[i + 3], t[i + 4], t[i + 5]), tz(m, t[i + 3], t[i + 4], t[i + 5]),
            tx(m, t[i + 6], t[i + 7], t[i + 8]), ty(m, t[i + 6], t[i + 7], t[i + 8]), tz(m, t[i + 6], t[i + 7], t[i + 8])
        )
        i += 9
    }
}

/**
 * Buffer slots.
 * lines: 0 terrain, 1 static entities, 2 dynamic (depth tested), 3 overlay (no depth test)
 * tris : 0 terrain, 1 static entities, 2 dynamic  (depth-only occlusion pass)
 */
interface RenderHost {
    val theme: Theme
    val xray: Boolean
    val jitter: Float
    val fogNear: Float
    val fogFar: Float
    val lines: Array<FBuf>
    val tris: Array<FBuf>
    fun tick(dt: Float)
    fun camera(aspect: Float, view: FloatArray, proj: FloatArray, eye: FloatArray)
    fun fill()
    fun onSize(w: Int, h: Int)
}

private const val LINE_VS = """#version 300 es
layout(location=0) in vec3 aA;
layout(location=1) in vec3 aB;
layout(location=2) in vec4 aColor;
layout(location=3) in float aWidth;
uniform mat4 uVP;
uniform vec2 uView;
uniform vec3 uCam;
uniform vec2 uFog;
uniform float uJit;
uniform float uDpr;
out vec4 vColor;
out float vSide;
vec3 jit(vec3 p) {
  if (uJit <= 0.0) return vec3(0.0);
  vec3 h = fract(sin(vec3(dot(p, vec3(12.9898, 78.233, 37.719)),
                          dot(p, vec3(39.346, 11.135, 83.155)),
                          dot(p, vec3(73.156, 52.235, 9.151)))) * 43758.5453);
  return (h - 0.5) * uJit;
}
void main() {
  vec3 pa = aA + jit(aA);
  vec3 pb = aB + jit(aB);
  vec4 ca = uVP * vec4(pa, 1.0);
  vec4 cb = uVP * vec4(pb, 1.0);
  float nw = 0.08;
  if (ca.w < nw && cb.w < nw) {
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    vColor = vec4(0.0);
    vSide = 0.0;
    return;
  }
  if (ca.w < nw) {
    float t = (nw - ca.w) / (cb.w - ca.w);
    ca = mix(ca, cb, t);
    pa = mix(pa, pb, t);
  } else if (cb.w < nw) {
    float t = (nw - cb.w) / (ca.w - cb.w);
    cb = mix(cb, ca, t);
    pb = mix(pb, pa, t);
  }
  vec2 sa = ca.xy / ca.w * uView * 0.5;
  vec2 sb = cb.xy / cb.w * uView * 0.5;
  vec2 d = sb - sa;
  float l = length(d);
  d = l > 0.0001 ? d / l : vec2(1.0, 0.0);
  vec2 n = vec2(-d.y, d.x);
  int id = gl_VertexID;
  bool endB = id >= 2;
  float side = ((id & 1) == 0) ? -1.0 : 1.0;
  vec4 c = endB ? cb : ca;
  vec2 s = endB ? sb : sa;
  vec3 wp = endB ? pb : pa;
  float w = max(aWidth * uDpr, 1.5);
  vec2 off = (n * side + d * (endB ? 1.0 : -1.0)) * w * 0.5;
  vec2 ndc = (s + off) / (uView * 0.5);
  gl_Position = vec4(ndc * c.w, c.z, c.w);
  float f = clamp((distance(wp, uCam) - uFog.x) / max(uFog.y - uFog.x, 1.0), 0.0, 1.0);
  vColor = vec4(aColor.rgb, aColor.a * (1.0 - 0.9 * f));
  vSide = side;
}
"""

private const val LINE_FS = """#version 300 es
precision mediump float;
in vec4 vColor;
in float vSide;
out vec4 o;
void main() {
  float e = smoothstep(1.0, 0.45, abs(vSide));
  o = vec4(vColor.rgb, vColor.a * e);
}
"""

private const val SOLID_VS = """#version 300 es
layout(location=0) in vec3 aP;
uniform mat4 uVP;
void main() {
  gl_Position = uVP * vec4(aP, 1.0);
}
"""

private const val SOLID_FS = """#version 300 es
precision mediump float;
out vec4 o;
void main() {
  o = vec4(0.0);
}
"""

class GLRenderer(private val host: RenderHost, private val density: Float) : GLSurfaceView.Renderer {
    @Volatile var fps = 0f
    @Volatile var frameMs = 0f
    private var fpsN = 0
    private var fpsT = 0L
    private var lineProg = 0
    private var solidProg = 0
    private var uVP = 0
    private var uView = 0
    private var uCam = 0
    private var uFog = 0
    private var uJit = 0
    private var uDpr = 0
    private var uVP2 = 0
    private val lineVbo = IntArray(4)
    private val triVbo = IntArray(3)
    private val lineVer = IntArray(4) { -1 }
    private val triVer = IntArray(3) { -1 }
    private val view = FloatArray(16)
    private val proj = FloatArray(16)
    private val vp = FloatArray(16)
    private val eye = FloatArray(3)
    private var w = 1
    private var h = 1
    private var last = 0L
    private var stage: FloatBuffer = ByteBuffer.allocateDirect(1 shl 16).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Shader compile failed: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private fun program(vs: String, fs: String): Int {
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(p, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(p)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Program link failed: " + GLES30.glGetProgramInfoLog(p))
        return p
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        lineProg = program(LINE_VS, LINE_FS)
        solidProg = program(SOLID_VS, SOLID_FS)
        uVP = GLES30.glGetUniformLocation(lineProg, "uVP")
        uView = GLES30.glGetUniformLocation(lineProg, "uView")
        uCam = GLES30.glGetUniformLocation(lineProg, "uCam")
        uFog = GLES30.glGetUniformLocation(lineProg, "uFog")
        uJit = GLES30.glGetUniformLocation(lineProg, "uJit")
        uDpr = GLES30.glGetUniformLocation(lineProg, "uDpr")
        uVP2 = GLES30.glGetUniformLocation(solidProg, "uVP")
        GLES30.glGenBuffers(4, lineVbo, 0)
        GLES30.glGenBuffers(3, triVbo, 0)
        lineVer.fill(-1)
        triVer.fill(-1)
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = maxOf(width, 1)
        h = maxOf(height, 1)
        GLES30.glViewport(0, 0, w, h)
        host.onSize(w, h)
    }

    private fun sync(vbo: Int, b: FBuf, ver: IntArray, i: Int) {
        if (ver[i] == b.version) return
        ver[i] = b.version
        if (b.n == 0) return
        if (b.n > stage.capacity()) {
            stage = ByteBuffer.allocateDirect(maxOf(b.n, stage.capacity() * 2) * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
        }
        stage.clear()
        stage.put(b.a, 0, b.n)
        stage.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, b.n * 4, stage, GLES30.GL_DYNAMIC_DRAW)
    }

    private fun drawTris(i: Int) {
        val n = host.tris[i].n / 3
        if (n == 0) return
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triVbo[i])
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribDivisor(0, 0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, n)
    }

    private fun attrib(loc: Int, size: Int, off: Int) {
        GLES30.glEnableVertexAttribArray(loc)
        GLES30.glVertexAttribPointer(loc, size, GLES30.GL_FLOAT, false, 44, off)
        GLES30.glVertexAttribDivisor(loc, 1)
    }

    private fun drawLines(i: Int) {
        val n = host.lines[i].n / 11
        if (n == 0) return
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, lineVbo[i])
        attrib(0, 3, 0)
        attrib(1, 3, 12)
        attrib(2, 4, 24)
        attrib(3, 1, 40)
        GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLE_STRIP, 0, 4, n)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceIn(0f, 0.1f)
        last = now
        fpsN++
        if (fpsT == 0L) fpsT = now
        if (now - fpsT >= 500_000_000L) {
            fps = fpsN * 1e9f / (now - fpsT)
            frameMs = 1000f / maxOf(fps, 0.01f)
            fpsN = 0
            fpsT = now
        }

        host.tick(dt)
        host.camera(w.toFloat() / h, view, proj, eye)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        host.fill()
        for (i in 0 until 4) sync(lineVbo[i], host.lines[i], lineVer, i)
        for (i in 0 until 3) sync(triVbo[i], host.tris[i], triVer, i)

        val bg = host.theme.bg
        GLES30.glDepthMask(true)
        GLES30.glColorMask(true, true, true, true)
        GLES30.glClearColor(cr(bg), cg(bg), cb(bg), 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // 1) invisible depth-only occlusion pass
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        if (!host.xray) {
            GLES30.glColorMask(false, false, false, false)
            GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
            GLES30.glPolygonOffset(1.5f, 2f)
            GLES30.glUseProgram(solidProg)
            GLES30.glUniformMatrix4fv(uVP2, 1, false, vp, 0)
            for (i in 0 until 3) drawTris(i)
            GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)
            GLES30.glColorMask(true, true, true, true)
        }

        // 2) lines
        GLES30.glDepthMask(false)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glUseProgram(lineProg)
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES30.glUniform2f(uView, w.toFloat(), h.toFloat())
        GLES30.glUniform3f(uCam, eye[0], eye[1], eye[2])
        GLES30.glUniform2f(uFog, host.fogNear, host.fogFar)
        GLES30.glUniform1f(uJit, host.jitter)
        GLES30.glUniform1f(uDpr, density)
        for (i in 0 until 3) drawLines(i)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        drawLines(3)

        for (loc in 0..3) {
            GLES30.glVertexAttribDivisor(loc, 0)
            GLES30.glDisableVertexAttribArray(loc)
        }
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDepthMask(true)
    }
}
