package com.lineengine3d

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

@Composable
fun HubScreen(store: Store, onEdit: (Project) -> Unit, onPlay: (Project) -> Unit) {
    val ctx = LocalContext.current
    var projects by remember { mutableStateOf(store.listProjects()) }
    var showNew by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Project?>(null) }
    var info by remember { mutableStateOf("") }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            info = try {
                val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                store.importJson(text)
            } catch (t: Throwable) {
                "Import failed: ${t.message}"
            }
            projects = store.listProjects()
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0E1118)).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("LineEngine3D", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Draw it. Build it. Play it.", color = Color(0xFF9AA4BC), fontSize = 13.sp)
            }
            OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*")) }) {
                Text("Import JSON")
            }
            Box(Modifier.size(8.dp))
            Button(onClick = { showNew = true }) { Text("+ New Project") }
        }
        if (info.isNotBlank()) Text(info, color = Color(0xFF80D8FF), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        if (projects.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No projects yet. Tap “+ New Project” to begin.", color = Color(0xFF9AA4BC))
            }
        } else {
            LazyColumn(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(projects, key = { it.id }) { p ->
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2030)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(p.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "${p.theme} · ${if (p.terrain.infinite) "infinite" else p.worldSize.toInt().toString() + " m"} · g ${p.gravity} · ${p.entities.size} objects · " +
                                    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.modified)),
                                color = Color(0xFF9AA4BC), fontSize = 12.sp
                            )
                            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(onClick = { onEdit(p) }) { Text("Edit") }
                                Button(onClick = { onPlay(p) }) { Text("Play") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = {
                                    try {
                                        val i = store.shareProject(p)
                                        ctx.startActivity(Intent.createChooser(i, "Share project JSON"))
                                    } catch (t: Throwable) {
                                        info = "Share failed: ${t.message}"
                                    }
                                }) { Text("Export / Share") }
                                TextButton(onClick = { toDelete = p }) { Text("Delete", color = Color(0xFFFF8A80)) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNew) NewProjectDialog(
        onDismiss = { showNew = false },
        onCreate = { name, theme, size, grav, inf ->
            val p = Project(
                id = newId(), name = name.ifBlank { "Untitled" }, theme = theme, worldSize = size, gravity = grav,
                terrain = TerrainData(48, size, infinite = inf), boundary = !inf, infinite = inf,
                renderDist = if (inf) size else 300f, voidY = -30f, modified = System.currentTimeMillis()
            )
            store.save(p)
            projects = store.listProjects()
            showNew = false
            onEdit(p)
        }
    )

    val d = toDelete
    if (d != null) AlertDialog(
        onDismissRequest = { toDelete = null },
        title = { Text("Delete project?") },
        text = { Text("“${d.name}” will be permanently removed.") },
        confirmButton = {
            TextButton(onClick = { store.delete(d.id); projects = store.listProjects(); toDelete = null }) { Text("Delete") }
        },
        dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
    )
}

@Composable
private fun NewProjectDialog(onDismiss: () -> Unit, onCreate: (String, String, Float, Float, Boolean) -> Unit) {
    var name by remember { mutableStateOf("My Project") }
    var theme by remember { mutableStateOf(Themes.list[0].name) }
    var size by remember { mutableStateOf(100f) }
    var grav by remember { mutableStateOf(9.8f) }
    var inf by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Project") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") })
                Text("Theme", modifier = Modifier.padding(top = 10.dp), fontSize = 12.sp)
                HRow { Themes.list.forEach { t -> Pill(t.name, theme == t.name) { theme = t.name } } }
                Text("World type", modifier = Modifier.padding(top = 6.dp), fontSize = 12.sp)
                HRow {
                    Pill("Finite", !inf) { inf = false; if (size < 50f) size = 100f }
                    Pill("Infinite land", inf) { inf = true; if (size > 400f) size = 400f }
                }
                Text(if (inf) "Render distance (m)" else "World size (m)", modifier = Modifier.padding(top = 6.dp), fontSize = 12.sp)
                HRow {
                    (if (inf) listOf(100f, 200f, 300f, 400f) else listOf(50f, 100f, 200f, 400f)).forEach { s ->
                        Pill("${s.toInt()}", size == s) { size = s }
                    }
                }
                Text("Gravity (m/s²)", modifier = Modifier.padding(top = 6.dp), fontSize = 12.sp)
                HRow {
                    listOf(1.6f to "Moon", 9.8f to "Earth", 15f to "Heavy", 0f to "Zero").forEach { (g, n) ->
                        Pill("$n $g", grav == g) { grav = g }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name, theme, size, grav, inf) }) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
