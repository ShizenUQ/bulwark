package com.lineengine3d

import android.opengl.Matrix
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.tan

class EditorEngine(private val ed: Editor, private val density: Float) : RenderHost {
    override val lines = Array(4) { FBuf() }
    override val tris = Array(3) { FBuf() }
    override val theme: Theme get() = ed.theme
    override val xray: Boolean get() = ed.xray
    override val jitter: Float get() = if (ed.jitter) 0.05f else 0f
    private val winRad: Float get() = if (ed.infinite) min(ed.renderDist, 260f) else 420f
    override val fogNear: Float get() = if (ed.infinite) winRad * 0.5f else ed.worldSize * 1.0f
    override val fogFar: Float get() = if (ed.infinite) winRad + 40f else ed.worldSize * 4f + 200f
    private var winA = Int.MIN_VALUE
    private var winB = Int.MIN_VALUE
    private var winX = 0f
    private var winZ = 0f

    private val cam get() = ed.cam
    private val view = FloatArray(16)
    private val proj = FloatArray(16)
    private val vp = FloatArray(16)
    private val invVp = FloatArray(16)
    private var eyeV = V3(0f, 10f, 10f)
    private var vw = 1
    private var vh = 1

    private var lastEnts: List<Entity>? = null
    private var lastTer = -1
    @Volatile private var snapVerts = FloatArray(0)
    @Volatile private var snapHit: V3? = null

    // gesture state
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downT = 0L
    private var moved = false
    private var mode = 0 // 0 none, 1 orbit, 2 gizmo, 3 draw, 4 pinch, 5 ignore
    private var gAxis = -1
    private var pinchDist = 0f
    private var pinchMx = 0f
    private var pinchMy = 0f
    private val freehand = ArrayList<V3>()
    private var rectStart: V3? = null
    private var lastBrush: V3? = null

    private class GStart(val id: String, val pos: V3, val rot: V3, val scl: V3, val localDir: V3, val lo: Float)
    private var gStarts: List<GStart> = emptyList()
    private var gsx = 1f
    private var gsy = 0f

    // ------------------------------------------------------------ RenderHost
    override fun onSize(w: Int, h: Int) { vw = w; vh = h }
    override fun tick(dt: Float) {}

    override fun camera(aspect: Float, view: FloatArray, proj: FloatArray, eye: FloatArray) {
        cam.pitch = cam.pitch.coerceIn(-89f, 89f)
        cam.dist = cam.dist.coerceIn(0.5f, 3000f)
        val e = cam.eye()
        eyeV = e
        eye[0] = e.x; eye[1] = e.y; eye[2] = e.z
        Matrix.setLookAtM(view, 0, e.x, e.y, e.z, cam.tx, cam.ty, cam.tz, 0f, 1f, 0f)
        Matrix.perspectiveM(proj, 0, 55f, aspect, max(0.05f, cam.dist * 0.01f), 4000f)
        System.arraycopy(view, 0, this.view, 0, 16)
        System.arraycopy(proj, 0, this.proj, 0, 16)
        val t = FloatArray(16)
        Matrix.multiplyMM(t, 0, proj, 0, view, 0)
        System.arraycopy(t, 0, vp, 0, 16)
        val iv = FloatArray(16)
        if (Matrix.invertM(iv, 0, t, 0)) System.arraycopy(iv, 0, invVp, 0, 16)
    }

    override fun fill() {
        val ents = ed.entities
        val na = Cull.chunkOf(cam.tx)
        val nb = Cull.chunkOf(cam.tz)
        val moved = na != winA || nb != winB
        if (moved) { winA = na; winB = nb; winX = Cull.centerOf(na); winZ = Cull.centerOf(nb) }
        if (ents !== lastEnts || moved) { lastEnts = ents; rebuildStatic(ents) }
        if (lastTer != ed.terrainVersion || moved) {
            lastTer = ed.terrainVersion
            ed.terrain.buildLines(lines[0], theme, winX, winZ, winRad + 70f)
            lines[0].version++
            ed.terrain.buildTris(tris[0], winX, winZ, winRad + 70f)
            tris[0].version++
        }
        lines[2].clear(); lines[3].clear(); tris[2].clear()
        helpers(lines[2], lines[3])
        lines[2].version++; lines[3].version++; tris[2].version++
    }

    private fun rebuildStatic(ents: List<Entity>) {
        lines[1].clear(); tris[1].clear()
        val w = ed.worlds()
        val sv = FloatList(1024)
        for (e in ents) {
            if (!e.visible) continue
            val m = w[e.id] ?: continue
            val eb = Geo.bounds(e)
            if (eb != null && !Cull.inWindow(m, eb.first, eb.second, winX, winZ, winRad + 70f)) continue
            emitStrokes(m, e, lines[1])
            emitTris(m, e, tris[1])
            for (s in e.strokes) for (p in s.pts) sv.add(M4.pt(m, p))
        }
        snapVerts = sv.toArray()
        lines[1].version++
        tris[1].version++
    }

    // ------------------------------------------------------------ overlay drawing
    private val RED = 0xFFFF5252.toInt()
    private val GREEN = 0xFF69F0AE.toInt()
    private val BLUE = 0xFF448AFF.toInt()
    private val YELLOW = 0xFFFFD600.toInt()
    private val ORANGE = 0xFFFFA000.toInt()
    private val LIME = 0xFF76FF03.toInt()
    private val MAGENTA = 0xFFFF40FF.toInt()

    private fun axisVec(a: Int) = when (a) { 0 -> V3(1f, 0f, 0f); 1 -> V3(0f, 1f, 0f); else -> V3(0f, 0f, 1f) }
    private fun axisCol(a: Int) = when (a) { 0 -> RED; 1 -> GREEN; else -> BLUE }

    private fun cross(b: FBuf, p: V3, s: Float, col: Int, al: Float, w: Float) {
        b.seg(p - V3(s, 0f, 0f), p + V3(s, 0f, 0f), col, al, w)
        b.seg(p - V3(0f, s, 0f), p + V3(0f, s, 0f), col, al, w)
        b.seg(p - V3(0f, 0f, s), p + V3(0f, 0f, s), col, al, w)
    }

    private fun poly(b: FBuf, pts: List<V3>, closed: Boolean, col: Int, al: Float, w: Float) {
        if (pts.size < 2) return
        val last = if (closed) pts.size else pts.size - 1
        for (i in 0 until last) b.seg(pts[i], pts[(i + 1) % pts.size], col, al, w)
    }

    private fun helpers(dyn: FBuf, ov: FBuf) {
        val th = theme
        if (ed.showAxis) {
            dyn.seg(V3.ZERO, V3(2f, 0f, 0f), RED, 0.9f, 2.5f)
            dyn.seg(V3.ZERO, V3(0f, 2f, 0f), GREEN, 0.9f, 2.5f)
            dyn.seg(V3.ZERO, V3(0f, 0f, 2f), BLUE, 0.9f, 2.5f)
        }
        val t = ed.tool
        val drawing = t == Tool.Polyline || t == Tool.Freehand || t == Tool.Rect || t == Tool.Circle
        if (ed.showGrid && drawing) drawWorkGrid(dyn, th.grid)
        if (ed.mirror) {
            val pts = listOf(V3(0f, 0f, -4f), V3(0f, 0f, 4f), V3(0f, 4f, 4f), V3(0f, 4f, -4f))
            poly(dyn, pts, true, MAGENTA, 0.5f, 1.5f)
        }
        // selection boxes
        val worlds = ed.worlds()
        for (id in ed.selected) {
            val e = ed.ent(id) ?: continue
            val m = worlds[id] ?: continue
            val b = Geo.bounds(e)
            if (b == null) { cross(ov, M4.origin(m), 0.4f, ORANGE, 0.9f, 2f); continue }
            val a = b.first; val c = b.second
            val cs = arrayOf(
                V3(a.x, a.y, a.z), V3(c.x, a.y, a.z), V3(c.x, a.y, c.z), V3(a.x, a.y, c.z),
                V3(a.x, c.y, a.z), V3(c.x, c.y, a.z), V3(c.x, c.y, c.z), V3(a.x, c.y, c.z)
            ).map { M4.pt(m, it) }
            for (i in 0 until 4) {
                ov.seg(cs[i], cs[(i + 1) % 4], ORANGE, 0.85f, 1.4f)
                ov.seg(cs[4 + i], cs[4 + (i + 1) % 4], ORANGE, 0.85f, 1.4f)
                ov.seg(cs[i], cs[4 + i], ORANGE, 0.85f, 1.4f)
            }
            val dh = e.find<Logic.DoorHinge>()
            if (dh != null) {
                val pw = M4.pt(m, dh.pivot)
                ov.seg(pw - V3(0f, 0.8f, 0f), pw + V3(0f, 0.8f, 0f), MAGENTA, 1f, 3.5f)
                cross(ov, pw, 0.15f, MAGENTA, 1f, 2.5f)
            }
        }
        // gizmo
        if (t == Tool.Select && ed.primary != null) {
            val o = gizmoOrigin()
            if (o != null) drawGizmo(ov, o, gizmoLen(o))
        }
        // drawing preview
        val cur = ed.cursor
        val pts = ed.drawPts
        if (t == Tool.Polyline) {
            poly(ov, pts, false, LIME, 1f, 2.5f)
            if (pts.isNotEmpty() && cur != null) ov.seg(pts.last(), cur, LIME, 0.6f, 1.5f)
            for (p in pts) cross(ov, p, 0.08f * max(1f, cam.dist * 0.1f), LIME, 1f, 2f)
        }
        if (t == Tool.Freehand) poly(ov, pts, false, LIME, 1f, 2.5f)
        val rs = rectStart
        if (t == Tool.Rect && rs != null && cur != null) poly(ov, rectCorners(rs, cur), true, LIME, 1f, 2.5f)
        if (t == Tool.Circle && rs != null && cur != null) poly(ov, circlePts(rs, cur), true, LIME, 1f, 2.5f)
        if (t == Tool.Shape && cur != null) {
            val k = ed.shapeKind
            val g = Prims.build(k)
            val (gp, gr) = ed.primTransform(k, cur, ed.shapeNormal)
            val ghost = Entity(id = "ghost", pos = gp, rot = gr, scl = V3(2f, 2f, 2f), strokes = g.strokes, color = LIME, width = 2f)
            emitStrokes(M4.trs(ghost.pos, ghost.rot, ghost.scl), ghost, ov, 0.7f)
        }
        if (t == Tool.Cells || ed.primary?.panel != null) {
            val wl = ed.worlds()
            for (e in ed.entities) {
                val spec = e.panel ?: continue
                if (!e.visible || (t != Tool.Cells && e.id !in ed.selected)) continue
                if (spec.cols * spec.rows > 576) continue
                val m = wl[e.id] ?: continue
                val rem = spec.removed.toSet()
                for (r in 0 until spec.rows) for (c in 0 until spec.cols) {
                    if ((r * spec.cols + c) in rem) continue
                    val x0 = -0.5f + c.toFloat() / spec.cols; val x1 = -0.5f + (c + 1).toFloat() / spec.cols
                    val z0 = -0.5f + r.toFloat() / spec.rows; val z1 = -0.5f + (r + 1).toFloat() / spec.rows
                    val a = M4.pt(m, V3(x0, 0f, z0)); val b = M4.pt(m, V3(x1, 0f, z0))
                    val d2 = M4.pt(m, V3(x1, 0f, z1)); val f2 = M4.pt(m, V3(x0, 0f, z1))
                    dyn.seg(a, b, 0xFF80D8FF.toInt(), 0.35f, 1.2f)
                    dyn.seg(b, d2, 0xFF80D8FF.toInt(), 0.35f, 1.2f)
                    dyn.seg(d2, f2, 0xFF80D8FF.toInt(), 0.35f, 1.2f)
                    dyn.seg(f2, a, 0xFF80D8FF.toInt(), 0.35f, 1.2f)
                }
            }
        }
        if (cur != null && (drawing || t == Tool.Stamp || t == Tool.Shape)) {
            val s = (cur - eyeV).len() * 0.02f
            cross(ov, cur, s, YELLOW, 1f, 2f)
        }
        val sh = snapHit
        if (sh != null && drawing) cross(ov, sh, (sh - eyeV).len() * 0.03f, YELLOW, 1f, 3f)
        if (t == Tool.Terrain && cur != null) {
            val r = ed.brushSize
            val ring = ArrayList<V3>()
            for (i in 0 until 40) {
                val a = i / 40f * 6.2831853f
                val x = cur.x + cos(a) * r
                val z = cur.z + sin(a) * r
                val h = ed.terrain.heightAt(x, z).let { if (it <= OUT_H + 1f) cur.y else it }
                ring.add(V3(x, h + 0.1f, z))
            }
            poly(ov, ring, true, YELLOW, 1f, 2.5f)
        }
        // stamp ghost
        val asset = ed.stampAsset
        if (t == Tool.Stamp && asset != null && cur != null && asset.entities.isNotEmpty()) {
            val root = asset.entities[0]
            val ents = asset.entities.map { if (it.id == root.id) it.copy(pos = cur) else it }
            val w = computeWorlds(ents)
            for (e in ents) { val m = w[e.id] ?: continue; emitStrokes(m, e, ov, 0.55f) }
        }
    }

    private fun drawWorkGrid(b: FBuf, col: Int) {
        val gs = ed.gridSize
        val n = 20
        val r = cr(col); val g = cg(col); val bl = cb(col)
        val off = ed.planeOffset
        var u = V3(1f, 0f, 0f); var v = V3(0f, 0f, 1f)
        var o = V3(round(cam.tx / gs) * gs, off, round(cam.tz / gs) * gs)
        when (ed.plane) {
            WPlane.Ground -> {}
            WPlane.Front -> { v = V3(0f, 1f, 0f); o = V3(round(cam.tx / gs) * gs, round(cam.ty / gs) * gs, off) }
            WPlane.Side -> { u = V3(0f, 0f, 1f); v = V3(0f, 1f, 0f); o = V3(off, round(cam.ty / gs) * gs, round(cam.tz / gs) * gs) }
            WPlane.Surface -> {
                val sp = ed.surfacePlane ?: return
                val nn = sp.n
                u = (if (abs(nn.y) < 0.9f) V3.UP.cross(nn) else V3(1f, 0f, 0f).cross(nn)).norm()
                v = nn.cross(u)
                o = sp.p
            }
        }
        for (i in -n..n) {
            val a = o + u * (i * gs) - v * (n * gs)
            val c = o + u * (i * gs) + v * (n * gs)
            b.seg(a.x, a.y, a.z, c.x, c.y, c.z, r, g, bl, 0.22f, 1f)
            val a2 = o + v * (i * gs) - u * (n * gs)
            val c2 = o + v * (i * gs) + u * (n * gs)
            b.seg(a2.x, a2.y, a2.z, c2.x, c2.y, c2.z, r, g, bl, 0.22f, 1f)
        }
    }

    private fun gizmoOrigin(): V3? {
        val e = ed.primary ?: return null
        val m = ed.worlds()[e.id] ?: return null
        return M4.origin(m)
    }

    private fun gizmoLen(o: V3) = max(0.2f, (o - eyeV).len() * 0.16f)

    private fun ringBasis(a: Int): Pair<V3, V3> = when (a) {
        0 -> V3(0f, 1f, 0f) to V3(0f, 0f, 1f)
        1 -> V3(0f, 0f, 1f) to V3(1f, 0f, 0f)
        else -> V3(1f, 0f, 0f) to V3(0f, 1f, 0f)
    }

    private fun drawGizmo(b: FBuf, o: V3, l: Float) {
        for (a in 0..2) {
            val col = if (a == gAxis && mode == 2) YELLOW else axisCol(a)
            val av = axisVec(a)
            if (ed.gizmo == GizmoMode.Rotate) {
                val (u, v) = ringBasis(a)
                val pts = ArrayList<V3>()
                for (i in 0 until 32) {
                    val t = i / 32f * 6.2831853f
                    pts.add(o + (u * cos(t) + v * sin(t)) * (0.8f * l))
                }
                poly(b, pts, true, col, 1f, 3f)
            } else {
                val tip = o + av * l
                b.seg(o, tip, col, 1f, 3.5f)
                val (u, v) = ringBasis(a)
                if (ed.gizmo == GizmoMode.Move) {
                    val base = tip - av * (0.18f * l)
                    for (s in arrayOf(u, -u, v, -v)) b.seg(tip, base + s * (0.07f * l), col, 1f, 2.5f)
                } else {
                    val s = 0.06f * l
                    b.seg(tip - u * s, tip + u * s, col, 1f, 5f)
                    b.seg(tip - v * s, tip + v * s, col, 1f, 5f)
                    b.seg(tip - av * s, tip + av * s, col, 1f, 5f)
                }
            }
        }
        if (ed.gizmo == GizmoMode.Scale) cross(b, o, 0.07f * l, if (gAxis == 3) YELLOW else 0xFFFFFFFF.toInt(), 1f, 4f)
    }

    // ------------------------------------------------------------ geometry helpers
    private fun ray(x: Float, y: Float) = Proj.ray(invVp, x, y, vw, vh)

    private fun hitPlane(o: V3, d: V3, pl: Plane): V3? {
        val den = d.dot(pl.n)
        if (abs(den) < 1e-5f) return null
        val t = (pl.p - o).dot(pl.n) / den
        return if (t < 0f) null else o + d * t
    }

    private fun planeOf(): Plane? = when (ed.plane) {
        WPlane.Ground -> Plane(V3(0f, ed.planeOffset, 0f), V3(0f, 1f, 0f))
        WPlane.Front -> Plane(V3(0f, 0f, ed.planeOffset), V3(0f, 0f, 1f))
        WPlane.Side -> Plane(V3(ed.planeOffset, 0f, 0f), V3(1f, 0f, 0f))
        WPlane.Surface -> ed.surfacePlane
    }

    private fun basis(): Pair<V3, V3> = when (ed.plane) {
        WPlane.Ground -> V3(1f, 0f, 0f) to V3(0f, 0f, 1f)
        WPlane.Front -> V3(1f, 0f, 0f) to V3(0f, 1f, 0f)
        WPlane.Side -> V3(0f, 0f, 1f) to V3(0f, 1f, 0f)
        WPlane.Surface -> {
            val n = ed.surfacePlane?.n ?: V3.UP
            val u = (if (abs(n.y) < 0.9f) V3.UP.cross(n) else V3(1f, 0f, 0f).cross(n)).norm()
            u to n.cross(u)
        }
    }

    private fun rectCorners(p0: V3, p1: V3): List<V3> {
        val (u, v) = basis()
        val d = p1 - p0
        val du = d.dot(u); val dv = d.dot(v)
        return listOf(p0, p0 + u * du, p0 + u * du + v * dv, p0 + v * dv)
    }

    private fun circlePts(c: V3, p1: V3): List<V3> {
        val (u, v) = basis()
        val d = p1 - c
        val r = sqrtF(d.dot(u) * d.dot(u) + d.dot(v) * d.dot(v))
        return (0 until 32).map { i ->
            val a = i / 32f * 6.2831853f
            c + (u * cos(a) + v * sin(a)) * r
        }
    }

    private fun sqrtF(x: Float) = kotlin.math.sqrt(x)

    private fun rayTerrain(o: V3, d: V3): V3? {
        var t = 0f
        var lastT = 0f
        while (t < 3000f) {
            val p = o + d * t
            val h = ed.terrain.heightAt(p.x, p.z)
            if (h > OUT_H + 1f && p.y <= h) {
                var lo = lastT
                var hi = t
                repeat(14) {
                    val mid = (lo + hi) * 0.5f
                    val q = o + d * mid
                    val hh = ed.terrain.heightAt(q.x, q.z)
                    if (hh > OUT_H + 1f && q.y <= hh) hi = mid else lo = mid
                }
                return o + d * hi
            }
            lastT = t
            t += max(0.5f, t * 0.01f)
        }
        return null
    }

    private fun surfaceHit(o: V3, d: V3): Plane? {
        var bestT = Float.MAX_VALUE
        var bn = V3.UP
        val worlds = ed.worlds()
        for (e in ed.entities) {
            if (!e.visible) continue
            val m = worlds[e.id] ?: continue
            if (e.tris.isNotEmpty()) {
                val t = e.tris
                var i = 0
                while (i + 8 < t.size) {
                    val a = M4.pt(m, V3(t[i], t[i + 1], t[i + 2]))
                    val b = M4.pt(m, V3(t[i + 3], t[i + 4], t[i + 5]))
                    val c = M4.pt(m, V3(t[i + 6], t[i + 7], t[i + 8]))
                    val tt = Proj.rayTri(o, d, a, b, c)
                    if (tt > 0f && tt < bestT) { bestT = tt; bn = (b - a).cross(c - a).norm() }
                    i += 9
                }
            } else {
                for (s in e.strokes) {
                    if (!s.closed || s.pts.size < 3) continue
                    val wp = s.pts.map { M4.pt(m, it) }
                    val n = Geo.normal(wp)
                    val idx = Geo.triangulate(wp, n)
                    var k = 0
                    while (k + 2 < idx.size) {
                        val tt = Proj.rayTri(o, d, wp[idx[k]], wp[idx[k + 1]], wp[idx[k + 2]])
                        if (tt > 0f && tt < bestT) { bestT = tt; bn = n }
                        k += 3
                    }
                }
            }
        }
        val th = rayTerrain(o, d)
        if (th != null) {
            val tt = (th - o).len()
            if (tt < bestT) { bestT = tt; bn = ed.terrain.normalAt(th.x, th.z) }
        }
        if (bestT == Float.MAX_VALUE) return null
        if (bn.dot(d) > 0f) bn = -bn
        return Plane(o + d * bestT, bn)
    }

    private fun nearestVertex(sx: Float, sy: Float, r: Float): V3? {
        val sv = snapVerts
        val o = FloatArray(3)
        var best = r
        var res: V3? = null
        var i = 0
        while (i + 2 < sv.size) {
            if (Proj.toScreen(vp, sv[i], sv[i + 1], sv[i + 2], vw, vh, o)) {
                val d = hypot(o[0] - sx, o[1] - sy)
                if (d < best) { best = d; res = V3(sv[i], sv[i + 1], sv[i + 2]) }
            }
            i += 3
        }
        for (p in ed.drawPts) {
            if (Proj.toScreen(vp, p.x, p.y, p.z, vw, vh, o)) {
                val d = hypot(o[0] - sx, o[1] - sy)
                if (d < best) { best = d; res = p }
            }
        }
        return res
    }

    private fun resolve(x: Float, y: Float): V3? {
        val (o, d) = ray(x, y)
        var p: V3? = null
        if (ed.plane == WPlane.Surface && ed.surfacePlane == null) {
            val h = surfaceHit(o, d)
            if (h != null) { ed.surfacePlane = h; p = h.p }
            else p = hitPlane(o, d, Plane(V3.ZERO, V3.UP))
        } else {
            val pl = planeOf()
            if (pl != null) p = hitPlane(o, d, pl)
        }
        if (p == null) return null
        snapHit = null
        if (ed.vertexSnap) {
            val v = nearestVertex(x, y, 26f * density)
            if (v != null) { snapHit = v; return v }
        }
        if (ed.gridSnap && ed.plane != WPlane.Surface) {
            val g = ed.gridSize
            fun r(a: Float) = round(a / g) * g
            p = when (ed.plane) {
                WPlane.Ground -> V3(r(p.x), p.y, r(p.z))
                WPlane.Front -> V3(r(p.x), r(p.y), p.z)
                else -> V3(p.x, r(p.y), r(p.z))
            }
        }
        return p
    }

    private var cellRemove = true
    private var cellEntity: String? = null

    private fun cellPick(x: Float, y: Float): Pair<Entity, Int>? {
        val (o, d) = ray(x, y)
        val w = ed.worlds()
        var best: Pair<Entity, Int>? = null
        var bt = Float.MAX_VALUE
        for (e in ed.entities) {
            val spec = e.panel ?: continue
            if (!e.visible) continue
            val m = w[e.id] ?: continue
            val iv = M4.inv(m)
            val lo = M4.pt(iv, o)
            val ld = M4.dir(iv, d)
            if (abs(ld.y) < 1e-6f) continue
            val t = -lo.y / ld.y
            if (t < 0f || t >= bt) continue
            val idx = Panels.cellIndex(spec, lo.x + ld.x * t, lo.z + ld.z * t)
            if (idx < 0) continue
            bt = t
            best = e to idx
        }
        return best
    }

    private fun cellDown(x: Float, y: Float) {
        val hit = cellPick(x, y) ?: return
        val e = hit.first
        ed.selected = setOf(e.id)
        cellEntity = e.id
        cellRemove = hit.second !in (e.panel?.removed ?: emptyList())
        ed.checkpoint()
        ed.setCell(e.id, hit.second, cellRemove)
    }

    private fun cellMove(x: Float, y: Float) {
        val hit = cellPick(x, y) ?: return
        if (hit.first.id != cellEntity) return
        ed.setCell(hit.first.id, hit.second, cellRemove)
    }

    /** Aims the shape cursor at an object surface or the terrain. */
    private fun shapeAim(x: Float, y: Float) {
        val (o, d) = ray(x, y)
        val h = surfaceHit(o, d)
        if (h != null) { ed.cursor = h.p; ed.shapeNormal = h.n }
        else { ed.cursor = hitPlane(o, d, Plane(V3.ZERO, V3.UP)); ed.shapeNormal = V3.UP }
    }

    private fun terrainHit(x: Float, y: Float): V3? {
        val (o, d) = ray(x, y)
        return rayTerrain(o, d) ?: hitPlane(o, d, Plane(V3.ZERO, V3.UP))
    }

    // ------------------------------------------------------------ camera presets
    fun preset(kind: Int) {
        when (kind) {
            0 -> { cam.pitch = 89f }
            1 -> { cam.yaw = 0f; cam.pitch = 0f }
            else -> { cam.yaw = 90f; cam.pitch = 0f }
        }
    }

    fun focusSelected() {
        val b = ed.selectionBounds() ?: return
        val c = (b.first + b.second) * 0.5f
        val r = (b.second - b.first).len() * 0.5f
        cam.tx = c.x; cam.ty = c.y; cam.tz = c.z
        cam.dist = max(r * 2.6f, 4f)
    }

    // ------------------------------------------------------------ touch
    fun touch(ev: MotionEvent, w: Int, h: Int): Boolean {
        vw = w; vh = h
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; lastX = ev.x; lastY = ev.y
                downT = System.currentTimeMillis(); moved = false
                begin(ev.x, ev.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (mode == 3) cancelGesture()
                if (mode == 2) { mode = 4 }
                mode = 4
                if (ev.pointerCount >= 2) startPinch(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 4) { if (ev.pointerCount >= 2) pinch(ev) }
                else if (mode != 5) move(ev.x, ev.y)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (ev.pointerCount - 1 < 2) mode = 5 else startPinch(ev)
            }
            MotionEvent.ACTION_UP -> {
                if (mode != 4 && mode != 5) end(ev.x, ev.y)
                mode = 0; gAxis = -1
            }
            MotionEvent.ACTION_CANCEL -> { cancelGesture(); mode = 0; gAxis = -1 }
        }
        return true
    }

    private fun cancelGesture() {
        freehand.clear()
        rectStart = null
        if (ed.tool == Tool.Freehand || ed.tool == Tool.Rect || ed.tool == Tool.Circle) ed.cancelDraw()
    }

    private fun startPinch(ev: MotionEvent) {
        pinchDist = hypot(ev.getX(0) - ev.getX(1), ev.getY(0) - ev.getY(1))
        pinchMx = (ev.getX(0) + ev.getX(1)) * 0.5f
        pinchMy = (ev.getY(0) + ev.getY(1)) * 0.5f
    }

    private fun pinch(ev: MotionEvent) {
        val d = hypot(ev.getX(0) - ev.getX(1), ev.getY(0) - ev.getY(1))
        val mx = (ev.getX(0) + ev.getX(1)) * 0.5f
        val my = (ev.getY(0) + ev.getY(1)) * 0.5f
        if (pinchDist > 8f && d > 8f) cam.dist = (cam.dist * pinchDist / d).coerceIn(0.5f, 3000f)
        val s = 2f * cam.dist * tan(rad(27.5f)) / max(vh, 1)
        val dx = mx - pinchMx
        val dy = my - pinchMy
        val rx = view[0]; val ry = view[4]; val rz = view[8]
        val ux = view[1]; val uy = view[5]; val uz = view[9]
        cam.tx += -rx * dx * s + ux * dy * s
        cam.ty += -ry * dx * s + uy * dy * s
        cam.tz += -rz * dx * s + uz * dy * s
        pinchDist = d; pinchMx = mx; pinchMy = my
    }

    private fun begin(x: Float, y: Float) {
        val nav = ed.tool == Tool.Select || ed.navMode
        if (nav) {
            if (ed.tool == Tool.Select && ed.primary != null && !ed.navMode) {
                gAxis = hitGizmo(x, y)
                if (gAxis >= 0) { startGizmo(); mode = 2; return }
            }
            mode = 1
        } else {
            mode = 3
            drawBegin(x, y)
        }
    }

    private fun move(x: Float, y: Float) {
        val dx = x - lastX
        val dy = y - lastY
        lastX = x; lastY = y
        if (!moved && hypot(x - downX, y - downY) > 14f * density) moved = true
        when (mode) {
            1 -> if (moved) {
                cam.yaw -= dx * 0.35f
                cam.pitch = (cam.pitch + dy * 0.35f).coerceIn(-89f, 89f)
            }
            2 -> gizmoDrag(x - downX, y - downY)
            3 -> drawMove(x, y)
        }
    }

    private fun end(x: Float, y: Float) {
        when (mode) {
            1 -> if (!moved && System.currentTimeMillis() - downT < 600) pick(x, y)
            2 -> {
                gStarts = emptyList()
                if (ed.autoDrop && ed.gizmo == GizmoMode.Move) ed.snapToSurface()
            }
            3 -> drawEnd(x, y)
        }
    }

    // ------------------------------------------------------------ drawing tools
    private fun drawBegin(x: Float, y: Float) {
        when (ed.tool) {
            Tool.Polyline -> ed.cursor = resolve(x, y)
            Tool.Freehand -> {
                if (ed.plane == WPlane.Surface) ed.surfacePlane = null
                freehand.clear()
                val p = resolve(x, y)
                if (p != null) freehand.add(p)
                ed.drawPts = freehand.toList()
            }
            Tool.Rect, Tool.Circle -> {
                if (ed.plane == WPlane.Surface) ed.surfacePlane = null
                rectStart = resolve(x, y)
                ed.cursor = rectStart
            }
            Tool.Eraser -> { ed.checkpoint(); erase(x, y) }
            Tool.Terrain -> terrainDown(x, y)
            Tool.Stamp -> ed.cursor = terrainHit(x, y)
            Tool.Shape -> shapeAim(x, y)
            Tool.Cells -> cellDown(x, y)
            else -> {}
        }
    }

    private fun drawMove(x: Float, y: Float) {
        when (ed.tool) {
            Tool.Polyline, Tool.Rect, Tool.Circle -> ed.cursor = resolve(x, y)
            Tool.Freehand -> {
                val p = resolve(x, y) ?: return
                if (freehand.isEmpty() || freehand.last().dist(p) > max(0.08f, cam.dist * 0.004f)) {
                    freehand.add(p)
                    ed.drawPts = freehand.toList()
                }
            }
            Tool.Eraser -> erase(x, y)
            Tool.Terrain -> terrainMove(x, y)
            Tool.Stamp -> ed.cursor = terrainHit(x, y)
            Tool.Shape -> shapeAim(x, y)
            Tool.Cells -> cellMove(x, y)
            else -> {}
        }
    }

    private fun drawEnd(x: Float, y: Float) {
        val o = FloatArray(3)
        when (ed.tool) {
            Tool.Polyline -> {
                val p = resolve(x, y) ?: return
                val pts = ed.drawPts
                if (pts.size >= 3) {
                    val f = pts[0]
                    if (Proj.toScreen(vp, f.x, f.y, f.z, vw, vh, o) && hypot(o[0] - x, o[1] - y) < 30f * density) {
                        ed.finishPolyline(true)
                        return
                    }
                }
                ed.drawPts = pts + p
                ed.cursor = p
            }
            Tool.Freehand -> {
                val pts = freehand.toList()
                freehand.clear()
                if (pts.size >= 2) {
                    var length = 0f
                    for (i in 1 until pts.size) length += pts[i].dist(pts[i - 1])
                    val s = Geo.simplify(pts, max(0.05f, cam.dist * 0.004f))
                    val close = s.size >= 4 && s.first().dist(s.last()) < max(0.3f, length * 0.08f)
                    val fin = if (close) s.dropLast(1) else s
                    ed.addShape(listOf(Stroke(fin, close)))
                }
                ed.cancelDraw()
            }
            Tool.Rect -> {
                val a = rectStart
                val b = resolve(x, y)
                if (a != null && b != null) {
                    val c = rectCorners(a, b)
                    if (c[0].dist(c[1]) > 0.05f && c[1].dist(c[2]) > 0.05f) ed.addShape(listOf(Stroke(c, true)))
                }
                rectStart = null
                ed.cancelDraw()
            }
            Tool.Circle -> {
                val a = rectStart
                val b = resolve(x, y)
                if (a != null && b != null && a.dist(b) > 0.05f) ed.addShape(listOf(Stroke(circlePts(a, b), true)))
                rectStart = null
                ed.cancelDraw()
            }
            Tool.Terrain -> { lastBrush = null }
            Tool.Stamp -> {
                val c = ed.cursor
                val a = ed.stampAsset
                if (c != null && a != null) {
                    ed.placeAsset(a, c.x, c.z)
                    if (!ed.multiStamp) { ed.stampAsset = null; ed.selectTool(Tool.Select) }
                }
            }
            Tool.Shape -> {
                shapeAim(x, y)
                val c = ed.cursor
                if (c != null) {
                    ed.placePrimitive(ed.shapeKind, c, ed.shapeNormal)
                    ed.cursor = null
                    if (!ed.multiStamp) ed.selectTool(Tool.Select)
                }
            }
            Tool.Hinge -> hingePick(x, y)
            else -> {}
        }
    }

    private fun terrainDown(x: Float, y: Float) {
        ed.checkpoint()
        val h = terrainHit(x, y) ?: return
        ed.flattenTarget = ed.terrain.heightAt(h.x, h.z).let { if (it <= OUT_H + 1f) 0f else it }
        ed.cursor = h
        lastBrush = h
        ed.sculpt(h.x, h.z, true)
    }

    private fun terrainMove(x: Float, y: Float) {
        val h = terrainHit(x, y) ?: return
        ed.cursor = h
        if (ed.brush == 4) {
            val lb = lastBrush
            if (lb == null || hypot(h.x - lb.x, h.z - lb.z) > ed.brushSize * 0.9f) {
                lastBrush = h
                ed.sculpt(h.x, h.z, true)
            }
        } else {
            lastBrush = h
            ed.sculpt(h.x, h.z, false)
        }
    }

    private fun hingePick(x: Float, y: Float) {
        val e = ed.primary ?: return
        val m = ed.worlds()[e.id] ?: return
        val o = FloatArray(3)
        var best = 46f * density
        var res: V3? = null
        for (s in e.strokes) for (p in s.pts) {
            val w = M4.pt(m, p)
            if (Proj.toScreen(vp, w.x, w.y, w.z, vw, vh, o)) {
                val d = hypot(o[0] - x, o[1] - y)
                if (d < best) { best = d; res = p }
            }
        }
        if (res != null) {
            ed.setHingePivot(res)
            ed.message = "Hinge pivot set"
            ed.selectTool(Tool.Select)
        } else ed.message = "Tap near a vertex of the selected door"
    }

    // ------------------------------------------------------------ picking / erasing
    private fun rayTrisWorld(m: FloatArray, t: FloatArray, o: V3, d: V3): Float {
        var best = -1f
        var i = 0
        while (i + 8 < t.size) {
            val a = M4.pt(m, V3(t[i], t[i + 1], t[i + 2]))
            val b = M4.pt(m, V3(t[i + 3], t[i + 4], t[i + 5]))
            val c = M4.pt(m, V3(t[i + 6], t[i + 7], t[i + 8]))
            val tt = Proj.rayTri(o, d, a, b, c)
            if (tt > 0f && (best < 0f || tt < best)) best = tt
            i += 9
        }
        return best
    }

    private fun pick(x: Float, y: Float) {
        val worlds = ed.worlds()
        val (o, d) = ray(x, y)
        var best: String? = null
        var bs = Float.MAX_VALUE
        val thr = 30f * density
        val mvp = FloatArray(16)
        val o1 = FloatArray(3)
        val o2 = FloatArray(3)
        for (e in ed.entities) {
            if (!e.visible) continue
            val m = worlds[e.id] ?: continue
            Matrix.multiplyMM(mvp, 0, vp, 0, m, 0)
            var score = Float.MAX_VALUE
            for (s in e.strokes) {
                val p = s.pts
                val n = p.size
                if (n < 2) continue
                val last = if (s.closed) n else n - 1
                for (i in 0 until last) {
                    val a = p[i]
                    val b = p[(i + 1) % n]
                    if (!Proj.toScreen(mvp, a.x, a.y, a.z, vw, vh, o1)) continue
                    if (!Proj.toScreen(mvp, b.x, b.y, b.z, vw, vh, o2)) continue
                    val dd = Proj.distSeg(x, y, o1[0], o1[1], o2[0], o2[1])
                    if (dd < score) score = dd
                }
            }
            if (e.tris.isNotEmpty()) {
                val tt = rayTrisWorld(m, e.tris, o, d)
                if (tt > 0f) score = min(score, 10f * density + tt * 0.01f)
            }
            if (score < thr && score < bs) { bs = score; best = e.id }
        }
        ed.tapEntity(best, true)
    }

    private fun erase(x: Float, y: Float) {
        val worlds = ed.worlds()
        val r = 26f * density
        val mvp = FloatArray(16)
        val o1 = FloatArray(3)
        val o2 = FloatArray(3)
        var changed = false
        val result = ArrayList<Entity>()
        val all = ed.entities
        for (e in all) {
            val m = worlds[e.id]
            if (m == null || !e.visible || e.strokes.isEmpty()) { result.add(e); continue }
            Matrix.multiplyMM(mvp, 0, vp, 0, m, 0)
            val ns = ArrayList<Stroke>()
            var ec = false
            for (s in e.strokes) {
                val p = s.pts
                val n = p.size
                if (n < 2) { ns.add(s); continue }
                val segs = if (s.closed) n else n - 1
                val hit = BooleanArray(segs)
                var any = false
                for (i in 0 until segs) {
                    val a = p[i]
                    val b = p[(i + 1) % n]
                    if (Proj.toScreen(mvp, a.x, a.y, a.z, vw, vh, o1) && Proj.toScreen(mvp, b.x, b.y, b.z, vw, vh, o2)) {
                        if (Proj.distSeg(x, y, o1[0], o1[1], o2[0], o2[1]) < r) { hit[i] = true; any = true }
                    }
                }
                if (!any) { ns.add(s); continue }
                ec = true
                var run = ArrayList<V3>()
                for (i in 0 until segs) {
                    if (hit[i]) {
                        if (run.size >= 2) ns.add(Stroke(run))
                        run = ArrayList()
                    } else {
                        if (run.isEmpty()) run.add(p[i])
                        run.add(p[(i + 1) % n])
                    }
                }
                if (run.size >= 2) ns.add(Stroke(run))
            }
            if (ec) {
                changed = true
                val hasKids = all.any { it.parentId == e.id }
                if (ns.isEmpty() && e.tris.isEmpty() && e.logic.isEmpty() && !hasKids) continue
                result.add(e.copy(strokes = ns))
            } else result.add(e)
        }
        if (changed) {
            ed.entities = result
            ed.selected = ed.selected.filter { id -> result.any { it.id == id } }.toSet()
            ed.revision++
        }
    }

    // ------------------------------------------------------------ gizmos
    private fun gizmoSamples(o: V3, a: Int, l: Float): List<V3> {
        if (ed.gizmo == GizmoMode.Rotate) {
            val (u, v) = ringBasis(a)
            return (0 until 32).map { i ->
                val t = i / 32f * 6.2831853f
                o + (u * cos(t) + v * sin(t)) * (0.8f * l)
            }
        }
        val av = axisVec(a)
        return (1..8).map { i -> o + av * (l * i / 8f) }
    }

    private fun hitGizmo(x: Float, y: Float): Int {
        val o = gizmoOrigin() ?: return -1
        val l = gizmoLen(o)
        val out = FloatArray(3)
        var best = -1
        var bd = 46f * density
        for (a in 0..2) {
            for (p in gizmoSamples(o, a, l)) {
                if (!Proj.toScreen(vp, p.x, p.y, p.z, vw, vh, out)) continue
                val d = hypot(out[0] - x, out[1] - y)
                if (d < bd) { bd = d; best = a }
            }
        }
        if (best < 0 && ed.gizmo == GizmoMode.Scale &&
            Proj.toScreen(vp, o.x, o.y, o.z, vw, vh, out) && hypot(out[0] - x, out[1] - y) < 34f * density
        ) return 3
        return best
    }

    private fun startGizmo() {
        ed.checkpoint()
        val roots = ed.rootsOfSelection()
        val worlds = ed.worlds()
        val o = gizmoOrigin() ?: return
        val axis = if (gAxis <= 2) axisVec(gAxis) else V3.UP
        gStarts = roots.map { e ->
            val pid = e.parentId
            val pm = if (pid != null) worlds[pid] else null
            val ld = if (pm != null) M4.dir(M4.inv(pm), axis) else axis
            val lb = Geo.bounds(e)
            val lo = if (lb == null || gAxis > 2) 0f else when (gAxis) { 0 -> lb.first.x; 1 -> lb.first.y; else -> lb.first.z }
            GStart(e.id, e.pos, e.rot, e.scl, ld, lo)
        }
        val a = FloatArray(3)
        val b = FloatArray(3)
        val p2 = o + axis
        if (Proj.toScreen(vp, o.x, o.y, o.z, vw, vh, a) && Proj.toScreen(vp, p2.x, p2.y, p2.z, vw, vh, b)) {
            gsx = b[0] - a[0]; gsy = b[1] - a[1]
        } else { gsx = 1f; gsy = 0f }
    }

    private fun gizmoDrag(totX: Float, totY: Float) {
        if (gStarts.isEmpty()) return
        val sp2 = max(gsx * gsx + gsy * gsy, 1e-3f)
        val units = (totX * gsx + totY * gsy) / sp2
        val map = gStarts.associateBy { it.id }
        val gs = ed.gridSize
        val axis = gAxis
        val mode = ed.gizmo
        ed.entities = ed.entities.map { e ->
            val s = map[e.id] ?: return@map e
            when (mode) {
                GizmoMode.Move -> {
                    val u = if (ed.gridSnap) round(units / gs) * gs else units
                    e.copy(pos = s.pos + s.localDir * u)
                }
                GizmoMode.Rotate -> {
                    var dg = totX * 0.45f
                    if (ed.gridSnap) dg = round(dg / 15f) * 15f
                    if (axis in 0..2) e.copy(rot = s.rot + axisVec(axis) * dg) else e
                }
                GizmoMode.Stretch -> {
                    if (axis !in 0..2) e else {
                        var f = (1f + units * 0.5f).coerceIn(0.05f, 50f)
                        if (ed.gridSnap) f = (round(f * 10f) / 10f).coerceAtLeast(0.1f)
                        val sa = when (axis) { 0 -> s.scl.x; 1 -> s.scl.y; else -> s.scl.z }
                        e.copy(
                            pos = s.pos + s.localDir * (s.lo * sa * (1f - f)),
                            scl = V3(
                                if (axis == 0) s.scl.x * f else s.scl.x,
                                if (axis == 1) s.scl.y * f else s.scl.y,
                                if (axis == 2) s.scl.z * f else s.scl.z
                            )
                        )
                    }
                }
                GizmoMode.Scale -> {
                    if (axis == 3) {
                        val f = (1f + (totX - totY) / 200f).coerceIn(0.05f, 50f)
                        e.copy(scl = s.scl * f)
                    } else {
                        val f = (1f + units * 0.5f).coerceIn(0.05f, 50f)
                        e.copy(
                            scl = V3(
                                if (axis == 0) s.scl.x * f else s.scl.x,
                                if (axis == 1) s.scl.y * f else s.scl.y,
                                if (axis == 2) s.scl.z * f else s.scl.z
                            )
                        )
                    }
                }
            }
        }
        ed.revision++
    }
}
