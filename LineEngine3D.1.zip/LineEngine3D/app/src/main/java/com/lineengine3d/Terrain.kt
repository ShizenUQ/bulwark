package com.lineengine3d

import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Chunked heightfield. Vertices sit on a global 2 m grid and are stored in 64 m chunks, so a world can be finite
 * (up to 400 m) or infinite. Chunks that were never edited are not stored at all (flat, height 0).
 * n / size / heights are only kept to load projects saved by older versions.
 */
@Serializable
class TerrainData(
    val n: Int = 48,
    val size: Float = 100f,
    val heights: FloatArray = FloatArray(0),
    val infinite: Boolean = false,
    val chunks: Map<Long, FloatArray> = HashMap()
) {
    companion object {
        const val C = 2f
        const val CH = 32
        const val CHM = 64f
        fun key(cx: Int, cz: Int): Long = (cx.toLong() shl 32) xor (cz.toLong() and 0xFFFFFFFFL)
    }

    @Transient
    private val store = ConcurrentHashMap<Long, FloatArray>()

    /** vertices on each side of the origin for finite worlds */
    private val nv: Int get() = ceil(size / 2f / C).toInt()

    val cell: Float get() = C
    val half: Float get() = if (infinite) 1e9f else nv * C

    init {
        for ((k, v) in chunks) store[k] = v.copyOf()
        if (heights.isNotEmpty() && chunks.isEmpty() && n > 0) migrate()
    }

    private fun migrate() {
        val oc = size / n
        val oh = size / 2f
        fun ov(i: Int, j: Int) = heights[j.coerceIn(0, n) * (n + 1) + i.coerceIn(0, n)]
        for (gj in -nv..nv) for (gi in -nv..nv) {
            val fx = (gi * C + oh) / oc
            val fz = (gj * C + oh) / oc
            if (fx < 0f || fz < 0f || fx > n || fz > n) continue
            val i = min(fx.toInt(), n - 1); val j = min(fz.toInt(), n - 1)
            val tx = fx - i; val tz = fz - j
            val h = (ov(i, j) * (1 - tx) + ov(i + 1, j) * tx) * (1 - tz) + (ov(i, j + 1) * (1 - tx) + ov(i + 1, j + 1) * tx) * tz
            if (h != 0f) setV(gi, gj, h)
        }
    }

    fun dup(): TerrainData {
        val m = HashMap<Long, FloatArray>()
        for ((k, v) in store) m[k] = v.copyOf()
        return TerrainData(n, size, FloatArray(0), infinite, m)
    }

    fun snapshot(): Map<Long, FloatArray> {
        val m = HashMap<Long, FloatArray>()
        for ((k, v) in store) m[k] = v.copyOf()
        return m
    }

    fun restore(s: Map<Long, FloatArray>) {
        store.clear()
        for ((k, v) in s) store[k] = v.copyOf()
    }

    fun sameAs(s: Map<Long, FloatArray>): Boolean {
        if (s.size != store.size) return false
        for ((k, v) in s) {
            val c = store[k] ?: return false
            if (!c.contentEquals(v)) return false
        }
        return true
    }

    // ------------------------------------------------------------ vertex access (global integer vertex coords)
    fun hv(gi0: Int, gj0: Int): Float {
        var gi = gi0; var gj = gj0
        if (!infinite) { gi = gi.coerceIn(-nv, nv); gj = gj.coerceIn(-nv, nv) }
        val a = store[key(Math.floorDiv(gi, CH), Math.floorDiv(gj, CH))] ?: return 0f
        return a[Math.floorMod(gj, CH) * CH + Math.floorMod(gi, CH)]
    }

    private fun setV(gi: Int, gj: Int, v: Float) {
        val k = key(Math.floorDiv(gi, CH), Math.floorDiv(gj, CH))
        val a = store.getOrPut(k) { FloatArray(CH * CH) }
        a[Math.floorMod(gj, CH) * CH + Math.floorMod(gi, CH)] = v
    }

    private fun inRange(gi: Int, gj: Int) = infinite || (gi >= -nv && gi <= nv && gj >= -nv && gj <= nv)

    fun heightAt(x: Float, z: Float): Float {
        if (!infinite) {
            val h = half
            if (x < -h || z < -h || x > h || z > h) return OUT_H
        }
        val fx = x / C
        val fz = z / C
        val gi = floor(fx).toInt()
        val gj = floor(fz).toInt()
        val tx = fx - gi
        val tz = fz - gj
        val h00 = hv(gi, gj); val h10 = hv(gi + 1, gj); val h01 = hv(gi, gj + 1); val h11 = hv(gi + 1, gj + 1)
        return (h00 * (1 - tx) + h10 * tx) * (1 - tz) + (h01 * (1 - tx) + h11 * tx) * tz
    }

    fun normalAt(x: Float, z: Float): V3 {
        val e = C * 0.5f
        val c = heightAt(x, z).let { if (it <= OUT_H + 1f) 0f else it }
        fun g(px: Float, pz: Float): Float {
            val h = heightAt(px, pz)
            return if (h <= OUT_H + 1f) c else h
        }
        return V3(g(x - e, z) - g(x + e, z), 2f * e, g(x, z - e) - g(x, z + e)).norm()
    }

    /** mode: 0 raise, 1 lower, 2 smooth, 3 flatten */
    fun brush(mode: Int, cx: Float, cz: Float, radius: Float, strength: Float, target: Float) {
        val i0 = floor((cx - radius) / C).toInt() - 1
        val i1 = ceil((cx + radius) / C).toInt() + 1
        val j0 = floor((cz - radius) / C).toInt() - 1
        val j1 = ceil((cz + radius) / C).toInt() + 1
        val w = i1 - i0 + 1
        val old = FloatArray(w * (j1 - j0 + 1))
        for (j in j0..j1) for (i in i0..i1) old[(j - j0) * w + (i - i0)] = hv(i, j)
        fun ov(i: Int, j: Int): Float =
            if (i in i0..i1 && j in j0..j1) old[(j - j0) * w + (i - i0)] else hv(i, j)
        for (j in j0..j1) for (i in i0..i1) {
            if (!inRange(i, j)) continue
            val dx = i * C - cx; val dz = j * C - cz
            val d = sqrt(dx * dx + dz * dz)
            if (d > radius) continue
            var f = 1f - d / radius
            f = f * f * (3f - 2f * f)
            val cur = ov(i, j)
            val nv2 = when (mode) {
                0 -> cur + strength * f * 0.24f
                1 -> cur - strength * f * 0.24f
                2 -> {
                    val avg = (ov(i - 1, j) + ov(i + 1, j) + ov(i, j - 1) + ov(i, j + 1)) * 0.25f
                    cur + (avg - cur) * min(1f, f * strength * 1.2f)
                }
                else -> cur + (target - cur) * min(1f, f * strength)
            }
            setV(i, j, nv2)
        }
    }

    fun hill(cx: Float, cz: Float, radius: Float, height: Float) {
        val r2 = radius * 2f
        val i0 = floor((cx - r2) / C).toInt()
        val i1 = ceil((cx + r2) / C).toInt()
        val j0 = floor((cz - r2) / C).toInt()
        val j1 = ceil((cz + r2) / C).toInt()
        for (j in j0..j1) for (i in i0..i1) {
            if (!inRange(i, j)) continue
            val dx = i * C - cx; val dz = j * C - cz
            val d2 = (dx * dx + dz * dz) / (radius * radius)
            if (d2 > 4f) continue
            setV(i, j, hv(i, j) + height * exp(-d2 * 2.5f))
        }
    }

    fun randomHill(cx: Float, cz: Float, radius: Float, strength: Float) {
        hill(cx, cz, radius, (0.5f + Random.nextFloat() * 1.5f) * strength * 2f)
    }

    // ------------------------------------------------------------ windowed mesh building
    private inline fun forChunks(cx: Float, cz: Float, radius: Float, body: (a: Int, b: Int, step: Int) -> Unit) {
        val a0 = floor((cx - radius) / CHM).toInt()
        val a1 = floor((cx + radius) / CHM).toInt()
        val b0 = floor((cz - radius) / CHM).toInt()
        val b1 = floor((cz + radius) / CHM).toInt()
        for (b in b0..b1) for (a in a0..a1) {
            val mx = (a + 0.5f) * CHM
            val mz = (b + 0.5f) * CHM
            val dx = mx - cx; val dz = mz - cz
            val d = sqrt(dx * dx + dz * dz)
            if (d - 46f > radius) continue
            val gi0 = a * CH; val gj0 = b * CH
            if (!infinite) {
                if (gi0 > nv || gi0 + CH < -nv || gj0 > nv || gj0 + CH < -nv) continue
            }
            var s = if (d < 110f) 1 else if (d < 230f) 2 else 4
            if (!infinite) {
                val inside = gi0 >= -nv && gi0 + CH <= nv && gj0 >= -nv && gj0 + CH <= nv
                if (!inside) s = 1
            }
            body(a, b, s)
        }
    }

    fun buildLines(f: FBuf, th: Theme, cx: Float, cz: Float, radius: Float) {
        f.clear()
        val gr = cr(th.grid); val gg = cg(th.grid); val gb = cb(th.grid)
        val cr2 = cr(th.contour); val cg2 = cg(th.contour); val cb2 = cb(th.contour)
        val px = FloatArray(8)
        forChunks(cx, cz, radius) { a, b, s ->
            val gi0 = a * CH; val gj0 = b * CH
            var j = gj0
            while (j < gj0 + CH) {
                var i = gi0
                while (i < gi0 + CH) {
                    val h = hv(i, j)
                    if (inRange(i + s, j) && inRange(i, j) && (infinite || (i >= -nv && i + s <= nv && j >= -nv && j <= nv))) {
                        f.seg(i * C, h, j * C, (i + s) * C, hv(i + s, j), j * C, gr, gg, gb, 0.5f, 1.2f)
                    }
                    if (infinite || (i >= -nv && i <= nv && j >= -nv && j + s <= nv)) {
                        f.seg(i * C, h, j * C, i * C, hv(i, j + s), (j + s) * C, gr, gg, gb, 0.5f, 1.2f)
                    }
                    i += s
                }
                j += s
            }
            if (s != 1) return@forChunks
            var mn = Float.MAX_VALUE
            var mx = -Float.MAX_VALUE
            for (jj in gj0..gj0 + CH) for (ii in gi0..gi0 + CH) {
                val h = hv(ii, jj)
                if (h < mn) mn = h
                if (h > mx) mx = h
            }
            if (mx - mn < 0.2f) return@forChunks
            val step = if (mx - mn > 30f) 2f else 1f
            var lvl = ceil(mn / step) * step
            while (lvl <= mx) {
                for (j2 in gj0 until gj0 + CH) for (i2 in gi0 until gi0 + CH) {
                    if (!infinite && (i2 < -nv || i2 + 1 > nv || j2 < -nv || j2 + 1 > nv)) continue
                    val h00 = hv(i2, j2); val h10 = hv(i2 + 1, j2); val h01 = hv(i2, j2 + 1); val h11 = hv(i2 + 1, j2 + 1)
                    if (min(min(h00, h10), min(h01, h11)) > lvl || max(max(h00, h10), max(h01, h11)) < lvl) continue
                    val x0 = i2 * C
                    val z0 = j2 * C
                    var k = 0
                    if ((h00 - lvl) * (h10 - lvl) < 0f) { val t = (lvl - h00) / (h10 - h00); px[k++] = x0 + t * C; px[k++] = z0 }
                    if ((h10 - lvl) * (h11 - lvl) < 0f) { val t = (lvl - h10) / (h11 - h10); px[k++] = x0 + C; px[k++] = z0 + t * C }
                    if ((h01 - lvl) * (h11 - lvl) < 0f) { val t = (lvl - h01) / (h11 - h01); px[k++] = x0 + t * C; px[k++] = z0 + C }
                    if ((h00 - lvl) * (h01 - lvl) < 0f) { val t = (lvl - h00) / (h01 - h00); px[k++] = x0; px[k++] = z0 + t * C }
                    if (k >= 4) f.seg(px[0], lvl + 0.03f, px[1], px[2], lvl + 0.03f, px[3], cr2, cg2, cb2, 0.95f, 1.8f)
                    if (k >= 8) f.seg(px[4], lvl + 0.03f, px[5], px[6], lvl + 0.03f, px[7], cr2, cg2, cb2, 0.95f, 1.8f)
                }
                lvl += step
            }
        }
    }

    fun buildTris(f: FBuf, cx: Float, cz: Float, radius: Float) {
        f.clear()
        forChunks(cx, cz, radius) { a, b, s ->
            val gi0 = a * CH; val gj0 = b * CH
            var j = gj0
            while (j < gj0 + CH) {
                var i = gi0
                while (i < gi0 + CH) {
                    if (infinite || (i >= -nv && i + s <= nv && j >= -nv && j + s <= nv)) {
                        val x0 = i * C; val x1 = (i + s) * C
                        val z0 = j * C; val z1 = (j + s) * C
                        val h00 = hv(i, j); val h10 = hv(i + s, j); val h01 = hv(i, j + s); val h11 = hv(i + s, j + s)
                        f.tri(x0, h00, z0, x1, h10, z0, x0, h01, z1)
                        f.tri(x1, h10, z0, x1, h11, z1, x0, h01, z1)
                    }
                    i += s
                }
                j += s
            }
        }
    }
}

/** Distance culling helpers for the render-distance window. */
object Cull {
    /** world-space bounding sphere of local bounds (lo, hi) under matrix m, tested against a circle on the XZ plane */
    fun inWindow(m: FloatArray, lo: V3, hi: V3, cx: Float, cz: Float, r: Float): Boolean {
        val c = M4.pt(m, (lo + hi) * 0.5f)
        val ext = (hi - lo) * 0.5f
        val sx = sqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2])
        val sy = sqrt(m[4] * m[4] + m[5] * m[5] + m[6] * m[6])
        val sz = sqrt(m[8] * m[8] + m[9] * m[9] + m[10] * m[10])
        val rad = sqrt(ext.x * ext.x * sx * sx + ext.y * ext.y * sy * sy + ext.z * ext.z * sz * sz)
        val dx = c.x - cx; val dz = c.z - cz
        val lim = r + rad
        return dx * dx + dz * dz <= lim * lim
    }

    fun chunkOf(v: Float): Int = floor(v / TerrainData.CHM).toInt()
    fun centerOf(chunk: Int): Float = (chunk + 0.5f) * TerrainData.CHM
}
